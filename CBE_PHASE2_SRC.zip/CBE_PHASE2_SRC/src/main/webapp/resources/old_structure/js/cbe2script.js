$(function()
{
	$('nav #cbe-navbar ul li > a').on('click',function()
	{
		var tab_id = $(this).attr('id');
		//alert(tab_id);
		$('nav #cbe-navbar ul li > a').removeClass('active');
		//$('div#nav-tab > div.dropdown > a.nav-link').removeAttr('style');
		$(this).addClass('active');
		
	});
	
	/* Event and Critical Path Tab Start */
	$('div#inner-nav-tab > a').click(function()
	{
		var inner_tab_id = $(this).attr('id');
		console.log(inner_tab_id);
		$('div#inner-nav-tab > a').removeClass('active');
		$(this).addClass('active');
		
		switch (inner_tab_id)
		{
			case'eventdetail-tab':
			{
				$('div#eventdetail-content').removeClass('hide');
				$('div#criticalpath-content').addClass('hide');
				break;
			}
			case'criticalpath-tab':
			{
				$('div#eventdetail-content').addClass('hide');
				$('div#criticalpath-content').removeClass('hide');
				break;
			}
		}
	});
	/* Event and Critical Path Tab END */
	
	
	
	/* Accordion START */
	
	 // Add down arrow icon for collapse element which is open by default
        $(".collapse.show").each(function(){
        	$(this).prev(".card-header").find(".fa").addClass("fa-angle-down").removeClass("fa-angle-right");
        });
        
        // Toggle right and down arrow icon on show hide of collapse element
        $(".collapse").on('show.bs.collapse', function(){
        	$(this).prev(".card-header").find(".fa").removeClass("fa-angle-right").addClass("fa-angle-down");
        }).on('hide.bs.collapse', function(){
        	$(this).prev(".card-header").find(".fa").removeClass("fa-angle-down").addClass("fa-angle-right");
        });
		
	/* Accordion END*/
	
	
	/*Calendar control to fit window size without scrollbar START */
	
		$("#calendar .fc-content .fc-border-separate tbody tr td.fc-day > div").css('min-height','74px');
			
		$('span.fc-button-month, span.fc-button-prev, span.fc-button-next').on('click',function()
		{
			$("#calendar .fc-content .fc-border-separate tbody tr td.fc-day > div").css('min-height','74px');
		});
		
	/*Calendar control to fit window size without scrollbar END */
	
	
	/* $('#view-event-entry-table').DataTable({
		"lengthMenu": [[05,10,-1],[05,10,"ALL"]],
		"searching":true
	});
	
	
		$('#criticalpath-table_1, #criticalpath-table_2, #criticalpath-table_3').DataTable({
		"lengthMenu": [[05,10,-1],[05,10,"ALL"]],
		"searching":false
	});  */
	
	
	
	
	// *** ADD EVENT START *** //
	
	$('#daily').click(function()
			{
				$("#daily-option-section").removeClass('hide');
				$('#weekly-option-section,#monthly-option-section').addClass('hide');
				$('#weekly-option-section > div input[type="radio"], input[type="checkbox"], #monthly-option-section > div input[type="radio"]').prop('checked',false);
				$("input.everydays-monthly-option1, input.everydays-monthly-option2, select.everydays-monthly-option2").prop('disabled',true);
			});
			$('#weekly').click(function()
			{
				$("#weekly-option-section").removeClass('hide');
				$('#daily-option-section,#monthly-option-section').addClass('hide');
				$('#daily-option-section > div input[type="radio"], #monthly-option-section > div input[type="radio"]').prop('checked',false);
				$('input#everydays-input').prop('disabled',true);
				$("input.everydays-monthly-option1, input.everydays-monthly-option2, select.everydays-monthly-option2").prop('disabled',true);
			});
			$('#monthly').click(function()
			{
				$("#monthly-option-section").removeClass('hide');
				$('#daily-option-section,#weekly-option-section').addClass('hide');
				$('#daily-option-section > div input[type="radio"],	#weekly-option-section > div input[type="radio"], input[type="checkbox"]').prop('checked',false);
				$('input#everydays-input').prop('disabled',true);
				$("input.everydays-monthly-option1, input.everydays-monthly-option2, select.everydays-monthly-option2").prop('disabled',true);
			});
				
			$("input[name='daily-options']").click(function()
			{
				if($('input#everydays').is(":checked"))
				{
					$('input#everydays-input').prop('disabled',false);
				}
				else
				{
					$('input#everydays-input').prop('disabled',true);
				}
			});
			
			$("input[name='monthly-options']").click(function()
			{
				if($('input#everydays-monthly').is(":checked"))
				{
					$("input.everydays-monthly-option1").prop('disabled',false);
					$("input.everydays-monthly-option2,select.everydays-monthly-option2").prop('disabled',true);
					
				}
				else
				{
					$("input.everydays-monthly-option2,select.everydays-monthly-option2").prop('disabled',false);
					$("input.everydays-monthly-option1").prop('disabled',true);
				}
			
			});
				
			$('select#eventName').change(function()
			{
				var eventName_selectedVal = $(this).children("option:selected").val()
				//alert(eventName_selectedVal);
				
				if(eventName_selectedVal == 'Others')
				{
					$('div.eventNameOther').removeClass('hide');
				}
				else{
					$('div.eventNameOther').addClass('hide');
				}
			});
			
			$('.multiselect-selected-text').text('Select A Resource');
			$('#eventName, #category, #application, #regionTerritory, #calendarType').select2();
			
			
			$("#addEventFileUpload").on("change", function () {
				var selectedFileName = $(this).val().split("\\").pop();
				$('#addEventFileName').text('File Name : '+selectedFileName);
			});
			
			$("#fileUpload-uploadScreen").on("change", function () {
				var uploadScreenSelectedFN = $(this).val().split("\\").pop();
				$('#uploadScreenFN-Detail').text('File Name : '+uploadScreenSelectedFN);
			});
			
	// *** ADD EVENT END *** //
	
	//multiselect dropdown  code start
	$('#resource').multiselect(
	{
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		numberDisplayed: 1,
		buttonWidth: '100%',
		inheritClass: true
	});

	$('#btnSubmit').click(function () {

		// get selected values of multiselect dropdown.
		var selectedResourceVal = $('#resource').val();

		// get selected text of multiselect dropdown.
		var selectedText = [];
		$('#resource option:selected').each(function () {
			var $this = $(this);
			if ($this.length) {
				var selText = $this.text();
				selectedText.push(selText);
			}
		});

		console.log("Selected Text: "+ selectedText);
		//console.log(selectedText);
		console.log("Selected Values: " + selectedResourceVal);
		//console.log(selectedResourceVal);

	});
	

});