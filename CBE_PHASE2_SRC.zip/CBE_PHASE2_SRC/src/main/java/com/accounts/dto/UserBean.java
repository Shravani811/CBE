package com.accounts.dto;

import java.util.List;

public class UserBean implements Comparable<UserBean>{
	
    private Long userID;	   
    private String Username;	    
    private String password;    
    private String emailID;    
    private String resourceName;    
    private boolean status;
    private String status1;    
    private String roleName;
    private String user_upload;
    private String user_account;
    private List<String> user_account_list;
    private  String[] userAccSet;
    private String userAccontName;
    private String Account_Name;
    
	public String getUserAccontName() {
		return userAccontName;
	}


	public void setUserAccontName(String userAccontName) {
		this.userAccontName = userAccontName;
	}


	public String[] getUserAccSet() {
		return userAccSet;
	}


	public void setUserAccSet(String[] userAccSet) {
		this.userAccSet = userAccSet;
	}


	public List<String> getUser_account_list() {
		return user_account_list;
	}


	public void setUser_account_list(List<String> user_account_list) {
		this.user_account_list = user_account_list;
	}


	public String getUser_account() {
		return user_account;
	}


	public void setUser_account(String user_account) {
		this.user_account = user_account;
	}
	
	public String getUser_upload() {
		return user_upload;
	}


	public void setUser_upload(String user_upload) {
		this.user_upload = user_upload;
	}


	public String getRoleName() {
		return roleName;
	}


	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}


	public Long getUserID() {
		return userID;
	}


	public void setUserID(Long userID) {
		this.userID = userID;
	}


	public String getUsername() {
		return Username;
	}


	public void setUsername(String Username) {
		this.Username = Username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getEmailID() {
		return emailID;
	}


	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}


	public String getResourceName() {
		return resourceName;
	}


	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}


	public boolean isStatus() {
		return status;
	}


	public void setStatus(boolean status) {
		this.status = status;
	}


	public String getStatus1() {
		return status1;
	}


	public void setStatus1(String status1) {
		this.status1 = status1;
	}


	

	@Override
	public int compareTo(UserBean o) {
		
		
		return this.getStatus1().compareTo(o.getStatus1());
		
	}


	public String getAccount_Name() {
		return Account_Name;
	}


	public void setAccount_Name(String account_Name) {
		Account_Name = account_Name;
	}    
}
