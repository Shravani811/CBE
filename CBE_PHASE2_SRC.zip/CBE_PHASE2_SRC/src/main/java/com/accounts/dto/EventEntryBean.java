package com.accounts.dto;

import java.util.List;
import java.util.Set;

import org.springframework.web.multipart.MultipartFile;

public class EventEntryBean {

	private Long Event_ID;
	private String EventName;
	private String EventNameOthers;
	private String Description_details;
	private String Start_date;
	private String Start_time;
	private String End_date;
	private String End_time;
    private String Email_receipients;
    private String Email_receipients1;
	private String Engagement_Name;

	private String Risk_summary;
	private String Region_territory;
	private String region_id;
	private Long Event_category_id;
	
	private String Event_category_Name;
	
	private  String[] eventAppSet;

	private String[] eventUserSet;

	private String Last_Modified_Date;
	private String Last_Modified_by;
	
	private String Created_Date;
	private String Created_By;
	private String Remarks;
	private List<MultipartFile> file_upload;
	private Long calendar_type_id;
    private String calendar_type_name;
    private Long account_id;
    private String account_name;
    private String[] hiddenuser;
    
    private String hiddenIncidentValue;
    
    private String event_upld_fix;
    private String event_file_name;
    
    private List<String> event_list;
	
    private String eventUsers;

    //Satya Code starts here
    private String recurrence_type;
	
	//added for Daily Recurrence
	private String recu_every_weekday;
	private String recu_every_day;
	private String recu_every_weekday_radio;
	
	//added for Weekly Recurrence
    private String recurrence_dayName;
	private String recu_every_week;
	
	//added for Monthly Recurrence
	private String recu_month_day;
	private String recu_every_month;
	private String recu_month_day_radio;
	
	private String applicationName;
	
	private Set<String> applicationNameSet;
	
	private String monthdd1;
	private String monthdd2;
	private String monthtext1;
	private String url;

	public String getMonthdd1() {
		return monthdd1;
	}

	public void setMonthdd1(String monthdd1) {
		this.monthdd1 = monthdd1;
	}

	public String getMonthdd2() {
		return monthdd2;
	}

	public void setMonthdd2(String monthdd2) {
		this.monthdd2 = monthdd2;
	}

	public String getMonthtext1() {
		return monthtext1;
	}

	public void setMonthtext1(String monthtext1) {
		this.monthtext1 = monthtext1;
	}

	public Long getAccount_id() {
		return account_id;
	}

	public void setAccount_id(Long account_id) {
		this.account_id = account_id;
	}

	public String getAccount_name() {
		return account_name;
	}

	public void setAccount_name(String account_name) {
		this.account_name = account_name;
	}

	public List<String> getEvent_list() {
		return event_list;
	}

	public void setEvent_list(List<String> event_list) {
		this.event_list = event_list;
	}

	public String getEvent_upld_fix() {
		return event_upld_fix;
	}

	public void setEvent_upld_fix(String event_upld_fix) {
		this.event_upld_fix = event_upld_fix;
	}

	public String getEvent_file_name() {
		return event_file_name;
	}

	public void setEvent_file_name(String event_file_name) {
		this.event_file_name = event_file_name;
	}
	
	public String[] getHiddenuser() {
		return hiddenuser;
	}

	public void setHiddenuser(String[] hiddenuser) {
		this.hiddenuser = hiddenuser;
	}

	public String getEmail_receipients1() {
		return Email_receipients1;
	}

	public void setEmail_receipients1(String email_receipients1) {
		Email_receipients1 = email_receipients1;
	}

	public String getCalendar_type_name() {
		return calendar_type_name;
	}

	public void setCalendar_type_name(String calendar_type_name) {
		this.calendar_type_name = calendar_type_name;
	}


	public Long getCalendar_type_id() {
		return calendar_type_id;
	}

	public void setCalendar_type_id(Long calendar_type_id) {
		this.calendar_type_id = calendar_type_id;
	}

	public List<MultipartFile> getFile_upload() {
		return file_upload;
	}

	public void setFile_upload(List<MultipartFile> file_upload) {
		this.file_upload = file_upload;
	}

	public Long getEvent_ID() {
		return Event_ID;
	}

	public String getEventName() {
		return EventName;
	}

	public void setEventName(String eventName) {
		EventName = eventName;
	}

	public String getDescription_details() {
		return Description_details;
	}

	public void setDescription_details(String description_details) {
		Description_details = description_details;
	}

	public String getStart_date() {
		return Start_date;
	}

	public void setStart_date(String start_date) {
		Start_date = start_date;
	}

	public String getEnd_date() {
		return End_date;
	}

	public void setEnd_date(String end_date) {
		End_date = end_date;
	}

	public String getEngagement_Name() {
		return Engagement_Name;
	}

	public void setEngagement_Name(String engagement_Name) {
		Engagement_Name = engagement_Name;
	}              

	public String[] getEventAppSet() {
		return eventAppSet;
	}

	public void setEventAppSet(String[] eventAppSet) {
		this.eventAppSet = eventAppSet;
	}

	public String[] getEventUserSet() {
		return eventUserSet;
	}

	public void setEventUserSet(String[] eventUserSet) {
		this.eventUserSet = eventUserSet;
	}

	public String getLast_Modified_Date() {
		return Last_Modified_Date;
	}

	public void setLast_Modified_Date(String last_Modified_Date) {
		Last_Modified_Date = last_Modified_Date;
	}

	public String getLast_Modified_by() {
		return Last_Modified_by;
	}

	public void setLast_Modified_by(String last_Modified_by) {
		Last_Modified_by = last_Modified_by;
	}

	public String getCreated_Date() {
		return Created_Date;
	}

	public void setCreated_Date(String created_Date) {
		Created_Date = created_Date;
	}

	public String getCreated_By() {
		return Created_By;
	}

	public void setCreated_By(String created_By) {
		Created_By = created_By;
	}

	public void setEvent_ID(Long event_ID) {
		Event_ID = event_ID;
	}

	public String getEmail_receipients() {
		return Email_receipients;
	}

	public void setEmail_receipients(String email_receipients) {
		Email_receipients = email_receipients;
	}
	
	

	public Long getEvent_category_id() {
		return Event_category_id;
	}

	public void setEvent_category_id(Long event_category_id) {
		Event_category_id = event_category_id;
	}

	public String getEvent_category_Name() {
		return Event_category_Name;
	}

	public void setEvent_category_Name(String event_category_Name) {
		Event_category_Name = event_category_Name;
	}


	public String getRisk_summary() {
		return Risk_summary;
	}

	public void setRisk_summary(String risk_summary) {
		Risk_summary = risk_summary;
	}

	public String getRegion_territory() {
		return Region_territory;
	}

	public void setRegion_territory(String region_territory) {
		Region_territory = region_territory;
	}
	
	

	public String getEventNameOthers() {
		return EventNameOthers;
	}

	public String getRegion_id() {
		return region_id;
	}

	public void setRegion_id(String region_id) {
		this.region_id = region_id;
	}

	public void setEventNameOthers(String eventNameOthers) {
		EventNameOthers = eventNameOthers;
	}
	
	
	public String getRemarks() {
		return Remarks;
	}

	public void setRemarks(String remarks) {
		Remarks = remarks;
	}

	public String getEventUsers() {
		return eventUsers;
	}

	public void setEventUsers(String eventUsers) {
		this.eventUsers = eventUsers;
	}

	public String getRecurrence_type() {
		return recurrence_type;
	}

	public void setRecurrence_type(String recurrence_type) {
		this.recurrence_type = recurrence_type;
	}

	public String getRecurrence_dayName() {
		return recurrence_dayName;
	}

	public void setRecurrence_dayName(String recurrence_dayName) {
		this.recurrence_dayName = recurrence_dayName;
	}


	public String getRecu_every_weekday() {
		return recu_every_weekday;
	}

	public void setRecu_every_weekday(String recu_every_weekday) {
		this.recu_every_weekday = recu_every_weekday;
	}

	public String getRecu_every_day() {
		return recu_every_day;
	}

	public void setRecu_every_day(String recu_every_day) {
		this.recu_every_day = recu_every_day;
	}

	public String getRecu_month_day() {
		return recu_month_day;
	}

	public void setRecu_month_day(String recu_month_day) {
		this.recu_month_day = recu_month_day;
	}

	public String getRecu_every_month() {
		return recu_every_month;
	}

	public void setRecu_every_month(String recu_every_month) {
		this.recu_every_month = recu_every_month;
	}

	public String getRecu_every_week() {
		return recu_every_week;
	}

	public void setRecu_every_week(String recu_every_week) {
		this.recu_every_week = recu_every_week;
	}

	public String getRecu_every_weekday_radio() {
		return recu_every_weekday_radio;
	}

	public void setRecu_every_weekday_radio(String recu_every_weekday_radio) {
		this.recu_every_weekday_radio = recu_every_weekday_radio;
	}

	public String getRecu_month_day_radio() {
		return recu_month_day_radio;
	}

	public void setRecu_month_day_radio(String recu_month_day_radio) {
		this.recu_month_day_radio = recu_month_day_radio;
	}

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	public String getStart_time() {
		return Start_time;
	}

	public void setStart_time(String start_time) {
		Start_time = start_time;
	}

	public String getEnd_time() {
		return End_time;
	}

	public void setEnd_time(String end_time) {
		End_time = end_time;
	}

	public Set<String> getApplicationNameSet() {
		return applicationNameSet;
	}

	public void setApplicationNameSet(Set<String> applicationNameSet) {
		this.applicationNameSet = applicationNameSet;
	}

	public String getHiddenIncidentValue() {
		return hiddenIncidentValue;
	}

	public void setHiddenIncidentValue(String hiddenIncidentValue) {
		this.hiddenIncidentValue = hiddenIncidentValue;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	
	/*public String getRecurrence() {
		return recurrence;
	}

	public void setRecurrence(String recurrence) {
		this.recurrence = recurrence;
	}

	public String getUntil_date() {
		return until_date;
	}

	public void setUntil_date(String until_date) {
		this.until_date = until_date;
	}

	public String[] getWeekDays() {
		return weekDays;
	}

	public void setWeekDays(String[] weekDays) {
		this.weekDays = weekDays;
	}*/




	/*@Override
	public String toString() {
		return "EventEntryBean [eventAppSet=" + Arrays.toString(eventAppSet) + ", eventUserSet="
				+ Arrays.toString(eventUserSet) + "]";
	}*/

}
