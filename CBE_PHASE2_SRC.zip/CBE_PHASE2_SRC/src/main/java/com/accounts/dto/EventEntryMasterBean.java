package com.accounts.dto;

import java.util.Arrays;
import java.util.Set;

/**
 * 
 * @author jaimishr
 *
 */

public class EventEntryMasterBean {

	private Long Event_ID;
	private String EventName;
	private String EventNameOthers;
	private String Description_details;
   private String Email_receipients;
	private String Engagement_Name;
	private String Email_receipients1;
	private String tower;
	private String cc_name;
	private String cluster;
	private String Risk_summary;
	private String region_id;
	private String Region_territory;
	private Long Event_category_id;
	private String Event_category_Name;
	/*private Long calendar_type_id;
    private String calendar_type_name;*/
	
	private  String[] eventAppSet;

	private   String[] eventUserSet;

	private String Last_Modified_Date;
	private String Last_Modified_by;
	private String Created_Date;
	private String Created_By;
	private String Remarks;
	private String[] hiddenuser;
	
	//newly added for evenUserSet,eventAppSet in String format
	private String eventUsers;
	private String eventApps;
	
	
	
	

	/*public String getCalendar_type_name() {
		return calendar_type_name;
	}

	public void setCalendar_type_name(String calendar_type_name) {
		this.calendar_type_name = calendar_type_name;
	}


	public Long getCalendar_type_id() {
		return calendar_type_id;
	}

	public void setCalendar_type_id(Long calendar_type_id) {
		this.calendar_type_id = calendar_type_id;
	}*/

	public String[] getHiddenuser() {
		return hiddenuser;
	}

	public String getEmail_receipients1() {
		return Email_receipients1;
	}

	public void setEmail_receipients1(String email_receipients1) {
		Email_receipients1 = email_receipients1;
	}

	public void setHiddenuser(String[] hiddenuser) {
		this.hiddenuser = hiddenuser;
	}

	public Long getEvent_ID() {
		return Event_ID;
	}

	public String getEventName() {
		return EventName;
	}

	public void setEventName(String eventName) {
		EventName = eventName;
	}

	public String getDescription_details() {
		return Description_details;
	}

	public void setDescription_details(String description_details) {
		Description_details = description_details;
	}


	public String getEngagement_Name() {
		return Engagement_Name;
	}

	public void setEngagement_Name(String engagement_Name) {
		Engagement_Name = engagement_Name;
	}              

	public String[] getEventAppSet() {
		return eventAppSet;
	}

	public void setEventAppSet(String[] eventAppSet) {
		this.eventAppSet = eventAppSet;
	}


	public String[] getEventUserSet() {
		return eventUserSet;
	}

	public void setEventUserSet(String[] eventUserSet) {
		this.eventUserSet = eventUserSet;
	}

	public String getLast_Modified_Date() {
		return Last_Modified_Date;
	}

	public void setLast_Modified_Date(String last_Modified_Date) {
		Last_Modified_Date = last_Modified_Date;
	}

	public String getLast_Modified_by() {
		return Last_Modified_by;
	}

	public void setLast_Modified_by(String last_Modified_by) {
		Last_Modified_by = last_Modified_by;
	}

	public String getCreated_Date() {
		return Created_Date;
	}

	public void setCreated_Date(String created_Date) {
		Created_Date = created_Date;
	}

	public String getCreated_By() {
		return Created_By;
	}

	public void setCreated_By(String created_By) {
		Created_By = created_By;
	}

	public void setEvent_ID(Long event_ID) {
		Event_ID = event_ID;
	}

	public String getEmail_receipients() {
		return Email_receipients;
	}

	public void setEmail_receipients(String email_receipients) {
		Email_receipients = email_receipients;
	}
	
	

	public Long getEvent_category_id() {
		return Event_category_id;
	}

	public void setEvent_category_id(Long event_category_id) {
		Event_category_id = event_category_id;
	}

	public String getEvent_category_Name() {
		return Event_category_Name;
	}

	public void setEvent_category_Name(String event_category_Name) {
		Event_category_Name = event_category_Name;
	}


	public String getRisk_summary() {
		return Risk_summary;
	}

	public void setRisk_summary(String risk_summary) {
		Risk_summary = risk_summary;
	}

	public String getRegion_territory() {
		return Region_territory;
	}

	public void setRegion_territory(String region_territory) {
		Region_territory = region_territory;
	}

	
	
	public String getTower() {
		return tower;
	}

	public String getRegion_id() {
		return region_id;
	}

	public void setRegion_id(String region_id) {
		this.region_id = region_id;
	}

	public void setTower(String tower) {
		this.tower = tower;
	}

	public String getCc_name() {
		return cc_name;
	}

	public void setCc_name(String cc_name) {
		this.cc_name = cc_name;
	}

	public String getCluster() {
		return cluster;
	}

	public void setCluster(String cluster) {
		this.cluster = cluster;
	}

	public String getEventNameOthers() {
		return EventNameOthers;
	}

	public void setEventNameOthers(String eventNameOthers) {
		EventNameOthers = eventNameOthers;
	}

	public String getRemarks() {
		return Remarks;
	}

	public void setRemarks(String remarks) {
		Remarks = remarks;
	}

	public String getEventUsers() {
		return eventUsers;
	}

	public void setEventUsers(String eventUsers) {
		this.eventUsers = eventUsers;
	}

	public String getEventApps() {
		return eventApps;
	}

	public void setEventApps(String eventApps) {
		this.eventApps = eventApps;
	}

	

	
	
	/*@Override
	public String toString() {
		return "EventEntryBean [eventAppSet=" + Arrays.toString(eventAppSet) + ", eventUserSet="
				+ Arrays.toString(eventUserSet) + "]";
	}*/



}
