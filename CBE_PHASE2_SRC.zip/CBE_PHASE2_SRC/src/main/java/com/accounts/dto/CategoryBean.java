package com.accounts.dto;

/**
 * 
 * @author jaimishr
 *
 */

public class CategoryBean {

	private Long event_cat_id;
    private String event_category_name;
    private boolean status;
    private String status1;
    
	public Long getEvent_cat_id() {
		return event_cat_id;
	}
	public void setEvent_cat_id(Long event_cat_id) {
		this.event_cat_id = event_cat_id;
	}
	public String getEvent_category_name() {
		return event_category_name;
	}
	public void setEvent_category_name(String event_category_name) {
		this.event_category_name = event_category_name;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getStatus1() {
		return status1;
	}
	public void setStatus1(String status1) {
		this.status1 = status1;
	}
	
    
    
}
