package com.accounts.dto;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.account.model.IncidentBean;

public class CalendarBean {

	private String  title;
	private String start;
	private String end;
	private String url;
	private String dateStart;
	private String dateEnd;
	private String startTime;
	private String endTime;
	private String region;
	private String calendarType;
	private String description;
	private String engagement;
	private String remarks;
	private String additional_recipients;
	private  Set<String> eventAppSet;
	private  Set<String> eventUserSet;
	
	/*private List<IncidentBean> incidents;*/
	
	private List<String> incidents;
	
	
	public String getAdditional_recipients() {
		return additional_recipients;
	}
	public void setAdditional_recipients(String additional_recipients) {
		this.additional_recipients = additional_recipients;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getStart() {
		return start;
	}
	public void setStart(String start) {
		this.start = start;
	}
	public String getEnd() {
		return end;
	}
	public void setEnd(String end) {
		this.end = end;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getEngagement() {
		return engagement;
	}
	public void setEngagement(String engagement) {
		this.engagement = engagement;
	}
	
	public Set<String> getEventAppSet() {
		return eventAppSet;
	}
	public void setEventAppSet(Set<String> eventAppSet) {
		this.eventAppSet = eventAppSet;
	}

	public Set<String> getEventUserSet() {
		return eventUserSet;
	}
	public void setEventUserSet(Set<String> eventUserSet) {
		this.eventUserSet = eventUserSet;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	/*public List<IncidentBean> getIncidents() {
		return incidents;
	}
	public void setIncidents(List<IncidentBean> incidents) {
		this.incidents = incidents;
	}*/
	public List<String> getIncidents() {
		return incidents;
	}
	public void setIncidents(List<String> incidents) {
		this.incidents = incidents;
	}
	public String getDateStart() {
		return dateStart;
	}
	public void setDateStart(String dateStart) {
		this.dateStart = dateStart;
	}
	public String getDateEnd() {
		return dateEnd;
	}
	public void setDateEnd(String dateEnd) {
		this.dateEnd = dateEnd;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getCalendarType() {
		return calendarType;
	}
	public void setCalendarType(String calendarType) {
		this.calendarType = calendarType;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
	
}
