package com.account.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.account.model.Category;
import com.account.model.FileUpload;
import com.account.model.User;
import com.account.service.CalendarTypeService;
import com.account.service.CategoryService;
import com.account.validator.CategoryValidator;
import com.accounts.dto.CategoryBean;
import com.accounts.dto.UserBean;
/**
 * 
 * @author jaimishr
 *
 */
@Controller
public class CategoryContrroller {
	@Autowired
	CategoryService categoryService;
	
	@Autowired
	CategoryValidator categoryValidator;
	
	@Autowired
    private CalendarTypeService calendarTypeService;
		
	@RequestMapping(value = "/categoryUploadscreen", method = RequestMethod.GET)
	public ModelAndView userupload(Model model) {
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("categoryUpload");
	}
	
	@RequestMapping(value = "/categoryUploadscreen", method = RequestMethod.POST)
	public ModelAndView userupload(ModelMap modelMap, @RequestParam("file") MultipartFile file,Model mod) throws SQLException {
        
        ModelAndView model = new ModelAndView();
        FileUpload fileUpload = new FileUpload();
        try {
			model.addObject("message", fileUpload.process(file));
		} catch (FileNotFoundException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
			mod.addAttribute("exception","No File uploaded. Please upload the file.");
			return new ModelAndView("categoryUpload");
		}
        model.setViewName("categoryUpload");
       // modelMap.addAttribute("maxRecDisplay",getMaxRecDisplay());  *
       // modelMap.addAttribute("loggedInUname",SecurityContextHolder.getContext().getAuthentication().getName());   *
        
        /* test xlsx file starts here */
		
        String fileName = file.getOriginalFilename();
        String rootPath = System.getProperty("catalina.home");
        File dir = new File(rootPath + File.separator + "tmpFiles"+File.separator);
		//File myFile = new File("/opt/files/"+fileName);   *
        File myFile = new File(dir+ File.separator +fileName);
        String ext1 = FilenameUtils.getExtension(fileName);
        
		FileInputStream fis = null;
		try {
			
			if (ext1.equalsIgnoreCase("xlsx"))
			fis = new FileInputStream(myFile);
			else
			{
				mod.addAttribute("exception","Please upload the xlsx file only.");
				return new ModelAndView("categoryUpload");
			}
		} 	
		
		catch (FileNotFoundException e1) {
			e1.printStackTrace();
			mod.addAttribute("exception","No File uploaded. Please upload the file.");
			return new ModelAndView("categoryUpload");
		} 	
		
		
		
		// Finds the workbook instance for XLSX file 
		
		XSSFWorkbook myWorkBook = null;
		try {
			myWorkBook = new XSSFWorkbook (fis);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		// Return first sheet from the XLSX workbook 
		XSSFSheet mySheet = myWorkBook.getSheetAt(0); 
		// Get iterator to all the rows in current sheet 
		Iterator<Row> rowIterator = mySheet.iterator(); 
		
		// Traversing over each row of XLSX file 
		while (rowIterator.hasNext()) { Row row = rowIterator.next(); 
		// For each row, iterate through each columns 
		
		
		
		Iterator<Cell> cellIterator = row.cellIterator();
		//AutomationReport automationReport = null;
		Category cat = null;
		boolean ucFlag = false;
		
		
		while (cellIterator.hasNext())
		{ 
			Cell cell = cellIterator.next(); 
		/*switch (cell.getCellType()) { case Cell.CELL_TYPE_STRING: 
			System.out.print(cell.getStringCellValue() + "\t"); 
			break; 
			case Cell.CELL_TYPE_NUMERIC: 
				System.out.print(cell.getNumericCellValue() + "\t"); 
			break; 
			case Cell.CELL_TYPE_BOOLEAN: 
				System.out.print(cell.getBooleanCellValue() + "\t"); 
				break; 
			default : 
				
		}*/
		
		long maxuser_Id = 0;
		
		if (null != cat) {
			maxuser_Id = cat.getEvent_cat_id(); 
		} else {
			maxuser_Id = 1;
		}
		if(cell.getRowIndex() > 0 && row != null &&  row.getCell(0) != null ){			
			
			cat = new Category();
			cat.setEvent_cat_id(maxuser_Id);
			cat.setEvent_category_name(row.getCell(0).toString());
			cat.setStatus(true);
		
			ucFlag = true;
		} 
		
		}
		if(ucFlag)
		{
			
			try{		
				categoryService.save(cat);
				//rowIterator =null;
			//return new ModelAndView("viewUser");
			}
			catch(Exception hex){
				mod.addAttribute("exception","There is an issue in uploading. Please contact technical support.");
				return new ModelAndView("userUpload");
			}
			/*catch (SQLException e3) {
		        e3.printStackTrace();
		        mod.addAttribute("exception","Duplicate entry in excel");
				return new ModelAndView("userUpload");
		    }*/
			
		}
	
		}
		List<CategoryBean> categoryBeanList=new ArrayList<>();
		List<Category> categoryList=categoryService.findAll();
		
		for(Category cate:categoryList){
			CategoryBean categoryBean=new CategoryBean();
			categoryBean.setEvent_cat_id(cate.getEvent_cat_id());
			categoryBean.setEvent_category_name(cate.getEvent_category_name());
			
			if(cate.isStatus()==true){
				categoryBean.setStatus1("Active");
			}else{
				categoryBean.setStatus1("InActive");
			}
			
			categoryBeanList.add(categoryBean);
		}
		
	     mod.addAttribute("categoryBeanList", categoryBeanList);
	     mod.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
	     return new ModelAndView("viewCategory");
	     //return "viewCategory";
		
		
	}
	
	@RequestMapping(value = "/addCategory", method = RequestMethod.GET)
    public String addCategory(Model model) {
		
		CategoryBean categoryBean=new CategoryBean();
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		model.addAttribute("categoryBean", categoryBean);
		
		return "addCategory";
    }

	@RequestMapping(value = "/addCategory", method = RequestMethod.POST)
    public ModelAndView addCategory(@ModelAttribute("categoryBean") CategoryBean categoryBean, BindingResult bindingResult, Model model) {
		categoryValidator.validate(categoryBean, bindingResult);

		if (bindingResult.hasErrors()) {
			System.out.println("errror addCategory");
			return new ModelAndView("addCategory");
		}
		Category category=new Category();
		category.setEvent_category_name(categoryBean.getEvent_category_name());
		category.setStatus(categoryBean.isStatus());
		
		categoryService.save(category);
		
	List<CategoryBean> categoryBeanList=new ArrayList<>();
	List<Category> categoryList=categoryService.findAll();
	
	for(Category cate:categoryList){
		CategoryBean categoryBeans = new CategoryBean();
		categoryBeans.setEvent_cat_id(cate.getEvent_cat_id());
		categoryBeans.setEvent_category_name(cate.getEvent_category_name());
		if(cate.isStatus()==true){
			categoryBeans.setStatus1("Active");
		}else{
			categoryBeans.setStatus1("InActive");
		}
		//categoryBeans.setStatus(cate.isStatus());
		categoryBeanList.add(categoryBeans);
	}
		model.addAttribute("categoryBeanList", categoryBeanList);
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("viewCategory");
		
	}
	
	@RequestMapping(value = "/viewCategory", method = RequestMethod.GET)
    public String viewCategory(Model model) {
		
		
		List<CategoryBean> categoryBeanList=new ArrayList<>();
		List<Category> categoryList=categoryService.findAll();
		
		for(Category cate:categoryList){
			CategoryBean categoryBean=new CategoryBean();
			categoryBean.setEvent_cat_id(cate.getEvent_cat_id());
			categoryBean.setEvent_category_name(cate.getEvent_category_name());
			
			if(cate.isStatus()==true){
				categoryBean.setStatus1("Active");
			}else{
				categoryBean.setStatus1("InActive");
			}
			
			categoryBeanList.add(categoryBean);
		}
		
	     model.addAttribute("categoryBeanList", categoryBeanList);
	     model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return "viewCategory";
    }
	
	@RequestMapping(value = "/editCategory/{id}", method = RequestMethod.GET)
	public ModelAndView edit(@PathVariable Long id, @ModelAttribute("categoryBean") CategoryBean categoryBean, Model model) {
		
		Category category=categoryService.findById(id);
		categoryBean.setEvent_cat_id(category.getEvent_cat_id());
		categoryBean.setEvent_category_name(category.getEvent_category_name());
		categoryBean.setStatus(category.isStatus());
		model.addAttribute("categoryBean", categoryBean);
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
	  return new ModelAndView("editCategory");
		
	}
	
	@RequestMapping(value = "/editCategory/{id}", method = RequestMethod.POST)
	public ModelAndView editUserDataSave(@PathVariable Long id, @ModelAttribute("categoryBean") CategoryBean categoryBean,
			BindingResult bindingResult, Model model) 
	{
				
		
		categoryValidator.validate(categoryBean, bindingResult);

		if (bindingResult.hasErrors()) {
			return new ModelAndView("editCategory");
		}
		
		Category category=new Category();
		category.setEvent_cat_id(categoryBean.getEvent_cat_id());
		category.setEvent_category_name(categoryBean.getEvent_category_name());
		category.setStatus(categoryBean.isStatus());
		
		categoryService.save(category);
		
		List<CategoryBean> categoryBeanList=new ArrayList<>();
		List<Category> categoryList=categoryService.findAll();
		
		for(Category cate:categoryList){
			CategoryBean categoryBeans=new CategoryBean();
			categoryBeans.setEvent_cat_id(cate.getEvent_cat_id());
			categoryBeans.setEvent_category_name(cate.getEvent_category_name());
			
			if(cate.isStatus()==true){
				categoryBeans.setStatus1("Active");
			}else{
				categoryBeans.setStatus1("InActive");
			}
			
			categoryBeanList.add(categoryBeans);
		}
		
	     model.addAttribute("categoryBeanList", categoryBeanList);
	     model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("viewCategory");
		
		
	}
	
	 
}
