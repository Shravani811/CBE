package com.account.web;

import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.mail.internet.ParseException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.account.model.CalendarType;
import com.account.model.Category;
import com.account.model.EventApplicationMaster;
import com.account.model.EventEntryMaster;
import com.account.model.EventUserMaster;
import com.account.model.FileUpload;
import com.account.model.Region;
import com.account.service.ApplicationService;
import com.account.service.CalendarService;
import com.account.service.CalendarTypeService;
import com.account.service.CategoryService;
import com.account.service.EventEntryMasterService;
import com.account.service.MailService;
import com.account.service.RegionService;
import com.account.service.UserService;
import com.account.validator.EventEntryMasterValidator;
import com.accounts.dto.CalendarBean;
import com.accounts.dto.EventEntryBean;
import com.accounts.dto.EventEntryMasterBean;
import com.google.gson.Gson;



@Controller
public class EventEntryMasterController {
	@Autowired
    private EventEntryMasterService eventEntryMasterService;

    @Autowired
    private ApplicationService applicationService;
    
    @Autowired
    private UserService userService;

    @Autowired
    private EventEntryMasterValidator eventEntryValidator;
  
    @Autowired
    private CategoryService categoryService;
    
    @Autowired
    MailService mailService ;
    
    @Autowired
    private EventEntryMasterService eventEntryServiceMaster;
    
    @Autowired
    private RegionService regionService;
    
    @Autowired
    private CalendarTypeService calendarTypeService;

    @Autowired
    private HttpServletRequest httpServletRequest;
    
   
    @RequestMapping(value = "/addEntryMaster", method = RequestMethod.GET)
    public String addEntry(Model model) {
        List<String> appList = applicationService.getAppNames();
        List<String> rescList = userService.getResourceNames();
        List<String> catList = categoryService.getCategoryName();
        List<String> regList = regionService.getRegionTerritory();
       
        EventEntryMasterBean eventEntry = new EventEntryMasterBean();
        
        /*List<Application> applicationFull=applicationService.findAll();*/
        
        List<HashMap<String, String>> listMastp=  applicationService.getPriAndSecResourceName();
                
       /* List<UserBean> userFull = userService.findAllUserBean();*/
        
      /*  Application application=applicationService.findByApplicationName(eventEntry.getEventAppSet());
        
        if(application!=null){
       	 eventEntry.setTower(application.getTower());
       	 eventEntry.setCc_name(application.getCC_name());
       	 eventEntry.setCluster(application.getCluster());
       	// eventEntry.setEventAppSet(application.getApp_Name()); 
       	 String[] eventAppSet = eventEntry.getEventAppSet();
    		eventEntry.setEventAppSet(eventAppSet);
        }*/
       
        Gson gson = new Gson();            
        String applicationEventJson = gson.toJson(listMastp);        
        HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		model.addAttribute("userAccountName",userAccountName);
        model.addAttribute("eventEntryJsonStr",applicationEventJson);        
        model.addAttribute("eventEntryBean", eventEntry);        
        model.addAttribute("appNameList",appList);
        model.addAttribute("rescNameList",rescList);
        model.addAttribute("catgoryList",catList);
        model.addAttribute("regionList",regList);
        model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
        return "addEntryMaster";    
    }
    
   
 /*   @RequestMapping(value = "/addEntryLoadMaster", method = RequestMethod.GET)
    public ModelAndView addEntryLoadMaster(@ModelAttribute("eventEntryBean") EventEntryMasterBean eventEntryBean, BindingResult bindingResult, Model model) {
    	
    	
    	 List<String> appList = applicationService.getAppNames();
         List<String> rescList = userService.getResourceNames();
         List<String> catList = categoryService.getCategoryName();
        
         EventEntryMasterBean eventEntry = new EventEntryMasterBean();
       
         Application application=applicationService.findByApplicationName(eventEntryBean.getEventAppSet());
         
         List<Application> applicationFull=applicationService.findAll();
         
         if(application!=null){
        	 eventEntry.setTower(application.getTower());
        	 eventEntry.setCc_name(application.getCC_name());
        	 eventEntry.setCluster(application.getCluster());
        	// eventEntry.setEventAppSet(application.getApp_Name());
        	 
        	 
        	 String[] eventAppSet = eventEntry.getEventAppSet();
     		
     		
     		eventEntry.setEventAppSet(eventAppSet);
         }
         
         
         
         
         model.addAttribute("appNameList",appList);
         model.addAttribute("rescNameList",rescList);
         model.addAttribute("catgoryList",catList);
         
         
         
        Gson gson = new Gson();
        String eventEntryJsonStr = gson.toJson(applicationFull);
    	
         model.addAttribute("eventEntryBean", eventEntry);
    	model.addAttribute("eventEntryJsonStr",eventEntryJsonStr);
    	
    	eventEntryValidator.validate(eventEntryBean, bindingResult);
        if (bindingResult.hasErrors()) {
        	
        	 List<String> appList = applicationService.getAppNames();
             List<String> rescList = userService.getResourceNames();
             List<String> catList = categoryService.getCategoryName();
             
             model.addAttribute("eventEntryBean", eventEntryBean);
             model.addAttribute("appNameList",appList);
             model.addAttribute("rescNameList",rescList);
             model.addAttribute("catgoryList",catList);
        	
           return new ModelAndView("addEntryMaster");
        }

        
        
        eventEntryService.save(eventEntryBean);

      
        
        List<EventEntryMasterBean> evnetEntryBeanList=new ArrayList<>();
		List<EventEntryMaster> eventList = eventEntryService.findAll();
    	for(EventEntryMaster event:eventList){
    		EventEntryMasterBean eventEntryBean1=new EventEntryMasterBean();
    		eventEntryBean1.setEvent_ID(event.getEvent_ID());
    		eventEntryBean1.setEventName(event.getEventname());
    		eventEntryBean1.setDescription_details(event.getDescription_details());
    		eventEntryBean1.setEmail_receipients(event.getAdditional_receipients());
    		eventEntryBean1.setRegion_territory(event.getRegion_territory());
    		eventEntryBean1.setRisk_summary(event.getRisk_summary());
    		Category category=categoryService.findByCategoryId(event.getEvent_category_id());
    		
    		if(category!=null){
    			eventEntryBean1.setEvent_category_Name(category.getEvent_category_name());
    		}
    		
    		String[] eventAppSet =new String[event.getEventAppSet().size()];
    		int i=0;
    		
    		for (EventApplicationMaster eventApp : event.getEventAppSet() ) {
    			
    			eventAppSet[i]=eventApp.getApplication();
    			i++;
    			
    			if(i==0){
    				eventAppStr.append(eventAppSet[i]);
    				eventAppStr.append(",");
    			} else {
    				eventAppStr.append(eventAppSet[i]);
    			}
    		}
    		eventEntryBean1.setEventAppSet(eventAppSet);
    		
    		String[] eventUserSet=new String[event.getEventUserSet().size()];
    		int j=0;
    		for(EventUserMaster eventUser:event.getEventUserSet()){
    			//for(String Username: userService.findByUsername(eventUser))
    			eventUserSet[j] = eventUser.getResource();
    			j++;
    		}
    		
    		eventEntryBean1.setEventUserSet(eventUserSet);
    		
    		
    		eventEntryBean1.setEngagement_Name(event.getEngagement_Name());
    		
    		
    		
    		evnetEntryBeanList.add(eventEntryBean1);
    	}
    	 
      	  
          return new ModelAndView("addEntryMaster");
 
    	
    }
    */
       
    
    @RequestMapping(value = "/addEntryMaster", method = RequestMethod.POST)
    public ModelAndView addEntryMaster(@ModelAttribute("eventEntryBean") EventEntryMasterBean eventEntryBean, BindingResult bindingResult, Model model) {
    	eventEntryBean.setEventUserSet(eventEntryBean.getHiddenuser());
    	eventEntryValidator.validate(eventEntryBean, bindingResult);
        if (bindingResult.hasErrors()) {
        	
        	System.out.println("%%%%%%%%%%%%%%%%inside addEntryMaster%%%%%%%%%%%%%%%%%%%%%%%%%%%% ");
        	
        	 List<String> appList = applicationService.getAppNames();
             List<String> rescList = userService.getResourceNames();
             List<String> catList = categoryService.getCategoryName();
             List<String> regList = regionService.getRegionTerritory();
             
             model.addAttribute("eventEntryBean", eventEntryBean);
             model.addAttribute("appNameList",appList);
             model.addAttribute("rescNameList",rescList);
             model.addAttribute("catgoryList",catList);
             model.addAttribute("regionList",regList);
        	
             /*List<Application> applicationFull=applicationService.findAll();             
             Gson gson = new Gson();
             String eventEntryJsonStr = gson.toJson(applicationFull);             
             model.addAttribute("eventEntryJsonStr",eventEntryJsonStr);*/ 
             
             List<HashMap<String, String>> listMastp=  applicationService.getPriAndSecResourceName();
             Gson gson = new Gson();
             String applicationEventJson = gson.toJson(listMastp);        
             HttpSession httpSession = httpServletRequest.getSession();
      		 String userAccountName = (String) httpSession.getAttribute("userAcctName");
      		 model.addAttribute("userAccountName",userAccountName);
             model.addAttribute("eventEntryJsonStr",applicationEventJson);        
              
             
             
           return new ModelAndView("addEntryMaster");
        }
        

        eventEntryMasterService.save(eventEntryBean);

        List<EventEntryMasterBean> evnetEntryBeanList=new ArrayList<>();
        HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		List<EventEntryMaster> eventList = eventEntryMasterService.findAllEventByResource(userAccountName);
        //List<EventEntryMaster> eventList = eventEntryMasterService.findAll();
    	for(EventEntryMaster event:eventList){
    		EventEntryMasterBean eventEntryBean1=new EventEntryMasterBean();
    		eventEntryBean1.setEvent_ID(event.getEvent_ID());
    		eventEntryBean1.setEventName(event.getEventname());
    		eventEntryBean1.setDescription_details(event.getDescription_details());
    		eventEntryBean1.setEmail_receipients(event.getAdditional_receipients());
    		//eventEntryBean1.setRegion_territory(event.getRegion_territory());
    		
    		Region region = regionService.findByRegionId(event.getRegion_id());
    				
            if(region!=null)
            {
            	eventEntryBean1.setRegion_territory(region.getRegion_territory());
            }
    		eventEntryBean1.setRisk_summary(event.getRisk_summary());
    		
    		Category category=categoryService.findByCategoryId(event.getEvent_category_id());
    		
    		if(category!=null){
    			eventEntryBean1.setEvent_category_Name(category.getEvent_category_name());
    		}
    		//System.out.println(category.getEvent_category_name());
    		String[] eventAppSet =new String[event.getEventAppSet().size()];
    		int i=0; 
    		for (EventApplicationMaster eventApp : event.getEventAppSet()) 
    		{
    			eventAppSet[i]=eventApp.getApplication();   
    			i++;
    			/*if(i==0){
    				eventAppStr.append(eventAppSet[i]);
    				eventAppStr.append(",");
    			} else {
    				eventAppStr.append(eventAppSet[i]);
    			}*/
    		}
    	   		
    		Set<String> appSet = new HashSet<String>(Arrays.asList(eventAppSet));
    		
    		eventAppSet= appSet.toArray(new String[appSet.size()]);
    		String eventApps = String.join(",", eventAppSet);
    		eventEntryBean1.setEventApps(eventApps);
    		eventEntryBean1.setEventAppSet(eventAppSet);
    		
    		String[] eventUserSet=new String[event.getEventUserSet().size()];
      		int j=0;
      		for(EventUserMaster eventUser:event.getEventUserSet()){
      			
      			eventUserSet[j] = eventUser.getResource();
      			
      			j++;
      		}  
      		
      		Set<String> userSet = new HashSet<String>(Arrays.asList(eventUserSet));
    		
    		eventUserSet= userSet.toArray(new String[userSet.size()]);
    		String eventUsersString = String.join(",", eventUserSet);
    		eventEntryBean1.setEventUsers(eventUsersString);
      		eventEntryBean1.setEventUserSet(eventUserSet);
    		
    		
    		
    		////////////////////comment after add email added/////////////////////
    	//	eventEntryBean1.setEventUserSet(eventEntryBean.getHiddenuser());
    		////////////////////////////////////
    		
    		
   	/*	String[] eventUserSet=new String[event.getEventUserSet().size()];    		
    		System.out.println("<<<<<<%%%%%%%event.getEventUserSet().size()-->"+event.getEventUserSet().size()+"<-----%%%%%%%%%%%% ");
    		int j=0;
    		for(EventUserMaster eventUser:event.getEventUserSet()){
    			//for(String Username: userService.findByUsername(eventUser))
    			eventUserSet[j] = eventUser.getResource();
    			j++;
    		}*/
    		//eventEntryBean1.setEventUserSet(eventUserSet);
    		
    		
    	
    		
    		/*Set<String> eventUserSet = new HashSet<String>();	
    		//String[] eventUserSet=new String[event.getEventUserSet().size()];
    		int j=0;
    		for(EventUserMaster eventUser:event.getEventUserSet()){
    		//	for(String Username: userService.findByUsername(eventUser))
    			//eventUserSet[j] = eventUser.getResource();    			
    			eventUserSet.add(eventUser.getResource());    			
    			j++;
    		}
    		
    		// create an iterator
    		   Iterator iterator = eventUserSet.iterator(); 
    		      
    		   // check values
    		   while (iterator.hasNext()){
    		   System.out.println("Value----->: "+iterator.next() + " <----------");  
    		   }
    		eventEntryBean1.setEventUserSet(eventUserSet); 
    		*/
    		
    		eventEntryBean1.setEngagement_Name(event.getEngagement_Name());    		
    		evnetEntryBeanList.add(eventEntryBean1);
    	}
    	 
      	   model.addAttribute("evnetEntryBeanList", evnetEntryBeanList);
      	 model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
          return new ModelAndView("viewEntryMaster");
 
    	
    }
    
   
    @RequestMapping(value = "/viewEntryMaster", method = RequestMethod.GET)
    public ModelAndView viewEntry(Model model) {
    	HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		
    	List<EventEntryMasterBean> evnetEntryBeanList=new ArrayList<>();
		List<EventEntryMaster> eventList = eventEntryMasterService.findAllEventByResource(userAccountName);
    	for(EventEntryMaster event:eventList){
    		EventEntryMasterBean eventEntryBean=new EventEntryMasterBean();
    		eventEntryBean.setEvent_ID(event.getEvent_ID());
    		eventEntryBean.setEventName(event.getEventname());
    		eventEntryBean.setDescription_details(event.getDescription_details());
    		
    	/*	eventEntryBean.setStart_date(event.getStart_date());
    		eventEntryBean.setEnd_date(event.getEnd_date());*/
    		//eventEntryBean.setRegion_territory(event.getRegion_territory());
    		eventEntryBean.setRisk_summary(event.getRisk_summary());
    		
            Region region = regionService.findByRegionId(event.getRegion_id());			
            if(region!=null)
            {
            	eventEntryBean.setRegion_territory(region.getRegion_territory());
            }    		
    		
    		Category category=categoryService.findByCategoryId(event.getEvent_category_id());    		
    		if(category!=null){
    			eventEntryBean.setEvent_category_Name(category.getEvent_category_name());
    		}
    		
    		String[] eventAppSet =new String[event.getEventAppSet().size()];
    		int i=0;
    		
    		for (EventApplicationMaster eventApp : event.getEventAppSet() ) {
    			
    			eventAppSet[i]=eventApp.getApplication();
    			i++;
    			
    			/*if(i==0){
    				eventAppStr.append(eventAppSet[i]);
    				eventAppStr.append(",");
    			} else {
    				eventAppStr.append(eventAppSet[i]);
    			}*/
    		}
    		
    		
    		Set<String> appSet = new HashSet<String>(Arrays.asList(eventAppSet));
    		
    		eventAppSet= appSet.toArray(new String[appSet.size()]);
    		String eventApps = String.join(",", eventAppSet);
    		eventEntryBean.setEventApps(eventApps);
    		eventEntryBean.setEventAppSet(eventAppSet);
    		
    		String[] eventUserSet=new String[event.getEventUserSet().size()];
    		int j=0;
    		for(EventUserMaster eventUser:event.getEventUserSet()){
    			//for(String Username: userService.findByUsername(eventUser))
    			eventUserSet[j] = eventUser.getResource();
    			j++;
    		}    		
    		
    		Set<String> userSet = new HashSet<String>(Arrays.asList(eventUserSet));
    		
    		eventUserSet= userSet.toArray(new String[userSet.size()]);
    		String eventUsers = String.join(",", eventUserSet);
    		eventEntryBean.setEventUsers(eventUsers);
    		eventEntryBean.setEventUserSet(eventUserSet);
    		
    		/*Set<String> eventUserSet = new HashSet<String>();	
    		//String[] eventUserSet=new String[event.getEventUserSet().size()];
    		int j=0;
    		for(EventUserMaster eventUser:event.getEventUserSet()){
    		//	for(String Username: userService.findByUsername(eventUser))
    			//eventUserSet[j] = eventUser.getResource();
    			eventUserSet.add(eventUser.getResource());
    			j++;
    		}
    		eventEntryBean.setEventUserSet(eventUserSet); */
    		
    		eventEntryBean.setEmail_receipients(event.getAdditional_receipients());
    		eventEntryBean.setEngagement_Name(event.getEngagement_Name());    		
    		evnetEntryBeanList.add(eventEntryBean);
    	}
    	
    	 
    
    	
      	  model.addAttribute("evnetEntryBeanList", evnetEntryBeanList);
      	// model.addAttribute("evnetEntryBeanList", evnetCalendarBeanList);
      	model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
          return new ModelAndView("viewEntryMaster");
 
    	
    }
  
    @RequestMapping(value="/editEntryMaster/{id}" ,method = RequestMethod.GET)
    public ModelAndView editEntry(@PathVariable Long id,@ModelAttribute("eventEntryBean") EventEntryMasterBean eventEntryBean, BindingResult bindingResult, Model model) {
		
    	EventEntryMaster event=eventEntryMasterService.findById(id);
    	
    	eventEntryBean.setEvent_ID(event.getEvent_ID());
		eventEntryBean.setEventName(event.getEventname());
		eventEntryBean.setDescription_details(event.getDescription_details());
		/*eventEntryBean.setStart_date(event.getStart_date());
		eventEntryBean.setEnd_date(event.getEnd_date());*/
		eventEntryBean.setEmail_receipients(event.getAdditional_receipients());
		eventEntryBean.setEmail_receipients1(event.getAdditional_receipients1());
		eventEntryBean.setEngagement_Name(event.getEngagement_Name());
		//eventEntryBean.setRegion_territory(event.getRegion_territory());
		eventEntryBean.setRisk_summary(event.getRisk_summary());
		
		Region region = regionService.findByRegionId(event.getRegion_id());
		
        if(region!=null)
        {
        	eventEntryBean.setRegion_territory(region.getRegion_territory());
        }
		
/*Category category=categoryService.findByEventCategoryName(eventEntry.getEvent_category_Name());
		
		if(category!=null){
			entry.setEvent_category_id(category.getEvent_cat_id());
			
		}*/
		
		Category category=categoryService.findByCategoryId(event.getEvent_category_id());
		
		if(category!=null){
			eventEntryBean.setEvent_category_Name(category.getEvent_category_name());
		}
		
		String[] eventAppSet =new String[event.getEventAppSet().size()];
		int i=0;
		
		for (EventApplicationMaster eventApp : event.getEventAppSet() ) {
			
			eventAppSet[i]=eventApp.getApplication();
			i++;
			
		}
		

		Set<String> appSet = new HashSet<String>(Arrays.asList(eventAppSet));
		
		eventAppSet= appSet.toArray(new String[appSet.size()]);
		
		eventEntryBean.setEventAppSet(eventAppSet);
		
		String[] eventUserSet=new String[event.getEventUserSet().size()];
  		int j=0;
  		for(EventUserMaster eventUser:event.getEventUserSet()){
  			
  			eventUserSet[j] = eventUser.getResource();
  			
  			j++;
  		}  
  		
  		Set<String> userSet = new HashSet<String>(Arrays.asList(eventUserSet));
		
		eventUserSet= userSet.toArray(new String[userSet.size()]);
  		
  		eventEntryBean.setEventUserSet(eventUserSet);
		/*
		Set<String> eventUserSet = new HashSet<String>();			
		int j=0;
		for(EventUserMaster eventUser:event.getEventUserSet())
		{
			eventUserSet.add(eventUser.getResource());
			j++;
		}
		eventEntryBean.setEventUserSet(eventUserSet); */
  		
		
		List<String> catList = categoryService.getCategoryName();
		List<String> appList = applicationService.getAppNames();
        List<String> rescList = userService.getResourceNames();
        List<String> regList = regionService.getRegionTerritory();
          
        Gson gson = new Gson();
      
  		List<HashMap<String, String>> listMastp=  applicationService.getPriAndSecResourceName();          
        String applicationEventJson = gson.toJson(listMastp);      
        model.addAttribute("eventEntryJsonStr",applicationEventJson);
        Set<HashMap<String, String>> setMast1 =  new HashSet<>();
        for(String eventApp : eventAppSet)
        {
	        HashMap<String, String> h = new HashMap<>();
	        h.put("App_name", eventApp);
	        setMast1.add(h);
        }        
        String applicationEventJson1 = gson.toJson(setMast1);      
        model.addAttribute("selectedeventAppJsonStr",applicationEventJson1);
          
        model.addAttribute("catgoryList",catList);
        model.addAttribute("appNameList",appList);
        model.addAttribute("rescNameList",rescList);
		model.addAttribute("eventEntryBean", eventEntryBean);
		 model.addAttribute("regionList",regList);
		 model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("editEntryMaster");
    	
    	
    }
    
    
    @RequestMapping(value="/editEntryMasterPopulate/{id}" ,method = RequestMethod.GET)
    public ModelAndView editEntryMasterPopulate(@PathVariable String id,@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean, BindingResult bindingResult, Model model) {
    	
    	EventEntryMaster event = new EventEntryMaster();
    	Gson gson = new Gson();
    	if(id.equalsIgnoreCase("Select Event Name"))
    	{
    		String engagementName = eventEntryBean.getEngagement_Name();
    		eventEntryBean = new EventEntryBean();
    		eventEntryBean.setEngagement_Name(engagementName);
    	}
    	//EventEntryMaster event=eventEntryService.findById(id);
    	else
    	{
    		event=eventEntryMasterService.findByEventName(id);
        	eventEntryBean.setEvent_ID(event.getEvent_ID());
    		eventEntryBean.setEventName(event.getEventname());
    		eventEntryBean.setDescription_details(event.getDescription_details());
    		eventEntryBean.setEmail_receipients(event.getAdditional_receipients());
    		eventEntryBean.setEmail_receipients1(event.getAdditional_receipients1());
    		eventEntryBean.setEngagement_Name(event.getEngagement_Name());
    		eventEntryBean.setRisk_summary(event.getRisk_summary());
    		eventEntryBean.setRemarks(event.getRemarks());
    		Region region = regionService.findByRegionId(event.getRegion_id());
    		
            if(region!=null)
            {
            	eventEntryBean.setRegion_territory(region.getRegion_territory());
            }
            
            /*Category category=categoryService.findByEventCategoryName(eventEntry.getEvent_category_Name());
    		
    		if(category!=null){
    			entry.setEvent_category_id(category.getEvent_cat_id());
    			
    		}*/
            Category category = null;
    		if(event.getEvent_category_id() != null)
    		{
    			category=categoryService.findByCategoryId(event.getEvent_category_id());
    		}
    		
    		if(category!=null){
    			eventEntryBean.setEvent_category_Name(category.getEvent_category_name());
    		}
    		
    		CalendarType calendartype=calendarTypeService.findByCalendarTypeId(event.getCalendar_type_id());
    		
    		System.out.println("@@@@@@@@@@@@@@@@@@@@@@inside calendartype@@@@@@@@@@"+calendartype+"@@@@@@@@@@@@@@@@@@@@@@@@@@@ ");
    					
    		if (calendartype != null) {
    			eventEntryBean.setCalendar_type_name(calendartype.getCalendar_type_name());  
    		} 
    		
            String[] eventAppSet = null;
    		if(event.getEventAppSet() != null)
    		{
    			eventAppSet =new String[event.getEventAppSet().size()];
    			int i=0;
    			for(EventApplicationMaster eventApp : event.getEventAppSet() ) {
    				if(eventAppSet != null)
    				{
    					eventAppSet[i]=eventApp.getApplication();
    				}
    				i++;
    			}
    			eventEntryBean.setEventAppSet(eventAppSet);
    			
    			Set<HashMap<String, String>> setMast1 =  new HashSet<>();
    	        for(String eventApp : eventAppSet)
    	        {
    		        HashMap<String, String> h = new HashMap<>();
    		        h.put("App_name", eventApp);
    		        setMast1.add(h);
    	        }        
    	        String applicationEventJson1 = gson.toJson(setMast1);      
    	        model.addAttribute("selectedeventAppJsonStr",applicationEventJson1);
    		}
    		String[] eventUserSet = null;
    		if(event.getEventUserSet() != null)
    		{
    			eventUserSet=new String[event.getEventUserSet().size()];
    			int j=0;
    	  		for(EventUserMaster eventUser:event.getEventUserSet()){
    	  			if(eventUserSet != null)
    				{
    	  				eventUserSet[j] = eventUser.getResource();
    				}
    	  			j++;
    	  		}  		
    	  		eventEntryBean.setEventUserSet(eventUserSet);
    		}
      		
      		if(!eventEntryBean.getStart_date().equals("") && !eventEntryBean.getStart_time().equals("") && !eventEntryBean.getEnd_date().equals("") && !eventEntryBean.getEnd_time().equals(""))
      		{
      			String s1 = eventEntryBean.getStart_date()+" "+eventEntryBean.getStart_time();
	      		String s2 = eventEntryBean.getEnd_date()+" "+eventEntryBean.getEnd_time();
	      		Date d = null;
	      		Date d1 = null;
	    		try {
	    			if(s1 != null && s2 != null)
	    			{
	    				d = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")).parse(s1);
	    				d1 = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")).parse(s2);
	    			}
	
	    		} catch (java.text.ParseException e) {
	    			// TODO Auto-generated catch block
	    			e.printStackTrace();
	    		}
	    		String convStartDate = null;
	    		String convEndDate = null;
	    		if(d != null)
	      		convStartDate = (new SimpleDateFormat("yyyy-MM-dd'T'HH:mm")).format(d);
	    		
	    		if(d1 != null)
	      		convEndDate = (new SimpleDateFormat("yyyy-MM-dd'T'HH:mm")).format(d1);
	      		
	      		eventEntryBean.setStart_date(convStartDate);
	      		eventEntryBean.setEnd_date(convEndDate);
      		}
      		model.addAttribute("eventAppSet", eventAppSet);
    		model.addAttribute("eventUserSet", eventUserSet);
    	}

		List<String> catList = categoryService.getCategoryName();
		List<String> appList = applicationService.getAppNames();
        List<String> rescList = userService.getResourceNames();
        List<String> regList = regionService.getRegionTerritory();
     
        List<HashMap<String, String>> listMastp=  applicationService.getPriAndSecResourceName();
        String eventEntryJsonStr = gson.toJson(listMastp);
        model.addAttribute("eventEntryJsonStr",eventEntryJsonStr);
        model.addAttribute("catgoryList",catList);
        model.addAttribute("appNameList",appList);
        model.addAttribute("rescNameList",rescList);
		model.addAttribute("eventEntryBean", eventEntryBean);
		model.addAttribute("regionList",regList);
		
		//account based select eventList
        HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");        
		List<String> eventList = eventEntryServiceMaster.getEventNameByAcctName(userAccountName);
		
		//List<String> eventList = eventEntryServiceMaster.getEventName();
        model.addAttribute("eventList", eventList);
        List<String> caltypList = calendarTypeService.getCalendarTypeName();
        model.addAttribute("caltypList",caltypList);
        model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("addEntry");
    }
    
    
    
    @RequestMapping(value = "/editEntryMasterPopulate/{id}", method = RequestMethod.POST)
    public ModelAndView editEntryMasterPopulateadd(@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean, BindingResult bindingResult, Model model,
    		final @RequestParam("File_upload") MultipartFile File_upload) 
    {
    	
    	System.out.println("%%%%%%%%%%%%%%%%inside editEntryMasterPopulate%%%%%%%%%%%%%%%%%%%%%%%%%%%% ");
    	
    	eventEntryValidator.validate(eventEntryBean, bindingResult);
    	
    	ModelAndView model1 = new ModelAndView();
    	FileUpload fileUpload = new FileUpload();
        try {
			model1.addObject("message", fileUpload.process(File_upload));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	
        if (bindingResult.hasErrors()) {
        	
        	
        	//@PathVariable Long id,
        	 List<String> appList = applicationService.getAppNames();
             List<String> rescList = userService.getResourceNames();
             List<String> catList = categoryService.getCategoryName();
             List<String> eventList = eventEntryMasterService.getEventName();
             List<String> regList = regionService.getRegionTerritory();
        
            model.addAttribute("eventEntryBean", eventEntryBean);
            model.addAttribute("eventList", eventList);
            model.addAttribute("appNameList",appList);
            model.addAttribute("rescNameList",rescList);
            model.addAttribute("catgoryList",catList);
            model.addAttribute("regionList",regList);
     		
           return new ModelAndView("addEntry");
        }

        /*eventEntryBean.setRecurrence_type("Daily");
        
        if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("Daily"))
        {
        	eventEntryBean.setRecu_every_day("1");
        	eventEntryBean.setRecu_every_weekday("MO,TU,WE,TH,FR");
        }
        else if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("Weekly"))
        {
        	eventEntryBean.setRecu_every_week("1");
            eventEntryBean.setRecurrence_dayName("MO,TU,WE,TH,FR,SU,SA");
        }
        else if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("Monthly"))
        {
        	eventEntryBean.setRecu_every_month("1");
        	eventEntryBean.setRecu_month_day("20");
        }*/
        //will update above code once UI changes done.
        
        eventEntryMasterService.save(eventEntryBean);
        System.out.println("--------------------after eventEntryService--------------------- ");
        
        /*String start_dt = eventEntryBean.getStart_date();
        String end_dt =  eventEntryBean.getEnd_date();*/
        
       // securityService.autologin(userForm.getUsername(), userForm.getPasswordConfirm());

        String remarks=eventEntryBean.getRemarks();
        String eventName=eventEntryBean.getEventName();
        String startSate=eventEntryBean.getStart_date();
        String endDate = eventEntryBean.getEnd_date();
        String emailID=eventEntryBean.getEmail_receipients();
        
      if(emailID.startsWith(",") || endDate.startsWith(",") || startSate.startsWith(",") || remarks.startsWith(",")){
 			
 			String startDate1=startSate.substring(1);
 			String end=endDate.substring(1);
 			
 			String email1=emailID.substring(1);
 			
 			 
 	       /*String startSate=eventEntryBean.getStart_date();
 	        String endDate = eventEntryBean.getEnd_date();*/
 	      
 	       /* String emailID=eventEntryBean.getEmail_receipients();*/
 	        model.addAttribute("eventName", eventName); 
 	       model.addAttribute("remarks", remarks); 
 	        model.addAttribute("startSate", startDate1);
 	        model.addAttribute("endDate", endDate);
 	        
 	       //emailID,null,eventName, eventEntryBean.getDescription_details()
 	        
 	        CalendarService calService = new CalendarService();
 	       calService.createCalendar(startSate, endDate, eventName, eventEntryBean.getDescription_details(),eventEntryBean.getEngagement_Name(),eventEntryBean.getRisk_summary());
 	        //mailService.sendMail(email1,null,eventName, eventEntryBean.getDescription_details());
 			
 		}else{
 			
 		 model.addAttribute("eventName", eventName);
        model.addAttribute("startSate", startSate);
        model.addAttribute("endDate", endDate);
        
        
        
        CalendarService calService = new CalendarService();
        calService.createCalendar(startSate, endDate, eventName, eventEntryBean.getDescription_details(),eventEntryBean.getEngagement_Name(),eventEntryBean.getRisk_summary());
        //mailService.sendMail(emailID,null,eventName, eventEntryBean.getDescription_details());
        
 		}
      
      String attachfileName = File_upload.getOriginalFilename();
      
  	System.out.print("attachName-------------->>"+attachfileName); 	 
	
      
      /* Email code starts here */
      /*SimpleDateFormat dateParser = new SimpleDateFormat( "yyyy-MM-dd'T'HH:mm" ) ;

      try {
    	  mailService.sendInvitation( "DL IN NATools_Support"
		                       , new String[] { eventEntryBean.getEmail_receipients()
		                                      }
		                       , eventEntryBean.getEventName()
		                       , dateParser.parse( "28-08-2006 18:00" )
		                       , dateParser.parse( "28-08-2006 21:00" )
		                       , dateParser.parse(eventEntryBean.getStart_date())
		                       , dateParser.parse(eventEntryBean.getEnd_date())
		                       , "LIS-42"
		                       , "TBD"
		                       , "<body bgcolor='#E6E6FA'> <table align='center' border='2' ><tr><td>EventName :</td><td><font color=\"Blue\">" + eventEntryBean.getEventName() + "</font></td></tr>"+
			           					"<tr><td>Description_details :</td><td><font color=\"Blue\">" + eventEntryBean.getDescription_details() + "</font></td></tr>"+
			                   			"<tr><td>Category Name :</td><td><font color=\"Blue\">" + eventEntryBean.getEvent_category_Name() + "</font></td></tr>"+
			                   			"<tr><td>Engagement Name :</td><td><font color=\"Blue\">" + eventEntryBean.getEngagement_Name() + "</font></td></tr>"+
			        					"<tr><td>Risk Summary :</td><td><font color=\"Blue\">" + eventEntryBean.getRisk_summary() + "</font></td></tr>"+
			        					"<tr><td>Region territory :</td><td><font color=\"Blue\">" + eventEntryBean.getEventName() + "</font></td></tr></table></body>",attachfileName);

	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}*/
  	
  	/* Email code starts here */
    SimpleDateFormat dateParser = new SimpleDateFormat( "yyyy-MM-dd'T'HH:mm" ) ;

    try {
  	  mailService.sendInvitation( "DL IN NATools_Support"
		                       , new String[] { eventEntryBean.getEmail_receipients()
		                                      }
		                       , eventEntryBean.getEventName()
		                       /*, dateParser.parse( "28-08-2006 18:00" )
		                       , dateParser.parse( "28-08-2006 21:00" )*/
		                       /*, eventEntryBean.getRecurrence()*/
		                       , dateParser.parse(eventEntryBean.getStart_date())
		                       , dateParser.parse(eventEntryBean.getEnd_date())
		                       
		                       , eventEntryBean.getRecurrence_type()
		                       
		                       , eventEntryBean.getRecu_every_day()
		                       , eventEntryBean.getRecu_every_weekday()
		                       
		                       , eventEntryBean.getRecu_every_week()
		                       , eventEntryBean.getRecurrence_dayName()
		                       
		                       , eventEntryBean.getRecu_every_month()
		                       , eventEntryBean.getRecu_month_day()
		                       , eventEntryBean.getMonthdd1()
		                       , eventEntryBean.getMonthdd2()
		                       , eventEntryBean.getMonthtext1()
		                       , eventEntryBean.getRecu_month_day_radio()
		                       , "LIS-42"
		                       , "TBD"
		                       /*, "<font color=\"Black\">"+eventEntryBean.getDescription_details()+"</font>"*/
		                       , "<body bgcolor='#E6E6FA'> <table align='center' border='2' ><tr><td>EventName :</td><td><font color=\"Blue\">" + eventEntryBean.getEventName() + "</font></td></tr>"+
			           					"<tr><td>Description_details :</td><td><font color=\"Blue\">" + eventEntryBean.getDescription_details() + "</font></td></tr>"+
			                   			"<tr><td>Category Name :</td><td><font color=\"Blue\">" + eventEntryBean.getEvent_category_Name() + "</font></td></tr>"+
			                   			"<tr><td>Engagement Name :</td><td><font color=\"Blue\">" + eventEntryBean.getEngagement_Name() + "</font></td></tr>"+
			        					"<tr><td>Risk Summary :</td><td><font color=\"Blue\">" + eventEntryBean.getRisk_summary() + "</font></td></tr>"+
			        					"<tr><td>Region territory :</td><td><font color=\"Blue\">" + eventEntryBean.getEventName() + "</font></td></tr></table></body>",attachfileName
		                       ) ;
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    
    /* Email code ends here */
      
      /* Email code ends here */
        
        List<CalendarBean> evnetCalendarBeanList=new ArrayList<>();
		List<EventEntryMaster> eventList = eventEntryMasterService.findAll();
    	for(EventEntryMaster event:eventList){
    		CalendarBean calendarBean=new CalendarBean();
    		//eventEntryBean.setEvent_ID(event.getEvent_ID());
    		calendarBean.setTitle(event.getEventname());
    		//eventEntryBean.setDescription_details(event.getDescription_details());
    		calendarBean.setDescription(event.getDescription_details());
    		//calendarBean.setStart(event.getStart_date());
    		//calendarBean.setEnd(event.getEnd_date());
    		calendarBean.setEngagement(event.getEngagement_Name());
    		calendarBean.setRemarks(event.getRemarks());
    		//eventEntryBean.setRegion_territory(event.getRegion_territory());
    		//eventEntryBean.setRisk_summary(event.getRisk_summary());
    		
    		
    		Set<String> eventAppSet = new HashSet<String>();
    		int i=0;
    		
    		for (EventApplicationMaster eventApp : event.getEventAppSet() ) {
    			
    			eventAppSet.add(eventApp.getApplication());
    			i++;
    			
    			/*if(i==0){
    				eventAppStr.append(eventAppSet[i]);
    				eventAppStr.append(",");
    			} else {
    				eventAppStr.append(eventAppSet[i]);
    			}*/
    		}
    		calendarBean.setEventAppSet(eventAppSet);
    		
    		Set<String> eventUserSet = new HashSet<String>();
    		//String[] eventUserSet=new String[event.getEventUserSet().size()];
    		int j=0;
    		for(EventUserMaster eventUser:event.getEventUserSet()){
    			/*for(String Username: userService.findByUsername(eventUser))*/
    			//eventUserSet[j] = eventUser.getResource();
    			eventUserSet.add(eventUser.getResource());
    			j++;
    		}
    		calendarBean.setEventUserSet(eventUserSet);      		
    		evnetCalendarBeanList.add(calendarBean);
    		
    	}
    	
    	Gson gson = new Gson();
    	String calendarJSON=gson.toJson(evnetCalendarBeanList);
    	
    	
      	model.addAttribute("calendarJSON", calendarJSON);
      	Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        model.addAttribute("userRoleName", auth.getAuthorities());
      	  
      	  
      	// model.addAttribute("evnetEntryBeanList", evnetCalendarBeanList);
      	model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray())); 
      	return new ModelAndView(new RedirectView("../viewEntry"));
 
    	
    }
    
    /*    @RequestMapping(value="/editEntryMaster/{id}" ,method = RequestMethod.POST)
    public ModelAndView editSaveEntry(@PathVariable Long id,@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean, BindingResult bindingResult, Model model) {
		
    	eventEntryValidator.validate(eventEntryBean, bindingResult);
        if (bindingResult.hasErrors()) {
        	
        	
        	 List<String> appList = applicationService.getAppNames();
             List<String> rescList = userService.getResourceNames();
             List<String> catList = categoryService.getCategoryName();
             
             model.addAttribute("eventEntryBean", eventEntryBean);
             
             model.addAttribute("catgoryList",catList);
             model.addAttribute("appNameList",appList);
             model.addAttribute("rescNameList",rescList);
        	
           return new ModelAndView("editEntryMaster");
        }
    	
    	
    	
    	eventEntryService.editSave(eventEntryBean);
    	
    	String eventName=eventEntryBean.getEventName();
        String startSate=eventEntryBean.getStart_date();
        String endDate = eventEntryBean.getEnd_date();
        String emailID=eventEntryBean.getEmail_receipients();
        model.addAttribute("eventName", eventName);
        model.addAttribute("startSate", startSate);
        model.addAttribute("endDate", endDate);
        CalendarService calService = new CalendarService();
        calService.createCalendar(startSate, endDate);
        mailService.sendMail(emailID,null,"Dear Jaiprakash", "Please open your mail and test it");
        return new ModelAndView("calender");
    	
		
    	
    	
    	
    	
    }
    @RequestMapping(value = "/addRecurrence", method = RequestMethod.GET)
    public String addRecurrene(Model model) {
		return "addRecurrence";
    	
    }
    
    */
    
    @RequestMapping(value="/editEntryMaster/{id}" ,method = RequestMethod.POST)
    public ModelAndView editSaveEntry(@PathVariable Long id,@ModelAttribute("eventEntryBean") EventEntryMasterBean eventEntryBean, BindingResult bindingResult, Model model) {
    	eventEntryBean.setEventUserSet(eventEntryBean.getHiddenuser());
    	eventEntryValidator.validate(eventEntryBean, bindingResult);
        if (bindingResult.hasErrors()) {
        	
        	
        	 List<String> appList = applicationService.getAppNames();
             List<String> rescList = userService.getResourceNames();
             List<String> catList = categoryService.getCategoryName();
             List<String> regList = regionService.getRegionTerritory();
             
             model.addAttribute("eventEntryBean", eventEntryBean);             
             model.addAttribute("catgoryList",catList);
             model.addAttribute("appNameList",appList);
             model.addAttribute("rescNameList",rescList);
             model.addAttribute("regionList",regList);
        	
           return new ModelAndView("editEntryMaster");
        }
        eventEntryMasterService.deleteEventUserBeforeEditSaveUsers(id);
    	eventEntryMasterService.deleteEventAppBeforeEditSaveApps(id);
    	
    	eventEntryMasterService.editSave(eventEntryBean);
    	
    	List<EventEntryMasterBean> evnetEntryBeanList=new ArrayList<>();
  		List<EventEntryMaster> eventList = eventEntryMasterService.findAll();
      	for(EventEntryMaster event:eventList){
      		EventEntryMasterBean eventEntryBean1=new EventEntryMasterBean();
      		eventEntryBean1.setEvent_ID(event.getEvent_ID());
      		eventEntryBean1.setEventName(event.getEventname());
      		eventEntryBean1.setDescription_details(event.getDescription_details());
      		eventEntryBean1.setEmail_receipients(event.getAdditional_receipients());
      		//eventEntryBean1.setRegion_territory(event.getRegion_territory());
      		eventEntryBean1.setRisk_summary(event.getRisk_summary());
      		
      		Region region = regionService.findByRegionId(event.getRegion_id());
			
            if(region!=null)
            {
            	eventEntryBean1.setRegion_territory(region.getRegion_territory());
            }
      		Category category=categoryService.findByCategoryId(event.getEvent_category_id());
      		
      		if(category!=null){
      			eventEntryBean1.setEvent_category_Name(category.getEvent_category_name());
      		}
      		
      		String[] eventAppSet =new String[event.getEventAppSet().size()];
      		int i=0;
      		
      		for (EventApplicationMaster eventApp : event.getEventAppSet() ) {
      			
      			eventAppSet[i]=eventApp.getApplication();
      			i++;
      			
      			/*if(i==0){
      				eventAppStr.append(eventAppSet[i]);
      				eventAppStr.append(",");
      			} else {
      				eventAppStr.append(eventAppSet[i]);
      			}*/
      		}
      		
      		Set<String> appSet = new HashSet<String>(Arrays.asList(eventAppSet));
    		
    		eventAppSet= appSet.toArray(new String[appSet.size()]);

    		String eventApps = String.join(",", eventAppSet);
    		eventEntryBean1.setEventApps(eventApps);
      		eventEntryBean1.setEventAppSet(eventAppSet);
      		
      		String[] eventUserSet=new String[event.getEventUserSet().size()];
      		int j=0;
      		for(EventUserMaster eventUser:event.getEventUserSet()){
      			//for(String Username: userService.findByUsername(eventUser))
      			eventUserSet[j] = eventUser.getResource();
      			j++;
      		}      		
      		
      		Set<String> userSet = new HashSet<String>(Arrays.asList(eventUserSet));    		
      		eventUserSet = userSet.toArray(new String[appSet.size()]);
      		String eventUsers = String.join(",", eventUserSet);
      		eventEntryBean1.setEventUsers(eventUsers);
      		eventEntryBean1.setEventUserSet(eventUserSet);
      		
      	/*	Set<String> eventUserSet = new HashSet<String>();	
    		//String[] eventUserSet=new String[event.getEventUserSet().size()];
    		int j=0;
    		for(EventUserMaster eventUser:event.getEventUserSet()){
    		//	for(String Username: userService.findByUsername(eventUser))
    			//eventUserSet[j] = eventUser.getResource();
    			eventUserSet.add(eventUser.getResource());
    			j++;
    		}
    		eventEntryBean.setEventUserSet(eventUserSet); */     	
       		eventEntryBean1.setEngagement_Name(event.getEngagement_Name());      		
      		evnetEntryBeanList.add(eventEntryBean1);
      	}
      	model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
        	   model.addAttribute("evnetEntryBeanList", evnetEntryBeanList);
            return new ModelAndView("redirect:/viewEntryMaster");
   	
    }
    
    
}
