package com.account.web;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.account.model.CalendarType;
import com.account.service.CalendarTypeService;
import com.account.validator.CalendarTypeValidator;
import com.accounts.dto.CalendarTypeBean;

	@Controller
	public class CalendarTypeController
	{	
		
		@Autowired
		private CalendarTypeService calendartypeService;
		
		@Autowired
		private CalendarTypeValidator calendarTypeValidator;
		
		@Autowired
	    private CalendarTypeService calendarTypeService;
		
		@RequestMapping(value = "/addCalendarType", method = RequestMethod.GET)
	    public String addCalendarType(Model model) {
			
			CalendarTypeBean calendartypebean=new CalendarTypeBean();
			
			model.addAttribute("calendartypebean", calendartypebean);
			model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
			return "addCalendarType";
	    }
			
		
		@RequestMapping(value = "/addCalendarType", method = RequestMethod.POST)
		public ModelAndView addRegion(@ModelAttribute("calendartypebean") CalendarTypeBean calendartypebean, BindingResult bindingResult, Model model)
		{
			calendarTypeValidator.validate(calendartypebean, bindingResult);

			if (bindingResult.hasErrors()) {
				return new ModelAndView("addCalendarType");
			}
			CalendarType calendartype=new CalendarType();
			calendartype.setCalendar_type_name(calendartypebean.getCalendar_type_name()); 
			calendartype.setStatus(calendartypebean.isStatus());
			
			calendartypeService.save(calendartype);
			
			List<CalendarTypeBean> calendartypeBeanList=new ArrayList<>();
		List<CalendarType> calendartypeList=calendartypeService.findAll();

		for(CalendarType calty:calendartypeList){
			CalendarTypeBean caltyBeans = new CalendarTypeBean();
			caltyBeans.setCalendar_type_id(calty.getCalendar_type_id());       
			caltyBeans.setCalendar_type_name(calty.getCalendar_type_name());    
			if(calty.isStatus()==true){
				caltyBeans.setStatus1("Active");
			}else{
				caltyBeans.setStatus1("InActive");
			}
			
			calendartypeBeanList.add(caltyBeans);
		}
			model.addAttribute("calendartypeBeanList", calendartypeBeanList);
			model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
			return new ModelAndView("viewCalendarType");
			
		}
		
		@RequestMapping(value = "/viewCalendarType", method = RequestMethod.GET)
	    public String viewRegion(Model model) {
			
			
			List<CalendarTypeBean> calendartypeBeanList=new ArrayList<>();
			List<CalendarType> calendartypeList=calendartypeService.findAll();

			for(CalendarType calty:calendartypeList){
				CalendarTypeBean caltyBeans = new CalendarTypeBean();
				caltyBeans.setCalendar_type_id(calty.getCalendar_type_id());       
				caltyBeans.setCalendar_type_name(calty.getCalendar_type_name());    
				if(calty.isStatus()==true){
					caltyBeans.setStatus1("Active");
				}else{
					caltyBeans.setStatus1("InActive");
				}
				
				calendartypeBeanList.add(caltyBeans);
			}
				model.addAttribute("calendartypeBeanList", calendartypeBeanList);
				//return new ModelAndView("viewCalendarType");
				model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
			return "viewCalendarType";
	    }
		
		@RequestMapping(value = "/editCalendarType/{id}", method = RequestMethod.GET)
		public ModelAndView edit(@PathVariable Long id, @ModelAttribute("calendartypebean") CalendarTypeBean calendartypeBean, Model model) {
			
			CalendarType calendartype=calendartypeService.findById(id);
			calendartypeBean.setCalendar_type_id(calendartype.getCalendar_type_id()); 
			calendartypeBean.setCalendar_type_name(calendartype.getCalendar_type_name());
			calendartypeBean.setStatus(calendartype.isStatus());
			model.addAttribute("calendartypeBean", calendartypeBean);
			model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		  return new ModelAndView("editCalendarType");
			
		}
		
		@RequestMapping(value = "/editCalendarType/{id}", method = RequestMethod.POST)
		public ModelAndView editUserDataSave(@PathVariable Long id, @ModelAttribute("calendartypebean") CalendarTypeBean calendartypeBean,
				BindingResult bindingResult, Model model) 
		{
			calendarTypeValidator.validate(calendartypeBean, bindingResult);

			if (bindingResult.hasErrors()) {
				return new ModelAndView("editCalendarType");
			}
		
			CalendarType calendartype1=new CalendarType();
			calendartype1.setCalendar_type_id(calendartypeBean.getCalendar_type_id()); 
			calendartype1.setCalendar_type_name(calendartypeBean.getCalendar_type_name()); 
			calendartype1.setStatus(calendartypeBean.isStatus());
			calendartypeService.save(calendartype1);
			
		List<CalendarTypeBean> calendartypeBeanList=new ArrayList<>();
		List<CalendarType> calendartypeList=calendartypeService.findAll();

		for(CalendarType calty:calendartypeList){
			CalendarTypeBean caltyBeans = new CalendarTypeBean();
			caltyBeans.setCalendar_type_id(calty.getCalendar_type_id());       
			caltyBeans.setCalendar_type_name(calty.getCalendar_type_name());    
			if(calty.isStatus()==true){
				caltyBeans.setStatus1("Active");
			}else{
				caltyBeans.setStatus1("InActive");
			}
			
			calendartypeBeanList.add(caltyBeans);
		}
			model.addAttribute("calendartypeBeanList", calendartypeBeanList);
			model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
			return new ModelAndView("viewCalendarType");
			
			
		}
		
	}

