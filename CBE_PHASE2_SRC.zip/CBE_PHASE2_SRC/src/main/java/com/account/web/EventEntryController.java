package com.account.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.mail.internet.ParseException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.account.model.CalendarType;
import com.account.model.Category;
import com.account.model.EventApplication;
import com.account.model.EventApplicationMaster;
import com.account.model.EventEntry;
import com.account.model.EventEntryMaster;
import com.account.model.EventPlanned;
import com.account.model.EventPlannedBean;
import com.account.model.EventUser;
import com.account.model.FileUpload;
import com.account.model.Region;
import com.account.repository.UserRepository;
import com.account.service.AccountService;
import com.account.service.ApplicationService;
import com.account.service.CalendarService;
import com.account.service.CalendarTypeService;
import com.account.service.CategoryService;
import com.account.service.EventEntryMasterService;
import com.account.service.EventEntryService;
import com.account.service.MailService;
import com.account.service.RegionService;
import com.account.service.UserService;
import com.account.validator.EventEntryValidator;
import com.accounts.dto.CalendarBean;
import com.accounts.dto.EventEntryBean;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.Gson;




/**
 * 
 * @author jaimishr
 *
 */

@Controller
public class EventEntryController {
	@Autowired
    private EventEntryService eventEntryService;
	
	@Autowired
    private EventEntryMasterService eventEntryServiceMaster;

    @Autowired
    private ApplicationService applicationService;
    
    @Autowired
    private UserService userService;

    @Autowired
    private EventEntryValidator eventEntryValidator;
  
    @Autowired
    private CategoryService categoryService;
    
    @Autowired
    MailService mailService ;
    
    @Autowired
	UserRepository userRepository;
    
    @Autowired
    private RegionService regionService;
    
    @Autowired
    private JavaMailSender mailSender;
    
    @Autowired
    private CalendarTypeService calendartypeService;
    
    @Autowired
    private CalendarTypeService calendarTypeService;
    
    @Autowired
    private AccountService accountService;
    
    String emailid=null;
    
    @Autowired
    private HttpServletRequest httpServletRequest;
    
 /*   @Configuration
    public class RestSecurityConfig extends WebSecurityConfigurerAdapter {
      @Override
      protected void configure(HttpSecurity http) throws Exception {
        http.csrf().disable();
      }
    }*/
    
    String rootPath = System.getProperty("catalina.home");
	 //File dir = new File(rootPath + File.separator + "tmpFiles");
    File dir = new File(rootPath + "\\webapps\\CBE_V2\\resources\\files\\");

    
    @RequestMapping(value = "/addEntry", method = RequestMethod.GET)
    public ModelAndView addEntry(Model model,@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean) 
    {
        List<String> appList = applicationService.getAppNames();
        List<String> rescList = userService.getResourceNames();
        List<String> catList = categoryService.getCategoryName();
    	//account based select eventList
        HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
        
		List<String> eventList = eventEntryServiceMaster.getEventNameByAcctName(userAccountName);
        List<String> regList = regionService.getRegionTerritory();
        List<String> caltypList = calendartypeService.getCalendarTypeName();
        List<String> accList = accountService.getAccountNames();
        //EventEntryBean eventEntry = new EventEntryBean();
        model.addAttribute("eventEntryBean", eventEntryBean);
        model.addAttribute("eventList", eventList);
        model.addAttribute("appNameList",appList);
        model.addAttribute("rescNameList",rescList);
        model.addAttribute("catgoryList",catList);
        model.addAttribute("regionList",regList);
        model.addAttribute("caltypList",caltypList);
        model.addAttribute("accountList",accList);
        
		model.addAttribute("userAccountName",userAccountName);
        
       /* Gson gson = new Gson();
        String calendarJSON=gson.toJson(eventList);*/
        
        List<HashMap<String, String>> listMastp=  applicationService.getPriAndSecResourceName();          
        Gson gson = new Gson();
        String applicationEventJson = gson.toJson(listMastp);      
        model.addAttribute("eventEntryJsonStr",applicationEventJson);
        model.addAttribute("filePath", dir + File.separator);
        model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
        return new ModelAndView("addEntry");
    }
    

    @RequestMapping(value = "/searchIncidents", method = RequestMethod.GET)
    public ModelAndView searchIncidentsUpdating(Model model,@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean) 
    {
        //account based select eventList
        HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		List<String> appList = applicationService.getAppNames();
        model.addAttribute("eventEntryBean", eventEntryBean);
		model.addAttribute("userAccountName",userAccountName);
		model.addAttribute("appNameList",appList);
        return new ModelAndView("searchIncidents");
    }

    @RequestMapping(value = "/searchIncidentsNew", method = RequestMethod.POST)
    public ModelAndView searchIncidents(@RequestParam("event") EventEntry event, Model model,@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean) 
    {
        //account based select eventList
        HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		List<String> appList = applicationService.getAppNames();
        model.addAttribute("eventEntryBean", eventEntryBean);
		model.addAttribute("userAccountName",userAccountName);
		model.addAttribute("appNameList",appList);
        return new ModelAndView("searchIncidents");
    }
    
    /*@RequestMapping(value = "/searchIncidents", method = RequestMethod.GET)
    public ModelAndView searchIncidents(Model model,@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean) 
    {
        //account based select eventList
        HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		List<String> appList = applicationService.getAppNames();
        model.addAttribute("eventEntryBean", eventEntryBean);
		model.addAttribute("userAccountName",userAccountName);
		model.addAttribute("appNameList",appList);
        return new ModelAndView("searchIncidents");
    }
    
    @RequestMapping(value = "/allIncidentsList", method = RequestMethod.POST)
    public String allIncidentsList(@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean, BindingResult bindingResult, Model model) 
    {
    	String accName = eventEntryBean.getEngagement_Name();
    	String startDate = eventEntryBean.getStart_date();
  		String endDate = eventEntryBean.getEnd_date();
  		String applicationName = eventEntryBean.getApplicationName();
		//List<HashMap<String, Object>> all_incidents = userService.getAllIncidents(accName,applicationName, startDate, endDate);
  		List<HashMap<String, Object>> all_incidents = userService.getAllIncidents(accName,applicationName, startDate, endDate);
		List allIncidentsList = new ArrayList<>();
		if(!all_incidents.isEmpty() && all_incidents != null)
		{
			for (HashMap<String, Object> allIncidentsMap : all_incidents) {
				Iterator<Entry<String, Object>> it = allIncidentsMap.entrySet().iterator();
				IncidentBean incidentBean = new IncidentBean();
				while (it.hasNext()) {
			        Map.Entry pair = (Map.Entry)it.next();
			        if(checkKeyValueNull(pair) && "Incident_ID".equalsIgnoreCase(pair.getKey().toString()))
			        incidentBean.setIncident_ID(pair.getValue().toString());
			        if(checkKeyValueNull(pair) && "Reported_Date".equalsIgnoreCase(pair.getKey().toString()))
				    incidentBean.setReported_Date(pair.getValue().toString());
			        if(checkKeyValueNull(pair) && "Summary".equalsIgnoreCase(pair.getKey().toString()))
				    incidentBean.setSummary(pair.getValue().toString());
			        if(checkKeyValueNull(pair) && "Notes".equalsIgnoreCase(pair.getKey().toString()))
			        incidentBean.setNotes(pair.getValue().toString());
				}
				incidentBean.setStartDate(startDate);
				incidentBean.setEndDate(endDate);
				eventEntryService.saveIncidents(incidentBean);
				allIncidentsList.add(incidentBean);
			}	
		}
		
		mailService.sendMail("dactoolssupport.in@capgemini.com", "dactoolssupport.in@capgemini.com", +allIncidentsList.size()+" incidents occured in period "+startDate+" to "+endDate);

		model.addAttribute("allIncidentsList", allIncidentsList);
    	return "allIncidents";
    }*/
    
    public static HashMap<String, String> getWorkingDaysBetweenTwoDates(Date startDate, Date endDate, boolean isWeekDay, String recurrenceDays) throws java.text.ParseException {
	    Calendar startCal = Calendar.getInstance();
	    startCal.setTime(startDate);        
	    Integer recDays = Integer.parseInt(recurrenceDays);
	    Calendar endCal = Calendar.getInstance();
	    endCal.setTime(endDate);

	    //Return 0 if start and end are the same
	    HashMap<String, String> map =  new HashMap<>();
		if (startCal.getTimeInMillis() == endCal.getTimeInMillis()) {
	        return map;
	    }

	    if (startCal.getTimeInMillis() > endCal.getTimeInMillis()) {
	        startCal.setTime(endDate);
	        endCal.setTime(startDate);
	    }
	    SimpleDateFormat sdf = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss" );
	    
	    String pattern = "yyyy-MM-dd";
	    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
	    String date = simpleDateFormat.format(startCal.getTime());
	    System.out.println(date);
	    
	    String pattern2 = "HH:mm:ss";
	    SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat(pattern2);
	    String time = simpleDateFormat2.format(endCal.getTime());
	    
	    /*if (isWeekDay == true && startCal.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY && startCal.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
        	String date1 = simpleDateFormat.format(startCal.getTime());
        	System.out.println(": weekdays only :");
        	System.out.println(sdf.format(startCal.getTime()) +"= "+date1+" "+time); 
        	map.put(sdf.format(startCal.getTime()), date1+" "+time);
        }
	    if (isWeekDay == false) {
        	String date1 = simpleDateFormat.format(startCal.getTime());
        	System.out.println(": all days :");
        	System.out.println(sdf.format(startCal.getTime()) +"= "+date1+" "+time); 
        	map.put(sdf.format(startCal.getTime()), date1+" "+time);
        }*/
	    
	    do {
	       //excluding start date
	        if (isWeekDay == true && startCal.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY && startCal.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
	        	String date1 = simpleDateFormat.format(startCal.getTime());
	        	System.out.println(": weekdays only :");
	        	System.out.println(sdf.format(startCal.getTime()) +"= "+date1+" "+time); 
	        	map.put(sdf.format(startCal.getTime()), date1+" "+time);
	        	//startCal.add(Calendar.DATE, recDays);
	        }
	        if (isWeekDay == false) {
	        	String date1 = simpleDateFormat.format(startCal.getTime());
	        	System.out.println(": all days :");
	        	System.out.println(sdf.format(startCal.getTime()) +"= "+date1+" "+time); 
	        	map.put(sdf.format(startCal.getTime()), date1+" "+time);
	        	
	        }
	        startCal.add(Calendar.DATE, recDays);
	    } while (startCal.getTimeInMillis() < endCal.getTimeInMillis()); //excluding end date
	    return map;
	}
    
    /*@RequestMapping(value = "/allCauseCodes", method = RequestMethod.POST)
    public String allIncidentsListUpdating(@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean, BindingResult bindingResult, Model model) throws java.text.ParseException 
    {
    	String accName = eventEntryBean.getEngagement_Name();
    	//String startDate = eventEntryBean.getStart_date();
  		//String endDate = eventEntryBean.getEnd_date();
		//List<HashMap<String, Object>> all_incidents = userService.getAllIncidents(accName,applicationName, startDate, endDate);
  		
    	List<HashMap<String, String>> all_incidents1 = new ArrayList<HashMap<String, String>>();
  		HashMap<String, String> map =  new HashMap<>();
  		//SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
  		SimpleDateFormat sdf = new SimpleDateFormat( "yyyy-MM-dd'T'HH:mm" );
		//String dateInString = "6-12-2018 10:20:56";
  		String dateInString = eventEntryBean.getStart_date()+"T"+eventEntryBean.getStart_time();
		Date startDate = sdf.parse(dateInString);
		
		//String dateInEndString = "12-12-2018 12:40:56";
		String dateInEndString = eventEntryBean.getEnd_date()+"T"+eventEntryBean.getEnd_time();
		Date endDate = sdf.parse(dateInEndString);
		HashMap<String, String> weekdaysList = new HashMap<>();
		boolean isWeekDay = false;
		List<HashMap<String, String>> all_incidents  = new ArrayList<>();
		if(eventEntryBean.getRecurrence_type() != null && eventEntryBean.getRecurrence_type().equalsIgnoreCase("daily") && eventEntryBean.getRecu_every_day() != null)
	    {
			isWeekDay = false;
			weekdaysList = EventEntryController.getWorkingDaysBetweenTwoDates(startDate, endDate,isWeekDay, eventEntryBean.getRecu_every_day());
			for (Map.Entry<String,String> entry : weekdaysList.entrySet()) 
	        {
				all_incidents1 = userService.getAllIncidentsByDaily(accName,eventEntryBean.getApplicationName(), entry.getKey(), entry.getValue(),eventEntryBean.getRecurrence_type(),eventEntryBean.getRecu_every_day());
				all_incidents.addAll(all_incidents1);
	        }
	        System.out.println(all_incidents.size());
	    }
		else if(eventEntryBean.getRecurrence_type() != null && eventEntryBean.getRecurrence_type().equalsIgnoreCase("daily") && eventEntryBean.getRecu_every_weekday() != null)
		{
			isWeekDay = true;
			String defaultValue = "1";
			weekdaysList = EventEntryController.getWorkingDaysBetweenTwoDates(startDate, endDate,isWeekDay,defaultValue);
			for (Map.Entry<String,String> entry : weekdaysList.entrySet()) 
	        {
				all_incidents1 = userService.getAllIncidentsByDaily(accName,eventEntryBean.getApplicationName(), entry.getKey(), entry.getValue(),eventEntryBean.getRecurrence_type(),eventEntryBean.getRecu_every_day());
				all_incidents.addAll(all_incidents1);
	        }
	        System.out.println(all_incidents.size());
		}
		
		else if(eventEntryBean.getRecurrence_type() != null && eventEntryBean.getRecurrence_type().equalsIgnoreCase("weekly")  && eventEntryBean.getRecurrence_dayName() != null && eventEntryBean.getRecu_every_week() != null)
		{
			String days = eventEntryBean.getRecurrence_dayName();
			String recurrenceWeeks = eventEntryBean.getRecu_every_week();
			weekdaysList = EventEntryController.getPerticualerWeekOfDaysBetweenTwoDates(startDate, endDate,days,recurrenceWeeks);
			for (Map.Entry<String,String> entry : weekdaysList.entrySet()) 
	        {
				all_incidents1 = userService.getAllIncidentsByDaily(accName,eventEntryBean.getApplicationName(), entry.getKey(), entry.getValue(),eventEntryBean.getRecurrence_type(),eventEntryBean.getRecu_every_day());
				all_incidents.addAll(all_incidents1);
	        }
	        System.out.println(all_incidents.size());
		}
		else if(eventEntryBean.getRecurrence_type() != null && eventEntryBean.getRecurrence_type().equalsIgnoreCase("monthly")  && !eventEntryBean.getRecu_month_day().equalsIgnoreCase("") && !eventEntryBean.getRecu_every_month().equalsIgnoreCase(""))
		{
			String days = eventEntryBean.getRecu_month_day();
			String recurrenceMonths = eventEntryBean.getRecu_every_month();
			weekdaysList = EventEntryController.getPerticualerMonthDaysBetweenTwoDates(startDate, endDate,days,recurrenceMonths);
			for (Map.Entry<String,String> entry : weekdaysList.entrySet()) 
	        {
				all_incidents1 = userService.getAllIncidentsByDaily(accName,eventEntryBean.getApplicationName(), entry.getKey(), entry.getValue(),eventEntryBean.getRecurrence_type(),eventEntryBean.getRecu_every_day());
				all_incidents.addAll(all_incidents1);
	        }
	        System.out.println(all_incidents.size());
		}
		
		List<IncidentBean> allIncidentsList = new ArrayList<>();
		HashMap<String, List> incidentsList = new HashMap<>();
		if(!all_incidents.isEmpty() && all_incidents != null)
		{
			for (HashMap<String, String> allIncidentsMap : all_incidents) {
				Iterator<Entry<String, String>> it = allIncidentsMap.entrySet().iterator();
				IncidentBean incidentBean = new IncidentBean();
				while (it.hasNext()) {
			        Map.Entry pair = (Map.Entry)it.next();
			        if(checkKeyValueNull(pair) && "Incident_ID".equalsIgnoreCase(pair.getKey().toString()))
			        incidentBean.setIncident_ID(pair.getValue().toString());
			        if(checkKeyValueNull(pair) && "Reported_Date".equalsIgnoreCase(pair.getKey().toString()))
				    incidentBean.setReported_Date(pair.getValue().toString());
			        if(checkKeyValueNull(pair) && "appName".equalsIgnoreCase(pair.getKey().toString()))
				    incidentBean.setApp_Name(pair.getValue().toString());
			        if(checkKeyValueNull(pair) && "token".equalsIgnoreCase(pair.getKey().toString()))
			        incidentBean.setCausecode_id(pair.getValue().toString());
				}
				incidentBean.setStartDate(startDate.toString());
				incidentBean.setEndDate(endDate.toString());
				eventEntryService.saveIncidents(incidentBean);
				allIncidentsList.add(incidentBean);
			}	
		}
		
		Map<String,List<String>> map1 = new HashMap<String,List<String>>();
		List<String> list = new ArrayList<>();
		List<String> dummy=new ArrayList<>();
		
		for (IncidentBean incidentBean : allIncidentsList)
		{
			if(!dummy.contains(incidentBean.getCausecode_id()))
			{
				dummy.add(incidentBean.getCausecode_id());
				
				for (IncidentBean incidentBeann : allIncidentsList)
				{
					if(incidentBean.getCausecode_id().equalsIgnoreCase(incidentBeann.getCausecode_id()))
					{
						list.add(incidentBeann.getIncident_ID());
						map1.put(incidentBean.getCausecode_id(), list);
					}
				}
			}
			list = new ArrayList<>();
		}
		String sendMailReturnValue = null;
		//mailService.sendMail("dactoolssupport.in@capgemini.com", "Incidents List", +allIncidentsList.size()+" incidents occured in period "+startDate+" to "+endDate);
		sendMailReturnValue = mailService.sendEmail("dactoolssupport.in@capgemini.com","Incidents List",  +allIncidentsList.size()+" incidents occured in period "+startDate+" to "+endDate);
		if(sendMailReturnValue.equalsIgnoreCase("smtpErrorPage"))
        {
        	model.addAttribute("mailserverIssue", "There is an Error Connecting to Mail Server, Kindly wait for some time and try again!! If the problem persist, Please Contact Technical Support Team na-am-industrialization-bangalore.in@capgemini.com");
        	List<String> appList = applicationService.getAppNames();
        	model.addAttribute("appNameList",appList);
        	return "searchIncidents";
        }
		Gson gson = new Gson();
		if(eventEntryBean.getRecurrence_dayName() != null)
  		{
  			List<String> recurrence_dayNameList = new ArrayList<String>(Arrays.asList(eventEntryBean.getRecurrence_dayName().split(",")));
  	        String recurrence_dayNamesJson = gson.toJson(recurrence_dayNameList);
  	        model.addAttribute("recurrence_dayNamesJson", recurrence_dayNamesJson);
  		}
		model.addAttribute("allIncidentsList", allIncidentsList);
		HttpSession httpSession = httpServletRequest.getSession();
		httpSession.setAttribute("map1",map1);
		model.addAttribute("causecodeList", map1);
		
    	return "allIncidents";
    }*/

    @RequestMapping(value = "/searchIncidentsUpdating", method = RequestMethod.GET)
    public ModelAndView displayIncidents(Model model,@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean) 
    {
    	String hiddenIncident = eventEntryBean.getHiddenIncidentValue();
        //account based select eventList
        HttpSession httpSession = httpServletRequest.getSession();
        Map<String,List<String>> map1 = new HashMap<String,List<String>>();
        map1 = (Map<String, List<String>>) httpSession.getAttribute("map1");
        // using for-each loop for iteration over Map.entrySet() 
        /*for (Entry<String, List<String>> entry : map1.entrySet())  
        {
        	if(entry.getKey().equalsIgnoreCase(id))
        	{
        		model.addAttribute("incidentsList",entry.getValue());
        	}
        	System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
        }
        */
		model.addAttribute("causecodeMap",map1);
		return new ModelAndView("causeCodeIncidents");
    }

    
    
    /*
    private static HashMap<String, String> getPerticualerWeekOfDaysBetweenTwoDates(Date startDate, Date endDate) {
		// TODO Auto-generated method stub
		return null;
	}*/

	public static HashMap<String, String> getPerticualerMonthDaysBetweenTwoDates(Date startDate, Date endDate,
			String day,String recurrenceMonths) {
		Integer recDays = Integer.parseInt(recurrenceMonths);
		Calendar startCal = Calendar.getInstance();
	    startCal.setTime(startDate);        

	    Calendar endCal = Calendar.getInstance();
	    endCal.setTime(endDate);

	    //Return 0 if start and end are the same
	    if (startCal.getTimeInMillis() == endCal.getTimeInMillis()) {
	        return new HashMap<>();
	    }

	    if (startCal.getTimeInMillis() > endCal.getTimeInMillis()) {
	        startCal.setTime(endDate);
	        endCal.setTime(startDate);
	    }
	    SimpleDateFormat sdf = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss" );
	    
	    String pattern = "yyyy-MM-dd";
	    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
	    String date = simpleDateFormat.format(startCal.getTime());
	    System.out.println(date);
	    
	    String pattern2 = "HH:mm:ss";
	    SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat(pattern2);
	    String time = simpleDateFormat2.format(endCal.getTime());
	    System.out.println(time);
	    HashMap<String, String> map =  new HashMap<>();
		    do {
    			if (startCal.get(Calendar.DAY_OF_MONTH) == Integer.parseInt(day)) {
		        	String date11 = simpleDateFormat.format(startCal.getTime());
		        	System.out.println("startDate: "+startCal.getTime()+ " EndDate: "+ date11+" "+time);
		        	map.put(sdf.format(startCal.getTime()), date11+" "+time);
		        	startCal.add(Calendar.MONTH,recDays-1);
		        }
    			startCal.add(Calendar.DATE,1);	
		        	
		    } while (startCal.getTimeInMillis() < endCal.getTimeInMillis()); //excluding end date
		return map;

	}

	public static HashMap<String, String> getPerticualerWeekOfDaysBetweenTwoDates(Date startDate, Date endDate,String days,String recurrenceWeeks) throws java.text.ParseException {
		
		Integer recDays = Integer.parseInt(recurrenceWeeks);
		Calendar startCal = Calendar.getInstance();
	    startCal.setTime(startDate);        

	    Calendar endCal = Calendar.getInstance();
	    endCal.setTime(endDate);

	    //Return 0 if start and end are the same
	    if (startCal.getTimeInMillis() == endCal.getTimeInMillis()) {
	        return new HashMap<>();
	    }

	    if (startCal.getTimeInMillis() > endCal.getTimeInMillis()) {
	        startCal.setTime(endDate);
	        endCal.setTime(startDate);
	    }
	    SimpleDateFormat sdf = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss" );
	    
	    String pattern = "yyyy-MM-dd";
	    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
	    String date = simpleDateFormat.format(startCal.getTime());
	    System.out.println(date);
	    
	    String pattern2 = "HH:mm:ss";
	    SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat(pattern2);
	    String time = simpleDateFormat2.format(endCal.getTime());
	    HashMap<String, String> map =  new HashMap<>();
    	String[] day_of_weeks = days.split(",");
    	long l =startCal.getTimeInMillis();
    	int  defaultValue = 1;
    	for (String day_of_week : day_of_weeks) 
    	{
    		do {
    			if("MO".equalsIgnoreCase(day_of_week)) {
    				day_of_week = "1";
    			}else
    			if("TU".equalsIgnoreCase(day_of_week)) {
    				day_of_week = "2";
    			}else
    			if("WE".equalsIgnoreCase(day_of_week)) {
    				day_of_week = "3";
    			}else
    			if("TH".equalsIgnoreCase(day_of_week)) {
    				day_of_week = "4";
    			}else
    				if("FR".equalsIgnoreCase(day_of_week)) {
        				day_of_week = "5";
        			}else
        				if("SA".equalsIgnoreCase(day_of_week)) {
            				day_of_week = "6";
            			}else
            				if("SU".equalsIgnoreCase(day_of_week)) {
            				day_of_week = "7";
            			}
    			
	    	if (startCal.get(Calendar.DAY_OF_WEEK) == Integer.parseInt(day_of_week)) {
	   			String date11 = simpleDateFormat.format(startCal.getTime());
	        	System.out.println("startDate: "+startCal.getTime()+ " EndDate: "+ date11+" "+time);
	        	map.put(sdf.format(startCal.getTime()), date11+" "+time);
	        	startCal.add(Calendar.WEEK_OF_MONTH,recDays-1);			        		
	    		}	    		
	    		startCal.add(Calendar.DATE,defaultValue);
    		} while (startCal.getTimeInMillis() < endCal.getTimeInMillis()); 
    		startCal.setTimeInMillis(l);
    	}
		return map;
	}

	private boolean checkKeyValueNull(Map.Entry pair) {
		return (null != pair.getKey() && !com.mysql.jdbc.StringUtils.isNullOrEmpty(String.valueOf(pair.getKey())) && null != pair.getValue() && !com.mysql.jdbc.StringUtils.isNullOrEmpty(String.valueOf(pair.getValue())));
	}
    
    @RequestMapping(value = "/addEntryLoad", method = RequestMethod.GET)
    public ModelAndView addEntryLoad(@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean, BindingResult bindingResult, Model model) 
    {
    	List<String> appList = applicationService.getAppNames();
        List<String> rescList = userService.getResourceNames();
        List<String> catList = categoryService.getCategoryName();
        List<String> eventEntryMaster = eventEntryServiceMaster.getEventName();
        List<String> regList = regionService.getRegionTerritory();
        
        //eventEntryBean.setRemarks(eventEntryBean.getRemarks());
        String name = eventEntryBean.getEventName();
      //  String remarks = eventEntryBean.getRemarks();
     //   String eventName = name.substring( 0, name.length( ) - ", ".length( ) );
        /*if (name.endsWith(",")) {
        	String names = name.substring(0, name.length() - 1);*/
        if(name.contains(",")){
			
            String st[]=name.split(", ");
            
            String names=st[0];
        	
        	 EventEntryMaster eventEntryMasterByName = eventEntryServiceMaster.findByEventName(names);
             
             if(eventEntryMasterByName!=null){
            	 eventEntryBean.setEvent_ID(eventEntryMasterByName.getEvent_ID());
            	 eventEntryBean.setEventName(eventEntryMasterByName.getEventname());
            	 eventEntryBean.setDescription_details(eventEntryMasterByName.getDescription_details());
            	 eventEntryBean.setEmail_receipients(eventEntryMasterByName.getAdditional_receipients());
            	 eventEntryBean.setEngagement_Name(eventEntryMasterByName.getEngagement_Name());
                 eventEntryBean.setRemarks(eventEntryMasterByName.getRemarks());
            	 
                 Region region = regionService.findByRegionId(eventEntryMasterByName.getRegion_id());
 				
                 if(region!=null)
                 {
                 	eventEntryBean.setRegion_territory(region.getRegion_territory());
                 }
                 
                 
            	 Category category=categoryService.findByCategoryId(eventEntryMasterByName.getEvent_category_id());
         		
         		if(category!=null){
         			eventEntryBean.setEvent_category_Name(category.getEvent_category_name());
         		}
         		
         		String[] eventAppSet =new String[eventEntryMasterByName.getEventAppSet().size()];
        		int i=0;
        		
        		for (EventApplicationMaster eventApp : eventEntryMasterByName.getEventAppSet() ) {
        			
        			eventAppSet[i]=eventApp.getApplication();
        			i++;
        			
        			/*if(i==0){
        				eventAppStr.append(eventAppSet[i]);
        				eventAppStr.append(",");
        			} else {
        				eventAppStr.append(eventAppSet[i]);
        			}*/
        		}
        		eventEntryBean.setEventAppSet(eventAppSet);
        		
        		//eventEntryBean.setRegion_territory(eventEntryMasterByName.getRegion_territory());
        		
        		eventEntryBean.setRisk_summary(eventEntryMasterByName.getRisk_summary());
            	 
             }
             
        	
        	} else{
        		EventEntryMaster eventEntryMasterByName = eventEntryServiceMaster.findByEventName(name);
                
                if(eventEntryMasterByName!=null){
               	 eventEntryBean.setEvent_ID(eventEntryMasterByName.getEvent_ID());
               	 eventEntryBean.setEventName(eventEntryMasterByName.getEventname());
               	 eventEntryBean.setDescription_details(eventEntryMasterByName.getDescription_details());
               	 eventEntryBean.setEmail_receipients(eventEntryMasterByName.getAdditional_receipients());
               	 eventEntryBean.setEngagement_Name(eventEntryMasterByName.getEngagement_Name());
               	 eventEntryBean.setRemarks(eventEntryMasterByName.getRemarks());
               	
               	Region region = regionService.findByRegionId(eventEntryMasterByName.getRegion_id());
				
                if(region!=null)
                {
                	eventEntryBean.setRegion_territory(region.getRegion_territory());
                }
               	 
               	 
               	 Category category=categoryService.findByCategoryId(eventEntryMasterByName.getEvent_category_id());
            		
            		if(category!=null){
            			eventEntryBean.setEvent_category_Name(category.getEvent_category_name());
            		}
            		
            		String[] eventAppSet =new String[eventEntryMasterByName.getEventAppSet().size()];
           		int i=0;
           		
           		for (EventApplicationMaster eventApp : eventEntryMasterByName.getEventAppSet() ) {
           			
           			eventAppSet[i]=eventApp.getApplication();
           			i++;           		
           		}
           		eventEntryBean.setEventAppSet(eventAppSet);           			
           		eventEntryBean.setRisk_summary(eventEntryMasterByName.getRisk_summary());               	 
                }
        		
        	}
        
       
        
        model.addAttribute("eventList", eventEntryMaster);
        model.addAttribute("appNameList",appList);
        model.addAttribute("rescNameList",rescList);
        model.addAttribute("catgoryList",catList);
        model.addAttribute("eventEntryBean", eventEntryBean);
        model.addAttribute("regionList",regList);
        model.addAttribute("filePath", dir + File.separator);
       /* Gson gson = new Gson();
        String calendarJSON=gson.toJson(eventList);*/
        model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
        return new ModelAndView("addEntry");
    }
    
    @RequestMapping(value = "/addEntryLoad", method = RequestMethod.POST)
    public ModelAndView addEntryLoad1(@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean, BindingResult bindingResult, Model model) 
    {
    	 eventEntryBean.setEventUserSet(eventEntryBean.getHiddenuser());
    	eventEntryValidator.validate(eventEntryBean, bindingResult);
        if (bindingResult.hasErrors()) {
        	//@PathVariable Long id,
        	 List<String> appList = applicationService.getAppNames();
             List<String> rescList = userService.getResourceNames();
             List<String> catList = categoryService.getCategoryName();
             List<String> eventList = eventEntryServiceMaster.getEventName();
             List<String> regList = regionService.getRegionTerritory();
             
                     
     		model.addAttribute("eventEntryBean", eventEntryBean);
            model.addAttribute("eventList", eventList);
            model.addAttribute("appNameList",appList);
            model.addAttribute("rescNameList",rescList);
            model.addAttribute("catgoryList",catList);
            model.addAttribute("regionList",regList);
            
           return new ModelAndView("addEntry");
        }
 
        eventEntryService.save(eventEntryBean);
        
       
        String remarks=eventEntryBean.getRemarks();
        String startSate=eventEntryBean.getStart_date()+"T"+eventEntryBean.getStart_time();
        String endDate = eventEntryBean.getEnd_date()+"T"+eventEntryBean.getEnd_time();
        String emailID=eventEntryBean.getEmail_receipients();
        
      if(emailID.startsWith(",") || endDate.startsWith(",") || startSate.startsWith(",") || remarks.startsWith(".")){
 			
 			String startDate1=startSate.substring(1);
 			String end=endDate.substring(1);
 			String remarks1=remarks.substring(1);
 			String email1=emailID.substring(1);
 			String eventName=eventEntryBean.getEventName();
 		    String st[]=eventName.split(",");
 		    String newEvName=st[0];
 			 
 	        /*String startSate=eventEntryBean.getStart_date();
 	        String endDate = eventEntryBean.getEnd_date();*/
 	      
 	       /* String emailID=eventEntryBean.getEmail_receipients();*/
 	        model.addAttribute("eventName", newEvName);
 	        model.addAttribute("remarks", remarks1);
 	        model.addAttribute("startSate", startDate1);
 	        model.addAttribute("endDate", end);
 	        
 	        
 	        
 	        CalendarService calService = new CalendarService();
 	       calService.createCalendar(startSate, endDate, eventName, eventEntryBean.getDescription_details(),eventEntryBean.getEngagement_Name(),eventEntryBean.getRisk_summary());
 	        mailService.sendMail(email1,null,newEvName, eventEntryBean.getDescription_details());
 			
 		}else{
 			
 		
        String eventName=eventEntryBean.getEventName();
        
        
        model.addAttribute("eventName", eventName);
        model.addAttribute("remarks", remarks);
        model.addAttribute("startSate", startSate);
        model.addAttribute("endDate", endDate);
        
        
        
        CalendarService calService = new CalendarService();
        calService.createCalendar(startSate, endDate, eventName, eventEntryBean.getDescription_details(),eventEntryBean.getEngagement_Name(),eventEntryBean.getRisk_summary());
        mailService.sendMail(emailID,null,eventName, eventEntryBean.getDescription_details());
        
 		}
        
        List<CalendarBean> evnetCalendarBeanList=new ArrayList<>();
        HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		List<EventEntry> eventList = eventEntryService.findAllEventByResource(userAccountName);
    	//List<EventEntry> eventList = eventEntryService.findAll();
    	for(EventEntry event:eventList){
    		if(event.getEventstatus()!=null && !event.getEventstatus().equalsIgnoreCase("Cancelled"))
	    	{
	    		CalendarBean calendarBean=new CalendarBean();
	    		//eventEntryBean.setEvent_ID(event.getEvent_ID());
	    		calendarBean.setTitle(event.getEventname());
	    		//eventEntryBean.setDescription_details(event.getDescription_details());
	    		calendarBean.setDescription(event.getDescription_details());
	    		calendarBean.setStart(event.getStart_date());
	    		calendarBean.setEnd(event.getEnd_date());
	    		calendarBean.setEngagement(event.getEngagement_Name());
	    		calendarBean.setRemarks(event.getRemarks());
	    		calendarBean.setAdditional_recipients(event.getEmail_receipients1());
	    		//eventEntryBean.setRegion_territory(event.getRegion_territory());
	    		//eventEntryBean.setRisk_summary(event.getRisk_summary());
	    		
	    		
	    		//String[] eventAppSet =new String[event.getEventAppSet().size()];
	    		Set<String> eventAppSet = new HashSet<String>();
	    		int i=0;
	    		
	    		for (EventApplication eventApp : event.getEventAppSet() ) {
	    			
	    			//eventAppSet[i]=eventApp.getApplication();
	    			eventAppSet.add(eventApp.getApplication());
	    			i++;
	    			
	    			/*if(i==0){
	    				eventAppStr.append(eventAppSet[i]);
	    				eventAppStr.append(",");
	    			} else {
	    				eventAppStr.append(eventAppSet[i]);
	    			}*/
	    		}
	    		calendarBean.setEventAppSet(eventAppSet);
	    		
	    		Set<String> eventUserSet = new HashSet<String>();	
	    		//String[] eventUserSet=new String[event.getEventUserSet().size()];
	    		int j=0;
	    		for(EventUser eventUser:event.getEventUserSet()){
	    		//	for(String Username: userService.findByUsername(eventUser))
	    			//eventUserSet[j] = eventUser.getResource();
	    			eventUserSet.add(eventUser.getResource());
	    			j++;
	    		}
	    		calendarBean.setEventUserSet(eventUserSet);
	    		
	    		evnetCalendarBeanList.add(calendarBean);
	    		
	    	}	
	    }
    	
    	Gson gson = new Gson();
    	String calendarJSON=gson.toJson(evnetCalendarBeanList);
    	
    	
      	  model.addAttribute("calendarJSON", calendarJSON);
      	// model.addAttribute("evnetEntryBeanList", evnetCalendarBeanList);
      	model.addAttribute("filePath", dir + File.separator);
      	model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
          return new ModelAndView("viewCalendar");
 
    	
    }
    	   
  //  String saveDirectory = "C:/Bala/apache-tomcat-7.0.37/Uploaded_files/";
    
    @RequestMapping(value = "/addEntry", method = RequestMethod.POST)
    public ModelAndView aaEntry(@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean, BindingResult bindingResult, Model model,
    		final @RequestParam("File_upload") List<MultipartFile> File_upload) 
    {
    	eventEntryValidator.validate(eventEntryBean, bindingResult);
    	List<MultipartFile> files = eventEntryBean.getFile_upload();
    	
    	ModelAndView model1 = new ModelAndView();
    	FileUpload fileUpload = new FileUpload();
    	String fileContent = null;
    	String attachfileName = null;
    	String getEvent_file_name = null;
    	List<String> fileNames = new ArrayList<String>();
        try {
        	if (null != files && files.size() > 0)
            {
        	for (MultipartFile multipartFile : files) {
        		fileContent = fileUpload.process(multipartFile).toString();
        		//String getEvent_upld_fix_content=fileContent;
        		//getEvent_file_name = multipartFile.getOriginalFilename();
                //eventEntryBean.setEvent_file_name(getEvent_file_name);
                //eventEntryBean.setEvent_upld_fix(getEvent_upld_fix_content);
                attachfileName = multipartFile.getOriginalFilename();
                fileNames.add(attachfileName);
            	System.out.print("attachName-------------->>"+attachfileName);
        	}
            }
			model1.addObject("message", fileContent);
			
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        getEvent_file_name = fileNames.toString().replaceAll("[\\[.\\].\\s+]", "");
       
        eventEntryBean.setEvent_file_name(getEvent_file_name);
    	
        if (bindingResult.hasErrors()) {
        	//@PathVariable Long id,
        	 List<String> appList = applicationService.getAppNames();
             List<String> rescList = userService.getResourceNames();
             List<String> catList = categoryService.getCategoryName();
             List<String> eventList = eventEntryServiceMaster.getEventName();
             List<String> regList = regionService.getRegionTerritory();
             List<String> caltypList = calendartypeService.getCalendarTypeName();
             
           
             
     		model.addAttribute("eventEntryBean", eventEntryBean);
            model.addAttribute("eventList", eventList);
            model.addAttribute("appNameList",appList);
            model.addAttribute("rescNameList",rescList);
            model.addAttribute("catgoryList",catList);
            model.addAttribute("regionList",regList);
            model.addAttribute("caltypList",caltypList);
            
           return new ModelAndView("addEntry");
        }        
        HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		eventEntryBean.setAccount_name(userAccountName);
        
		  //will update once UI changes done.
	      
	      /*eventEntryBean.setRecurrence_type("Daily");
	      
	      if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("Daily"))
	      {
	      	eventEntryBean.setRecu_every_day("1");
	      	eventEntryBean.setRecu_every_weekday("MO,TU,WE,TH,FR");
	      }
	      else if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("Weekly"))
	      {
	      	eventEntryBean.setRecu_every_week("1");
	          eventEntryBean.setRecurrence_dayName("MO,TU,WE,TH,FR,SU,SA");
	      }
	      else if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("Monthly"))
	      {
	      	eventEntryBean.setRecu_every_month("1");
	      	eventEntryBean.setRecu_month_day("20");
	      }*/
		  
	      //will update above code once UI changes done.
	      
		
		eventEntryService.saveOther(eventEntryBean);
        String eventName=eventEntryBean.getEventName();
        String remarks=eventEntryBean.getRemarks();
        String startDate=eventEntryBean.getStart_date()+"T"+eventEntryBean.getStart_time();
        String endDate = eventEntryBean.getEnd_date()+"T"+eventEntryBean.getEnd_time();
        String emailID=eventEntryBean.getEmail_receipients();
        String emailID1=eventEntryBean.getEmail_receipients1();  
    				 
        if(emailID != null && emailID1 != null)
        {
			emailid = emailID + "," + emailID1;
		} else {
			
			emailid = emailID;
		}
        
        String file_upload=String.valueOf(eventEntryBean.getFile_upload());
        eventEntryBean.setFile_upload(eventEntryBean.getFile_upload());
        
      if(emailID.startsWith(",") || endDate.startsWith(",") || startDate.startsWith(",") || remarks.startsWith(".")){
 			
 			String startDate1=startDate.substring(1);
 			String end=endDate.substring(1);
 			String remark=remarks.substring(1);
 			String email1=emailID.substring(1);
 			
 			 
 	       /*String startSate=eventEntryBean.getStart_date();
 	        String endDate = eventEntryBean.getEnd_date();*/
 	      
 	       /* String emailID=eventEntryBean.getEmail_receipients();*/
 			eventEntryBean.setFile_upload(eventEntryBean.getFile_upload());
 			model.addAttribute("file_upload", file_upload); 
 	    	
 	        model.addAttribute("eventName", eventName); 
 	       model.addAttribute("remarks", remark);
 	        model.addAttribute("startSate", startDate1);
 	        model.addAttribute("endDate", endDate);
 	        
 	       //emailID,null,eventName, eventEntryBean.getDescription_details()
 	        
 	        CalendarService calService = new CalendarService();
 	       calService.createCalendar(startDate, endDate, eventName, eventEntryBean.getDescription_details(),eventEntryBean.getEngagement_Name(),eventEntryBean.getRisk_summary());
 	        //mailService.sendMail(email1,null,eventName, eventEntryBean.getDescription_details());
 			
 		}else{
 			
 			//model.addAttribute("remarks", remarks);
        model.addAttribute("eventName", eventName);
        model.addAttribute("remarks", remarks);
        model.addAttribute("startSate", startDate);
        model.addAttribute("endDate", endDate);
        
        CalendarService calService = new CalendarService();
        calService.createCalendar(startDate, endDate, eventName, eventEntryBean.getDescription_details(),eventEntryBean.getEngagement_Name(),eventEntryBean.getRisk_summary());
        //mailService.sendMail(emailID,null,eventName, eventEntryBean.getDescription_details());
        
 		}
   
    	/* Email code starts here */
        SimpleDateFormat dateParser = new SimpleDateFormat( "yyyy-MM-dd'T'HH:mm" ) ;

        try {
      	  mailService.sendInvitation( "DL IN NATools_Support"
    		                       , new String[] {emailid
    		                                      }
    		                       , eventEntryBean.getEventName()
    		                       /*, dateParser.parse( "28-08-2006 18:00" )
    		                       , dateParser.parse( "28-08-2006 21:00" )*/
    		                       /*, eventEntryBean.getRecurrence()*/
    		                       , dateParser.parse(eventEntryBean.getStart_date()+"T"+eventEntryBean.getStart_time())
    		                       , dateParser.parse(eventEntryBean.getEnd_date()+"T"+eventEntryBean.getEnd_time())
    		                       
    		                       , eventEntryBean.getRecurrence_type()
    		                       
    		                       , eventEntryBean.getRecu_every_day()
    		                       , eventEntryBean.getRecu_every_weekday()
    		                       
    		                       , eventEntryBean.getRecu_every_week()
    		                       , eventEntryBean.getRecurrence_dayName()
    		                       
    		                       , eventEntryBean.getRecu_every_month()
    		                       , eventEntryBean.getRecu_month_day()
    		                       , eventEntryBean.getMonthdd1()
    		                       , eventEntryBean.getMonthdd2()
    		                       , eventEntryBean.getMonthtext1()
    		                       , eventEntryBean.getRecu_month_day_radio()
    		                       , "LIS-42"
    		                       , "TBD"
    		                       /*, "<font color=\"Black\">"+eventEntryBean.getDescription_details()+"</font>"*/
    		                       , "<body bgcolor='#E6E6FA'> <table align='center' border='2' ><tr><td>EventName :</td><td><font color=\"Blue\">" + eventEntryBean.getEventName() + "</font></td></tr>"+
   			           					"<tr><td>Description_details :</td><td><font color=\"Blue\">" + eventEntryBean.getDescription_details() + "</font></td></tr>"+
   			                   			"<tr><td>Category Name :</td><td><font color=\"Blue\">" + eventEntryBean.getEvent_category_Name() + "</font></td></tr>"+
   			                   			"<tr><td>Engagement Name :</td><td><font color=\"Blue\">" + eventEntryBean.getEngagement_Name() + "</font></td></tr>"+
   			        					"<tr><td>Risk Summary :</td><td><font color=\"Blue\">" + eventEntryBean.getRisk_summary() + "</font></td></tr>"+
   			        					"<tr><td>Region territory :</td><td><font color=\"Blue\">" + eventEntryBean.getEventName() + "</font></td></tr></table></body>",getEvent_file_name
    		                       ) ;
    	} catch (ParseException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	} catch (Exception e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	}
        
        /* Email code ends here */
      
      /* Email code ends here */
        
        List<CalendarBean> evnetCalendarBeanList=new ArrayList<>();
		List<EventEntry> eventList = eventEntryService.findAllEventByResource(userAccountName);
    	
		//List<EventEntry> eventList = eventEntryService.findAll();
    	for(EventEntry event:eventList){
    		if(event.getEventstatus()!=null && !event.getEventstatus().equalsIgnoreCase("Cancelled"))
	    	{
	    		CalendarBean calendarBean=new CalendarBean();
	    		//eventEntryBean.setEvent_ID(event.getEvent_ID());
	    		calendarBean.setTitle(event.getEventname());
	    		//eventEntryBean.setDescription_details(event.getDescription_details());
	    		calendarBean.setDescription(event.getDescription_details());
	    		calendarBean.setStart(event.getStart_date());
	    		calendarBean.setEnd(event.getEnd_date());
	    		calendarBean.setEngagement(event.getEngagement_Name());
	    		calendarBean.setRemarks(event.getRemarks());
	    		calendarBean.setAdditional_recipients(event.getEmail_receipients1());
	    		
	    		//eventEntryBean.setRegion_territory(event.getRegion_territory());
	    		//eventEntryBean.setRisk_summary(event.getRisk_summary());
	    		
	    		
	    		Set<String> eventAppSet = new HashSet<String>();
	    		int i=0;
	    		
	    		for (EventApplication eventApp : event.getEventAppSet() ) {
	    			
	    			//eventAppSet[i]=eventApp.getApplication();
	    			eventAppSet.add(eventApp.getApplication());
	    			i++;
	    			
	    			/*if(i==0){
	    				eventAppStr.append(eventAppSet[i]);
	    				eventAppStr.append(",");
	    			} else {
	    				eventAppStr.append(eventAppSet[i]);
	    			}*/
	    		}
	    		calendarBean.setEventAppSet(eventAppSet);
	    		
	    		Set<String> eventUserSet = new HashSet<String>();	
	    		//String[] eventUserSet=new String[event.getEventUserSet().size()];
	    		int j=0;
	    		for(EventUser eventUser:event.getEventUserSet()){
	    		//	for(String Username: userService.findByUsername(eventUser))
	    			//eventUserSet[j] = eventUser.getResource();
	    			eventUserSet.add(eventUser.getResource());
	    			j++;
	    		}
	    		calendarBean.setEventUserSet(eventUserSet);
	    		
	    		evnetCalendarBeanList.add(calendarBean);
	    		
	    	}	
	    }
    	
    	Gson gson = new Gson();
    	String calendarJSON=gson.toJson(evnetCalendarBeanList);	
      model.addAttribute("calendarJSON", calendarJSON);
      	// model.addAttribute("evnetEntryBeanList", evnetCalendarBeanList);
      model.addAttribute("filePath", dir + File.separator);
      model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
          return new ModelAndView("viewCalendar");
   	
    }
    
    /*@RequestMapping(value = "/spellCheck", method = RequestMethod.POST)
    public ModelAndView spellCheck(@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean, BindingResult bindingResult, Model model) 
    {
    	SpellCheckExample checkExample = new SpellCheckExample();
    	HashMap<Object, List> suggestions2 = checkExample.SpellCheckExample(eventEntryBean.getDescription_details());
    	HashMap suggestions = new HashMap<>();
    	List<String> values = new ArrayList<>();
    	values.add("vara");
    	values.add("satya");
    	suggestions.put("satya", values);
    	suggestions.put("vara", values);
    	model.addAttribute("eventDescDetails", values);
    	return new ModelAndView("addEntry");
    }*/
    
    @RequestMapping(value = "/spellCheck", headers = "Accept=*/*", method = RequestMethod.GET)
    public @ResponseBody String spellCheck(@RequestParam(value = "descDetails", required = true) String descDetails,Model model) throws IllegalStateException {
       
    	SpellCheckExample checkExample = new SpellCheckExample();
    	HashMap<String, List<String>> suggestions2 = checkExample.SpellCheckExample(descDetails);
    	model.addAttribute("descDetailsHidden",descDetails);
    	HashMap suggestions = new HashMap<>();
    	List<String> values = new ArrayList<>();
    	values.add("vara");
    	values.add("satya");
    	suggestions.put("satya", values);
    	suggestions.put("vara", values);
    	Gson gson = new Gson();   
    	String sugession = gson.toJson(suggestions2);
    	model.addAttribute("eventDescDetails", sugession);

    	return sugession;
    }

    
    @RequestMapping(value = "/editEntryMasterPopulate", method = RequestMethod.POST)
    public ModelAndView editEntryMasterPopulate(@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean, BindingResult bindingResult, Model model,
    		final @RequestParam("File_upload") List<MultipartFile> File_upload) 
    {
    	SpellCheckExample checkExample = new SpellCheckExample();
    	HashMap<String, List<String>> suggestions = checkExample.SpellCheckExample(eventEntryBean.getDescription_details());
    	
    	if(com.mysql.jdbc.StringUtils.isNullOrEmpty(eventEntryBean.getEventNameOthers()))
    	{
    		if(eventEntryBean.getEvent_ID() != null)
    		{
    			EventEntryMaster eventEntry = eventEntryServiceMaster.findById(eventEntryBean.getEvent_ID());
        		if(eventEntry.getEventname() != null)
        		{
        			eventEntryBean.setEventName(eventEntry.getEventname());
        		}
    		}
    		
    	} else {
    		eventEntryBean.setEventName(eventEntryBean.getEventNameOthers());
    	}
    	
    	if(!(eventEntryBean.getHiddenuser().length <= 0))
    	{
    		eventEntryBean.setEventUserSet(eventEntryBean.getHiddenuser());	
    	}    	
    	eventEntryValidator.validate(eventEntryBean, bindingResult);
    	
    	if (bindingResult.hasErrors()) {
        	System.out.println("@@@@@@@@@@@@@@@@@@@@@@inside bindingResult@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        	//@PathVariable Long id,
        	 List<String> appList = applicationService.getAppNames();
             List<String> rescList = userService.getResourceNames();
             List<String> catList = categoryService.getCategoryName();
             HttpSession httpSession = httpServletRequest.getSession();
             String userAccountName = (String) httpSession.getAttribute("userAcctName");
             List<String> eventList = eventEntryServiceMaster.getEventNameByAcctName(userAccountName);
             List<String> regList = regionService.getRegionTerritory();
             List<String> caltypList = calendartypeService.getCalendarTypeName();
             List<String> accList = accountService.getAccountNames();
        	
            model.addAttribute("eventList", eventList);
            model.addAttribute("appNameList",appList);
            model.addAttribute("rescNameList",rescList);
            model.addAttribute("catgoryList",catList);
            model.addAttribute("regionList",regList);
            model.addAttribute("caltypList",caltypList);
            model.addAttribute("accountList",accList);
            model.addAttribute("eventAppSet",eventEntryBean.getEventAppSet());
            model.addAttribute("eventUserSet",eventEntryBean.getEventUserSet());
            List<HashMap<String, String>> listMastp=  applicationService.getPriAndSecResourceName();          
            Gson gson = new Gson();
            String applicationEventJson = gson.toJson(listMastp);   
            model.addAttribute("eventEntryJsonStr",applicationEventJson);
            
          //added code start for Recurrence 
      		
      		/*eventEntryBean.setRecu_every_day(event.getRecu_every_day());
      		eventEntryBean.setRecu_every_month(event.getRecu_every_month());
      		eventEntryBean.setRecu_every_week(event.getRecu_every_week());
      		eventEntryBean.setRecu_every_weekday(event.getRecu_every_weekday());
      		eventEntryBean.setRecu_every_weekday_radio(event.getRecu_every_weekday());
      		
      		eventEntryBean.setRecu_month_day(event.getRecu_month_day());
      		eventEntryBean.setRecurrence_dayName(event.getRecurrence_dayName());
      		eventEntryBean.setRecurrence_type(event.getRecurrence_type());*/
      		if(eventEntryBean.getRecurrence_dayName() != null)
      		{
      			List<String> recurrence_dayNameList = new ArrayList<String>(Arrays.asList(eventEntryBean.getRecurrence_dayName().split(",")));
      	        String recurrence_dayNamesJson = gson.toJson(recurrence_dayNameList);
      	        model.addAttribute("recurrence_dayNamesJson", recurrence_dayNamesJson);
      		}
      		model.addAttribute("eventEntryBean", eventEntryBean);
            
            return new ModelAndView("addEntry");
        }

    	
    	if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("weekly") && eventEntryBean.getRecu_every_week().equalsIgnoreCase(""))
    	{
    		   	 model.addAttribute("recerrorMsg","Please provide the Recur every week");
    		   	 model.addAttribute("recType","weekly");
    			 List<String> appList = applicationService.getAppNames();
                 List<String> rescList = userService.getResourceNames();
                 List<String> catList = categoryService.getCategoryName();
                 HttpSession httpSession = httpServletRequest.getSession();
                 String userAccountName = (String) httpSession.getAttribute("userAcctName");
                 List<String> eventList = eventEntryServiceMaster.getEventNameByAcctName(userAccountName);
                 List<String> regList = regionService.getRegionTerritory();
                 List<String> caltypList = calendartypeService.getCalendarTypeName();
                 List<String> accList = accountService.getAccountNames();
                model.addAttribute("eventEntryBean", eventEntryBean);
                model.addAttribute("eventList", eventList);
                model.addAttribute("appNameList",appList);
                model.addAttribute("rescNameList",rescList);
                model.addAttribute("catgoryList",catList);
                model.addAttribute("regionList",regList);
                model.addAttribute("caltypList",caltypList);
                model.addAttribute("accountList",accList);
                model.addAttribute("eventAppSet",eventEntryBean.getEventAppSet());
                model.addAttribute("eventUserSet",eventEntryBean.getEventUserSet());
                List<HashMap<String, String>> listMastp=  applicationService.getPriAndSecResourceName();          
                Gson gson = new Gson();
                String applicationEventJson = gson.toJson(listMastp);   
                model.addAttribute("eventEntryJsonStr",applicationEventJson);
               return new ModelAndView("addEntry");
               
    	}
    	if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("weekly") && !eventEntryBean.getRecu_every_week().equalsIgnoreCase("") && eventEntryBean.getRecurrence_dayName() == null)
    	{
    		   model.addAttribute("recDayerrorMsg","Please Select atleast a day");
    		   model.addAttribute("recType","weekly");
    		   List<String> appList = applicationService.getAppNames();
               List<String> rescList = userService.getResourceNames();
               List<String> catList = categoryService.getCategoryName();
               HttpSession httpSession = httpServletRequest.getSession();
               String userAccountName = (String) httpSession.getAttribute("userAcctName");
               List<String> eventList = eventEntryServiceMaster.getEventNameByAcctName(userAccountName);
               List<String> regList = regionService.getRegionTerritory();
               List<String> caltypList = calendartypeService.getCalendarTypeName();
               List<String> accList = accountService.getAccountNames();
       		  model.addAttribute("eventEntryBean", eventEntryBean);
              model.addAttribute("eventList", eventList);
              model.addAttribute("appNameList",appList);
              model.addAttribute("rescNameList",rescList);
              model.addAttribute("catgoryList",catList);
              model.addAttribute("regionList",regList);
              model.addAttribute("caltypList",caltypList);
              model.addAttribute("accountList",accList);
              model.addAttribute("eventAppSet",eventEntryBean.getEventAppSet());
              model.addAttribute("eventUserSet",eventEntryBean.getEventUserSet());
              List<HashMap<String, String>> listMastp=  applicationService.getPriAndSecResourceName();          
              Gson gson = new Gson();
              String applicationEventJson = gson.toJson(listMastp);   
              model.addAttribute("eventEntryJsonStr",applicationEventJson);
              return new ModelAndView("addEntry");
    	}
    	
    	ModelAndView model1 = new ModelAndView();
    	FileUpload fileUpload = new FileUpload();
    	String fileContent = null;
    	String attachfileName = null;
    	String getEvent_file_name = null;
    	List<String> fileNames = new ArrayList<String>();
        try {
        	for (MultipartFile multipartFile : File_upload) {
        		fileContent = fileUpload.process(multipartFile).toString();
                attachfileName = multipartFile.getOriginalFilename();
                fileNames.add(attachfileName);
            	System.out.print("attachName-------------->>"+attachfileName);
        	}
        	
			model1.addObject("message", fileContent);
			
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        getEvent_file_name = fileNames.toString().replaceAll("[\\[\\]+]", "");
        eventEntryBean.setEvent_file_name(getEvent_file_name);
    	
    	
    	if(!com.mysql.jdbc.StringUtils.isNullOrEmpty(eventEntryBean.getRegion_territory())){
    		eventEntryBean.setRegion_id(String.valueOf(regionService.findByRegionTerritory(eventEntryBean.getRegion_territory()).getRegion_id()));
    	}
    	
    	if(!com.mysql.jdbc.StringUtils.isNullOrEmpty(eventEntryBean.getRegion_territory())){
    		eventEntryBean.setCalendar_type_id(calendartypeService.findByCalendarTypeName(eventEntryBean.getCalendar_type_name()).getCalendar_type_id());
    	}
    	
    	System.out.println("%%%%%%%%%%%%%%%%inside editEntryMasterPopulate%%%%%%%%%%%%%%%%%%%%%%%%%%%% ");
    	
        
        /*HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");*/
		eventEntryBean.setAccount_name(eventEntryBean.getEngagement_Name());
		
		//will update the below code once UI changes done.
	      
		  /*eventEntryBean.setRecurrence_type("Daily");
	      
	      if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("Daily"))
	      {
	      	eventEntryBean.setRecu_every_day("1");
	      	eventEntryBean.setRecu_every_weekday("MO,TU,WE,TH,FR");
	      }
	      else if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("Weekly"))
	      {
	      	eventEntryBean.setRecu_every_week("1");
	          eventEntryBean.setRecurrence_dayName("MO,TU,WE,TH,FR,SA,SU");
	      }
	      else if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("Monthly"))
	      {
	      	eventEntryBean.setRecu_every_month("1");
	      	eventEntryBean.setRecu_month_day("20");
	      }*/
	      //will update above code once UI changes done.
		
		eventEntryService.saveOther(eventEntryBean);
        
		List<CalendarBean> evnetCalendarBeanList=new ArrayList<>();
        List<EventEntry> eventList = eventEntryService.findAllEventByResource(eventEntryBean.getAccount_name());
		
      		//List<EventEntry> eventList = eventEntryService.findAll();
          	for(EventEntry event:eventList){
          		if(event.getEventstatus()!=null && !event.getEventstatus().equalsIgnoreCase("Cancelled"))
	          		{
	          		CalendarBean calendarBean=new CalendarBean();
	          		//eventEntryBean.setEvent_ID(event.getEvent_ID());
	          		calendarBean.setTitle(event.getEventname());
	          		//eventEntryBean.setDescription_details(event.getDescription_details());
	          		calendarBean.setDescription(event.getDescription_details());
	          		calendarBean.setStart(event.getStart_date());
	          		calendarBean.setEnd(event.getEnd_date());
	          		calendarBean.setEngagement(event.getEngagement_Name());
	          		calendarBean.setRemarks(event.getRemarks());
	          		calendarBean.setAdditional_recipients(event.getEmail_receipients1());
	          		//eventEntryBean.setRegion_territory(event.getRegion_territory());
	          		//eventEntryBean.setRisk_summary(event.getRisk_summary());
	          		
	          		
	          		Set<String> eventAppSet = new HashSet<String>();
	          		int i=0;
	          		
	          		for (EventApplication eventApp : event.getEventAppSet() ) {
	          			
	          			//eventAppSet[i]=eventApp.getApplication();
	          			eventAppSet.add(eventApp.getApplication());
	          			i++;
	          			
	          			/*if(i==0){
	          				eventAppStr.append(eventAppSet[i]);
	          				eventAppStr.append(",");
	          			} else {
	          				eventAppStr.append(eventAppSet[i]);
	          			}*/
	          		}
	          		calendarBean.setEventAppSet(eventAppSet);
	          		
	          		Set<String> eventUserSet = new HashSet<String>();	
	          		//String[] eventUserSet=new String[event.getEventUserSet().size()];
	          		int j=0;
	          		for(EventUser eventUser:event.getEventUserSet()){
	          		//	for(String Username: userService.findByUsername(eventUser))
	          			//eventUserSet[j] = eventUser.getResource();
	          			eventUserSet.add(eventUser.getResource());
	          			j++;
	          		}
	          		
	          		 // create an iterator
	          		   Iterator iterator = eventUserSet.iterator(); 
	          		      
	          		   // check values
	          		   while (iterator.hasNext()){
	          		   System.out.println("Value:---------------------> "+iterator.next()+"<---------------------------- ");  
	          		   }
	          		   
	          		   System.out.println("eventUserSet Value:------> "+eventUserSet+ "<------ ");  
	          		
	          		calendarBean.setEventUserSet(eventUserSet);
	          		  System.out.println("calendarBean Value:------> "+calendarBean+ "<------ ");  
	          		
	          		evnetCalendarBeanList.add(calendarBean);
	          	}	
	          }
          	
          	Gson gson = new Gson();
          	String calendarJSON=gson.toJson(evnetCalendarBeanList);
          	
        System.out.println("--------------------after eventEntryService--------------------- ");

        /*String start_dt = eventEntryBean.getStart_date();
        String end_dt =  eventEntryBean.getEnd_date();*/
        
       // securityService.autologin(userForm.getUsername(), userForm.getPasswordConfirm());

        //eventEntryBean.setRemarks(eventEntryBean.getRemarks());
        String remarks=eventEntryBean.getRemarks();
        String eventName=eventEntryBean.getEventNameOthers();
        String startSate=eventEntryBean.getStart_date()+"T"+eventEntryBean.getStart_time();
        String endDate = eventEntryBean.getEnd_date()+"T"+eventEntryBean.getEnd_time();
        String emailID=eventEntryBean.getEmail_receipients();
        String emailID1=eventEntryBean.getEmail_receipients1();  
    		 
        if(emailID != null && emailID1 != null)
        {
			emailid = emailID + "," + emailID1;
		} else {
			
			emailid = emailID;
		}
        
               
      if(emailID.startsWith(",") || endDate.startsWith(",") || startSate.startsWith(",") || remarks.startsWith(",")){
 			
 			String startDate1=startSate.substring(1);
 			String end=endDate.substring(1);
 			
 		
 			 
 	       /*String startSate=eventEntryBean.getStart_date();
 	        String endDate = eventEntryBean.getEnd_date();*/
 	      
 	       /* String emailID=eventEntryBean.getEmail_receipients();*/
 			// model.addAttribute("regionList",regList);
 	        model.addAttribute("eventName", eventName); 
 	        model.addAttribute("remarks", remarks);
 	        model.addAttribute("startSate", startDate1);
 	        model.addAttribute("endDate", endDate);
 	        
 	       //emailID,null,eventName, eventEntryBean.getDescription_details()
 	        
 	        CalendarService calService = new CalendarService();
 	       calService.createCalendar(startSate, endDate, eventName, eventEntryBean.getDescription_details(),eventEntryBean.getEngagement_Name(),eventEntryBean.getRisk_summary());
 	        //mailService.sendMail(email1,null,eventName, eventEntryBean.getDescription_details());
 			
 		}else{
 			
 			model.addAttribute("remarks", remarks);
        model.addAttribute("eventName", eventName);
        model.addAttribute("startSate", startSate);
        model.addAttribute("endDate", endDate);
        
        
        
        CalendarService calService = new CalendarService();
        calService.createCalendar(startSate, endDate, eventName, eventEntryBean.getDescription_details(),eventEntryBean.getEngagement_Name(),eventEntryBean.getRisk_summary());
        //mailService.sendMail(emailID,null,eventName, eventEntryBean.getDescription_details());
        
 		}
      /* Email code starts here */
      /*SimpleDateFormat dateParser = new SimpleDateFormat( "yyyy-MM-dd'T'HH:mm" ) ;

      try {
    	  mailService.sendInvitation( "DL IN NATools_Support"
		                       , new String[] { eventEntryBean.getEmail_receipients()
		                                      }
		                       , eventEntryBean.getEventName()
		                       , dateParser.parse( "28-08-2006 18:00" )
		                       , dateParser.parse( "28-08-2006 21:00" )
		                       , dateParser.parse(eventEntryBean.getStart_date())
		                       , dateParser.parse(eventEntryBean.getEnd_date())
		                       , "LIS-42"
		                       , "TBD"
		                       , "<body bgcolor='#E6E6FA'> <table align='center' border='2' ><tr><td>EventName :</td><td><font color=\"Blue\">" + eventEntryBean.getEventName() + "</font></td></tr>"+
			           					"<tr><td>Description_details :</td><td><font color=\"Blue\">" + eventEntryBean.getDescription_details() + "</font></td></tr>"+
			                   			"<tr><td>Category Name :</td><td><font color=\"Blue\">" + eventEntryBean.getEvent_category_Name() + "</font></td></tr>"+
			                   			"<tr><td>Engagement Name :</td><td><font color=\"Blue\">" + eventEntryBean.getEngagement_Name() + "</font></td></tr>"+
			        					"<tr><td>Risk Summary :</td><td><font color=\"Blue\">" + eventEntryBean.getRisk_summary() + "</font></td></tr>"+
			        					"<tr><td>Region territory :</td><td><font color=\"Blue\">" + eventEntryBean.getEventName() + "</font></td></tr></table></body>",attachfileName
			        					);

	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}*/
  	
      
      
  	/* Email code starts here */
    SimpleDateFormat dateParser = new SimpleDateFormat( "yyyy-MM-dd'T'HH:mm" ) ;

    try {
  	  mailService.sendInvitation( "DL IN NATools_Support"
		                       , new String[] { emailid
		                                      }
		                       , eventEntryBean.getEventName()
		                       /*, eventEntryBean.getRecurrence()*/
		                       /*, dateParser.parse( "28-08-2006 18:00" )
		                       , dateParser.parse( "28-08-2006 21:00" )*/
		                       , dateParser.parse(eventEntryBean.getStart_date()+"T"+eventEntryBean.getStart_time())
		                       , dateParser.parse(eventEntryBean.getEnd_date()+"T"+eventEntryBean.getEnd_time())
		                       , eventEntryBean.getRecurrence_type()
		                       
		                       , eventEntryBean.getRecu_every_day()
		                       , eventEntryBean.getRecu_every_weekday()
		                       
		                       , eventEntryBean.getRecu_every_week()
		                       , eventEntryBean.getRecurrence_dayName()
		                       
		                       , eventEntryBean.getRecu_every_month()
		                       , eventEntryBean.getRecu_month_day()
		                       , eventEntryBean.getMonthdd1()
		                       , eventEntryBean.getMonthdd2()
		                       , eventEntryBean.getMonthtext1()
		                       , eventEntryBean.getRecu_month_day_radio()
		                       , "LIS-42"
		                       , "TBD"
		                       /*, "<font color=\"Black\">"+eventEntryBean.getDescription_details()+"</font>"*/
		                       , "<body bgcolor='#E6E6FA'> <table align='center' border='2' ><tr><td>EventName :</td><td><font color=\"Blue\">" + eventEntryBean.getEventName() + "</font></td></tr>"+
			           					"<tr><td>Description_details :</td><td><font color=\"Blue\">" + eventEntryBean.getDescription_details() + "</font></td></tr>"+
			                   			"<tr><td>Category Name :</td><td><font color=\"Blue\">" + eventEntryBean.getEvent_category_Name() + "</font></td></tr>"+
			                   			"<tr><td>Engagement Name :</td><td><font color=\"Blue\">" + eventEntryBean.getEngagement_Name() + "</font></td></tr>"+
			        					"<tr><td>Risk Summary :</td><td><font color=\"Blue\">" + eventEntryBean.getRisk_summary() + "</font></td></tr>"+
			        					"<tr><td>Region territory :</td><td><font color=\"Blue\">" + eventEntryBean.getEventName() + "</font></td></tr></table></body>",getEvent_file_name
		                       
		                       ) ;
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    
    /* Email code ends here */
      
      /* Email code ends here */
        
      
    	
      	  model.addAttribute("calendarJSON", calendarJSON);
      	model.addAttribute("calendarid", "Consolidated");  
      	
      	Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        model.addAttribute("userRoleName", auth.getAuthorities());
      	  
        // model.addAttribute("evnetEntryBeanList", evnetCalendarBeanList);
      	model.addAttribute("filePath", dir + File.separator);
      	model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
          return new ModelAndView("viewCalendar");
 
    }
    
    
    @RequestMapping(value = "/viewEntry", method = RequestMethod.GET)
    public ModelAndView viewEntry(Model model) 
    {
       
    	List<EventEntryBean> evnetEntryBeanList=new ArrayList<>();
    	HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		List<EventEntry> eventList = eventEntryService.findAllEventByResource(userAccountName);
    	for(EventEntry event:eventList){
    		if(event.getEventstatus()!=null && !event.getEventstatus().equalsIgnoreCase("Cancelled"))
	    	{
	    		EventEntryBean eventEntryBean=new EventEntryBean();
	    		eventEntryBean.setEvent_ID(event.getEvent_ID());
	    		eventEntryBean.setEventName(event.getEventname());
	    		eventEntryBean.setDescription_details(event.getDescription_details());
	    		eventEntryBean.setStart_date(event.getStart_date());
	    		eventEntryBean.setEnd_date(event.getEnd_date());
	    		//eventEntryBean.setRegion_territory(event.getRegion_territory());
	    		eventEntryBean.setRisk_summary(event.getRisk_summary());
	    		eventEntryBean.setRemarks(event.getRemarks());
	    		if(event.getEvent_file_name() != null) 
	    		{
		    		List<String> fileNameList = Arrays.asList(event.getEvent_file_name().split("\\s*,\\s*"));
		    		eventEntryBean.setEvent_list(fileNameList);
	    		}
	    		//eventEntryBean.setEvent_file_name(event.getEvent_file_name());
	    		//eventEntryBean.setEvent_upld_fix(event.getEvent_upld_fix());
	    		
	    		Region region = regionService.findByRegionId(event.getRegion_id());
				
	            if(region!=null)
	            {
	            	eventEntryBean.setRegion_territory(region.getRegion_territory());
	            }
	    		
	           	Category category=categoryService.findByCategoryId(event.getEvent_category_id());
	    		//System.out.print(category);
	    		
	    		if(category!=null){
	    			eventEntryBean.setEvent_category_Name(category.getEvent_category_name());
	    		}
	    		
	    		String[] eventAppSet =new String[event.getEventAppSet().size()];
	    		int i=0;
	    		
	    		for (EventApplication eventApp : event.getEventAppSet() ) {
	    			
	    			eventAppSet[i]=eventApp.getApplication();
	    			i++;
	    			
	
	    			/*if(i==0){
	    				eventAppStr.append(eventAppSet[i]);
	    				eventAppStr.append(",");
	    			} else {
	    				eventAppStr.append(eventAppSet[i]);
	    			}*/
	    		}
	    		eventEntryBean.setEventAppSet(eventAppSet);
	    		
	    		String[] eventUserSet=new String[event.getEventUserSet().size()];
	    		int j=0;
	    		for(EventUser eventUser:event.getEventUserSet()){
	    			//for(String Username: userService.findByUsername(eventUser))
	    			eventUserSet[j] = eventUser.getResource();
	    			j++;
	    		}
	    		eventUserSet = Arrays.stream(eventUserSet)
	                    .filter(s -> (s != null && s.length() > 0))
	                    .toArray(String[]::new);
	    		
	    		Set<String> userSet = new HashSet<String>(Arrays.asList(eventUserSet));    		
	    		eventUserSet= userSet.toArray(new String[userSet.size()]);
	    		String eventUsersString = String.join(",", eventUserSet);
	    		eventEntryBean.setEventUsers(eventUsersString);
	      		eventEntryBean.setEventUserSet(eventUserSet);
	    		eventEntryBean.setEmail_receipients(event.getAdditional_receipients());
	    		eventEntryBean.setEngagement_Name(event.getEngagement_Name());
	    		evnetEntryBeanList.add(eventEntryBean);
	    	}
    	}
    	
    	 
    /*	List<CalendarBean> evnetCalendarBeanList=new ArrayList<>();
		List<EventEntry> eventList1 = eventEntryService.findAll();
    	for(EventEntry event:eventList){
    		CalendarBean calendarBean=new CalendarBean();
    		//eventEntryBean.setEvent_ID(event.getEvent_ID());
    		calendarBean.setTitle(event.getEventname());
    		//eventEntryBean.setDescription_details(event.getDescription_details());
    		calendarBean.setDescription(event.getDescription_details());
    		calendarBean.setStart(event.getStart_date());
    		calendarBean.setEnd(event.getEnd_date());
    		calendarBean.setEngagement(event.getEngagement_Name());
    		//eventEntryBean.setRegion_territory(event.getRegion_territory());
    		//eventEntryBean.setRisk_summary(event.getRisk_summary());
    		
    		String[] eventAppSet =new String[event.getEventAppSet().size()];
    		int i=0;
    		
    		for (EventApplication eventApp : event.getEventAppSet() ) {
    			
    			eventAppSet[i]=eventApp.getApplication();
    			i++;
    			
    			/*if(i==0){
    				eventAppStr.append(eventAppSet[i]);
    				eventAppStr.append(",");
    			} else {
    				eventAppStr.append(eventAppSet[i]);
    			}
    		}
    		calendarBean.setEventAppSet(eventAppSet);
    		
    		String[] eventUserSet=new String[event.getEventUserSet().size()];
    		int j=0;
    		for(EventUser eventUser:event.getEventUserSet()){
    			/*for(String Username: userService.findByUsername(eventUser))
    			eventUserSet[j] = eventUser.getResource();
    			j++;
    		}
    		calendarBean.setEventUserSet(eventUserSet);
    		
    		evnetCalendarBeanList.add(calendarBean);
    		
    	}
    	
    	
    	Gson gson = new Gson();
    	String calendarJSON=gson.toJson(evnetCalendarBeanList);
    	
    	
      	  model.addAttribute("calendarJSON", calendarJSON);
      	// model.addAttribute("evnetEntryBeanList", evnetCalendarBeanList);*/
    	
    	model.addAttribute("evnetEntryBeanList", evnetEntryBeanList);
		model.addAttribute("filePath", dir + File.separator);
    	model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
          return new ModelAndView("viewEntry");
 
    	
    }

    @RequestMapping(value="/editEntry/{id}" ,method = RequestMethod.GET)
    public ModelAndView editEntry(@PathVariable Long id,@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean, BindingResult bindingResult, Model model) throws java.text.ParseException 
    {
		
    	EventEntry event=eventEntryService.findById(id);
    	
    	eventEntryBean.setEvent_ID(event.getEvent_ID());
		eventEntryBean.setEventName(event.getEventname());
		eventEntryBean.setDescription_details(event.getDescription_details());
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		
		Date theStartDate = format.parse(event.getStart_date());
		Calendar startCal = Calendar.getInstance();
	    startCal.setTime(theStartDate);
	    
	    String pattern = "yyyy-MM-dd";
	    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
	    String pattern2 = "HH:mm:ss";
	    SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat(pattern2);
	    
	    String startDate = simpleDateFormat.format(startCal.getTime());
	    eventEntryBean.setStart_date(startDate);
	    
	    String startTime = simpleDateFormat2.format(startCal.getTime());
	    eventEntryBean.setStart_time(startTime);
		
	    Date theEndDate = format.parse(event.getEnd_date());
		Calendar endCal = Calendar.getInstance();
	    endCal.setTime(theEndDate);
	    
	    String endDate = simpleDateFormat.format(endCal.getTime());
	    eventEntryBean.setEnd_date(endDate);
	    
	    String endTime = simpleDateFormat2.format(endCal.getTime());
	    eventEntryBean.setEnd_time(endTime);
		
		eventEntryBean.setEmail_receipients(event.getAdditional_receipients());
		eventEntryBean.setEmail_receipients1(event.getEmail_receipients1());
		eventEntryBean.setEngagement_Name(event.getEngagement_Name());
		//eventEntryBean.setRegion_territory(event.getRegion_territory());
		eventEntryBean.setRisk_summary(event.getRisk_summary());
		CalendarType calType = calendartypeService.findByCalendarTypeId(event.getCalendar_type_id());
		if(calType != null && calType.getCalendar_type_id() != null)
		eventEntryBean.setCalendar_type_name(calType.getCalendar_type_name());
		eventEntryBean.setRemarks(event.getRemarks());
		eventEntryBean.setEvent_file_name(event.getEvent_file_name());
		if(event.getEvent_file_name() != null) 
		{
    		List<String> fileNameList = Arrays.asList(event.getEvent_file_name().split("\\s*,\\s*"));
    		eventEntryBean.setEvent_list(fileNameList);
		}
		eventEntryBean.setEvent_upld_fix(event.getEvent_upld_fix());
		
		Region region = regionService.findByRegionId(event.getRegion_id());
		
        if(region!=null)
        {
        	eventEntryBean.setRegion_territory(region.getRegion_territory());
        }
		
		Category category=categoryService.findByCategoryId(event.getEvent_category_id());
		
		if(category!=null){
			eventEntryBean.setEvent_category_Name(category.getEvent_category_name());
		}
		
		String[] eventAppSet =new String[event.getEventAppSet().size()];
		int i=0;
		
		for (EventApplication eventApp : event.getEventAppSet() ) {
			
			eventAppSet[i]=eventApp.getApplication();
			i++;
			
		}
		eventEntryBean.setEventAppSet(eventAppSet);
		
		String[] eventUserSet=new String[event.getEventUserSet().size()];
  		int j=0;
  		for(EventUser eventUser:event.getEventUserSet()){
  			
  			eventUserSet[j] = eventUser.getResource();
  			j++;
  		}
  		
  		eventEntryBean.setEventUserSet(eventUserSet);
  		
  		/*String s1 = eventEntryBean.getStart_date();
  		String s2 = eventEntryBean.getEnd_date();
  		Date d = null;
  		Date d1 = null;
		try {
			d = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")).parse(s1);
			d1 = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")).parse(s2);
		} catch (java.text.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  		String convStartDate = (new SimpleDateFormat("yyyy-MM-dd'T'HH:mm")).format(d);
  		String convEndDate = (new SimpleDateFormat("yyyy-MM-dd'T'HH:mm")).format(d1);
  		
  		eventEntryBean.setStart_date(convStartDate);
  		eventEntryBean.setEnd_date(convEndDate);
  		*/
  		
  		//added code start for Recurrence 
  		
  		eventEntryBean.setRecu_every_day(event.getRecu_every_day());
  		eventEntryBean.setRecu_every_month(event.getRecu_every_month());
  		eventEntryBean.setRecu_every_week(event.getRecu_every_week());
  		eventEntryBean.setRecu_every_weekday(event.getRecu_every_weekday());
  		eventEntryBean.setRecu_every_weekday_radio(event.getRecu_every_weekday());
  		
  		eventEntryBean.setRecu_month_day(event.getRecu_month_day());
  		eventEntryBean.setRecurrence_dayName(event.getRecurrence_dayName());
  		eventEntryBean.setRecurrence_type(event.getRecurrence_type());
  		eventEntryBean.setMonthdd1(event.getMonthdd1());
  		eventEntryBean.setMonthdd2(event.getMonthdd2());
  		eventEntryBean.setMonthtext1(event.getMonthtext1());
  		eventEntryBean.setRecu_month_day_radio(event.getRecu_month_day_radio());
  		if(event.getRecurrence_dayName() != null)
  		{
  			List<String> recurrence_dayNameList = new ArrayList<String>(Arrays.asList(event.getRecurrence_dayName().split(",")));
  			Gson gson = new Gson();
  	        String recurrence_dayNamesJson = gson.toJson(recurrence_dayNameList);
  	        model.addAttribute("recurrence_dayNamesJson", recurrence_dayNamesJson);
  		}
  		
  		
  		//code completed for Recurrence 
  		
  		
		List<String> catList = categoryService.getCategoryName();
		List<String> appList = applicationService.getAppNames();
        List<String> rescList = userService.getResourceNames();
        List<String> regList = regionService.getRegionTerritory();
      
        model.addAttribute("catgoryList",catList);
        model.addAttribute("appNameList",appList);
        model.addAttribute("rescNameList",rescList);
		model.addAttribute("eventEntryBean", eventEntryBean);
		
		List<HashMap<String, String>> listMastp=  applicationService.getPriAndSecResourceName();          
        Gson gson = new Gson();
        String applicationEventJson = gson.toJson(listMastp);      
        model.addAttribute("eventEntryJsonStr",applicationEventJson);
        Set<HashMap<String, String>> setMast1 =  new HashSet<>();
        for(String eventApp : eventAppSet)
        {
	        HashMap<String, String> h = new HashMap<>();
	        h.put("App_name", eventApp);
	        setMast1.add(h);
        }        
        String applicationEventJson1 = gson.toJson(setMast1);      
        model.addAttribute("selectedeventAppJsonStr",applicationEventJson1);
        
		model.addAttribute("regionList",regList);
		List<String> caltypList = calendartypeService.getCalendarTypeName();
		model.addAttribute("caltypList",caltypList);
		model.addAttribute("filePath", dir + File.separator);
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("editEntry");
    }
    
    @RequestMapping(value="/cancelEntry/{id}" ,method = RequestMethod.GET)
    public ModelAndView cancelEntry(@PathVariable Long id, @ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean, BindingResult bindingResult, Model model) throws java.text.ParseException 
    {
		
    	EventEntry eventEntry=eventEntryService.findById(id);

    	/* Email code starts here */
    	
    	String emailid=eventEntry.getAdditional_receipients();
    	
    	
    	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
    	SimpleDateFormat dateParser = new SimpleDateFormat( "yyyy-MM-dd'T'HH:mm" );
		Date theStartDate = format.parse(eventEntry.getStart_date());
		Calendar startCal = Calendar.getInstance();
	    startCal.setTime(theStartDate);
	    
	    String pattern = "yyyy-MM-dd";
	    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
	    String pattern2 = "HH:mm";
	    SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat(pattern2);
	    
	    String startDate = simpleDateFormat.format(startCal.getTime());

	    String startTime = simpleDateFormat2.format(startCal.getTime());
	    
	    eventEntry.setStart_date(startDate+'T'+startTime);
	    
	    Date theEndDate = format.parse(eventEntry.getEnd_date());
		Calendar endCal = Calendar.getInstance();
	    endCal.setTime(theEndDate);
	    
	    String endDate = simpleDateFormat.format(endCal.getTime());
	    String endTime = simpleDateFormat2.format(endCal.getTime());
	    eventEntry.setEnd_date(endDate+'T'+endTime);
	    
        try {
		mailService.sendCancelInvitation( "DL IN NATools_Support"
    		                       , new String[] {emailid}
    		                       , eventEntry.getEventname()
    		                       , dateParser.parse(eventEntry.getStart_date())
    		                       , dateParser.parse(eventEntry.getEnd_date())
    		                       , eventEntry.getRecurrence_type()
    		                       , eventEntry.getRecu_every_day()
    		                       , eventEntry.getRecu_every_weekday()
    		                       , eventEntry.getRecu_every_week()
    		                       , eventEntry.getRecurrence_dayName()
    		                       , eventEntry.getRecu_every_month()
    		                       , eventEntry.getRecu_month_day()
    		                       , "LIS-42"
    		                       , "TBD"
    		                       ) ;
    	} catch (ParseException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	} catch (Exception e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	}
        /* Email code ends here */

        //once cancelled the event delete the record from database.
        /*eventEntryService.deleteCanceledEvent(id);*/
        eventEntryService.saveCancelledEntry(eventEntry);
        
    	List<EventEntryBean> evnetEntryBeanList=new ArrayList<>();
    	HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		List<EventEntry> eventList = eventEntryService.findAllEventByResource(userAccountName);
    	for(EventEntry event:eventList){
    		if(event.getEventstatus()!=null && !event.getEventstatus().equalsIgnoreCase("Cancelled"))
    		{
    			EventEntryBean eventEntryBeanDetails=new EventEntryBean();
        		eventEntryBeanDetails.setEvent_ID(event.getEvent_ID());
        		eventEntryBeanDetails.setEventName(event.getEventname());
        		eventEntryBeanDetails.setDescription_details(event.getDescription_details());
        		eventEntryBeanDetails.setStart_date(event.getStart_date());
        		eventEntryBeanDetails.setEnd_date(event.getEnd_date());
        		//eventEntryBean.setRegion_territory(event.getRegion_territory());
        		eventEntryBeanDetails.setRisk_summary(event.getRisk_summary());
        		eventEntryBeanDetails.setRemarks(event.getRemarks());
        		if(event.getEvent_file_name() != null) 
        		{
    	    		List<String> fileNameList = Arrays.asList(event.getEvent_file_name().split("\\s*,\\s*"));
    	    		eventEntryBeanDetails.setEvent_list(fileNameList);
        		}
        		
        		Region region = regionService.findByRegionId(event.getRegion_id());
    			
                if(region!=null)
                {
                	eventEntryBeanDetails.setRegion_territory(region.getRegion_territory());
                }
        		
               	Category category=categoryService.findByCategoryId(event.getEvent_category_id());
        		
        		if(category!=null){
        			eventEntryBeanDetails.setEvent_category_Name(category.getEvent_category_name());
        		}
        		
        		String[] eventAppSet =new String[event.getEventAppSet().size()];
        		int i=0;
        		
        		for (EventApplication eventApp : event.getEventAppSet() ) {
        			
        			eventAppSet[i]=eventApp.getApplication();
        			i++;
        		}
        		eventEntryBeanDetails.setEventAppSet(eventAppSet);
        		
        		String[] eventUserSet=new String[event.getEventUserSet().size()];
        		int j=0;
        		for(EventUser eventUser:event.getEventUserSet()){
        			//for(String Username: userService.findByUsername(eventUser))
        			eventUserSet[j] = eventUser.getResource();
        			j++;
        		}
        		eventUserSet = Arrays.stream(eventUserSet)
                        .filter(s -> (s != null && s.length() > 0))
                        .toArray(String[]::new);
        		
        		Set<String> userSet = new HashSet<String>(Arrays.asList(eventUserSet));    		
        		eventUserSet= userSet.toArray(new String[userSet.size()]);
        		String eventUsersString = String.join(",", eventUserSet);
        		eventEntryBeanDetails.setEventUsers(eventUsersString);
          		eventEntryBeanDetails.setEventUserSet(eventUserSet);
        		eventEntryBeanDetails.setEmail_receipients(event.getAdditional_receipients());
        		eventEntryBeanDetails.setEngagement_Name(event.getEngagement_Name());
        		evnetEntryBeanList.add(eventEntryBeanDetails);
    		}
    	}    	
    	model.addAttribute("evnetEntryBeanList", evnetEntryBeanList);
		model.addAttribute("filePath", dir + File.separator);
    	model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
        return new ModelAndView("viewEntry");
     }
    
    @RequestMapping(value="/editEntry/{id}",method = RequestMethod.POST)
    public ModelAndView editSaveEntry(@PathVariable Long id,@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean, BindingResult bindingResult, Model model,
    		final @RequestParam("File_upload") List<MultipartFile> File_upload) 
    {
    	eventEntryBean.setEventUserSet(eventEntryBean.getHiddenuser());
    	if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("weekly") && eventEntryBean.getRecu_every_week().equalsIgnoreCase(""))
    	{
    		   	 model.addAttribute("recerrorMsg","Please provide the Recur every week");
    		   	 model.addAttribute("recType","weekly");
               	 List<String> appList = applicationService.getAppNames();
                 List<String> rescList = userService.getResourceNames();
                 List<String> catList = categoryService.getCategoryName();
                 List<String> regList = regionService.getRegionTerritory();
                 List<String> caltypList = calendartypeService.getCalendarTypeName();
                 model.addAttribute("eventEntryBean", eventEntryBean);             
                 model.addAttribute("catgoryList",catList);
                 model.addAttribute("appNameList",appList);
                 model.addAttribute("rescNameList",rescList);
                 model.addAttribute("regionList",regList);
                 model.addAttribute("caltypList",caltypList);
                 
                 EventEntry event=eventEntryService.findById(id);
             	 String[] eventAppSet =new String[event.getEventAppSet().size()];
         		 int i=0;
        		 for (EventApplication eventApp : event.getEventAppSet() ) {
        			eventAppSet[i]=eventApp.getApplication();
        			i++;
        		 }
         		 List<HashMap<String, String>> listMastp=  applicationService.getPriAndSecResourceName();          
                 Gson gson = new Gson();
                 String applicationEventJson = gson.toJson(listMastp);      
                 model.addAttribute("eventEntryJsonStr",applicationEventJson);
                 Set<HashMap<String, String>> setMast1 =  new HashSet<>();
                 for(String eventApp : eventAppSet)
                 {
         	        HashMap<String, String> h = new HashMap<>();
         	        h.put("App_name", eventApp);
         	        setMast1.add(h);
                 }        
                 String applicationEventJson1 = gson.toJson(setMast1);      
                 model.addAttribute("selectedeventAppJsonStr",applicationEventJson1);
                 
                 return new ModelAndView("editEntry");
    	}
    	if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("weekly") && !eventEntryBean.getRecu_every_week().equalsIgnoreCase("") && eventEntryBean.getRecurrence_dayName() == null)
    	{
    		   model.addAttribute("recDayerrorMsg","Please Select atleast a day");
    		   model.addAttribute("recType","weekly");
    		   List<String> appList = applicationService.getAppNames();
                 List<String> rescList = userService.getResourceNames();
                 List<String> catList = categoryService.getCategoryName();
                 List<String> regList = regionService.getRegionTerritory();
                 List<String> caltypList = calendartypeService.getCalendarTypeName();
                 model.addAttribute("eventEntryBean", eventEntryBean);             
                 model.addAttribute("catgoryList",catList);
                 model.addAttribute("appNameList",appList);
                 model.addAttribute("rescNameList",rescList);
                 model.addAttribute("regionList",regList);
                 model.addAttribute("caltypList",caltypList);
                 
                 EventEntry event=eventEntryService.findById(id);
             	 String[] eventAppSet =new String[event.getEventAppSet().size()];
	             int i=0;
	       		 for (EventApplication eventApp : event.getEventAppSet() ) {
	       			eventAppSet[i]=eventApp.getApplication();
	       			i++;
	       		 }
	       		 List<HashMap<String, String>> listMastp=  applicationService.getPriAndSecResourceName();          
                 Gson gson = new Gson();
                 String applicationEventJson = gson.toJson(listMastp);      
                 model.addAttribute("eventEntryJsonStr",applicationEventJson);
                 Set<HashMap<String, String>> setMast1 =  new HashSet<>();
                 for(String eventApp : eventAppSet)
                 {
         	        HashMap<String, String> h = new HashMap<>();
         	        h.put("App_name", eventApp);
         	        setMast1.add(h);
                 }        
                 String applicationEventJson1 = gson.toJson(setMast1);      
                 model.addAttribute("selectedeventAppJsonStr",applicationEventJson1);
                 return new ModelAndView("editEntry");
    	}
    	
    	eventEntryValidator.validate(eventEntryBean, bindingResult);
    	
    	if (bindingResult.hasErrors()) 
        {     	
    		   List<String> appList = applicationService.getAppNames();
               List<String> rescList = userService.getResourceNames();
               List<String> catList = categoryService.getCategoryName();
               List<String> regList = regionService.getRegionTerritory();
               List<String> caltypList = calendartypeService.getCalendarTypeName();
               model.addAttribute("catgoryList",catList);
               model.addAttribute("appNameList",appList);
               model.addAttribute("rescNameList",rescList);
               model.addAttribute("regionList",regList);
               model.addAttribute("caltypList",caltypList);
               
               EventEntry event=eventEntryService.findById(id);
               
               
             //added code start for Recurrence 
         		
         	if(event.getRecurrence_dayName() != null)
         	{
        			List<String> recurrence_dayNameList = new ArrayList<String>(Arrays.asList(event.getRecurrence_dayName().split(",")));
        			Gson gson = new Gson();
         	        String recurrence_dayNamesJson = gson.toJson(recurrence_dayNameList);
         	        model.addAttribute("recurrence_dayNamesJson", recurrence_dayNamesJson);
       		}
           	   String[] eventAppSet =new String[event.getEventAppSet().size()];
	             int i=0;
	       		 for (EventApplication eventApp : event.getEventAppSet() ) {
	       			eventAppSet[i]=eventApp.getApplication();
	       			i++;
	       		 }
	       		 List<HashMap<String, String>> listMastp=  applicationService.getPriAndSecResourceName();          
               Gson gson = new Gson();
               String applicationEventJson = gson.toJson(listMastp);      
               model.addAttribute("eventEntryJsonStr",applicationEventJson);
               Set<HashMap<String, String>> setMast1 =  new HashSet<>();
               for(String eventApp : eventAppSet)
               {
       	        HashMap<String, String> h = new HashMap<>();
       	        h.put("App_name", eventApp);
       	        setMast1.add(h);
               }        
               String applicationEventJson1 = gson.toJson(setMast1);      
               model.addAttribute("selectedeventAppJsonStr",applicationEventJson1);
               model.addAttribute("eventEntryBean", eventEntryBean);             
               
               return new ModelAndView("editEntry");
        }
    	
    	eventEntryService.deleteEventUserBeforeEditSaveUsers(id);
    	eventEntryService.deleteEventAppBeforeEditSaveApps(id);

    	ModelAndView model1 = new ModelAndView();
    	FileUpload fileUpload = new FileUpload();
    	String fileContent = null;
    	String attachfileName = null;
    	String getEvent_file_name = null;
    	List<String> fileNames = new ArrayList<String>();
        try {
        	for (MultipartFile multipartFile : File_upload) {
        		fileContent = fileUpload.process(multipartFile).toString();
                attachfileName = multipartFile.getOriginalFilename();
                fileNames.add(attachfileName);
            	System.out.print("attachName-------------->>"+attachfileName);
        	
        	}
			model1.addObject("message", fileContent);
			
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        getEvent_file_name = fileNames.toString().replaceAll("[\\[\\]+]", "");
        EventEntry eventEntry=eventEntryService.findById(eventEntryBean.getEvent_ID());
    	StringBuffer buffer  = null;
    	if(eventEntry.getEvent_file_name() != null && eventEntry.getEvent_file_name() != "")
    	{
        	buffer = new StringBuffer(eventEntry.getEvent_file_name());
        	if(!getEvent_file_name.equals("") && buffer.length() != 0)
        	{
        		buffer.append(", "+getEvent_file_name);
        	}
        	eventEntryBean.setEvent_file_name(buffer.toString());
    	}
    	else
    	{
    		eventEntryBean.setEvent_file_name(getEvent_file_name);
    	}
        eventEntryBean.getEngagement_Name();
        /*HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		eventEntryBean.setAccount_name(userAccountName);*/
        eventEntryBean.setAccount_name(eventEntryBean.getEngagement_Name());
        
        
        System.out.print("inside editSave");
       
        eventEntryService.editSave(eventEntryBean); 

        eventEntryBean.setRemarks(eventEntryBean.getRemarks());
    	eventEntryBean.setFile_upload(eventEntryBean.getFile_upload());
    	String file_upload=String.valueOf(eventEntryBean.getFile_upload());
    	String remarks=eventEntryBean.getRemarks();
    	String eventName=eventEntryBean.getEventName();
        String startSate=eventEntryBean.getStart_date()+"T"+eventEntryBean.getStart_time();
        String endDate = eventEntryBean.getEnd_date()+"T"+eventEntryBean.getEnd_time();
        String emailID=eventEntryBean.getEmail_receipients();
        String emailID1=eventEntryBean.getEmail_receipients1();  
    			 
        if(emailID != null && emailID1 != null)
        {
			emailid = emailID + "," + emailID1;
		} else {
			
			emailid = emailID;
		}
        
        model.addAttribute("eventName", eventName);
        model.addAttribute("remarks", remarks);
        model.addAttribute("startSate", startSate);
        model.addAttribute("endDate", endDate);
        model.addAttribute("endDate", endDate);
        model.addAttribute("file_upload", file_upload);
        
        CalendarService calService = new CalendarService();
        calService.createCalendar(startSate, endDate, eventName, eventEntryBean.getDescription_details(),eventEntryBean.getEngagement_Name(),eventEntryBean.getRisk_summary());
        SimpleDateFormat dateParser = new SimpleDateFormat( "yyyy-MM-dd'T'HH:mm" ) ;

        try {
      	  mailService.sendInvitation( "DL IN NATools_Support"
    		                       , new String[] { emailid
    		                                      }
    		                       , eventEntryBean.getEventName()
    		                       /*, dateParser.parse( "28-08-2006 18:00" )
    		                       , dateParser.parse( "28-08-2006 21:00" )*/
    		                       /*, eventEntryBean.getRecurrence()*/
    		                       , dateParser.parse(eventEntryBean.getStart_date()+"T"+eventEntryBean.getStart_time())
    		                       , dateParser.parse(eventEntryBean.getEnd_date()+"T"+eventEntryBean.getEnd_time())
    		                       
    		                       , eventEntryBean.getRecurrence_type()
    		                       
    		                       , eventEntryBean.getRecu_every_day()
    		                       , eventEntryBean.getRecu_every_weekday()
    		                       
    		                       , eventEntryBean.getRecu_every_week()
    		                       , eventEntryBean.getRecurrence_dayName()
    		                       
    		                       , eventEntryBean.getRecu_every_month()
    		                       , eventEntryBean.getRecu_month_day()
    		                       , eventEntryBean.getMonthdd1()
    		                       , eventEntryBean.getMonthdd2()
    		                       , eventEntryBean.getMonthtext1()
    		                       , eventEntryBean.getRecu_month_day_radio()
    		                       , "LIS-42"
    		                       , "TBD"
    		                       /*, "<font color=\"Black\">"+eventEntryBean.getDescription_details()+"</font>"*/
    		                       , "<body bgcolor='#E6E6FA'> <table align='center' border='2' ><tr><td>EventName :</td><td><font color=\"Blue\">" + eventEntryBean.getEventName() + "</font></td></tr>"+
   			           					"<tr><td>Description_details :</td><td><font color=\"Blue\">" + eventEntryBean.getDescription_details() + "</font></td></tr>"+
   			                   			"<tr><td>Category Name :</td><td><font color=\"Blue\">" + eventEntryBean.getEvent_category_Name() + "</font></td></tr>"+
   			                   			"<tr><td>Engagement Name :</td><td><font color=\"Blue\">" + eventEntryBean.getEngagement_Name() + "</font></td></tr>"+
   			        					"<tr><td>Risk Summary :</td><td><font color=\"Blue\">" + eventEntryBean.getRisk_summary() + "</font></td></tr>"+
   			        					"<tr><td>Region territory :</td><td><font color=\"Blue\">" + eventEntryBean.getEventName() + "</font></td></tr></table></body>",eventEntryBean.getEvent_file_name()
    		                       ) ;
    	} catch (ParseException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	} catch (Exception e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	}
        
        /* Email code ends here */

		/* Email code ends here */
        
       //return new ModelAndView("viewEntry");
        model.addAttribute("filePath", dir + File.separator);
        model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView(new RedirectView("../viewEntry"));
    	
    }
    @RequestMapping(value = "/addRecurrence", method = RequestMethod.GET)
    public String addRecurrene(Model model) {
    	model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return "addRecurrence";
    	
    }
    
    @RequestMapping(value = "/viewEventsInExcel", method = RequestMethod.POST)
	public ModelAndView viewEventsInExcel(Model model) {
		
    	List<EventEntryBean> evnetEntryBeanList=new ArrayList<>();
    	HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		List<EventEntry> eventList = eventEntryService.findAllEventByResource(userAccountName);
    	for(EventEntry event:eventList){
    		if(event.getEventstatus()!=null && !event.getEventstatus().equalsIgnoreCase("Cancelled"))
	    	{
	    		EventEntryBean eventEntryBean=new EventEntryBean();
	    		eventEntryBean.setEvent_ID(event.getEvent_ID());
	    		eventEntryBean.setEventName(event.getEventname());
	    		eventEntryBean.setDescription_details(event.getDescription_details());
	    		eventEntryBean.setStart_date(event.getStart_date());
	    		eventEntryBean.setEnd_date(event.getEnd_date());
	    		eventEntryBean.setRisk_summary(event.getRisk_summary());
	    		eventEntryBean.setRemarks(event.getRemarks());
	    		if(event.getEvent_file_name() != null) 
	    		{
		    		List<String> fileNameList = Arrays.asList(event.getEvent_file_name().split("\\s*,\\s*"));
		    		eventEntryBean.setEvent_list(fileNameList);
	    		}
	    		Region region = regionService.findByRegionId(event.getRegion_id());
	            if(region!=null)
	            {
	            	eventEntryBean.setRegion_territory(region.getRegion_territory());
	            }
	           	Category category=categoryService.findByCategoryId(event.getEvent_category_id());
	    		if(category!=null){
	    			eventEntryBean.setEvent_category_Name(category.getEvent_category_name());
	    		}
	    		String[] eventAppSet =new String[event.getEventAppSet().size()];
	    		int i=0;
	    		for (EventApplication eventApp : event.getEventAppSet() ) {
	    			eventAppSet[i]=eventApp.getApplication();
	    			i++;
	    		}
	    		eventEntryBean.setEventAppSet(eventAppSet);
	    		String[] eventUserSet=new String[event.getEventUserSet().size()];
	    		int j=0;
	    		for(EventUser eventUser:event.getEventUserSet()){
	    			eventUserSet[j] = eventUser.getResource();
	    			j++;
	    		}
	    		eventUserSet = Arrays.stream(eventUserSet)
	                    .filter(s -> (s != null && s.length() > 0))
	                    .toArray(String[]::new);
	    		
	    		Set<String> userSet = new HashSet<String>(Arrays.asList(eventUserSet));    		
	    		eventUserSet= userSet.toArray(new String[userSet.size()]);
	    		String eventUsersString = String.join(",", eventUserSet);
	    		eventEntryBean.setEventUsers(eventUsersString);
	      		eventEntryBean.setEventUserSet(eventUserSet);
	    		eventEntryBean.setEmail_receipients(event.getAdditional_receipients());
	    		eventEntryBean.setEngagement_Name(event.getEngagement_Name());
	    		evnetEntryBeanList.add(eventEntryBean);
	    	}
    	}
    	model.addAttribute("evnetEntryBeanList", evnetEntryBeanList);
    	model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
    	model.addAttribute("loggedInUname",SecurityContextHolder.getContext().getAuthentication().getName());
		return new ModelAndView("ViewEventsExcel","evnetEntryBeanList",evnetEntryBeanList);
	}
    
   /* @RequestMapping(value = "/uploadEvent", method = RequestMethod.GET)
    public ModelAndView uploadEvent(Model model,@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean) 
    {
    	//model.addAttribute("notOKRecordsPath", dir + "\\UploadEventsNotOKRecords_" + loggedInUsername + ".xlsx");
        return new ModelAndView("uploadEvent");
    }*/

    
    
    /* Upload Account Master starts here */

	private boolean checkIfRowIsEmpty(Row row) {
		if (row == null) {
			return true;
		}
		if (row.getLastCellNum() <= 0) {
			return true;
		}
		for (int cellNum = row.getFirstCellNum(); cellNum < row.getLastCellNum(); cellNum++) {
			Cell cell = row.getCell(cellNum);
			if (cell != null && cell.getCellType() != Cell.CELL_TYPE_BLANK) {
				return false;
			}
		}
		return true;
	}

	@RequestMapping(value = { "/uploadEvent" }, method = RequestMethod.GET)
	public String uploadEventPlannedGET(ModelMap model, @ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean) {
		model.addAttribute("headerName","eventSetup");
		List<EventEntry> eventEntry = eventEntryService.findAll();
		
		List<String> eventEntryStr = new ArrayList<String>();
				
		for(EventEntry eventEntryObj: eventEntry){
			eventEntryStr.add(eventEntryObj.getEventname());
		}
				
		model.addAttribute("eventEntryList", eventEntryStr);
		model.addAttribute("eventEntryBeanVal",eventEntryBean);
		
		
		model.addAttribute("loggedInUname", SecurityContextHolder.getContext().getAuthentication().getName());
		model.addAttribute("message", "");
		return "uploadEvent";
	}
	
	@RequestMapping(value = "/uploadEvent", method = RequestMethod.POST)
	public ModelAndView uploadEventPlannedPOST(ModelMap modelMap, @ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean, @RequestParam("file") MultipartFile file, Model mod, HttpServletRequest request) throws FileNotFoundException {

		ModelAndView model = new ModelAndView();
		FileUpload fileUpload = new FileUpload();
		model.addObject("message", fileUpload.processEventUpload(file));
		model.setViewName("uploadEvent");
		modelMap.addAttribute("loggedInUname", SecurityContextHolder.getContext().getAuthentication().getName());
		modelMap.addAttribute("eventEntryBeanVal",eventEntryBean);
		/* test xlsx file starts here */

		String fileName = file.getOriginalFilename();
		String rootPath = System.getProperty("catalina.home");
 	    //File myFile = new File(rootPath + "/webapps/CBE-ARMS/resources/documents/"+fileName);
		
		EventEntryBean eventEntryBeanVal = new EventEntryBean();

		File myFile = new File("D:/opt/file/" + fileName);
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(myFile);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}

		// Finds the workbook instance for XLSX file

		XSSFWorkbook myWorkBook = null;
		try {
			myWorkBook = new XSSFWorkbook(fis);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		/* FIRST SHEET DATA HANDLING STARTS HERE */
		// Return first sheet from the XLSX workbook
		//XSSFSheet mySheet = myWorkBook.getSheetAt(1);
		XSSFSheet mySheet = myWorkBook.getSheet("EventDetail");
		
		
		/* Adding error document starts here */
		
		/* Create a copy of uploaded excel starts here */

		XSSFWorkbook wb = null;

		XSSFSheet sheet = null;

		String errors = "";

		String userId = SecurityContextHolder.getContext().getAuthentication().getName();

		try {

			FileInputStream excelFile = new FileInputStream(myFile);

			Workbook workbook = new XSSFWorkbook(excelFile);

			if (!dir.exists())

				dir.mkdirs();

			FileOutputStream outputStream = new FileOutputStream(

					dir + "\\UploadEventErrorRecords_" + userId + ".xlsx");

			workbook.write(outputStream);

			workbook.close();

			FileInputStream clonedFile = new FileInputStream(

					new File(dir + "\\UploadEventErrorRecords_" + userId + ".xlsx"));

			wb = new XSSFWorkbook(clonedFile);

			sheet = wb.getSheetAt(0);

		} catch (Exception e) {

			// TODO: handle exception

		}

		/* Create a copy of uploaded excel ends here */
		
		/* Adding error document ends here */
		
		
		// Get iterator to all the rows in current sheet
		Iterator<Row> rowIterator = mySheet.iterator();
		rowIterator.next();
		// Traversing over each row of XLSX file
		while (rowIterator.hasNext()) {
			Row row = rowIterator.next();
			// For each row, iterate through each columns

			Iterator<Cell> cellIterator = row.cellIterator();
			EventPlanned eventPlanned = null;
			boolean eventPlannedFlag = false;
			Long categoryIdLong = categoryService.findByEventCategoryName(row.getCell(2).toString()).getEvent_cat_id();
			Long regionIdLong = regionService.findByRegionTerritory(row.getCell(10).toString()).getRegion_id();
			Long calTypeIdLong = calendartypeService.findByCalendarTypeName(row.getCell(12).toString()).getCalendar_type_id();
			String[] appNamesStrArr = null;
			if(row.getCell(6) != null){
				appNamesStrArr = row.getCell(6).toString().split(",");
			}
			String[] resourceNamesStrArr = null;
			if(row.getCell(7) != null){
				resourceNamesStrArr = row.getCell(7).toString().split(",");
			}
			while (cellIterator.hasNext()) {
				Cell cell = cellIterator.next();
				/*
				 * switch (cell.getCellType()) { case Cell.CELL_TYPE_STRING:
				 * System.out.print(cell.getStringCellValue() + "\t"); break; case
				 * Cell.CELL_TYPE_NUMERIC: System.out.print(cell.getNumericCellValue() + "\t");
				 * break; case Cell.CELL_TYPE_BOOLEAN:
				 * System.out.print(cell.getBooleanCellValue() + "\t"); break; default :
				 * 
				 * }
				 */
				if (cell.getRowIndex() > 0) {
					
					if(row.getCell(0)!= null)
					eventEntryBeanVal.setEventName(row.getCell(0).toString());
					if(row.getCell(1)!= null)
					eventEntryBeanVal.setDescription_details(row.getCell(1).toString());
					if(row.getCell(2)!= null)
					eventEntryBeanVal.setEvent_category_id(categoryIdLong);
					if(row.getCell(3)!= null){
					eventEntryBeanVal.setEngagement_Name(row.getCell(3).toString());
					eventEntryBeanVal.setAccount_name(row.getCell(3).toString());
					}
					if(row.getCell(4)!= null)
					eventEntryBeanVal.setStart_date(row.getCell(4).toString());
					if(row.getCell(5)!= null)
					eventEntryBeanVal.setEnd_date(row.getCell(5).toString());
					if(row.getCell(6)!= null)
						eventEntryBeanVal.setEventAppSet(appNamesStrArr);
					if(row.getCell(7)!= null)
						eventEntryBeanVal.setEventUserSet(resourceNamesStrArr);
					if(row.getCell(8)!= null)
					eventEntryBeanVal.setEmail_receipients(row.getCell(8).toString());
					if(row.getCell(9)!= null)
					eventEntryBeanVal.setRisk_summary(row.getCell(9).toString());
					if(row.getCell(10)!= null)
					eventEntryBeanVal.setRegion_id(String.valueOf(regionIdLong));
					if(row.getCell(11)!= null)
					eventEntryBeanVal.setRemarks(row.getCell(11).toString());
					if(row.getCell(12)!= null)
					eventEntryBeanVal.setCalendar_type_id(calTypeIdLong);
					if(row.getCell(13)!= null)
					eventEntryBeanVal.setRecurrence_type(row.getCell(13).toString());
					if(row.getCell(14)!= null && !row.getCell(14).toString().equalsIgnoreCase(""))
					eventEntryBeanVal.setRecu_every_day(String.valueOf(Math.round(Float.parseFloat(row.getCell(14).toString()))));
					if(row.getCell(15)!= null && !row.getCell(15).toString().equalsIgnoreCase(""))
						eventEntryBeanVal.setRecu_every_week(String.valueOf(Math.round(Float.parseFloat(row.getCell(15).toString()))));
					if(row.getCell(16)!= null)
					eventEntryBeanVal.setRecurrence_dayName(row.getCell(16).toString());
					/*if(row.getCell(15)!= null)
					eventEntryBeanVal.setRecu_every_weekday(row.getCell(15).toString());*/

					if(row.getCell(17) != null && !row.getCell(17).toString().equalsIgnoreCase("")){
						eventEntryBeanVal.setRecu_month_day(String.valueOf(Math.round(Float.parseFloat(row.getCell(17).toString()))));
						eventEntryBeanVal.setRecu_month_day_radio("1");
					}
					if(row.getCell(18) != null && !row.getCell(18).toString().equalsIgnoreCase("")){
						eventEntryBeanVal.setRecu_every_month(String.valueOf(Math.round(Float.parseFloat(row.getCell(18).toString()))));
						eventEntryBeanVal.setRecu_month_day_radio("1");
					} else {
						eventEntryBeanVal.setRecu_month_day_radio("2");
					}
					
					//eventEntryBeanVal.setCalendar_type_id(1L);
					
					/*eventEntryBeanVal.setRegion_id("4");
					
					
					eventEntryBeanVal.setEvent_category_id(1L);
					eventEntryBeanVal.setMonthdd1("1");
					eventEntryBeanVal.setMonthdd2("2");*/
					
					
					if(row.getCell(19) != null){
						if(row.getCell(19).toString().equalsIgnoreCase("First")){
								eventEntryBeanVal.setMonthdd1("1");
						} else if(row.getCell(19).toString().equalsIgnoreCase("Second")) {
							eventEntryBeanVal.setMonthdd1("2");
						} else if(row.getCell(19).toString().equalsIgnoreCase("Third")) {
							eventEntryBeanVal.setMonthdd1("3");
						} else if(row.getCell(19).toString().equalsIgnoreCase("Fourth")) {
							eventEntryBeanVal.setMonthdd1("4");
						} else if(row.getCell(19).toString().equalsIgnoreCase("Fifth")) {
							eventEntryBeanVal.setMonthdd1("5");
						} else if(row.getCell(19).toString().equalsIgnoreCase("Last")) {
							eventEntryBeanVal.setMonthdd1("99");
						}
				
					}
					if(row.getCell(20) != null){
						
						if(row.getCell(20).toString().equalsIgnoreCase("Weekday")){
								eventEntryBeanVal.setMonthdd2("9");
						} else if(row.getCell(20).toString().equalsIgnoreCase("Weekendday")) {
							eventEntryBeanVal.setMonthdd2("8");
						} else if(row.getCell(20).toString().equalsIgnoreCase("Sunday")) {
							eventEntryBeanVal.setMonthdd2("1");
						} else if(row.getCell(20).toString().equalsIgnoreCase("Monday")) {
							eventEntryBeanVal.setMonthdd2("2");
						} else if(row.getCell(20).toString().equalsIgnoreCase("Tuesday")) {
							eventEntryBeanVal.setMonthdd2("3");
						} else if(row.getCell(20).toString().equalsIgnoreCase("Wednesday")) {
							eventEntryBeanVal.setMonthdd2("4");
						} else if(row.getCell(20).toString().equalsIgnoreCase("Thursday")) {
							eventEntryBeanVal.setMonthdd2("5");
						} else if(row.getCell(20).toString().equalsIgnoreCase("Friday")) {
							eventEntryBeanVal.setMonthdd2("6");
						} else if(row.getCell(20).toString().equalsIgnoreCase("Saturday")) {
							eventEntryBeanVal.setMonthdd2("7");
						}
						eventEntryBeanVal.setRecu_month_day("1");
						eventEntryBeanVal.setRecu_every_month("1");
						eventEntryBeanVal.setRecu_month_day_radio("1");
						
					}
					if(row.getCell(21) != null && !row.getCell(21).toString().equalsIgnoreCase("")){
					eventEntryBeanVal.setMonthtext1(String.valueOf(Math.round(Float.parseFloat(row.getCell(21).toString()))));
					}
					eventPlannedFlag = true;
				}

			}
			
			errors = uploadEventEntry(eventEntryBeanVal,request,errors);
			
			if (eventPlannedFlag) {

				try {
					if(request.getParameter("finalUpload") != null && request.getParameter("finalUpload").equalsIgnoreCase("true")){
						//eventEntryService.savePlanned(eventPlanned);
						mod.addAttribute("finalUploadMsg", "yes");
					} else {
						if(errors != null && errors.length()>0){
							
							/*  Cell color add starts here */
							CellStyle style = wb.createCellStyle();
							Font font = wb.createFont();
				            font.setColor(HSSFColor.RED.index);
				            style.setFont(font);
				            /*  Cell color add ends here */
				            
							XSSFRow row1 = sheet.getRow(0);

							XSSFCell cell = row1.createCell(28);

							cell.setCellValue("Errors");
							cell.setCellStyle(style);
							
							XSSFRow rowC = sheet.getRow(row.getRowNum());

							XSSFCell cellC = rowC.createCell(22);

							cellC.setCellValue(errors);
							cellC.setCellStyle(style);
							errors = "";
							mod.addAttribute("errorFlag","yes");
						} else {
							mod.addAttribute("validateMsg","yes");
						}
					}
				} catch (Exception hex) {
					mod.addAttribute("exception", "There is an issue in uploading. Please contact technical support.");
					return new ModelAndView("uploadEvent");
				}

			}
		}
		/* test xlsx file ends here */
		/* FIRST SHEET DATA HANDLING ENDS HERE */
		
		/* SECOND SHEET DATA HANDLING STARTS HERE */
		
		// Return first sheet from the XLSX workbook
		//XSSFSheet mySheet1 = myWorkBook.getSheetAt(0);
		XSSFSheet mySheet1 = myWorkBook.getSheet("EventPlanDetail");
		// Get iterator to all the rows in current sheet
		Iterator<Row> rowIterator1 = mySheet1.iterator();
		rowIterator1.next();
		Row row = null;
		Iterator<Cell> cellIterator = null;
		Cell cell = null;
		// Traversing over each row of XLSX file
		while (rowIterator1.hasNext()) {
			row = rowIterator1.next();
			// For each row, iterate through each columns

			cellIterator = row.cellIterator();
			EventPlanned eventPlanned = null;
			boolean eventPlannedFlag = false;
			while (cellIterator.hasNext()) {
				cell = cellIterator.next();
				/*
				 * switch (cell.getCellType()) { case Cell.CELL_TYPE_STRING:
				 * System.out.print(cell.getStringCellValue() + "\t"); break; case
				 * Cell.CELL_TYPE_NUMERIC: System.out.print(cell.getNumericCellValue() + "\t");
				 * break; case Cell.CELL_TYPE_BOOLEAN:
				 * System.out.print(cell.getBooleanCellValue() + "\t"); break; default :
				 * 
				 * }
				 */
				if (cell.getRowIndex() > 0) {
					eventPlanned = new EventPlanned();

					if(row != null && row.getCell(0) != null){
						eventPlanned.setEvent_ID(row.getCell(0).toString());
					} else {
						errors = errors + "The Event ID should not be empty";
					}
					if(row != null && row.getCell(1) != null){
						eventPlanned.setStep_Number(row.getCell(1).toString());
					} else {
						errors = errors + "The Step Number should not be empty";
					}
					if(row != null && row.getCell(2) != null){
						eventPlanned.setCritical_Path(row.getCell(2).toString());
					}
					if(row != null && row.getCell(3) != null){
						eventPlanned.setApplication_Name(row.getCell(3).toString());
					}
					if(row != null && row.getCell(4) != null){
						eventPlanned.setJob_Name(row.getCell(4).toString());
					} else {
						errors = errors + "Job Name should not be empty";
					}
					if(row != null && row.getCell(5) != null){
						eventPlanned.setOwner(row.getCell(5).toString());
					} else {
						errors = errors + "Owner should not be empty";
					}
					if(row != null && row.getCell(6) != null){
						eventPlanned.setTechnology(row.getCell(6).toString());
					}
					if(row != null && row.getCell(7) != null){
						eventPlanned.setPlanned_Start_Time(row.getCell(7).toString());
					}
					if(row != null && row.getCell(8) != null){
						eventPlanned.setPlanned_End_Time(row.getCell(8).toString());
					}
					if(row != null && row.getCell(9) != null){
						eventPlanned.setPlanned_Run_Time(row.getCell(9).toString());
					}
					if(row != null && row.getCell(10) != null){
						eventPlanned.setSupport_Team_Email_ID(row.getCell(10).toString());
					}
					if(row != null && row.getCell(11) != null){
					eventPlanned.setEscalation_Email_Group(row.getCell(11).toString());
					}
					if(row != null && row.getCell(12) != null){
						eventPlanned.setBusiness_Contact_Email(row.getCell(12).toString());
					}
					if(row != null && row.getCell(13) != null){
						eventPlanned.setThresold_Alert_Time(row.getCell(13).toString());
					}
					eventPlanned.setVersion(1);
					eventPlannedFlag = true;
				}

			}
			if (eventPlannedFlag) {

				try {
					if(request.getParameter("finalUpload") != null && request.getParameter("finalUpload").equalsIgnoreCase("true")){
						eventEntryService.savePlanned(eventPlanned);
						mod.addAttribute("finalUploadMsg", "yes");
					} else {
						if(errors != null && errors.length()>0){
							
							/*  Cell color add starts here */
							CellStyle style = wb.createCellStyle();
							Font font = wb.createFont();
				            font.setColor(HSSFColor.RED.index);
				            style.setFont(font);
				            /*  Cell color add ends here */
							
						XSSFRow row1 = mySheet1.getRow(0);

						XSSFCell cell1 = row1.createCell(14);

						cell1.setCellValue("Errors");
						cell1.setCellStyle(style);
						
						XSSFRow rowC = sheet.getRow(row.getRowNum());

						XSSFCell cellC = rowC.createCell(14);

						cellC.setCellValue(errors);
						cellC.setCellStyle(style);
						errors = "";
						mod.addAttribute("errorFlag","yes");
					} else {
						mod.addAttribute("validateMsg","yes");
					}
				}
				} catch (Exception hex) {
					mod.addAttribute("exception", "There is an issue in uploading. Please contact technical support.");
					return new ModelAndView("uploadEvent");
				}

			}
		}
		
		/* SECOND SHEET DATA HANDLING ENDS HERE */
		mod.addAttribute("headerName","eventSetup");
		return model;
	}

	@JsonIgnoreProperties
	@RequestMapping(value = "/uploadEventAJAX", method = RequestMethod.POST)
	public ResponseEntity<?> uploadEventPlannedAJAX(ModelMap modelMap, @ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean, @RequestParam("file") MultipartFile file, Model mod, HttpServletRequest request) throws FileNotFoundException {

		ModelAndView model = new ModelAndView();
		FileUpload fileUpload = new FileUpload();
		model.addObject("message", fileUpload.processEventUpload(file));
		model.setViewName("uploadEvent");
		modelMap.addAttribute("loggedInUname", SecurityContextHolder.getContext().getAuthentication().getName());
		modelMap.addAttribute("eventEntryBeanVal",eventEntryBean);
		/* test xlsx file starts here */

		String fileName = file.getOriginalFilename();
		String rootPath = System.getProperty("catalina.home");
 	    //File myFile = new File(rootPath + "/webapps/CBE-ARMS/resources/documents/"+fileName);
		
		EventEntryBean eventEntryBeanVal = new EventEntryBean();

		File myFile = new File("D:/opt/file/" + fileName);
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(myFile);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}

		// Finds the workbook instance for XLSX file

		XSSFWorkbook myWorkBook = null;
		try {
			myWorkBook = new XSSFWorkbook(fis);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		/* FIRST SHEET DATA HANDLING STARTS HERE */
		// Return first sheet from the XLSX workbook
		//XSSFSheet mySheet = myWorkBook.getSheetAt(1);
		XSSFSheet mySheet = myWorkBook.getSheet("EventDetail");
		
		
		/* Adding error document starts here */
		
		/* Create a copy of uploaded excel starts here */

		XSSFWorkbook wb = null;

		XSSFSheet sheet = null;

		String errors = "";

		String userId = SecurityContextHolder.getContext().getAuthentication().getName();

		try {

			FileInputStream excelFile = new FileInputStream(myFile);

			Workbook workbook = new XSSFWorkbook(excelFile);

			if (!dir.exists())

				dir.mkdirs();

			FileOutputStream outputStream = new FileOutputStream(

					dir + "\\UploadEventErrorRecords_" + userId + ".xlsx");

			workbook.write(outputStream);

			workbook.close();

			FileInputStream clonedFile = new FileInputStream(

					new File(dir + "\\UploadEventErrorRecords_" + userId + ".xlsx"));

			wb = new XSSFWorkbook(clonedFile);

			sheet = wb.getSheet("EventDetail");

		} catch (Exception e) {

			// TODO: handle exception

		}

		/* Create a copy of uploaded excel ends here */
		
		/* Adding error document ends here */
		
		
		// Get iterator to all the rows in current sheet
		Iterator<Row> rowIterator = mySheet.iterator();
		rowIterator.next();
		// Traversing over each row of XLSX file
		while (rowIterator.hasNext()) {
			Row row = rowIterator.next();
			// For each row, iterate through each columns

			Iterator<Cell> cellIterator = row.cellIterator();
			EventPlanned eventPlanned = null;
			boolean eventPlannedFlag = false;
			Long categoryIdLong = categoryService.findByEventCategoryName(row.getCell(2).toString()).getEvent_cat_id();
			Long regionIdLong = regionService.findByRegionTerritory(row.getCell(10).toString()).getRegion_id();
			Long calTypeIdLong = calendartypeService.findByCalendarTypeName(row.getCell(12).toString()).getCalendar_type_id();
			while (cellIterator.hasNext()) {
				Cell cell = cellIterator.next();
				/*
				 * switch (cell.getCellType()) { case Cell.CELL_TYPE_STRING:
				 * System.out.print(cell.getStringCellValue() + "\t"); break; case
				 * Cell.CELL_TYPE_NUMERIC: System.out.print(cell.getNumericCellValue() + "\t");
				 * break; case Cell.CELL_TYPE_BOOLEAN:
				 * System.out.print(cell.getBooleanCellValue() + "\t"); break; default :
				 * 
				 * }
				 */
				if (cell.getRowIndex() > 0) {
					
					if(row.getCell(0)!= null)
					eventEntryBeanVal.setEventName(row.getCell(0).toString());
					if(row.getCell(1)!= null)
					eventEntryBeanVal.setDescription_details(row.getCell(1).toString());
					if(row.getCell(2)!= null)
					eventEntryBeanVal.setEvent_category_id(categoryIdLong);
					if(row.getCell(3)!= null){
					eventEntryBeanVal.setEngagement_Name(row.getCell(3).toString());
					eventEntryBeanVal.setAccount_name(row.getCell(3).toString());
					}
					if(row.getCell(4)!= null)
					eventEntryBeanVal.setStart_date(row.getCell(4).toString());
					if(row.getCell(5)!= null)
					eventEntryBeanVal.setEnd_date(row.getCell(5).toString());
					if(row.getCell(8)!= null)
					eventEntryBeanVal.setEmail_receipients(row.getCell(8).toString());
					if(row.getCell(9)!= null)
					eventEntryBeanVal.setRisk_summary(row.getCell(9).toString());
					if(row.getCell(10)!= null)
					eventEntryBeanVal.setRegion_id(String.valueOf(regionIdLong));
					if(row.getCell(11)!= null)
					eventEntryBeanVal.setRemarks(row.getCell(11).toString());
					if(row.getCell(12)!= null)
					eventEntryBeanVal.setCalendar_type_id(calTypeIdLong);
					if(row.getCell(13)!= null)
					eventEntryBeanVal.setRecurrence_type(row.getCell(13).toString());
					if(row.getCell(14)!= null && !row.getCell(14).toString().equalsIgnoreCase(""))
					eventEntryBeanVal.setRecu_every_day(String.valueOf(Math.round(Float.parseFloat(row.getCell(14).toString()))));
					if(row.getCell(15)!= null && !row.getCell(15).toString().equalsIgnoreCase(""))
						eventEntryBeanVal.setRecu_every_week(String.valueOf(Math.round(Float.parseFloat(row.getCell(15).toString()))));
					if(row.getCell(16)!= null)
					eventEntryBeanVal.setRecurrence_dayName(row.getCell(16).toString());
					/*if(row.getCell(15)!= null)
					eventEntryBeanVal.setRecu_every_weekday(row.getCell(15).toString());*/

					if(row.getCell(17) != null && !row.getCell(17).toString().equalsIgnoreCase("")){
						eventEntryBeanVal.setRecu_month_day(String.valueOf(Math.round(Float.parseFloat(row.getCell(17).toString()))));
						eventEntryBeanVal.setRecu_month_day_radio("1");
					}
					if(row.getCell(18) != null && !row.getCell(18).toString().equalsIgnoreCase("")){
						eventEntryBeanVal.setRecu_every_month(String.valueOf(Math.round(Float.parseFloat(row.getCell(18).toString()))));
						eventEntryBeanVal.setRecu_month_day_radio("1");
					} else {
						eventEntryBeanVal.setRecu_month_day_radio("2");
					}
					
					eventEntryBeanVal.setCalendar_type_id(1L);
					
					/*eventEntryBeanVal.setRegion_id("4");
					
					
					eventEntryBeanVal.setEvent_category_id(1L);
					eventEntryBeanVal.setMonthdd1("1");
					eventEntryBeanVal.setMonthdd2("2");*/
					
					
					if(row.getCell(19) != null){
						if(row.getCell(19).toString().equalsIgnoreCase("First")){
								eventEntryBeanVal.setMonthdd1("1");
						} else if(row.getCell(19).toString().equalsIgnoreCase("Second")) {
							eventEntryBeanVal.setMonthdd1("2");
						} else if(row.getCell(19).toString().equalsIgnoreCase("Third")) {
							eventEntryBeanVal.setMonthdd1("3");
						} else if(row.getCell(19).toString().equalsIgnoreCase("Fourth")) {
							eventEntryBeanVal.setMonthdd1("4");
						} else if(row.getCell(19).toString().equalsIgnoreCase("Fifth")) {
							eventEntryBeanVal.setMonthdd1("5");
						} else if(row.getCell(19).toString().equalsIgnoreCase("Last")) {
							eventEntryBeanVal.setMonthdd1("99");
						}
				
					}
					if(row.getCell(20) != null){
						
						if(row.getCell(20).toString().equalsIgnoreCase("Weekday")){
								eventEntryBeanVal.setMonthdd2("9");
						} else if(row.getCell(20).toString().equalsIgnoreCase("Weekendday")) {
							eventEntryBeanVal.setMonthdd2("8");
						} else if(row.getCell(20).toString().equalsIgnoreCase("Sunday")) {
							eventEntryBeanVal.setMonthdd2("1");
						} else if(row.getCell(20).toString().equalsIgnoreCase("Monday")) {
							eventEntryBeanVal.setMonthdd2("2");
						} else if(row.getCell(20).toString().equalsIgnoreCase("Tuesday")) {
							eventEntryBeanVal.setMonthdd2("3");
						} else if(row.getCell(20).toString().equalsIgnoreCase("Wednesday")) {
							eventEntryBeanVal.setMonthdd2("4");
						} else if(row.getCell(20).toString().equalsIgnoreCase("Thursday")) {
							eventEntryBeanVal.setMonthdd2("5");
						} else if(row.getCell(20).toString().equalsIgnoreCase("Friday")) {
							eventEntryBeanVal.setMonthdd2("6");
						} else if(row.getCell(20).toString().equalsIgnoreCase("Saturday")) {
							eventEntryBeanVal.setMonthdd2("7");
						}
						eventEntryBeanVal.setRecu_month_day("1");
						eventEntryBeanVal.setRecu_every_month("1");
						eventEntryBeanVal.setRecu_month_day_radio("1");
						
					}
					if(row.getCell(21) != null && !row.getCell(21).toString().equalsIgnoreCase("")){
					eventEntryBeanVal.setMonthtext1(String.valueOf(Math.round(Float.parseFloat(row.getCell(21).toString()))));
					}
					eventPlannedFlag = true;
				}

			}
			
			errors = uploadEventEntry(eventEntryBeanVal,request,errors);
			
			if (eventPlannedFlag) {

				try {
					if(request.getParameter("finalUpload") != null && request.getParameter("finalUpload").equalsIgnoreCase("true")){
						//eventEntryService.savePlanned(eventPlanned);
						mod.addAttribute("finalUploadMsg", "yes");
					} else {
						if(errors != null && errors.length()>0){
							
							/*  Cell color add starts here */
							CellStyle style = wb.createCellStyle();
							Font font = wb.createFont();
				            font.setColor(HSSFColor.RED.index);
				            style.setFont(font);
				            /*  Cell color add ends here */
							
							XSSFRow row1 = sheet.getRow(0);

							XSSFCell cell = row1.createCell(22);

							cell.setCellValue("Errors");
							cell.setCellStyle(style);
							
							XSSFRow rowC = sheet.getRow(row.getRowNum());

							XSSFCell cellC = rowC.createCell(22);

							cellC.setCellValue(errors);
							cellC.setCellStyle(style);
							
							File outWB = new File(dir + "\\UploadEventErrorRecords_" + userId + ".xlsx");

							OutputStream out = new FileOutputStream(outWB);
							
							wb.write(out);

							out.flush();

							out.close();

							wb.close();
							
							
							//errors = "";
							mod.addAttribute("errorFlag","yes");
						} else {
							mod.addAttribute("validateMsg","yes");
						}
					}
				} catch (Exception hex) {
					mod.addAttribute("exception", "There is an issue in uploading. Please contact technical support.");
					//return new ModelAndView("uploadEvent");
				}

			}
		}
		/* test xlsx file ends here */
		/* FIRST SHEET DATA HANDLING ENDS HERE */
		
		/* SECOND SHEET DATA HANDLING STARTS HERE */
		
		// Return first sheet from the XLSX workbook
		//XSSFSheet mySheet1 = myWorkBook.getSheetAt(0);
		XSSFSheet mySheet1 = myWorkBook.getSheet("EventPlanDetail");
		// Get iterator to all the rows in current sheet
		Iterator<Row> rowIterator1 = mySheet1.iterator();
		rowIterator1.next();
		Row row = null;
		Iterator<Cell> cellIterator = null;
		Cell cell = null;
		Set<String> errors1 = new HashSet<String>();
		// Traversing over each row of XLSX file
		while (rowIterator1.hasNext()) {
			row = rowIterator1.next();
			// For each row, iterate through each columns

			cellIterator = row.cellIterator();
			EventPlanned eventPlanned = null;
			boolean eventPlannedFlag = false;
			while (cellIterator.hasNext()) {
				cell = cellIterator.next();
				/*
				 * switch (cell.getCellType()) { case Cell.CELL_TYPE_STRING:
				 * System.out.print(cell.getStringCellValue() + "\t"); break; case
				 * Cell.CELL_TYPE_NUMERIC: System.out.print(cell.getNumericCellValue() + "\t");
				 * break; case Cell.CELL_TYPE_BOOLEAN:
				 * System.out.print(cell.getBooleanCellValue() + "\t"); break; default :
				 * 
				 * }
				 */
				if (cell.getRowIndex() > 0) {
					eventPlanned = new EventPlanned();

					if(row != null && row.getCell(0) != null && String.valueOf(row.getCell(0)) != ""){
						eventPlanned.setEvent_ID(row.getCell(0).toString());
					} else {
						errors1.add("The Event ID should not be empty;");
					}
					if(row != null && row.getCell(1) != null && String.valueOf(row.getCell(1)) != ""){
						eventPlanned.setStep_Number(row.getCell(1).toString());
					} else {
						errors1.add("The Step Number should not be empty;");
					}
					if(row != null && row.getCell(2) != null){
						eventPlanned.setCritical_Path(row.getCell(2).toString());
					}
					if(row != null && row.getCell(3) != null){
						eventPlanned.setApplication_Name(row.getCell(3).toString());
					}
					if(row != null && row.getCell(4) != null && String.valueOf(row.getCell(4)) != ""){
						eventPlanned.setJob_Name(row.getCell(4).toString());
					} else {
						errors1.add("Job Name should not be empty;");
					}
					if(row != null && row.getCell(5) != null && String.valueOf(row.getCell(5)) != ""){
						eventPlanned.setOwner(row.getCell(5).toString());
					} else {
						errors1.add("Owner should not be empty;");
					}
					if(row != null && row.getCell(6) != null){
						eventPlanned.setTechnology(row.getCell(6).toString());
					}
					if(row != null && row.getCell(7) != null){
						eventPlanned.setPlanned_Start_Time(row.getCell(7).toString());
					}
					if(row != null && row.getCell(8) != null){
						eventPlanned.setPlanned_End_Time(row.getCell(8).toString());
					}
					if(row != null && row.getCell(9) != null){
						eventPlanned.setPlanned_Run_Time(row.getCell(9).toString());
					}
					if(row != null && row.getCell(10) != null){
						eventPlanned.setSupport_Team_Email_ID(row.getCell(10).toString());
					}
					if(row != null && row.getCell(11) != null){
					eventPlanned.setEscalation_Email_Group(row.getCell(11).toString());
					}
					if(row != null && row.getCell(12) != null){
						eventPlanned.setBusiness_Contact_Email(row.getCell(12).toString());
					}
					if(row != null && row.getCell(13) != null){
						eventPlanned.setThresold_Alert_Time(row.getCell(13).toString());
					}
					eventPlanned.setVersion(1);
					eventPlannedFlag = true;
				}
			}
			if (eventPlannedFlag) {

				try {
					if(request.getParameter("finalUpload") != null && request.getParameter("finalUpload").equalsIgnoreCase("true")){
						eventEntryService.savePlanned(eventPlanned);
						mod.addAttribute("finalUploadMsg", "yes");
					} else {
							if(errors1 != null && errors1.size()>0){
								
								
								
								//Cloning the file starts here
								
								FileInputStream excelFile = new FileInputStream(dir + "\\UploadEventErrorRecords_" + userId + ".xlsx");

								Workbook workbook = new XSSFWorkbook(excelFile);

								if (!dir.exists())

									dir.mkdirs();

								FileOutputStream outputStream = new FileOutputStream(

										dir + "\\UploadEventErrorRecords_" + userId + ".xlsx");

								workbook.write(outputStream);

								workbook.close();
								
								//Cloning the file ends here
								
							
								XSSFWorkbook wb1 = null;
								
								FileInputStream clonedFile1 = new FileInputStream(

										new File(dir + "\\UploadEventErrorRecords_" + userId + ".xlsx"));
								
								wb1 = new XSSFWorkbook(clonedFile1);

								XSSFSheet sheet1 = wb1.getSheet("EventPlanDetail");
							
							XSSFRow row1 = sheet1.getRow(0);

							XSSFCell cell1 = row1.createCell(14);
							
							/*  Cell color add starts here */
							CellStyle style = wb1.createCellStyle();
							Font font = wb1.createFont();
				            font.setColor(HSSFColor.RED.index);
				            style.setFont(font);
				            /*  Cell color add ends here */

							cell1.setCellValue("Errors");
							cell1.setCellStyle(style);
							
							XSSFRow rowC = sheet1.getRow(row.getRowNum());

							XSSFCell cellC = rowC.createCell(14);

							cellC.setCellValue(errors1.toString());
							cellC.setCellStyle(style);
							
							File outWB = new File(dir + "\\UploadEventErrorRecords_" + userId + ".xlsx");

							OutputStream out = new FileOutputStream(outWB);
							
							wb1.write(out);

							out.flush();

							out.close();

							wb1.close();							
							
							errors1 = new HashSet<String>();
							mod.addAttribute("errorFlag","yes");
						} else {
							mod.addAttribute("validateMsg","yes");
						}
					}
				} catch (Exception hex) {
					hex.printStackTrace();
					mod.addAttribute("exception", "There is an issue in uploading. Please contact technical support.");
					//return new ModelAndView("uploadEvent");
				}

			}
		}
		
		/* SECOND SHEET DATA HANDLING ENDS HERE */
		if(!StringUtils.isEmpty(errors) || (errors1 != null && errors1.size()>0)){
			return ResponseEntity.ok("Yes");
		} else {
			return ResponseEntity.ok("");
		}
	}
	
	
	/* Add event details through upload starts here */
	
	public String uploadEventEntry(EventEntryBean eventEntryBean,HttpServletRequest request,String errors) 
    {
    	//eventEntryValidator.validate(eventEntryBean, bindingResult);
    	List<MultipartFile> files = eventEntryBean.getFile_upload();
    	
    	ModelAndView model1 = new ModelAndView();
    	FileUpload fileUpload = new FileUpload();
    	String fileContent = null;
    	String attachfileName = null;
    	String getEvent_file_name = null;
    	List<String> fileNames = new ArrayList<String>();
        try {
        	if (null != files && files.size() > 0)
            {
        	for (MultipartFile multipartFile : files) {
        		fileContent = fileUpload.process(multipartFile).toString();
        		//String getEvent_upld_fix_content=fileContent;
        		//getEvent_file_name = multipartFile.getOriginalFilename();
                //eventEntryBean.setEvent_file_name(getEvent_file_name);
                //eventEntryBean.setEvent_upld_fix(getEvent_upld_fix_content);
                attachfileName = multipartFile.getOriginalFilename();
                fileNames.add(attachfileName);
            	System.out.print("attachName-------------->>"+attachfileName);
        	}
            }
			model1.addObject("message", fileContent);
			
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        getEvent_file_name = fileNames.toString().replaceAll("[\\[.\\].\\s+]", "");
       
        eventEntryBean.setEvent_file_name(getEvent_file_name);

        HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		eventEntryBean.setAccount_name(userAccountName);
        
		  //will update once UI changes done.
	      
	      /*eventEntryBean.setRecurrence_type("Daily");
	      
	      if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("Daily"))
	      {
	      	eventEntryBean.setRecu_every_day("1");
	      	eventEntryBean.setRecu_every_weekday("MO,TU,WE,TH,FR");
	      }
	      else if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("Weekly"))
	      {
	      	eventEntryBean.setRecu_every_week("1");
	          eventEntryBean.setRecurrence_dayName("MO,TU,WE,TH,FR,SU,SA");
	      }
	      else if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("Monthly"))
	      {
	      	eventEntryBean.setRecu_every_month("1");
	      	eventEntryBean.setRecu_month_day("20");
	      }*/
		  
	      //will update above code once UI changes done.
	      
		if (eventEntryBean != null) {

			try {
				if(request.getParameter("finalUpload") != null && request.getParameter("finalUpload").equalsIgnoreCase("true")){
					eventEntryService.saveOther(eventEntryBean);
				}
			} catch (Exception hex) {
				hex.printStackTrace();
			}

		}
		
		
        String eventName=eventEntryBean.getEventName();
        
        if(StringUtils.isEmpty(eventName)){
        	errors = errors + "The Event Name should not be empty;";
        }
        
        EventEntry eb = eventEntryService.findByEventName(eventName);
        if(eb.getEventname() != null){
        	errors = errors + "The Event Name provided already exists. Please provide a different Event Name;";
        }
        
        String remarks=eventEntryBean.getRemarks();
        String startDate=eventEntryBean.getStart_date();
        if(StringUtils.isEmpty(startDate)){
        	errors = errors + "The Start Date should not be empty;";
        }
        
        String endDate = eventEntryBean.getEnd_date();
        if(StringUtils.isEmpty(endDate)){
        	errors = errors + "The End Date should not be empty;";
        }
        
        String emailID=eventEntryBean.getEmail_receipients();
        String emailID1=eventEntryBean.getEmail_receipients1();  
    				 
        if(emailID != null && emailID1 != null)
        {
			emailid = emailID + "," + emailID1;
		} else {
			
			emailid = emailID;
		}
        
        String file_upload=String.valueOf(eventEntryBean.getFile_upload());
        eventEntryBean.setFile_upload(eventEntryBean.getFile_upload());
        
      if(emailID.startsWith(",") || endDate.startsWith(",") || startDate.startsWith(",") || remarks.startsWith(".")){
 			
 			String startDate1=startDate.substring(1);
 			String end=endDate.substring(1);
 			String remark=remarks.substring(1);
 			String email1=emailID.substring(1);
 			
 			 
 	       /*String startSate=eventEntryBean.getStart_date();
 	        String endDate = eventEntryBean.getEnd_date();*/
 	      
 	       /* String emailID=eventEntryBean.getEmail_receipients();*/
 			eventEntryBean.setFile_upload(eventEntryBean.getFile_upload());
 			 	        
 	       //emailID,null,eventName, eventEntryBean.getDescription_details()
 	        
 	        CalendarService calService = new CalendarService();
 	       calService.createUploadCalendar(startDate, endDate, eventName, eventEntryBean.getDescription_details(),eventEntryBean.getEngagement_Name(),eventEntryBean.getRisk_summary());
 	        //mailService.sendMail(email1,null,eventName, eventEntryBean.getDescription_details());
 			
 		}else{
 			
 			//model.addAttribute("remarks", remarks);
               
        CalendarService calService = new CalendarService();
        calService.createUploadCalendar(startDate, endDate, eventName, eventEntryBean.getDescription_details(),eventEntryBean.getEngagement_Name(),eventEntryBean.getRisk_summary());
        //mailService.sendMail(emailID,null,eventName, eventEntryBean.getDescription_details());
        
 		}
      
      
   
    	/* Email code starts here */
        SimpleDateFormat dateParser = new SimpleDateFormat( "yyyy-MM-dd'T'HH:mm" ) ;//BKM
      //SimpleDateFormat dateParser = new SimpleDateFormat( "dd-MM-yyyy" ) ;

        try {
        	if(!StringUtils.isEmpty(eventEntryBean.getStart_date()) && !StringUtils.isEmpty(eventEntryBean.getEnd_date())){
	      	  mailService.sendInvitation( "DL IN NATools_Support"
	    		                       , new String[] {emailid
	    		                                      }
	    		                       , eventEntryBean.getEventName()
	    		                       /*, dateParser.parse( "28-08-2006 18:00" )
	    		                       , dateParser.parse( "28-08-2006 21:00" )*/
	    		                       /*, eventEntryBean.getRecurrence()*/
	    		                       /*, dateParser.parse("07-12-2020 14:00")
	    		                       , dateParser.parse("07-12-2025 17:00")*/
	    		                       , dateParser.parse(eventEntryBean.getStart_date())
	    		                       , dateParser.parse(eventEntryBean.getEnd_date())
	    		                       
	    		                       , eventEntryBean.getRecurrence_type()
	    		                       
	    		                       , eventEntryBean.getRecu_every_day()
	    		                       , eventEntryBean.getRecu_every_weekday()
	    		                       
	    		                       , eventEntryBean.getRecu_every_week()
	    		                       , eventEntryBean.getRecurrence_dayName()
	    		                       
	    		                       , eventEntryBean.getRecu_every_month()
	    		                       , eventEntryBean.getRecu_month_day()
	    		                       , eventEntryBean.getMonthdd1()
	    		                       , eventEntryBean.getMonthdd2()
	    		                       , eventEntryBean.getMonthtext1()
	    		                       , eventEntryBean.getRecu_month_day_radio()
	    		                       , "LIS-42"
	    		                       , "TBD"
	    		                       /*, "<font color=\"Black\">"+eventEntryBean.getDescription_details()+"</font>"*/
	    		                       , "<body bgcolor='#E6E6FA'> <table align='center' border='2' ><tr><td>EventName :</td><td><font color=\"Blue\">" + eventEntryBean.getEventName() + "</font></td></tr>"+
	   			           					"<tr><td>Description_details :</td><td><font color=\"Blue\">" + eventEntryBean.getDescription_details() + "</font></td></tr>"+
	   			                   			"<tr><td>Engagement Name :</td><td><font color=\"Blue\">" + eventEntryBean.getEngagement_Name() + "</font></td></tr>"+
	   			        					"<tr><td>Risk Summary :</td><td><font color=\"Blue\">" + eventEntryBean.getRisk_summary() + "</font></td></tr>"+
	   			        					"<tr><td>Region territory :</td><td><font color=\"Blue\">" + eventEntryBean.getEventName() + "</font></td></tr></table></body>",getEvent_file_name
	    		                       ) ;
        	}
    	} catch (ParseException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	} catch (Exception e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	}
        
        /* Email code ends here */

        return errors;
   	
    }
	
	
	/* Add event details through upload ends here */
    
    
}
