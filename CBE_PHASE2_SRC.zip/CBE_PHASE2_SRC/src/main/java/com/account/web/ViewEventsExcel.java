package com.account.web;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.accounts.dto.EventEntryBean;

public class ViewEventsExcel extends AbstractExcelView{

	@Override
	protected void buildExcelDocument(Map model, HSSFWorkbook workbook,
		HttpServletRequest request, HttpServletResponse response)
		throws Exception {

		List<EventEntryBean> EventEntryBeanList = (List<EventEntryBean>) model.get("evnetEntryBeanList");
		//create a wordsheet
		HSSFSheet sheet = workbook.createSheet("View Events");

		HSSFRow header = sheet.createRow(0);
		header.createCell(0).setCellValue("Event Name");
		header.createCell(1).setCellValue("Engagement Name");
		header.createCell(2).setCellValue("Start Date");
		header.createCell(3).setCellValue("End Date");
		header.createCell(4).setCellValue("Description");
		header.createCell(5).setCellValue("Resource");
		header.createCell(6).setCellValue("Email Recipients");
		header.createCell(7).setCellValue("Event category Name");
		header.createCell(8).setCellValue("Risk summary");
		header.createCell(9).setCellValue("File Upload");
		header.createCell(10).setCellValue("Region territory");
		int rowNum = 1;
		for (EventEntryBean eventEntryBean : EventEntryBeanList) {
			//create the row data
			HSSFRow row = sheet.createRow(rowNum++);
			if(eventEntryBean.getEventName() != null)
			{
				row.createCell(0).setCellValue(eventEntryBean.getEventName());
			}
			if(eventEntryBean.getEngagement_Name() != null)
			{
				row.createCell(1).setCellValue(eventEntryBean.getEngagement_Name());
			}
			if(eventEntryBean.getStart_date() != null)
			{
				row.createCell(2).setCellValue(eventEntryBean.getStart_date());
			}
			if(eventEntryBean.getEnd_date() != null)
			{
				row.createCell(3).setCellValue(eventEntryBean.getEnd_date());
			}
			
			if(eventEntryBean.getDescription_details() != null)
			{
				row.createCell(4).setCellValue(eventEntryBean.getDescription_details());
			}
			
			if(eventEntryBean.getEventUsers()!= null)
			{
				row.createCell(5).setCellValue(eventEntryBean.getEventUsers());
			}
			
			if(eventEntryBean.getEmail_receipients() != null)
			{
				row.createCell(6).setCellValue(eventEntryBean.getEmail_receipients());
			}
			if(eventEntryBean.getEvent_category_Name() != null)
			{
				row.createCell(7).setCellValue(eventEntryBean.getEvent_category_Name());
			}
			if(eventEntryBean.getRisk_summary() != null)
			{
				row.createCell(8).setCellValue(eventEntryBean.getRisk_summary());
			}
			if(!eventEntryBean.getEvent_list().isEmpty() && eventEntryBean.getEvent_list() != null)
			{
				StringBuilder builder = new StringBuilder();
				for (String fileName : eventEntryBean.getEvent_list()) {
					builder.append(fileName);
				}
				row.createCell(9).setCellValue(builder.toString());
			}
			if(eventEntryBean.getRegion_territory() != null)
			{
				row.createCell(10).setCellValue(eventEntryBean.getRegion_territory());
			}		
        }
	}
}