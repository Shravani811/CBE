package com.account.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.account.model.EventApplication;
import com.account.model.EventEntry;
import com.account.model.EventPlanned;
import com.account.model.EventPlannedBean;
import com.account.model.EventUser;
import com.account.model.FileUpload;
import com.account.model.IncidentBean;
import com.account.model.Role;
import com.account.model.User;
import com.account.service.AccountService;
import com.account.service.ApplicationService;
import com.account.service.CalendarTypeService;
import com.account.service.EventEntryService;
import com.account.service.RegionService;
import com.account.service.RegionServiceImpl;
import com.account.service.RoleService;
import com.account.service.UserService;
import com.account.validator.UserValidator;
import com.accounts.dto.CalendarBean;
import com.accounts.dto.EventEntryBean;
import com.accounts.dto.UserBean;
import com.google.gson.Gson;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;

	
	@Autowired
	private AccountService accountService;
	
	@Autowired
	private RoleService roleService;
	// @Autowired
	// private SecurityService securityService;
	@Autowired
    private EventEntryService eventEntryService;
	
	@Autowired
	private UserValidator userValidator;
	
	@Autowired
    private CalendarTypeService calendarTypeService;
	
	@Autowired
    private HttpServletRequest httpServletRequest;

	@Autowired
    private ApplicationService applicationService;
	
	@Autowired
    private RegionService regionService;
    
	
/*	@RequestMapping(value = { "/","/uploadAutomationReport" }, method = RequestMethod.GET)
	public String uploadAutomationReport(ModelMap model) {
		model.addAttribute("loggedInUname",SecurityContextHolder.getContext().getAuthentication().getName());
		model.addAttribute("message", "");
		model.addAttribute("maxRecDisplay",getMaxRecDisplay());
		return "uploadAutomationReport";
	}*/
	
	@RequestMapping(value = "/userUploadscreen", method = RequestMethod.GET)
	public ModelAndView userupload(Model model) {
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("userUpload");
	}
	
	@RequestMapping(value = "/userUploadscreen", method = RequestMethod.POST)
	public ModelAndView userupload(ModelMap modelMap, @RequestParam("file") MultipartFile file,Model mod) throws SQLException {
        
        ModelAndView model = new ModelAndView();
        FileUpload fileUpload = new FileUpload();
        try {
			model.addObject("message", fileUpload.process(file));
		} catch (FileNotFoundException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
			mod.addAttribute("exception","No File uploaded. Please upload the file.");
			return new ModelAndView("userUpload");
		}
        model.setViewName("userUpload");
       // modelMap.addAttribute("maxRecDisplay",getMaxRecDisplay());  *
       // modelMap.addAttribute("loggedInUname",SecurityContextHolder.getContext().getAuthentication().getName());   *
        
        /* test xlsx file starts here */
		
        String fileName = file.getOriginalFilename();
        String rootPath = System.getProperty("catalina.home");
        File dir = new File(rootPath + File.separator + "tmpFiles"+File.separator);
		//File myFile = new File("/opt/files/"+fileName);   *
        File myFile = new File(dir+ File.separator +fileName);
        String ext1 = FilenameUtils.getExtension(fileName);
        
		FileInputStream fis = null;
		try {
			
			if (ext1.equalsIgnoreCase("xlsx"))
			fis = new FileInputStream(myFile);
			else
			{
				mod.addAttribute("exception","Please upload the xlsx file only.");
				return new ModelAndView("userUpload");
			}
		} 	
		
		catch (FileNotFoundException e1) {
			e1.printStackTrace();
			mod.addAttribute("exception","No File uploaded. Please upload the file.");
			return new ModelAndView("userUpload");
		} 	
		
		
		
		// Finds the workbook instance for XLSX file 
		
		XSSFWorkbook myWorkBook = null;
		try {
			myWorkBook = new XSSFWorkbook (fis);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		// Return first sheet from the XLSX workbook 
		XSSFSheet mySheet = myWorkBook.getSheetAt(0); 
		// Get iterator to all the rows in current sheet 
		Iterator<Row> rowIterator = mySheet.iterator(); 
		
		// Traversing over each row of XLSX file 
		while (rowIterator.hasNext()) { Row row = rowIterator.next(); 
		// For each row, iterate through each columns 
		
		
		
		Iterator<Cell> cellIterator = row.cellIterator();
		//AutomationReport automationReport = null;
		User user = null;
		boolean ucFlag = false;
		
		
		while (cellIterator.hasNext())
		{ 
			Cell cell = cellIterator.next(); 
		/*switch (cell.getCellType()) { case Cell.CELL_TYPE_STRING: 
			System.out.print(cell.getStringCellValue() + "\t"); 
			break; 
			case Cell.CELL_TYPE_NUMERIC: 
				System.out.print(cell.getNumericCellValue() + "\t"); 
			break; 
			case Cell.CELL_TYPE_BOOLEAN: 
				System.out.print(cell.getBooleanCellValue() + "\t"); 
				break; 
			default : 
				
		}*/
		
/*		long maxuser_Id = 0;
		
		if (null != user) {
			maxuser_Id = user.getUser_ID();
		} else {
			maxuser_Id = 1;
		}*/
		if(cell.getRowIndex() > 0 && row != null &&  row.getCell(0) != null ){			
			
			user = new User();
			//user.setUser_ID(maxuser_Id);
			user.setUsername(row.getCell(0).toString());
			user.setPassword(row.getCell(1).toString());
			user.setResourcename(row.getCell(2).toString());
			user.setEmail_ID(row.getCell(3).toString());
			user.setStatus(true);
			user.setRole_Name(row.getCell(4).toString());	
			ucFlag = true;
		} 
		
		}
		if(ucFlag)
		{
			
			try{		
				userService.save(user);	
				//rowIterator =null;
			//return new ModelAndView("viewUser");
			}
			catch(Exception hex){
				mod.addAttribute("exception","There is an issue in uploading. Please contact technical support.");
				return new ModelAndView("userUpload");
			}
			/*catch (SQLException e3) {
		        e3.printStackTrace();
		        mod.addAttribute("exception","Duplicate entry in excel");
				return new ModelAndView("userUpload");
		    }*/
			
		}
	
		}
		List<UserBean> userBeanList = new ArrayList<>();
		List<User> userList = userService.findAll();
		for (User userListDataBean : userList) {
			UserBean userBean = new UserBean();
			userBean.setUserID(userListDataBean.getUser_ID());
			userBean.setUsername(userListDataBean.getUsername());
			userBean.setPassword(userListDataBean.getPassword());
			userBean.setEmailID(userListDataBean.getEmail_ID());
			userBean.setResourceName(userListDataBean.getResourcename());
			userBean.setRoleName(userListDataBean.getRole_Name());

			if (userListDataBean.isStatus() == true) {
				userBean.setStatus1("Active");
			} else {
				userBean.setStatus1("InActive");
			}

			// userBean.setStatus(userListDataBean.isStatus());

			userBeanList.add(userBean);
		}
		Collections.sort(userBeanList);
		mod.addAttribute("userBeanList", userBeanList);
		mod.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		
		return new ModelAndView("viewUser");
		
		
	}

/*	@RequestMapping(value = "/userDetails", method = RequestMethod.GET)
	public ModelAndView userDetails(Model model) {
		User user = new User();
		
      // RoleBean roleBean=new RoleBean();
	 //model.addAttribute("roleBean", roleBean);
		Role role=new Role();
		user.setRoles(new HashSet<Role>(roleService.findAll()));
		model.addAttribute("userForm", user);
		model.addAttribute("roleList", userService.getRoleName());
		List<String> appList = accountService.getAccountNames();
        model.addAttribute("accountList", appList);
		model.addAttribute("roleForm", role);
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		// return "userDetails";
		return new ModelAndView("userDetails");
	}

	@RequestMapping(value = "/userDetails", method = RequestMethod.POST)
	public ModelAndView userDetails(@ModelAttribute("userForm") User userForm, BindingResult bindingResult,
			Model model) {
		userValidator.validate(userForm, bindingResult);

		if (bindingResult.hasErrors()) {
			model.addAttribute("roleList", userService.getRoleName());
			List<String> appList = accountService.getAccountNames();
	        model.addAttribute("accountList", appList);
			return new ModelAndView("userDetails");
		}
		
		Set<Role> roles = new HashSet();
		Role role = roleService.findByName(userForm.getRole_Name());
		roles.add(role);
		userForm.setRoles(roles);
		
		
		userService.save(userForm);

		List<UserBean> userBeanList = new ArrayList<>();
		List<User> userList = userService.findAll();
		for (User userListDataBean : userList) {
			UserBean userBean = new UserBean();
			userBean.setUserID(userListDataBean.getUser_ID());
			userBean.setUsername(userListDataBean.getUsername());
			userBean.setPassword(userListDataBean.getPassword());
			userBean.setEmailID(userListDataBean.getEmail_ID());
			userBean.setResourceName(userListDataBean.getResourcename());
			userBean.setRoleName(userListDataBean.getRole_Name());
			
			boolean b = userListDataBean.isStatus();
			if (b == true) {
				userBean.setStatus1("Active");
			} else {
				userBean.setStatus1("InActive");
			}

			// userBean.setStatus(userListDataBean.isStatus());

			userBeanList.add(userBean);
		}
		model.addAttribute("userBeanList", userBeanList);
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("viewUser");

		// List<AccountGoals> acctGoalsList = accountGoalService.findAll();

		// return new ModelAndView("viewUser", "userBean", userBean);
	}*/
	
	@RequestMapping(value = "/userDetails", method = RequestMethod.GET)
	public ModelAndView userDetails(Model model) {
		User user = new User();

		// RoleBean roleBean=new RoleBean();
		// model.addAttribute("roleBean", roleBean);
		Role role = new Role();
		user.setRoles(new HashSet<Role>(roleService.findAll()));
		model.addAttribute("userForm", user);
		model.addAttribute("roleList", userService.getRoleName());
		List<String> appList = accountService.getAccountNames();
		model.addAttribute("accountList", appList);
		model.addAttribute("roleForm", role);
		model.addAttribute("calendarType",
				StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		// return "userDetails";
		return new ModelAndView("userDetails");
	}

	@RequestMapping(value = "/userDetails", method = RequestMethod.POST)
	public ModelAndView userDetails(@ModelAttribute("userForm") User userForm, BindingResult bindingResult,
			Model model) {
		userValidator.validate(userForm, bindingResult);

		if (bindingResult.hasErrors()) {
			model.addAttribute("roleList", userService.getRoleName());
			List<String> appList = accountService.getAccountNames();
			model.addAttribute("accountList", appList);
			return new ModelAndView("userDetails");
		}

		Set<Role> roles = new HashSet();
		Role role = roleService.findByName(userForm.getRole_Name());
		roles.add(role);
		userForm.setRoles(roles);

		userService.save(userForm);

		List<UserBean> userBeanList = new ArrayList<>();
		List<User> userList = userService.findAll();
		for (User userListDataBean : userList) {
			UserBean userBean = new UserBean();
			userBean.setUserID(userListDataBean.getUser_ID());
			userBean.setUsername(userListDataBean.getUsername());
			userBean.setPassword(userListDataBean.getPassword());
			userBean.setEmailID(userListDataBean.getEmail_ID());
			userBean.setResourceName(userListDataBean.getResourcename());
			userBean.setRoleName(userListDataBean.getRole_Name());

			boolean b = userListDataBean.isStatus();
			if (b == true) {
				userBean.setStatus1("Active");
			} else {
				userBean.setStatus1("InActive");
			}

			// userBean.setStatus(userListDataBean.isStatus());

			userBeanList.add(userBean);
		}
		model.addAttribute("userBeanList", userBeanList);
		model.addAttribute("calendarType",
				StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("viewUser");

		// List<AccountGoals> acctGoalsList = accountGoalService.findAll();

		// return new ModelAndView("viewUser", "userBean", userBean);
	}
	
	@RequestMapping(value = "/viewUser", method = RequestMethod.GET)
	public ModelAndView viewUser(@ModelAttribute("userForm") User userForm, BindingResult bindingResult, Model model) {
		HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		if(userAccountName != null)
		{
			userAccountName.trim();
		}
		List<UserBean> userBeanList = new ArrayList<>();
		List<User> userList = userService.findAll();
		if(userAccountName != null)
		{
			for (User userListDataBean : userList) {
				if(userListDataBean.getUser_Account() != null)
				{
					String[] userAcctList = userListDataBean.getUser_Account().split(",");
					for (String userAcct : userAcctList) {
						String accountName = userAcct.trim();
						if(accountName.equalsIgnoreCase(userAccountName)) 
						{
							UserBean userBean = new UserBean();
							userBean.setUserID(userListDataBean.getUser_ID());
							userBean.setUsername(userListDataBean.getUsername());
							userBean.setPassword(userListDataBean.getPassword());
							userBean.setEmailID(userListDataBean.getEmail_ID());
							userBean.setResourceName(userListDataBean.getResourcename());
							userBean.setRoleName(userListDataBean.getRole_Name());
							if (userListDataBean.isStatus() == true) {
								userBean.setStatus1("Active");
							} else {
								userBean.setStatus1("InActive");
							}
							userBeanList.add(userBean);
						}
					}				
				}
			}
		}
		Collections.sort(userBeanList);
		model.addAttribute("userBeanList", userBeanList);
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("viewUser");

		// List<AccountGoals> acctGoalsList = accountGoalService.findAll();

		// return new ModelAndView("viewUser", "userBean", userBean);
	}

/*	@RequestMapping(value = "/editUserData/{id}", method = RequestMethod.GET)
	public ModelAndView edit(@PathVariable Long id, @ModelAttribute("userBean") UserBean userBean, Model model) {
		// Emp emp=dao.getEmpById(id);

		User user = userService.findById(id);

		userBean.setUserID(user.getUser_ID());
		userBean.setUsername(user.getUsername());
		userBean.setPassword(user.getPassword());
		userBean.setEmailID(user.getEmail_ID());
		userBean.setResourceName(user.getResourcename());
		model.addAttribute("roleList", userService.getRoleName());
		userBean.setUser_account(user.getUser_Account());
        List<String> userAccountList = new ArrayList<String>(Arrays.asList(user.getUser_Account().split(",")));
        Gson gson = new Gson();
	    String userAccountListJson = gson.toJson(userAccountList);
	    model.addAttribute("userAccountListJson", userAccountListJson);
	    List<String> appList = accountService.getAccountNames();
	    String appListJson = gson.toJson(appList);
	    model.addAttribute("appListJson", appListJson);
        model.addAttribute("accountList", appList);
        
        	Role role = roleService.findById(user.getUser_ID());
			
	        if(role!=null)
	        {
	        	userBean.setRoleName(role.getRole_Name());
	        }
		userBean.setRoleName(user.getRole_Name());
		userBean.setStatus(user.isStatus());
		
		model.addAttribute("userBean", userBean);
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("editUserData");
	}

	@RequestMapping(value = "/editUserData/{id}", method = RequestMethod.POST)
	public ModelAndView editUserDataSave(@PathVariable Long id, @ModelAttribute("userBean") UserBean userForm,
			BindingResult bindingResult, Model model) {

		User user = new User();
		user.setUser_ID(userForm.getUserID());
		user.setUsername(userForm.getUsername());
		
		//need to change in feature
		User savedUser = userService.findById(id);
		user.setUser_Account(savedUser.getUser_Account());
		//will remove once done the edit changes
		
		user.setPassword(userForm.getPassword());
		user.setEmail_ID(userForm.getEmailID());
		user.setResourcename(userForm.getResourceName());
		user.setRole_Name(userForm.getRoleName());
		user.setStatus(userForm.isStatus());
		user.setUser_Account(userForm.getUser_account());
		

		Set<Role> roles = new HashSet();
		Role role = roleService.findByName(userForm.getRoleName());
		roles.add(role);
		user.setRoles(roles);
		
		userService.save(user);

		List<UserBean> userBeanList = new ArrayList<>();
		List<User> userList = userService.findAll();
		for (User userListDataBean : userList) {
			UserBean userBean = new UserBean();
			userBean.setUserID(userListDataBean.getUser_ID());
			userBean.setUsername(userListDataBean.getUsername());
			userBean.setPassword(userListDataBean.getPassword());
			userBean.setEmailID(userListDataBean.getEmail_ID());
			userBean.setResourceName(userListDataBean.getResourcename());
			userBean.setRoleName(userListDataBean.getRole_Name());

			if (userListDataBean.isStatus() == true) {
				userBean.setStatus1("Active");
			} else {
				userBean.setStatus1("InActive");
			}

			// userBean.setStatus(userListDataBean.isStatus());
			userBeanList.add(userBean);
		}
		Collections.sort(userBeanList);
		model.addAttribute("userBeanList", userBeanList);
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("viewUser");

	}*/
	// -------------------------------------------------------------------------------------------------------------------------

	
	@RequestMapping(value = "/editUserData/{id}", method = RequestMethod.GET)
	public ModelAndView edit(@PathVariable Long id, @ModelAttribute("userBean") UserBean userBean, Model model) {
		// Emp emp=dao.getEmpById(id);

		User user = userService.findById(id);

		userBean.setUserID(user.getUser_ID());
		userBean.setUsername(user.getUsername());
		userBean.setPassword(user.getPassword());
		userBean.setEmailID(user.getEmail_ID());
		userBean.setResourceName(user.getResourcename());
		model.addAttribute("roleList", userService.getRoleName());
		userBean.setUser_account(user.getUser_Account());
		List<String> userAccountList = new ArrayList<String>(Arrays.asList(user.getUser_Account().split(",")));
		Gson gson = new Gson();
		String userAccountListJson = gson.toJson(userAccountList);
		model.addAttribute("userAccountListJson", userAccountListJson);
		List<String> appList = accountService.getAccountNames();
		String appListJson = gson.toJson(appList);
		model.addAttribute("appListJson", appListJson);
		model.addAttribute("accountList", appList);

		/*
		 * Role role = roleService.findById(user.getUser_ID());
		 * 
		 * if(role!=null) { userBean.setRoleName(role.getRole_Name()); }
		 */
		userBean.setRoleName(user.getRole_Name());
		userBean.setStatus(user.isStatus());

		model.addAttribute("userBean", userBean);
		model.addAttribute("calendarType",
				StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("editUserData");
	}

	@RequestMapping(value = "/editUserData/{id}", method = RequestMethod.POST)
	public ModelAndView editUserDataSave(@PathVariable Long id, @ModelAttribute("userBean") UserBean userForm,
			BindingResult bindingResult, Model model) {

		User user = new User();
		user.setUser_ID(userForm.getUserID());
		user.setUsername(userForm.getUsername());

		// need to change in feature
		User savedUser = userService.findById(id);
		user.setUser_Account(savedUser.getUser_Account());
		// will remove once done the edit changes

		user.setPassword(userForm.getPassword());
		user.setEmail_ID(userForm.getEmailID());
		user.setResourcename(userForm.getResourceName());
		user.setRole_Name(userForm.getRoleName());
		user.setStatus(userForm.isStatus());
		user.setUser_Account(userForm.getUser_account());

		Set<Role> roles = new HashSet();
		Role role = roleService.findByName(userForm.getRoleName());
		roles.add(role);
		user.setRoles(roles);

		userService.save(user);

		List<UserBean> userBeanList = new ArrayList<>();
		List<User> userList = userService.findAll();
		for (User userListDataBean : userList) {
			UserBean userBean = new UserBean();
			userBean.setUserID(userListDataBean.getUser_ID());
			userBean.setUsername(userListDataBean.getUsername());
			userBean.setPassword(userListDataBean.getPassword());
			userBean.setEmailID(userListDataBean.getEmail_ID());
			userBean.setResourceName(userListDataBean.getResourcename());
			userBean.setRoleName(userListDataBean.getRole_Name());

			if (userListDataBean.isStatus() == true) {
				userBean.setStatus1("Active");
			} else {
				userBean.setStatus1("InActive");
			}

			// userBean.setStatus(userListDataBean.isStatus());
			userBeanList.add(userBean);
		}
		Collections.sort(userBeanList);
		model.addAttribute("userBeanList", userBeanList);
		model.addAttribute("calendarType",
				StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("viewUser");

	}
	// -------------------------------------------------------------------------------------------------------------------------

	
	@RequestMapping(value = "/createRole", method = RequestMethod.GET)
	public ModelAndView createRole(Model model) {
		model.addAttribute("roleForm", new Role());
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		// return "userDetails";
		return new ModelAndView("createRole");
	}

	@RequestMapping(value = "/createRole", method = RequestMethod.POST)
	public ModelAndView userDetails(@ModelAttribute("roleForm") Role roleForm, BindingResult bindingResult,
			Model model) {
		userValidator.validate(roleForm, bindingResult);

		if (bindingResult.hasErrors()) {
			return new ModelAndView("createRole");
		}

		roleService.save(roleForm);

		/*
		 * UserBean userBean=new UserBean();
		 * 
		 * User user=userService.findById(userForm.getUser_ID());
		 * 
		 * userBean.setUserID(user.getUser_ID());
		 * userBean.setUserName(user.getEmail_ID());
		 * userBean.setEmailID(user.getEmail_ID());
		 * userBean.setResourceName(user.getUsername());
		 * userBean.setStatus(user.getStatus());
		 */
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("viewRole");
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(Model model, String error, String logout) {
		if (error != null)
			model.addAttribute("message", "Your username and password is invalid.");

		if (logout != null)
			model.addAttribute("message", "You have been logged out successfully.");

		return "login";
	}
	
	@RequestMapping(value = "/selectAccount", method = RequestMethod.GET)
	public String selectAccount(@ModelAttribute("userForm") UserBean user, Model model,
			HttpServletRequest request) {

		// model.addAttribute("userForm", user);
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();
		
		List<String> userAccountsList = userService.getUserAccounts(loginusrname);
		model.addAttribute("showUID", loginusrname);
		model.addAttribute("userAccounts", userAccountsList);
		//userService.insertUserLogin(loginusrname, request.getParameter("Account_Name"), "Logged In Successfully");
		return "selectAccount";
	}
	
	@RequestMapping(value = "/selectAccount", method = RequestMethod.POST)
	public String selectAccountPOST(@ModelAttribute("userForm") UserBean user, Model model,
			HttpServletRequest request) {

		// model.addAttribute("userForm", user);
		
		
		
		return "viewCalendar";
	}
	
	@RequestMapping(value = "/chart", method = RequestMethod.GET)
	public String chart(@ModelAttribute("userForm") UserBean user, Model model,
			HttpServletRequest request) {

		// model.addAttribute("userForm", user);
		String eventReqId = request.getParameter("chartEventId");
		EventEntry eventEntryObj = null;
		
		if(!StringUtils.isEmpty(eventReqId)){
			eventEntryObj = eventEntryService.findById(Long.parseLong(eventReqId));
		}
		
		model.addAttribute("CalendarTypeName",calendarTypeService.findByCalendarTypeId(eventEntryObj.getCalendar_type_id()).getCalendar_type_name());
		
		/* AppName start */
		Set<String> eventAppSet =new HashSet<String>();
		int i=0;
		
		for (EventApplication eventApp : eventEntryObj.getEventAppSet() ) {
			eventAppSet.add(eventApp.getApplication());
			i++;
		}
		
		model.addAttribute("ApplicationNames",String.join(",",eventAppSet));
		/* AppName end */
		
		/* ResourceName start */
		
		Set<String> eventUserSet=new HashSet<String>();
		int j=0;
		for(EventUser eventUser:eventEntryObj.getEventUserSet()){
			//for(String Username: userService.findByUsername(eventUser))
			eventUserSet.add(eventUser.getResource());
			j++;
		}
		/*eventUserSet = Arrays.stream(eventUserSet)
                .filter(s -> (s != null && s.length() > 0))
                .toArray(String[]::new);
		
		Set<String> userSet = new HashSet<String>(Arrays.asList(eventUserSet));    		
		eventUserSet= userSet.toArray(new String[userSet.size()]);
		String eventUsersString = String.join(",", eventUserSet);*/
		
		model.addAttribute("ResourceNames",String.join(",",eventUserSet));
		
		/* ResourceName end */
		
		model.addAttribute("RegionName",regionService.findById(eventEntryObj.getRegion_id()).getRegion_territory());
		
		model.addAttribute("eventEntryVal",eventEntryObj);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName();

		model.addAttribute("showUID", loginusrname);
		
		/* chart section starts here */
		
		List<EventPlanned> epb = new LinkedList<EventPlanned>();
		Map<Integer,List<EventPlanned>> epbMap = new HashMap<Integer,List<EventPlanned>>();
		List<EventPlanned> epbBean = eventEntryService.getAllPlanned(eventEntryObj.getEvent_ID());
		List<String> cpLabelStr = new LinkedList<String>();
		List<String> plannedDtStr = new LinkedList<String>();
		List<String> actualDtStr = new LinkedList<String>();
		String overallEventStartTime = "";
		String overallEventEndTime = "";
		int count = 1;
		for(EventPlanned ep: epbBean){
			if(!StringUtils.isEmpty(ep.getCritical_Path()) && ep.getCritical_Path().split("_").length > 1  
					&& Integer.parseInt(ep.getCritical_Path().split("_")[1]) == count){
				epbMap.put(count, epb);
				epb  = new LinkedList<EventPlanned>();
				cpLabelStr.add("'CP "+count+"'");
				if(ep.getDay() != null && ep.getDay().equalsIgnoreCase("1")){
					plannedDtStr.add("{y: new Date(\"2020-09-22 "+ ep.getPlanned_End_Time() + "\")}");
				} else {
					plannedDtStr.add("{y: new Date(\"2020-09-23 "+ ep.getPlanned_End_Time() + "\")}");
				}
				if(count == 1){
					overallEventStartTime = ep.getPlanned_Start_Time();
					model.addAttribute("overallEventStartTimeVal",overallEventStartTime);
				}
				count++;
			} else {
				epb.add(ep);
			}
			model.addAttribute("overallEventEndTimeVal",ep.getPlanned_End_Time());
		}
		
		/* CP LABEL STARTS HERE */
		
		StringBuilder str = new StringBuilder("");
		
		str.append("[");
        // Traversing the ArrayList
        for (String eachstring : cpLabelStr) {
  
            // Each element in ArrayList is appended
            // followed by comma
            str.append(eachstring).append(",");
        }
        // StringBuffer to String conversion
        String commaseparatedlist = str.toString();
        if (commaseparatedlist.length() > 0)
            commaseparatedlist
                = commaseparatedlist.substring(
                    0, commaseparatedlist.length() - 1);
        commaseparatedlist = commaseparatedlist + "]";
		model.addAttribute("cpLabelListStr", commaseparatedlist);
        /* CP LABEL ENDS HERE */
        
        /* PLANNED STARTS HERE */
        
        str = new StringBuilder("");
		
		str.append("[");
        // Traversing the ArrayList
        for (String eachstring : plannedDtStr) {
  
            // Each element in ArrayList is appended
            // followed by comma
            str.append(eachstring).append(",");
        }
        // StringBuffer to String conversion
        commaseparatedlist = str.toString();
        if (commaseparatedlist.length() > 0)
            commaseparatedlist
                = commaseparatedlist.substring(
                    0, commaseparatedlist.length() - 1);
        commaseparatedlist = commaseparatedlist + "]";
		model.addAttribute("plannedDtListStr", commaseparatedlist);
        /* PLANNED ENDS HERE */
		
		/* ACTUAL STARTS HERE */
        
        str = new StringBuilder("");
		
		str.append("[");
        // Traversing the ArrayList
        for (String eachstring : actualDtStr) {
  
            // Each element in ArrayList is appended
            // followed by comma
            str.append(eachstring).append(",");
        }
        // StringBuffer to String conversion
        commaseparatedlist = str.toString();
        if (commaseparatedlist.length() > 0)
            commaseparatedlist
                = commaseparatedlist.substring(
                    0, commaseparatedlist.length() - 1);
        commaseparatedlist = commaseparatedlist + "]";
		model.addAttribute("actualDtListStr", commaseparatedlist);
        /* ACTUAL ENDS HERE */
        
        
		model.addAttribute("epMapVal",epbMap);
		
		/* chart section ends here */
		
		
		return "chart";
	}
	
	/*@RequestMapping(value = {"/selectAccount"}, method = RequestMethod.GET)
	public ModelAndView selectAccount(Model model, @ModelAttribute("userBean") UserBean userBean) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
	    String userName = auth.getName(); //get logged in username			
		User user = userService.findByUsername(userName);
		if(user != null)
		{
			List<String> accountNameList = userService.findAccountsByUserID(user.getUser_ID());
			model.addAttribute("accountList", accountNameList);
			userBean.setUsername(user.getUsername());
		}
		else
		{
			model.addAttribute("error", "Your username is invalid.");
			return new ModelAndView("login");
		}
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("selectAccount");
	}*/

	@RequestMapping(value = {"/home" }, method = RequestMethod.GET)
	public String home(Model model) {
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return "home";
	}
	
	@RequestMapping(value = "/consolidatedCalender", method = RequestMethod.GET)
	public String viewConsolidatedCalendar(@ModelAttribute("userBean") UserBean userBean, BindingResult result, Model model) throws ParseException {
		/*HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");*/
		List<CalendarBean> evnetCalendarBeanList=new ArrayList<>();
		HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		List<EventEntry> eventList = eventEntryService.findAllEventByResource(userAccountName);
    	for(EventEntry event:eventList){
    		if(event.getEventstatus()!=null && !event.getEventstatus().equalsIgnoreCase("Cancelled"))
    		{
	    		CalendarBean calendarBean=new CalendarBean();
	    		//eventEntryBean.setEvent_ID(event.getEvent_ID());
	    		calendarBean.setTitle(event.getEventname());
	    		//eventEntryBean.setDescription_details(event.getDescription_details());
	    		calendarBean.setDescription(event.getDescription_details());
	    		calendarBean.setStart(event.getStart_date());
	    		calendarBean.setEnd(event.getEnd_date());
	    		calendarBean.setEngagement(event.getEngagement_Name());
	    		calendarBean.setAdditional_recipients(event.getEmail_receipients1());
	    		calendarBean.setRegion(regionService.findById(event.getRegion_id()).getRegion_territory());
	    		calendarBean.setCalendarType(calendarTypeService.findById(event.getCalendar_type_id()).getCalendar_type_name());
	    		//eventEntryBean.setRegion_territory(event.getRegion_territory());
	    		//eventEntryBean.setRisk_summary(event.getRisk_summary());
	    		
	    		//String[] eventAppSet =new String[event.getEventAppSet().size()];
	    		
	    		Set<String> eventAppSet = new HashSet<String>();
	    		
	    		int i=0;
	    		
	    		for (EventApplication eventApp : event.getEventAppSet() ) {
	    			
	    			eventAppSet.add(eventApp.getApplication());
	    			i++;
	    			
	    			/*if(i==0){
	    				eventAppStr.append(eventAppSet[i]);
	    				eventAppStr.append(",");
	    			} else {
	    				eventAppStr.append(eventAppSet[i]);
	    			}*/
	    		}
	    		calendarBean.setEventAppSet(eventAppSet);
	    		
	     		Set<String> eventUserSet = new HashSet<String>();
	     		
	    		//String[] eventUserSet=new String[event.getEventUserSet().size()];
	    		int j=0;
	    		for(EventUser eventUser:event.getEventUserSet()){
	    			/*for(String Username: userService.findByUsername(eventUser))*/
	    			eventUserSet.add(eventUser.getResource());
	    			//eventUserSet[j] = eventUser.getResource();
	    			j++;
	    		}
				calendarBean.setEventUserSet(eventUserSet);
	    		
	    		calendarBean.setRemarks(event.getRemarks());
	    		
	    		EventEntryBean eventEntryBean = new EventEntryBean();
	    		
	    		eventEntryBean.setEngagement_Name(event.getEngagement_Name());
	    		
	    		String eventAppString = String.join(",", eventAppSet);
	    		//eventEntryBean.setApplicationNameSet(eventAppSet);
	    		eventEntryBean.setApplicationName(eventAppString);
	    		
	    		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	    		
	    		Date theStartDate = format.parse(event.getStart_date());
	    		Calendar startCal = Calendar.getInstance();
	    	    startCal.setTime(theStartDate);
	    	    
	    	    String pattern = "yyyy-MM-dd";
	    	    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
	    	    String pattern2 = "HH:mm:ss";
	    	    SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat(pattern2);
	    	    
	    	    String startDate = simpleDateFormat.format(startCal.getTime());
	    	    eventEntryBean.setStart_date(startDate);
	    	    
	    	    String startTime = simpleDateFormat2.format(startCal.getTime());
	    	    eventEntryBean.setStart_time(startTime);
	    	    calendarBean.setStartTime(startTime);
	    		
	    	    Date theEndDate = format.parse(event.getEnd_date());
	    		Calendar endCal = Calendar.getInstance();
	    	    endCal.setTime(theEndDate);
	    	    
	    	    String endDate = simpleDateFormat.format(endCal.getTime());
	    	    eventEntryBean.setEnd_date(endDate);
	    	    
	    	    String endTime = simpleDateFormat2.format(endCal.getTime());
	    	    eventEntryBean.setEnd_time(endTime);
	    	    calendarBean.setEndTime(endTime);
	    		
	    	    eventEntryBean.setRecurrence_type(event.getRecurrence_type());
	    		eventEntryBean.setRecu_every_day(event.getRecu_every_day());
	    		eventEntryBean.setRecu_every_weekday(event.getRecu_every_weekday());
	    		eventEntryBean.setRecurrence_dayName(event.getRecurrence_dayName());
	    		eventEntryBean.setRecu_every_week(event.getRecu_every_week());
	    		eventEntryBean.setRecu_month_day(event.getRecu_month_day());
	    		eventEntryBean.setRecu_every_month(event.getRecu_every_month());
	    		
	    		//will change once added as like in database
	    		//eventEntryBean.setApplicationName("ERP Finance");
	    		
	    		//List<String> incidentList = allIncidentsListUpdating(eventEntryBean);
	    		//calendarBean.setIncidents(incidentList);
	    		List<CalendarBean> cbl=getRecurrenceList(calendarBean,event);//new ArrayList<CalendarBean>();
	    		for(CalendarBean cb : cbl) {
	    			evnetCalendarBeanList.add(cb);
	    		}
	    		
	    		
	    		//evnetCalendarBeanList.add(calendarBean);
    		}
    	}
    	
    	Gson gson = new Gson();
    	String calendarJSON=gson.toJson(evnetCalendarBeanList);
    	
    	model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
      	  model.addAttribute("calendarJSON", calendarJSON);
      	 
       		model.addAttribute("calendarid", "Consolidated");  
       	  
      	// model.addAttribute("evnetEntryBeanList", evnetCalendarBeanList);
      	   
          //return new ModelAndView("viewEntry");
       	Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        model.addAttribute("userRoleName", auth.getAuthorities());
    		
    	return "viewCalendar";

	
	}
	
	
	
	/*@RequestMapping(value = {"/", "/welcome" }, method = RequestMethod.POST)
	public ModelAndView viewUserCalendar(@ModelAttribute("userBean") UserBean userBean, BindingResult result, Model model) throws ParseException {

		HttpSession httpSession = httpServletRequest.getSession();
		List<EventEntry> eventList = new ArrayList<>();
		if(userBean.getUserAccontName() != null && !userBean.getUserAccontName().equals(""))
		{
			httpSession.setAttribute("userAcctName",userBean.getUserAccontName());
			eventList = eventEntryService.findAllEventByResource(userBean.getUserAccontName());
		}
		else
		{
			model.addAttribute("message", "Please Select AccountName");
			return new ModelAndView(new RedirectView("/account/selectAccount"));
		}
		List<CalendarBean> evnetCalendarBeanList=new ArrayList<>();
    	for(EventEntry event:eventList){
    		if(event.getEventstatus()!=null && !event.getEventstatus().equalsIgnoreCase("Cancelled"))
    		{
    			CalendarBean calendarBean=new CalendarBean();
	    		//eventEntryBean.setEvent_ID(event.getEvent_ID());
	    		calendarBean.setTitle(event.getEventname());
	    		//eventEntryBean.setDescription_details(event.getDescription_details());
	    		calendarBean.setDescription(event.getDescription_details());
	    		calendarBean.setStart(event.getStart_date());
	    		calendarBean.setEnd(event.getEnd_date());
	    		calendarBean.setEngagement(event.getEngagement_Name());
	    		calendarBean.setAdditional_recipients(event.getEmail_receipients1());
	    		calendarBean.setRegion(regionService.findById(event.getRegion_id()).getRegion_territory());
	    		calendarBean.setCalendarType(calendarTypeService.findById(event.getCalendar_type_id()).getCalendar_type_name());
	    		
	    		//eventEntryBean.setRegion_territory(event.getRegion_territory());
	    		//eventEntryBean.setRisk_summary(event.getRisk_summary());
	    		
	    		//String[] eventAppSet =new String[event.getEventAppSet().size()];
	    		
	    		Set<String> eventAppSet = new HashSet<String>();
	    		
	    		int i=0;
	    		
	    		for (EventApplication eventApp : event.getEventAppSet() ) {
	    			
	    			eventAppSet.add(eventApp.getApplication());
	    			i++;
	    		}
	    		calendarBean.setEventAppSet(eventAppSet);
	    		
	     		Set<String> eventUserSet = new HashSet<String>();
	     		
	    		//String[] eventUserSet=new String[event.getEventUserSet().size()];
	    		int j=0;
	    		for(EventUser eventUser:event.getEventUserSet()){
	    			//for(String Username: userService.findByUsername(eventUser))
	    			eventUserSet.add(eventUser.getResource());
	    			//eventUserSet[j] = eventUser.getResource();
	    			j++;
	    		}
	    		calendarBean.setEventUserSet(eventUserSet);
	    		
	    		calendarBean.setRemarks(event.getRemarks());
	    		
	    		EventEntryBean eventEntryBean = new EventEntryBean();
	    		
	    		eventEntryBean.setEngagement_Name(event.getEngagement_Name());
	    		
	    		String eventAppString = String.join(",", eventAppSet);
	    		//eventEntryBean.setApplicationNameSet(eventAppSet);
	    		eventEntryBean.setApplicationName(eventAppString);
	    		
	    		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	    		
	    		Date theStartDate = format.parse(event.getStart_date());
	    		Calendar startCal = Calendar.getInstance();
	    	    startCal.setTime(theStartDate);
	    	    
	    	    String pattern = "yyyy-MM-dd";
	    	    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
	    	    String pattern2 = "HH:mm:ss";
	    	    SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat(pattern2);
	    	    
	    	    String startDate = simpleDateFormat.format(startCal.getTime());
	    	    eventEntryBean.setStart_date(startDate);
	    	    
	    	    String startTime = simpleDateFormat2.format(startCal.getTime());
	    	    eventEntryBean.setStart_time(startTime);
	    	    calendarBean.setStartTime(startTime);
	    		
	    	    Date theEndDate = format.parse(event.getEnd_date());
	    		Calendar endCal = Calendar.getInstance();
	    	    endCal.setTime(theEndDate);	    	    
	    	    
	    	    String endDate = simpleDateFormat.format(endCal.getTime());
	    	    eventEntryBean.setEnd_date(endDate);
	    	    
	    	    String endTime = simpleDateFormat2.format(endCal.getTime());
	    	    eventEntryBean.setEnd_time(endTime);
	    	    calendarBean.setEndTime(endTime);
	    		
	    	    eventEntryBean.setRecurrence_type(event.getRecurrence_type());
	    		eventEntryBean.setRecu_every_day(event.getRecu_every_day());
	    		eventEntryBean.setRecu_every_weekday(event.getRecu_every_weekday());
	    		eventEntryBean.setRecurrence_dayName(event.getRecurrence_dayName());
	    		eventEntryBean.setRecu_every_week(event.getRecu_every_week());
	    		eventEntryBean.setRecu_month_day(event.getRecu_month_day());
	    		eventEntryBean.setRecu_every_month(event.getRecu_every_month());
	    		
	    		//will change once added as like in database
	    		//eventEntryBean.setApplicationName("ERP Finance");
	    		
	    		//List<String> incidentList = allIncidentsListUpdating(eventEntryBean);
	    		//calendarBean.setIncidents(incidentList);
	    		
	    		//evnetCalendarBeanList.add(calendarBean);
	    		List<CalendarBean> cbl=getRecurrenceList(calendarBean,event);//new ArrayList<CalendarBean>();
	    		for(CalendarBean cb : cbl) {
	    			evnetCalendarBeanList.add(cb);
	    		}
    		}
    	}
    	
    	Gson gson = new Gson();
    	String calendarJSON=gson.toJson(evnetCalendarBeanList);
    	
    	model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
      	  model.addAttribute("calendarJSON", calendarJSON);
      	 
       		model.addAttribute("calendarid", "Consolidated");  
       	  
      	// model.addAttribute("evnetEntryBeanList", evnetCalendarBeanList);
      	   
          //return new ModelAndView("viewEntry");
       	
       	Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        model.addAttribute("userRoleName", auth.getAuthorities()); 
        	
    	return new ModelAndView("viewCalendar");

	
	}*/
	
	/**
	 * Welcome.
	 *
	 * @param model        the model
	 * @param modelAndView the model and view
	 * @return the model and view
	 */
	@RequestMapping(value = {"/", "/welcome" }, method = RequestMethod.GET)
	public ModelAndView welcome(Model model, ModelAndView modelAndView) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String loginusrname = auth.getName(); // get logged in username
		try {
			/*userService.resetAttempts(loginusrname);

			LandingScreenBean accessControlBean = userService.getUserDetail(loginusrname);

			if (accessControlBean.getDefaultLandingPage() == 2 && accessControlBean.getProfileID() > 1) {
				modelAndView.setViewName("redirect:ticketSummary?fromLogin=1&searchTypeChosen=2");
				model.addAttribute("formheading", "Ticket Summary");
			} else if (accessControlBean.getDefaultLandingPage() == 1) {
				modelAndView.setViewName("redirect:dashboard");
				// modelAndView.setViewName("redirect:teamMemberDashboard");
				// model.addAttribute("formheading", "Ticket Summary");
			} else if (accessControlBean.getDefaultLandingPage() == 3) {
				modelAndView.setViewName("redirect:search");
				// model.addAttribute("formheading", "Ticket Summary");
			} else if (accessControlBean.getDefaultLandingPage() == 4) {
				modelAndView.setViewName("redirect:underconstruction.jsp");
				// model.addAttribute("formheading", "Ticket Summary");
			} else if (accessControlBean.getDefaultLandingPage() == 5) {
				modelAndView.setViewName("redirect:koList");
				// model.addAttribute("formheading", "Ticket Summary");
			} else if (accessControlBean.getDefaultLandingPage() == 6) {
				modelAndView.setViewName("redirect:viewProfile");
				// model.addAttribute("formheading", "Ticket Summary");
			} else if (accessControlBean.getDefaultLandingPage() == 7) {
				modelAndView.setViewName("redirect:underconstruction.jsp");
				// model.addAttribute("formheading", "Ticket Summary");
			} else if (accessControlBean.getDefaultLandingPage() == 8) {
				modelAndView.setViewName("redirect:setting");
				// model.addAttribute("formheading", "Ticket Summary");
			} else {
				modelAndView.setViewName("redirect:ticketSummary?fromLogin=1");
				model.addAttribute("formheading", "Ticket Summary");
			}

			userService.insertUserLogin(loginusrname, getDefaultAccountId(), "");*/
			
			modelAndView.setViewName("redirect:selectAccount/"+loginusrname);
			
			return modelAndView;
		} catch (Exception e) {
			//userService.insertUserLogin(loginusrname, getDefaultAccountId(), e.getMessage());
			return null;
		}
	}
	
    public List<String> allIncidentsListUpdating(EventEntryBean eventEntryBean) throws java.text.ParseException 
    {
    	String accName = eventEntryBean.getEngagement_Name();
    	//String startDate = eventEntryBean.getStart_date();
  		//String endDate = eventEntryBean.getEnd_date();
		//List<HashMap<String, Object>> all_incidents = userService.getAllIncidents(accName,applicationName, startDate, endDate);
  		
    	List<HashMap<String, String>> all_incidents1 = new ArrayList<HashMap<String, String>>();
  		HashMap<String, String> map =  new HashMap<>();
  		//SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
  		SimpleDateFormat sdf = new SimpleDateFormat( "yyyy-MM-dd'T'HH:mm" );
		//String dateInString = "6-12-2018 10:20:56";
  		String dateInString = eventEntryBean.getStart_date()+"T"+eventEntryBean.getStart_time();
		Date startDate = sdf.parse(dateInString);
		
		//String dateInEndString = "12-12-2018 12:40:56";
		String dateInEndString = eventEntryBean.getEnd_date()+"T"+eventEntryBean.getEnd_time();
		Date endDate = sdf.parse(dateInEndString);
		HashMap<String, String> weekdaysList = new HashMap<>();
		boolean isWeekDay = false;
		List<HashMap<String, String>> all_incidents  = new ArrayList<>();
		if(eventEntryBean.getRecurrence_type() != null && eventEntryBean.getRecurrence_type().equalsIgnoreCase("daily") && eventEntryBean.getRecu_every_day() != null)
	    {
			isWeekDay = false;
			weekdaysList = EventEntryController.getWorkingDaysBetweenTwoDates(startDate, endDate,isWeekDay, eventEntryBean.getRecu_every_day());
			for (Map.Entry<String,String> entry : weekdaysList.entrySet()) 
	        {
				all_incidents1 = userService.getAllIncidentsByDaily(accName,eventEntryBean.getApplicationName(), entry.getKey(), entry.getValue(),eventEntryBean.getRecurrence_type(),eventEntryBean.getRecu_every_day());
				all_incidents.addAll(all_incidents1);
	        }
	    }
		else if(eventEntryBean.getRecurrence_type() != null && eventEntryBean.getRecurrence_type().equalsIgnoreCase("daily") && eventEntryBean.getRecu_every_weekday() != null)
		{
			isWeekDay = true;
			String defaultValue = "1";
			weekdaysList = EventEntryController.getWorkingDaysBetweenTwoDates(startDate, endDate,isWeekDay,defaultValue);
			for (Map.Entry<String,String> entry : weekdaysList.entrySet()) 
	        {
				all_incidents1 = userService.getAllIncidentsByDaily(accName,eventEntryBean.getApplicationName(), entry.getKey(), entry.getValue(),eventEntryBean.getRecurrence_type(),eventEntryBean.getRecu_every_day());
				all_incidents.addAll(all_incidents1);
	        }
		}
		
		else if(eventEntryBean.getRecurrence_type() != null && eventEntryBean.getRecurrence_type().equalsIgnoreCase("weekly")  && eventEntryBean.getRecurrence_dayName() != null && eventEntryBean.getRecu_every_week() != null)
		{
			String days = eventEntryBean.getRecurrence_dayName();
			String recurrenceWeeks = eventEntryBean.getRecu_every_week();
			weekdaysList = EventEntryController.getPerticualerWeekOfDaysBetweenTwoDates(startDate, endDate,days,recurrenceWeeks);
			for (Map.Entry<String,String> entry : weekdaysList.entrySet()) 
	        {
				all_incidents1 = userService.getAllIncidentsByDaily(accName,eventEntryBean.getApplicationName(), entry.getKey(), entry.getValue(),eventEntryBean.getRecurrence_type(),eventEntryBean.getRecu_every_day());
				all_incidents.addAll(all_incidents1);
	        }
		}
		else if(eventEntryBean.getRecurrence_type() != null && eventEntryBean.getRecurrence_type().equalsIgnoreCase("monthly")  && !eventEntryBean.getRecu_month_day().equalsIgnoreCase("") && !eventEntryBean.getRecu_every_month().equalsIgnoreCase(""))
		{
			String days = eventEntryBean.getRecu_month_day();
			String recurrenceMonths = eventEntryBean.getRecu_every_month();
			weekdaysList = EventEntryController.getPerticualerMonthDaysBetweenTwoDates(startDate, endDate,days,recurrenceMonths);
			for (Map.Entry<String,String> entry : weekdaysList.entrySet()) 
	        {
				all_incidents1 = userService.getAllIncidentsByDaily(accName,eventEntryBean.getApplicationName(), entry.getKey(), entry.getValue(),eventEntryBean.getRecurrence_type(),eventEntryBean.getRecu_every_day());
				all_incidents.addAll(all_incidents1);
	        }
		}
		
		List<IncidentBean> allIncidentsList = new ArrayList<>();
		List<String> allCausecodeIdsList = new ArrayList<>();
		HashMap<String, List> incidentsList = new HashMap<>();
		if(!all_incidents.isEmpty() && all_incidents != null)
		{
			for (HashMap<String, String> allIncidentsMap : all_incidents) {
				Iterator<Entry<String, String>> it = allIncidentsMap.entrySet().iterator();
				IncidentBean incidentBean = new IncidentBean();
				while (it.hasNext()) {
			        Map.Entry pair = (Map.Entry)it.next();
			        if(checkKeyValueNull(pair) && "Incident_ID".equalsIgnoreCase(pair.getKey().toString()))
			        incidentBean.setIncident_ID(pair.getValue().toString());
			        if(checkKeyValueNull(pair) && "Reported_Date".equalsIgnoreCase(pair.getKey().toString()))
				    incidentBean.setReported_Date(pair.getValue().toString());
			        if(checkKeyValueNull(pair) && "appName".equalsIgnoreCase(pair.getKey().toString()))
				    incidentBean.setApp_Name(pair.getValue().toString());
			        if(checkKeyValueNull(pair) && "token".equalsIgnoreCase(pair.getKey().toString()))
			        incidentBean.setCausecode_id(pair.getValue().toString());
				}
				incidentBean.setStartDate(startDate.toString());
				incidentBean.setEndDate(endDate.toString());
				allCausecodeIdsList.add(incidentBean.getIncident_ID());
				eventEntryService.saveIncidents(incidentBean);
				allIncidentsList.add(incidentBean);
			}	
		}
		
		Map<String,List<String>> map1 = new HashMap<String,List<String>>();
		List<String> list = new ArrayList<>();
		List<String> dummy=new ArrayList<>();
		
		for (IncidentBean incidentBean : allIncidentsList)
		{
			if(!dummy.contains(incidentBean.getCausecode_id()))
			{
				dummy.add(incidentBean.getCausecode_id());
				
				for (IncidentBean incidentBeann : allIncidentsList)
				{
					if(incidentBean.getCausecode_id().equalsIgnoreCase(incidentBeann.getCausecode_id()))
					{
						list.add(incidentBeann.getIncident_ID());
						map1.put(incidentBean.getCausecode_id(), list);
					}
				}
			}
			list = new ArrayList<>();
		}
		/*String sendMailReturnValue = null;
		//mailService.sendMail("dactoolssupport.in@capgemini.com", "Incidents List", +allIncidentsList.size()+" incidents occured in period "+startDate+" to "+endDate);
		sendMailReturnValue = mailService.sendEmail("dactoolssupport.in@capgemini.com","Incidents List",  +allIncidentsList.size()+" incidents occured in period "+startDate+" to "+endDate);
		if(sendMailReturnValue.equalsIgnoreCase("smtpErrorPage"))
        {
        	model.addAttribute("mailserverIssue", "There is an Error Connecting to Mail Server, Kindly wait for some time and try again!! If the problem persist, Please Contact Technical Support Team na-am-industrialization-bangalore.in@capgemini.com");
        	List<String> appList = applicationService.getAppNames();
        	model.addAttribute("appNameList",appList);
        	return "searchIncidents";
        }
		Gson gson = new Gson();
		if(eventEntryBean.getRecurrence_dayName() != null)
  		{
  			List<String> recurrence_dayNameList = new ArrayList<String>(Arrays.asList(eventEntryBean.getRecurrence_dayName().split(",")));
  	        String recurrence_dayNamesJson = gson.toJson(recurrence_dayNameList);
  	        model.addAttribute("recurrence_dayNamesJson", recurrence_dayNamesJson);
  		}
		model.addAttribute("allIncidentsList", allIncidentsList);
		HttpSession httpSession = httpServletRequest.getSession();
		httpSession.setAttribute("map1",map1);
		model.addAttribute("causecodeList", map1);*/
		
    	return allCausecodeIdsList;
    }
	
	
	private boolean checkKeyValueNull(Map.Entry pair) {
		return (null != pair.getKey() && !com.mysql.jdbc.StringUtils.isNullOrEmpty(String.valueOf(pair.getKey())) && null != pair.getValue() && !com.mysql.jdbc.StringUtils.isNullOrEmpty(String.valueOf(pair.getValue())));
	}
	
	
	@RequestMapping(value = {"/viewCalendar" }, method = RequestMethod.GET)
	public String viewCalendar(Model model) throws ParseException {
		
		HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		List<CalendarBean> evnetCalendarBeanList=new ArrayList<>();
		List<EventEntry> eveMaintList = new ArrayList<>();
		List<EventEntry> eventAccountList = eventEntryService.findAllEventByResource("DAC");
		List<EventEntry> eventCalenderListList = eventEntryService.findAll("Period End close");
		for(EventEntry eventAcct: eventAccountList){
			for (EventEntry eventEntry : eventCalenderListList) {
				if(eventEntry.getEvent_ID().equals(eventAcct.getEvent_ID())){
					eveMaintList.add(eventAcct);
				}
			}
		}
    	for(EventEntry event:eveMaintList){
    		if(event.getEventstatus()!=null && !event.getEventstatus().equalsIgnoreCase("Cancelled"))
    		{
	    		CalendarBean calendarBean=new CalendarBean();
	    		//eventEntryBean.setEvent_ID(event.getEvent_ID());
	    		calendarBean.setTitle(event.getEventname());
	    		//eventEntryBean.setDescription_details(event.getDescription_details());
	    		calendarBean.setDescription(event.getDescription_details());
	    		calendarBean.setStart(event.getStart_date());
	    		
	    		//Commented By Bkm for new calendar view
	    		calendarBean.setEnd(event.getEnd_date());
	    		/*calendarBean.setEngagement(event.getEngagement_Name());
	    		calendarBean.setAdditional_recipients(event.getEmail_receipients1());
	    		calendarBean.setRegion(regionService.findById(event.getRegion_id()).getRegion_territory());
	    		calendarBean.setCalendarType(calendarTypeService.findById(event.getCalendar_type_id()).getCalendar_type_name());*/
	    		
	    		
	    		//eventEntryBean.setRegion_territory(event.getRegion_territory());
	    		//eventEntryBean.setRisk_summary(event.getRisk_summary());
	    		
	    		//String[] eventAppSet =new String[event.getEventAppSet().size()];
	    		
	    		Set<String> eventAppSet = new HashSet<String>();
	    		int i=0;
	    		
	    		for (EventApplication eventApp : event.getEventAppSet() ) {
	    			
	    			eventAppSet.add(eventApp.getApplication());
	    			i++;
	    			
	    			/*if(i==0){
	    				eventAppStr.append(eventAppSet[i]);
	    				eventAppStr.append(",");
	    			} else {
	    				eventAppStr.append(eventAppSet[i]);
	    			}*/
	    		}
	    		calendarBean.setEventAppSet(eventAppSet);
	    		
	    		Set<String> eventUserSet = new HashSet<String>();
	    		//String[] eventUserSet=new String[event.getEventUserSet().size()];
	    		int j=0;
	    		for(EventUser eventUser:event.getEventUserSet()){
	    			/*for(String Username: userService.findByUsername(eventUser))*/
	    			//eventUserSet[j] = eventUser.getResource();
	    			eventUserSet.add(eventUser.getResource());
	    			j++;
	    		}
				calendarBean.setEventUserSet(eventUserSet);
	    		
	    		calendarBean.setRemarks(event.getRemarks());
	    		
	    		EventEntryBean eventEntryBean = new EventEntryBean();
	    		
	    		eventEntryBean.setEngagement_Name(event.getEngagement_Name());
	    		
	    		String eventAppString = String.join(",", eventAppSet);
	    		//eventEntryBean.setApplicationNameSet(eventAppSet);
	    		eventEntryBean.setApplicationName(eventAppString);
	    		
	    		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	    		
	    		Date theStartDate = format.parse(event.getStart_date());
	    		Calendar startCal = Calendar.getInstance();
	    	    startCal.setTime(theStartDate);
	    	    
	    	    String pattern = "yyyy-MM-dd";
	    	    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
	    	    String pattern2 = "HH:mm:ss";
	    	    SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat(pattern2);
	    	    
	    	    String startDate = simpleDateFormat.format(startCal.getTime());
	    	    eventEntryBean.setStart_date(startDate);
	    	    
	    	    String startTime = simpleDateFormat2.format(startCal.getTime());
	    	    eventEntryBean.setStart_time(startTime);
	    	    calendarBean.setStartTime(startTime);
	    		
	    	    Date theEndDate = format.parse(event.getEnd_date());
	    		Calendar endCal = Calendar.getInstance();
	    	    endCal.setTime(theEndDate);
	    	    
	    	    String endDate = simpleDateFormat.format(endCal.getTime());
	    	    eventEntryBean.setEnd_date(endDate);
	    	    
	    	    String endTime = simpleDateFormat2.format(endCal.getTime());
	    	    eventEntryBean.setEnd_time(endTime);
	    	    calendarBean.setEndTime(endTime);
	    		
	    	    eventEntryBean.setRecurrence_type(event.getRecurrence_type());
	    		eventEntryBean.setRecu_every_day(event.getRecu_every_day());
	    		eventEntryBean.setRecu_every_weekday(event.getRecu_every_weekday());
	    		eventEntryBean.setRecurrence_dayName(event.getRecurrence_dayName());
	    		eventEntryBean.setRecu_every_week(event.getRecu_every_week());
	    		eventEntryBean.setRecu_month_day(event.getRecu_month_day());
	    		eventEntryBean.setRecu_every_month(event.getRecu_every_month());
	    		
	    		//will change once added as like in database
	    		//eventEntryBean.setApplicationName("ERP Finance");
	    		
	    		//List<String> incidentList = allIncidentsListUpdating(eventEntryBean);
	    		//calendarBean.setIncidents(incidentList);
	    		
	    		List<CalendarBean> cbl=getRecurrenceList(calendarBean,event);//new ArrayList<CalendarBean>();
	    		for(CalendarBean cb : cbl) {
	    			cb.setUrl("chart?chartEventId="+event.getEvent_ID());
	    			evnetCalendarBeanList.add(cb);
	    		}
	    		
	    		//evnetCalendarBeanList.add(calendarBean);
    		}
    	}
    	
    	Gson gson = new Gson();
    	String calendarJSON=gson.toJson(evnetCalendarBeanList);
    	
    	
      	  model.addAttribute("calendarJSON", calendarJSON);
      	 
      	model.addAttribute("calendarid", "BD");
      	 
      	 
      	// model.addAttribute("evnetEntryBeanList", evnetCalendarBeanList);
      	   
          //return new ModelAndView("viewEntry");
      	model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
      	
      	Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        model.addAttribute("userRoleName", auth.getAuthorities());
        
      	return "viewCalendar";

	
	}

	private List<CalendarBean> getRecurrenceList(CalendarBean calendarBean, EventEntry event) throws ParseException {
		List<CalendarBean> tbl = new ArrayList<CalendarBean>();	
		
		String recurrenceType = event.getRecurrence_type();
		switch(recurrenceType) {
		case "monthly":
			//int monthDay = null != event.getRecu_month_day() ? Integer.parseInt(event.getRecu_month_day()) : 0;
			getMonthRecur(calendarBean, event, tbl);
			break;
		case "weekly":
			//int weekDay = null != event.getRecu_every_day() ? Integer.parseInt(event.getRecu_every_day()) : 0;
			getWeekRecur(calendarBean, event, tbl);
			break;
		default:
			//Commented By Bkm for new calendar view
			//calendarBean.setDateStart(calendarBean.getStart().substring(0,10));
			//calendarBean.setDateEnd(calendarBean.getEnd().substring(0,10));
			//calendarBean.setRegion(event.getre);
			//calendarBean.getCalendarType(event.getCalendar_type_id());
			getDailyRecur(calendarBean, event, tbl);
			//tbl.add(calendarBean); //BKM
		}
		
		
		
		return tbl;
	}
	
	private void getDailyRecur(CalendarBean calendarBean, EventEntry event, List<CalendarBean> tbl) throws ParseException {
		
		String start = calendarBean.getStart();
		String end1 = calendarBean.getEnd();
		Calendar cal = Calendar.getInstance();
		Calendar calEnd = Calendar.getInstance();
		Calendar calEndSet = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date st = sdf.parse(start);
		Date end = sdf.parse(end1);
		cal.setTimeInMillis(st.getTime());
		calEnd.setTimeInMillis(end.getTime());
		
		String everyDayNum = event.getRecu_every_day();
		int count = 1;
		if(everyDayNum != null && !everyDayNum.equalsIgnoreCase("")){
			count = Integer.parseInt(everyDayNum);
		}
		//cal.add(Calendar.MONTH, recurMonth);
		while(calEnd.getTimeInMillis()>cal.getTimeInMillis()){
			CalendarBean cb1 = new CalendarBean();
			cb1.setTitle(calendarBean.getTitle());
			cb1.setDescription(calendarBean.getDescription());
			cb1.setEngagement(calendarBean.getEngagement());
			cb1.setAdditional_recipients(calendarBean.getAdditional_recipients());
			cb1.setEventAppSet(calendarBean.getEventAppSet());
			cb1.setEventUserSet(calendarBean.getEventUserSet());
			cb1.setRemarks(calendarBean.getRemarks());
			//Commented By Bkm for new calendar view
			/*cb1.setDateStart(calendarBean.getStart().substring(0,10));
    		cb1.setDateEnd(calendarBean.getEnd().substring(0,10));
    		cb1.setStartTime(calendarBean.getStartTime());
    		cb1.setEndTime(calendarBean.getEndTime());*/
    		cb1.setRegion(calendarBean.getRegion());
    		cb1.setCalendarType(calendarBean.getCalendarType());
			
			cb1.setStart(sdf.format(cal.getTime()));			
			calEndSet.setTimeInMillis(cal.getTimeInMillis());
			calEndSet.add(Calendar.HOUR_OF_DAY, 1);
			cb1.setEnd(sdf.format(calEndSet.getTime()));
			cal.add(Calendar.DATE, count);
			tbl.add(cb1);
			}					
		
		
	}

	private void getWeekRecur(CalendarBean calendarBean, EventEntry event, List<CalendarBean> tbl) throws ParseException {
		
		String recurMonthDay = !StringUtils.isEmpty(event.getRecurrence_dayName()) ?event.getRecurrence_dayName().replace("MO", "2").replace("TU", "3").replace("WE", "4").replace("TH", "5").replace("FR", "6").replace("SA", "7").replace("SU", "1") : "";
		//int weekDay = !StringUtils.isEmpty(recurMonthDay) ? Integer.parseInt(recurMonthDay) : 0;
		String start = calendarBean.getStart();
		String end1 = calendarBean.getEnd();
		Calendar cal = Calendar.getInstance();
		Calendar calEnd = Calendar.getInstance();
		Calendar calEndSet = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date st = sdf.parse(start);
		Date end = sdf.parse(end1);
		int recurWeek = !StringUtils.isEmpty(event.getRecu_every_week()) ? Integer.parseInt(event.getRecu_every_week()) : 1;
		for(String s : recurMonthDay.split(",")){
			cal.setTimeInMillis(st.getTime());
			calEnd.setTimeInMillis(end.getTime());			
			int weekDay = !StringUtils.isEmpty(s) ? Integer.parseInt(s) : 0;
		if(cal.get(Calendar.DAY_OF_WEEK)==weekDay) {
			CalendarBean cb1 = new CalendarBean();
			cb1.setTitle(calendarBean.getTitle());
			cb1.setDescription(calendarBean.getDescription());
			cb1.setEngagement(calendarBean.getEngagement());
			cb1.setAdditional_recipients(calendarBean.getAdditional_recipients());
			cb1.setEventAppSet(calendarBean.getEventAppSet());
			cb1.setEventUserSet(calendarBean.getEventUserSet());
			cb1.setRemarks(calendarBean.getRemarks());	
			//Commented By Bkm for new calendar view
			/*cb1.setDateStart(calendarBean.getStart().substring(0,10));
    		cb1.setDateEnd(calendarBean.getEnd().substring(0,10));    		
    		cb1.setStartTime(calendarBean.getStartTime());
    		cb1.setEndTime(calendarBean.getEndTime());*/
    		cb1.setRegion(calendarBean.getRegion());
    		cb1.setCalendarType(calendarBean.getCalendarType());
			
    		cb1.setStart(sdf.format(cal.getTime()));
			calEndSet.setTimeInMillis(cal.getTimeInMillis());
			calEndSet.add(Calendar.HOUR_OF_DAY, 1);
			//cb1.setEnd(sdf.format(cal.getTime()).replace("00:00:00", "23:59:59"));
			cb1.setEnd(sdf.format(calEndSet.getTime()));//Commented By Bkm for new calendar view
			tbl.add(cb1);
			
			
		}
		cal.add(Calendar.WEEK_OF_YEAR, recurWeek);
		cal.set(Calendar.DAY_OF_WEEK, weekDay);			
		while(calEnd.getTimeInMillis()>cal.getTimeInMillis()){
			CalendarBean cb1 = new CalendarBean();
			cb1.setTitle(calendarBean.getTitle());
			cb1.setDescription(calendarBean.getDescription());
			cb1.setEngagement(calendarBean.getEngagement());
			cb1.setAdditional_recipients(calendarBean.getAdditional_recipients());
			cb1.setEventAppSet(calendarBean.getEventAppSet());
			cb1.setEventUserSet(calendarBean.getEventUserSet());
			cb1.setRemarks(calendarBean.getRemarks());
			/*cb1.setDateStart(calendarBean.getStart().substring(0,10));
    		cb1.setDateEnd(calendarBean.getEnd().substring(0,10));			
    		cb1.setStartTime(calendarBean.getStartTime());
    		cb1.setEndTime(calendarBean.getEndTime());*/
    		cb1.setRegion(calendarBean.getRegion());
    		cb1.setCalendarType(calendarBean.getCalendarType());
			
    		cb1.setStart(sdf.format(cal.getTime()));
			calEndSet.setTimeInMillis(cal.getTimeInMillis());
			calEndSet.add(Calendar.HOUR_OF_DAY, 1);
			//cb1.setEnd(sdf.format(cal.getTime()).replace("00:00:00", "23:59:59"));
			cb1.setEnd(sdf.format(calEndSet.getTime()));//Commented By Bkm for new calendar view
			tbl.add(cb1);
			System.out.println(cal.getTime());
			cal.add(Calendar.WEEK_OF_YEAR, recurWeek);
			cal.set(Calendar.DAY_OF_WEEK, weekDay);			
			
		}
		}
	}

	private void getMonthRecur(CalendarBean calendarBean, EventEntry event, List<CalendarBean> tbl) throws ParseException {
		
		String start = calendarBean.getStart();
		String end1 = calendarBean.getEnd();
		Calendar cal = Calendar.getInstance();
		Calendar calEnd = Calendar.getInstance();
		Calendar calEndSet = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date st = sdf.parse(start);
		Date end = sdf.parse(end1);
		cal.setTimeInMillis(st.getTime());
		calEnd.setTimeInMillis(end.getTime());
		if("2".equalsIgnoreCase(event.getRecu_month_day_radio())) {
			

			int recurWeek = !StringUtils.isEmpty(event.getMonthdd1()) ? Integer.parseInt(event.getMonthdd1()) : 1;
			int weekday = !StringUtils.isEmpty(event.getMonthdd2()) ? Integer.parseInt(event.getMonthdd2()) : 1;
			int recurMonth = !StringUtils.isEmpty(event.getMonthtext1()) ? Integer.parseInt(event.getMonthtext1()) : 1;
			
		if(weekday == cal.get(Calendar.DAY_OF_WEEK)) {
			recurWeek = recurWeek < 5 ? recurWeek : getLastWeekday(weekday,cal);
			cal.set(Calendar.WEEK_OF_MONTH, recurWeek);
		}else if(weekday < cal.get(Calendar.DAY_OF_WEEK)){
			recurWeek = recurWeek < 5 ? recurWeek+1 : getLastWeekday(weekday,cal);			
			cal.set(Calendar.DAY_OF_WEEK, weekday);
			cal.set(Calendar.WEEK_OF_MONTH, recurWeek);
		}else if(weekday <= Calendar.SATURDAY){
			recurWeek = recurWeek < 5 ? recurWeek : getLastWeekday(weekday,cal);			
			cal.set(Calendar.DAY_OF_WEEK, weekday);
			cal.set(Calendar.WEEK_OF_MONTH, recurWeek);			
		}else if(weekday == 9){			
				cal.set(Calendar.DAY_OF_MONTH, getNthWeekDay(recurWeek,cal));			
		}else if(weekday == 8){			
			cal.set(Calendar.DAY_OF_MONTH, getNthWeekEndDay(recurWeek,cal));			
		}
		//cal.add(Calendar.MONTH, recurMonth);
		while(calEnd.getTimeInMillis()>cal.getTimeInMillis()){
			CalendarBean cb1 = new CalendarBean();
			cb1.setTitle(calendarBean.getTitle());
			cb1.setDescription(calendarBean.getDescription());
			cb1.setEngagement(calendarBean.getEngagement());
			cb1.setAdditional_recipients(calendarBean.getAdditional_recipients());
			cb1.setEventAppSet(calendarBean.getEventAppSet());
			cb1.setEventUserSet(calendarBean.getEventUserSet());
			cb1.setRemarks(calendarBean.getRemarks());
			//Commented By Bkm for new calendar view
			/*cb1.setDateStart(calendarBean.getStart().substring(0,10));
    		cb1.setDateEnd(calendarBean.getEnd().substring(0,10));
    		cb1.setStartTime(calendarBean.getStartTime());
    		cb1.setEndTime(calendarBean.getEndTime());*/
    		cb1.setRegion(calendarBean.getRegion());
    		cb1.setCalendarType(calendarBean.getCalendarType());
			
			cb1.setStart(sdf.format(cal.getTime()));			
			calEndSet.setTimeInMillis(cal.getTimeInMillis());
			calEndSet.add(Calendar.HOUR_OF_DAY, 1);
			cb1.setEnd(sdf.format(calEndSet.getTime()));//Commented By Bkm for new calendar view
			tbl.add(cb1);
			System.out.println(cal.getTime());
			cal.add(Calendar.MONTH, recurMonth);
			if(weekday == cal.get(Calendar.DAY_OF_WEEK)) {
				recurWeek = recurWeek < 5 ? recurWeek : getLastWeekday(weekday,cal);
				cal.set(Calendar.WEEK_OF_MONTH, recurWeek);
			}else if(weekday < cal.get(Calendar.DAY_OF_WEEK)){
				recurWeek = recurWeek < 5 ? recurWeek+1 : getLastWeekday(weekday,cal);				
				cal.set(Calendar.DAY_OF_WEEK, weekday);
				cal.set(Calendar.WEEK_OF_MONTH, recurWeek);
			}else if(weekday <= Calendar.SATURDAY){
				recurWeek = recurWeek < 5 ? recurWeek : getLastWeekday(weekday,cal);			
				cal.set(Calendar.DAY_OF_WEEK, weekday);
				cal.set(Calendar.WEEK_OF_MONTH, recurWeek);			
			}else if(weekday == 9){			
					cal.set(Calendar.DAY_OF_MONTH, getNthWeekDay(recurWeek,cal));			
			}else if(weekday == 8){			
				cal.set(Calendar.DAY_OF_MONTH, getNthWeekEndDay(recurWeek,cal));			
			}
						
		}
		
			
		}else {

			int monthDay = !StringUtils.isEmpty(event.getRecu_month_day()) ? Integer.parseInt(event.getRecu_month_day()) : 1;
			int recurMonth = !StringUtils.isEmpty(event.getRecu_every_month()) ? Integer.parseInt(event.getRecu_every_month()) : 1;
		if(cal.get(Calendar.DAY_OF_MONTH)==monthDay) {
			CalendarBean cb1 = new CalendarBean();
			cb1.setTitle(calendarBean.getTitle());
			cb1.setDescription(calendarBean.getDescription());
			cb1.setEngagement(calendarBean.getEngagement());
			cb1.setAdditional_recipients(calendarBean.getAdditional_recipients());
			cb1.setEventAppSet(calendarBean.getEventAppSet());
			cb1.setEventUserSet(calendarBean.getEventUserSet());
			cb1.setRemarks(calendarBean.getRemarks());
			//Commented By Bkm for new calendar view
			/*cb1.setDateStart(calendarBean.getStart().substring(0,10));
    		cb1.setDateEnd(calendarBean.getEnd().substring(0,10));	
    		cb1.setStartTime(calendarBean.getStartTime());
    		cb1.setEndTime(calendarBean.getEndTime());*/
    		cb1.setRegion(calendarBean.getRegion());
    		cb1.setCalendarType(calendarBean.getCalendarType());
			
    		cb1.setStart(sdf.format(cal.getTime()));
			calEndSet.setTimeInMillis(cal.getTimeInMillis());
			calEndSet.add(Calendar.HOUR_OF_DAY, 1);
			//cb1.setEnd(sdf.format(cal.getTime()).replace("00:00:00", "23:59:59"));
			cb1.setEnd(sdf.format(calEndSet.getTime()));//Commented By Bkm for new calendar view
			tbl.add(cb1);
			//cal.set(Calendar.MONTH, cal.get(Calendar.MONTH)+1);
			//cal.set(Calendar.DAY_OF_MONTH, monthDay);			
			
		}
		//cal.set(Calendar.MONTH, cal.get(Calendar.MONTH)+1);
		cal.add(Calendar.MONTH, recurMonth);
		cal.set(Calendar.DAY_OF_MONTH, monthDay);
		while(calEnd.getTimeInMillis()>cal.getTimeInMillis()){
			CalendarBean cb1 = new CalendarBean();
			cb1.setTitle(calendarBean.getTitle());
			cb1.setDescription(calendarBean.getDescription());
			cb1.setEngagement(calendarBean.getEngagement());
			cb1.setAdditional_recipients(calendarBean.getAdditional_recipients());
			cb1.setEventAppSet(calendarBean.getEventAppSet());
			cb1.setEventUserSet(calendarBean.getEventUserSet());
			cb1.setRemarks(calendarBean.getRemarks());
			//Commented By Bkm for new calendar view
			/*cb1.setDateStart(calendarBean.getStart().substring(0,10));
    		cb1.setDateEnd(calendarBean.getEnd().substring(0,10));
    		cb1.setStartTime(calendarBean.getStartTime());
    		cb1.setEndTime(calendarBean.getEndTime());*/
    		cb1.setRegion(calendarBean.getRegion());
    		cb1.setCalendarType(calendarBean.getCalendarType());
			
			cb1.setStart(sdf.format(cal.getTime()));
			calEndSet.setTimeInMillis(cal.getTimeInMillis());
			calEndSet.add(Calendar.HOUR_OF_DAY, 1);
			//cb1.setEnd(sdf.format(cal.getTime()).replace("00:00:00", "23:59:59"));
			cb1.setEnd(sdf.format(calEndSet.getTime()));//Commented By Bkm for new calendar view
			tbl.add(cb1);
			System.out.println(cal.getTime());
			//cal.set(Calendar.MONTH, cal.get(Calendar.MONTH)+1);
			cal.add(Calendar.MONTH, recurMonth);
			cal.set(Calendar.DAY_OF_MONTH, monthDay);			
						
		}
		
		}
		
		
	}

	private int getNthWeekEndDay(int recurWeek, Calendar cal3) {
		Calendar cal2 = (Calendar) cal3.clone();
		   cal2.set( Calendar.DAY_OF_MONTH, 1);
		   if(recurWeek<5) {
			   int cnt=1;
			   while ((cal2.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY
			           && cal2.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) || cnt<recurWeek){				   
			       if((cal2.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY
				           || cal2.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY)) {
			    	   cnt++;
			       }
			         cal2.add(Calendar.DATE, 1);			       
			   } 		   	       
		   }else {
			   cal2.add( Calendar.MONTH, 1);
			   do{
			       cal2.add(Calendar.DATE, -1);			       
			   } while (cal2.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY
			           && cal2.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY );
		   
			}
		   return cal2.get(Calendar.DAY_OF_MONTH);
		   }

	private int getNthWeekDay(int recurWeek, Calendar cal3) {
		Calendar cal2 = (Calendar) cal3.clone();
	   cal2.set( Calendar.DAY_OF_MONTH, 1);
	   if(recurWeek<21) {
		   int cnt=1;
		   
		   while ((cal2.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY
	           || cal2.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) || cnt<recurWeek){
			   if((cal2.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY
			           && cal2.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY)) {
		    	   cnt++;
			   }
			   cal2.add(Calendar.DATE, 1);			       
	   } 
	   }else {
		   cal2.add( Calendar.MONTH, 1);
		   do{
			   cal2.add(Calendar.DATE, -1);
		       
		   } while (cal2.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY
		           || cal2.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY );
		}
	   return cal2.get(Calendar.DAY_OF_MONTH);
	   }

	private int getLastWeekday(int weekday, Calendar cal2) {
		   Calendar cal = (Calendar) cal2.clone();
		   cal.add( Calendar.MONTH, 1);
		   cal.set(Calendar.DAY_OF_MONTH, 1);
		   cal.add( Calendar.DAY_OF_MONTH, -(( cal.get( Calendar.DAY_OF_WEEK ) % 7 + (7-weekday) )%7) );
		   return cal.get(Calendar.WEEK_OF_MONTH);
		}

	
	/*
	 * @RequestMapping("/viewUser") public String viewUser(){
	 * 
	 * User list=userService.findById(id);
	 * 
	 * // return new ModelAndView("viewUser", "list", list);
	 * 
	 * }
	 */
	

   /* @RequestMapping(value = "/searchIncidents", method = RequestMethod.GET)
    public String searchIncidents(Model model) 
    {
    	//account based select eventList
        HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		model.addAttribute("userAccountName",userAccountName);
        return "searchIncidents";
    }
	*/

    /*@RequestMapping(value = "/searchIncidents", method = RequestMethod.GET)
    public ModelAndView addEntry(Model model,@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean) 
    {
    	System.out.println("searchIncidents");
    	//account based select eventList
        HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
        
        return new ModelAndView("searchIncidents");
    }*/
	
	
}
