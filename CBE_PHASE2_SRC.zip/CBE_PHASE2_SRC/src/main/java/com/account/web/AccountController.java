package com.account.web;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.account.model.Account;
import com.account.service.AccountService;
import com.account.validator.AccountValidator;
import com.accounts.dto.AccountBean;

@Controller
@SessionAttributes
public class AccountController {

	@Autowired
    private AccountService accountService;
		
	@Autowired
	private AccountValidator accountValidator;
	
		//View Application
	 @RequestMapping(value = "/viewAccount", method = RequestMethod.GET)
	    public ModelAndView viewAccount(@ModelAttribute("accountBean") AccountBean accountBean, BindingResult bindingResult, Model model) {
			
		 List<AccountBean> accBeanList=new ArrayList<>();
		 List<Account> appList=accountService.findAll();
		 for(Account app: appList){
			 AccountBean accBean=new AccountBean();
			 accBean.setAcc_ID(app.getAccount_Id());
			 accBean.setAccName(app.getAccount_Name());
			 accBeanList.add(accBean);
		 }
		 model.addAttribute("accBeanList", accBeanList);
		 return new ModelAndView("viewAccount");
	 }
	   
	 @RequestMapping(value = "/accountDetails", method = RequestMethod.GET)
	    public String accountDetails(@ModelAttribute("accountBean") AccountBean accountBean, BindingResult bindingResult, Model model) {
			return "accountDetails";
	    }
	 
	 @RequestMapping(value = "/accountDetails", method = RequestMethod.POST)
	    public ModelAndView appDetails(@ModelAttribute("accountBean") AccountBean accountBean, BindingResult bindingResult, Model model) {
		 
		 accountValidator.validate(accountBean, bindingResult);
	        
	        if (bindingResult.hasErrors()) {
	        	model.addAttribute("applicationBean", accountBean);
	        	return new ModelAndView("applicationDetails");
	        }
		 		 
	        accountService.save(accountBean);
		 
		 List<AccountBean> accBeanList=new ArrayList<>();
		 List<Account> accList=accountService.findAll();
		 for(Account acc: accList){
			 AccountBean appBean=new AccountBean();
			 appBean.setAcc_ID(acc.getAccount_Id());
			 appBean.setAccName(acc.getAccount_Name());
			 accBeanList.add(appBean);
		 }
		 model.addAttribute("accBeanList", accBeanList);
		 return new ModelAndView("viewAccount");
		 
	 }
	 
	 @RequestMapping(value="/editAccount/{id}" ,method = RequestMethod.GET) 
	 public ModelAndView editAccount(@PathVariable Long id,@ModelAttribute("accountBean") AccountBean accountBean, Model model){ 
		 Account account = accountService.findById(id);
		 accountBean.setAcc_ID(account.getAccount_Id());
		 accountBean.setAccName(account.getAccount_Name());
		 model.addAttribute("accountBean", accountBean);
		 return new ModelAndView("editAccount");
	 }
	 
	 @RequestMapping(value="/editAccount/{id}" ,method = RequestMethod.POST)  
	    public ModelAndView editAccountSave(@PathVariable Long id,@ModelAttribute("accountBean") AccountBean accountBean, Model model){  
		    	 
		 Account account=new Account();
		 account.setAccount_Id(accountBean.getAcc_ID());
		 account.setAccount_Name(accountBean.getAccName());
		 accountService.save(account);
		 List<AccountBean> accBeanList=new ArrayList<>();
		 List<Account> accList=accountService.findAll();
		 for(Account acc: accList){
			 AccountBean accBean=new AccountBean();
			 accBean.setAcc_ID(acc.getAccount_Id());
			 accBean.setAccName(acc.getAccount_Name());
			 accBeanList.add(accBean);
		 }
		 model.addAttribute("accBeanList", accBeanList);
		 return new ModelAndView("viewAccount");
			 
	    }

}
