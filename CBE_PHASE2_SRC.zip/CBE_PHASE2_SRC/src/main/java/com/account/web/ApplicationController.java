package com.account.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.account.model.Application;
import com.account.model.FileUpload;
import com.account.model.User;
import com.account.service.ApplicationService;
import com.account.service.CalendarTypeService;
import com.account.service.UserService;
import com.account.validator.ApplicationValidator;
import com.accounts.dto.ApplicationBean;
import com.accounts.dto.UserBean;

@Controller
@SessionAttributes
public class ApplicationController {

	@Autowired
    private ApplicationService applicationService;
	
	@Autowired
    private UserService userService;
	
	@Autowired
   private ApplicationValidator applicationValidator;
	
	@Autowired
    private CalendarTypeService calendarTypeService;
	
	@RequestMapping(value = "/applicationUploadscreen", method = RequestMethod.GET)
	public ModelAndView applicationUpload(Model model) {
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("applicationUpload");
	}		
	
	@RequestMapping(value = "/applicationUploadscreen", method = RequestMethod.POST)
	public ModelAndView applicationUpload(ModelMap modelMap, @RequestParam("file") MultipartFile file,Model mod) throws SQLException {
        
        ModelAndView model = new ModelAndView();
        FileUpload fileUpload = new FileUpload();
        try {
			model.addObject("message", fileUpload.process(file));
		} catch (FileNotFoundException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
			mod.addAttribute("exception","No File uploaded. Please upload the file.");
			return new ModelAndView("applicationUpload");
		}
        model.setViewName("applicationUpload");
       // modelMap.addAttribute("maxRecDisplay",getMaxRecDisplay());  *
       // modelMap.addAttribute("loggedInUname",SecurityContextHolder.getContext().getAuthentication().getName());   *
        
        /* test xlsx file starts here */
		
        String fileName = file.getOriginalFilename();
        String rootPath = System.getProperty("catalina.home");
        File dir = new File(rootPath + File.separator + "tmpFiles"+File.separator);
		//File myFile = new File("/opt/files/"+fileName);   *
        File myFile = new File(dir+ File.separator +fileName);
        String ext1 = FilenameUtils.getExtension(fileName);
        
		FileInputStream fis = null;
		try {
			
			if (ext1.equalsIgnoreCase("xlsx"))
			fis = new FileInputStream(myFile);
			else
			{
				mod.addAttribute("exception","Please upload the xlsx file only.");
				return new ModelAndView("applicationUpload");
			}
		} 	
		
		catch (FileNotFoundException e1) {
			e1.printStackTrace();
			mod.addAttribute("exception","No File uploaded. Please upload the file.");
			return new ModelAndView("applicationUpload");
		} 	
		
		
		
		// Finds the workbook instance for XLSX file 
		
		XSSFWorkbook myWorkBook = null;
		try {
			myWorkBook = new XSSFWorkbook (fis);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		// Return first sheet from the XLSX workbook 
		XSSFSheet mySheet = myWorkBook.getSheetAt(0); 
		// Get iterator to all the rows in current sheet 
		Iterator<Row> rowIterator = mySheet.iterator(); 
		
		// Traversing over each row of XLSX file 
		while (rowIterator.hasNext()) { Row row = rowIterator.next(); 
		// For each row, iterate through each columns 
		
		
		
		Iterator<Cell> cellIterator = row.cellIterator();
		//AutomationReport automationReport = null;
		//User user = null;
		
		Application app =null;
		boolean ucFlag = false;
		
		
		while (cellIterator.hasNext())
		{ 
			Cell cell = cellIterator.next(); 
		/*switch (cell.getCellType()) { case Cell.CELL_TYPE_STRING: 
			System.out.print(cell.getStringCellValue() + "\t"); 
			break; 
			case Cell.CELL_TYPE_NUMERIC: 
				System.out.print(cell.getNumericCellValue() + "\t"); 
			break; 
			case Cell.CELL_TYPE_BOOLEAN: 
				System.out.print(cell.getBooleanCellValue() + "\t"); 
				break; 
			default : 
				
		}*/
		
		long maxuser_Id = 0;
		
		if (null != app) {
			maxuser_Id = app.getApp_ID();
		} else {
			maxuser_Id = 1;
		}
		if(cell.getRowIndex() > 0 && row != null &&  row.getCell(0) != null ){			
			
			app = new Application();
			app.setApp_ID(maxuser_Id); 
			app.setApp_Name(row.getCell(0).toString());
			app.setPrimary_resource(row.getCell(1).toString());
			app.setSecondary_resource(row.getCell(2).toString());
			app.setStatus(true);
			app.setTower(row.getCell(3).toString());
			app.setCC_name(row.getCell(4).toString());
			app.setCluster(row.getCell(5).toString());
			
			ucFlag = true;
		} 
		
		}
		if(ucFlag)
		{
			
			try{		
				//userService.save(user);	
				 applicationService.save(app);
				//rowIterator =null;
			//return new ModelAndView("viewUser");
			}
			catch(Exception hex){
				mod.addAttribute("exception","There is an issue in uploading or duplicate record . Please contact technical support.");
				return new ModelAndView("userUpload");
			}
			/*catch (SQLException e3) {
		        e3.printStackTrace();
		        mod.addAttribute("exception","Duplicate entry in excel");
				return new ModelAndView("userUpload");
		    }*/
			
		}
	
		}
		 List<ApplicationBean> appBeanList=new ArrayList<>();
		 List<Application> appList=applicationService.findAll();

		 for(Application app: appList){
			 ApplicationBean appBean=new ApplicationBean();
			 appBean.setApp_ID(app.getApp_ID());
			 appBean.setAppName(app.getApp_Name());
						 
			 appBean.setPrimaryResource(app.getPrimary_resource());   
			 appBean.setSecondaryResource(app.getSecondary_resource());
			
			 if(app.isStatus()==true){
				 appBean.setStatus1("Active");
			 }else{
				 appBean.setStatus1("InActive");
			 }
			
			 appBean.setTower(app.getTower());
			 appBean.setCcname(app.getCC_name());
			 appBean.setCluster(app.getCluster());
			 appBeanList.add(appBean);
		 }
		 Collections.sort(appBeanList);
		 mod.addAttribute("appBeanList", appBeanList);
		 mod.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		 return new ModelAndView("viewApplication");
		
	}
	
/*	@RequestMapping(value = "/applicationDetails", method = RequestMethod.GET)
    public String applicationDetails(Model model) {
		ApplicationBean applicationBean=new ApplicationBean();
		List<String> rescList = userService.getResourceNames();
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		model.addAttribute("rescList", rescList);
		model.addAttribute("applicationBean", applicationBean);
		return "applicationDetails";
    }
	
	 @RequestMapping(value = "/applicationDetails", method = RequestMethod.POST)
	    public ModelAndView applicationDetails(@ModelAttribute("applicationBean") ApplicationBean applicationBean, BindingResult bindingResult, Model model) {
		 
		 applicationValidator.validate(applicationBean, bindingResult);
	        
	        if (bindingResult.hasErrors()) {
	        	
	        	List<String> rescList = userService.getResourceNames();
	        	model.addAttribute("rescList", rescList);
	    		model.addAttribute("applicationBean", applicationBean);
	        	return new ModelAndView("applicationDetails");
	        }
		 		 
		 applicationService.save(applicationBean);
		 
		 List<ApplicationBean> appBeanList=new ArrayList<>();
		 List<Application> appList=applicationService.findAll();
		 for(Application app: appList){
			 ApplicationBean appBean=new ApplicationBean();
			 appBean.setApp_ID(app.getApp_ID());
			 appBean.setAppName(app.getApp_Name());
			 
			 appBean.setPrimaryResource(app.getPrimary_resource());
			 appBean.setSecondaryResource(app.getSecondary_resource());
			 
			 User userNamePrimary = userService.findByUserNameForPrimary(app.getPrimary_resource());		
			 if(userNamePrimary!=null )
			 { 
				//appBean.setPrimaryResource(userNamePrimary.getResourcename());
				 appBean.setPrimaryResource(userNamePrimary.getResourcename());
			 }
			 
			 User userNameSecondry = userService.findByUserNameForSecondry(app.getSecondary_resource());
			 if(userNameSecondry!=null){
				 appBean.setSecondaryResource(userNameSecondry.getResourcename());
			 }
			 
			 boolean b=app.isStatus();
			 if(b==true){
				 appBean.setStatus1("Active");
			 }else{
				 appBean.setStatus1("InActive");
			 }
			 
			 //appBean.setStatus();
			 appBean.setTower(app.getTower());
			 appBean.setCcname(app.getCC_name());
			 appBean.setCluster(app.getCluster());
			 appBeanList.add(appBean);
		 }
		 model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		 model.addAttribute("appBeanList", appBeanList);
		 return new ModelAndView("viewApplication");
		 
	 }*/
	

	@RequestMapping(value = "/applicationDetails", method = RequestMethod.GET)
    public String applicationDetails(Model model) {
		ApplicationBean applicationBean=new ApplicationBean();
		List<String> rescList = userService.getResourceNames();
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		model.addAttribute("rescList", rescList);
		model.addAttribute("applicationBean", applicationBean);
		return "applicationDetails";
    }
	
	 @RequestMapping(value = "/applicationDetails", method = RequestMethod.POST)
	    public ModelAndView applicationDetails(@ModelAttribute("applicationBean") ApplicationBean applicationBean, BindingResult bindingResult, Model model) {
		 
		 applicationValidator.validate(applicationBean, bindingResult);
	        
	        if (bindingResult.hasErrors()) {
	        	
	        	List<String> rescList = userService.getResourceNames();
	        	model.addAttribute("rescList", rescList);
	    		model.addAttribute("applicationBean", applicationBean);
	        	return new ModelAndView("applicationDetails");
	        }
		 		 
		 applicationService.save(applicationBean);
		 
		 List<ApplicationBean> appBeanList=new ArrayList<>();
		 List<Application> appList=applicationService.findAll();
		 for(Application app: appList){
			 ApplicationBean appBean=new ApplicationBean();
			 appBean.setApp_ID(app.getApp_ID());
			 appBean.setAppName(app.getApp_Name());
			 
			 appBean.setPrimaryResource(app.getPrimary_resource());
			 appBean.setSecondaryResource(app.getSecondary_resource());
			 
			/* User userNamePrimary = userService.findByUserNameForPrimary(app.getPrimary_resource());		
			 if(userNamePrimary!=null )
			 { 
				//appBean.setPrimaryResource(userNamePrimary.getResourcename());
				 appBean.setPrimaryResource(userNamePrimary.getResourcename());
			 }
			 
			 User userNameSecondry = userService.findByUserNameForSecondry(app.getSecondary_resource());
			 if(userNameSecondry!=null){
				 appBean.setSecondaryResource(userNameSecondry.getResourcename());
			 }*/
			 
			 boolean b=app.isStatus();
			 if(b==true){
				 appBean.setStatus1("Active");
			 }else{
				 appBean.setStatus1("InActive");
			 }
			 
			 //appBean.setStatus();
			 appBean.setTower(app.getTower());
			 appBean.setCcname(app.getCC_name());
			 appBean.setCluster(app.getCluster());
			 appBeanList.add(appBean);
		 }
		 model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		 model.addAttribute("appBeanList", appBeanList);
		 return new ModelAndView("viewApplication");
		 
	 }
	 
	 //View Application
	 @RequestMapping(value = "/viewApplication", method = RequestMethod.GET)
	    public ModelAndView viewApplication(@ModelAttribute("applicationBean") ApplicationBean applicationBean, BindingResult bindingResult, Model model) {
			
		 
		 List<ApplicationBean> appBeanList=new ArrayList<>();
		 List<Application> appList=applicationService.findAll();
		//Collections.sort(appList);
		// Collections.sort(appList);
		 for(Application app: appList){
			 ApplicationBean appBean=new ApplicationBean();
			 appBean.setApp_ID(app.getApp_ID());
			 appBean.setAppName(app.getApp_Name());
			 /*appBean.setPrimaryResource(app.getPrimary_resource());
			 appBean.setSecondaryResource(app.getSecondary_resource());*/
			 
			 appBean.setPrimaryResource(app.getPrimary_resource());   
			 appBean.setSecondaryResource(app.getSecondary_resource());
			 
			/* User userNamePrimary = userService.findByUserNameForPrimary(app.getPrimary_resource());
			 if(userNamePrimary!=null){
				 appBean.setPrimaryResource(userNamePrimary.getResourcename());
			 }
			 
			 User userNameSecondry = userService.findByUserNameForSecondry(app.getSecondary_resource());
			 if(userNameSecondry!=null){
				 appBean.setSecondaryResource(userNameSecondry.getResourcename());
			 }
			 */
			 /*boolean b=app.isStatus();
			 if(b==false){
				 String str = String.valueOf(b);
				 
			 }*/
			 if(app.isStatus()==true){
				 appBean.setStatus1("Active");
			 }else{
				 appBean.setStatus1("InActive");
			 }
			// appBean.setStatus(app.isStatus());
			 appBean.setTower(app.getTower());
			 appBean.setCcname(app.getCC_name());
			 appBean.setCluster(app.getCluster());
			 appBeanList.add(appBean);
		 }
		 Collections.sort(appBeanList);
		 model.addAttribute("appBeanList", appBeanList);
		 model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		 return new ModelAndView("viewApplication");
		 
	 }
	   
	 /*@RequestMapping(value="/editApplication/{id}" ,method = RequestMethod.GET) 
	 public ModelAndView editApplication(@PathVariable Long id,@ModelAttribute("applicationBean") ApplicationBean applicationBean, Model model){ 
	// Application application = null;
	 //accountGoals=accountGoalService.findById(id);
	 Application application = applicationService.findById(id);
	 applicationBean.setApp_ID(application.getApp_ID());
	 applicationBean.setAppName(application.getApp_Name());
	 applicationBean.setPrimaryResource(application.getPrimary_resource());
	 applicationBean.setSecondaryResource(application.getSecondary_resource());
	 
	 User userNamePrimary = userService.findByUserNameForPrimary(application.getPrimary_resource());
	 if(userNamePrimary!=null){
		 applicationBean.setPrimaryResource(application.getPrimary_resource());
	 }
	 
	 User userNameSecondry = userService.findByUserNameForSecondry(application.getSecondary_resource());
	 if(userNameSecondry!=null){
		 applicationBean.setSecondaryResource(application.getSecondary_resource());
	 }
	 
	 
	 if(application.isStatus()==true){
		 applicationBean.setStatus1("Active");
	 }else{
		 applicationBean.setStatus1("InActive");
	 }
	 
	 applicationBean.setStatus(application.isStatus());
	 applicationBean.setCluster(application.getCluster());
	 applicationBean.setCcname(application.getCC_name());
	 applicationBean.setTower(application.getTower());
	 applicationBean.setLastModified_by(application.getLast_Modified_by());
	 applicationBean.setLastModified_date(application.getLast_Modified_date());
	 
	 List<String> rescList = userService.getResourceNames();
	 
	 model.addAttribute("rescList", rescList);
	 model.addAttribute("applicationBean", applicationBean);
	 model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
	 return new ModelAndView("editApplication");
	
	 }

	 @RequestMapping(value="/editApplication/{id}" ,method = RequestMethod.POST)  
	    public ModelAndView editApplicationSave(@PathVariable Long id,@ModelAttribute("applicationBean") ApplicationBean applicationBean1, Model model){  
		    	 
		 Application application=new Application();
		 application.setApp_ID(applicationBean1.getApp_ID());
		 application.setApp_Name(applicationBean1.getAppName());
		 
		  application.setPrimary_resource(applicationBean1.getPrimaryResource());
		 application.setSecondary_resource(applicationBean1.getSecondaryResource());
		
		 User userPrimary=userService.findByPrimaryResoureName(applicationBean1.getPrimaryResource());
			if(userPrimary!=null ){
				application.setPrimary_resource(applicationBean1.getPrimaryResource());
			}
			User userSecondry=userService.findByPrimaryResoureName(applicationBean1.getSecondaryResource());
			if(userSecondry!=null){
				application.setSecondary_resource(applicationBean1.getSecondaryResource());
			}
		 
		 application.setStatus(applicationBean1.isStatus());
		 application.setCluster(applicationBean1.getCluster());
		 application.setCC_name(applicationBean1.getCcname());
		 application.setTower(applicationBean1.getTower());
		 application.setLast_Modified_by(applicationBean1.getLastModified_by());
		 application.setLast_Modified_date(applicationBean1.getLastModified_date());
		     
		 applicationService.save(application);
			
			
		 
		 List<ApplicationBean> appBeanList=new ArrayList<>();
		 List<Application> appList=applicationService.findAll();
		//Collections.sort(appList);
		// Collections.sort(appList);
		 for(Application app: appList){
			 ApplicationBean appBean=new ApplicationBean();
			 appBean.setApp_ID(app.getApp_ID());
			 appBean.setAppName(app.getApp_Name());
			 
			 appBean.setPrimaryResource(app.getPrimary_resource());
			 appBean.setSecondaryResource(app.getSecondary_resource());
			 
			User userNamePrimary = userService.findByUserNameForPrimary(app.getPrimary_resource());
			 if(userNamePrimary!=null){
				 appBean.setPrimaryResource(userNamePrimary.getResourcename());
			 }
			 
			 User userNameSecondry = userService.findByUserNameForSecondry(app.getSecondary_resource());
			 if(userNameSecondry!=null){
				 appBean.setSecondaryResource(userNameSecondry.getResourcename());
			 }
			 
			 boolean b=app.isStatus();
			 if(b==false){
				 String str = String.valueOf(b);
				 
			 }
			 if(app.isStatus()==true){
				 appBean.setStatus1("Active");
			 }else{
				 appBean.setStatus1("InActive");
			 }
			// appBean.setStatus(app.isStatus());
			 appBean.setTower(app.getTower());
			 appBean.setCcname(app.getCC_name());
			 appBean.setCluster(app.getCluster());
			 appBeanList.add(appBean);
		 }
		 Collections.sort(appBeanList);
		 model.addAttribute("appBeanList", appBeanList);
		 model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		 return new ModelAndView("viewApplication");
			 
	    }*/
	 
	 
	 @RequestMapping(value="/editApplication/{id}" ,method = RequestMethod.GET) 
	 public ModelAndView editApplication(@PathVariable Long id,@ModelAttribute("applicationBean") ApplicationBean applicationBean, Model model){ 
	// Application application = null;
	 //accountGoals=accountGoalService.findById(id);
	 Application application = applicationService.findById(id);
	 applicationBean.setApp_ID(application.getApp_ID());
	 applicationBean.setAppName(application.getApp_Name());
	 /*applicationBean.setPrimaryResource(application.getPrimary_resource());
	 applicationBean.setSecondaryResource(application.getSecondary_resource());*/
	 
	 User userNamePrimary = userService.findByUserNameForPrimary(application.getPrimary_resource());
	 if(userNamePrimary!=null){
		 applicationBean.setPrimaryResource(application.getPrimary_resource());
	 }
	 
	 User userNameSecondry = userService.findByUserNameForSecondry(application.getSecondary_resource());
	 if(userNameSecondry!=null){
		 applicationBean.setSecondaryResource(application.getSecondary_resource());
	 }
	 
	 
	 /*if(application.isStatus()==true){
		 applicationBean.setStatus1("Active");
	 }else{
		 applicationBean.setStatus1("InActive");
	 }
	 */
	 applicationBean.setStatus(application.isStatus());
	 applicationBean.setCluster(application.getCluster());
	 applicationBean.setCcname(application.getCC_name());
	 applicationBean.setTower(application.getTower());
	 applicationBean.setLastModified_by(application.getLast_Modified_by());
	 applicationBean.setLastModified_date(application.getLast_Modified_date());
	 
	 List<String> rescList = userService.getResourceNames();
	 
	 model.addAttribute("rescList", rescList);
	 model.addAttribute("applicationBean", applicationBean);
	 model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
	 return new ModelAndView("editApplication");
	
	 }

	 @RequestMapping(value="/editApplication/{id}" ,method = RequestMethod.POST)  
	    public ModelAndView editApplicationSave(@PathVariable Long id,@ModelAttribute("applicationBean") ApplicationBean applicationBean1, Model model){  
		    	 
		 Application application=new Application();
		 application.setApp_ID(applicationBean1.getApp_ID());
		 application.setApp_Name(applicationBean1.getAppName());
		 
		  application.setPrimary_resource(applicationBean1.getPrimaryResource());
		 application.setSecondary_resource(applicationBean1.getSecondaryResource());
		
		/* User userPrimary=userService.findByPrimaryResoureName(applicationBean1.getPrimaryResource());
			if(userPrimary!=null ){
				application.setPrimary_resource(applicationBean1.getPrimaryResource());
			}
			User userSecondry=userService.findByPrimaryResoureName(applicationBean1.getSecondaryResource());
			if(userSecondry!=null){
				application.setSecondary_resource(applicationBean1.getSecondaryResource());
			}*/
		 
		 application.setStatus(applicationBean1.isStatus());
		 application.setCluster(applicationBean1.getCluster());
		 application.setCC_name(applicationBean1.getCcname());
		 application.setTower(applicationBean1.getTower());
		 application.setLast_Modified_by(applicationBean1.getLastModified_by());
		 application.setLast_Modified_date(applicationBean1.getLastModified_date());
		     
		 applicationService.save(application);
			
			
		 
		 List<ApplicationBean> appBeanList=new ArrayList<>();
		 List<Application> appList=applicationService.findAll();
		//Collections.sort(appList);
		// Collections.sort(appList);
		 for(Application app: appList){
			 ApplicationBean appBean=new ApplicationBean();
			 appBean.setApp_ID(app.getApp_ID());
			 appBean.setAppName(app.getApp_Name());
			 
			 appBean.setPrimaryResource(app.getPrimary_resource());
			 appBean.setSecondaryResource(app.getSecondary_resource());
			 
			/*User userNamePrimary = userService.findByUserNameForPrimary(app.getPrimary_resource());
			 if(userNamePrimary!=null){
				 appBean.setPrimaryResource(userNamePrimary.getResourcename());
			 }
			 
			 User userNameSecondry = userService.findByUserNameForSecondry(app.getSecondary_resource());
			 if(userNameSecondry!=null){
				 appBean.setSecondaryResource(userNameSecondry.getResourcename());
			 }*/
			 
			 /*boolean b=app.isStatus();
			 if(b==false){
				 String str = String.valueOf(b);
				 
			 }*/
			 if(app.isStatus()==true){
				 appBean.setStatus1("Active");
			 }else{
				 appBean.setStatus1("InActive");
			 }
			// appBean.setStatus(app.isStatus());
			 appBean.setTower(app.getTower());
			 appBean.setCcname(app.getCC_name());
			 appBean.setCluster(app.getCluster());
			 appBeanList.add(appBean);
		 }
		 Collections.sort(appBeanList);
		 model.addAttribute("appBeanList", appBeanList);
		 model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		 return new ModelAndView("viewApplication");
			 
	    }
	 
}
