package com.account.web;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.account.model.Region;
import com.account.service.CalendarTypeService;
import com.account.service.RegionService;

import com.account.validator.RegionValidator;

import com.accounts.dto.RegionBean;

/**
 * 
 * @author Bala
 *
 */
@Controller
public class RegionController
{
	@Autowired
	private RegionService regionService;
	
	@Autowired
	private RegionValidator regionValidator;
	
	@Autowired
    private CalendarTypeService calendarTypeService;
	
	@RequestMapping(value = "/addRegion", method = RequestMethod.GET)
    public String addRegion(Model model) {
		
		RegionBean regionBean=new RegionBean();
		
		model.addAttribute("regionBean", regionBean);
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return "addRegion";
    }

	@RequestMapping(value = "/addRegion", method = RequestMethod.POST)
    public ModelAndView addCategory(@ModelAttribute("regionBean") RegionBean regionBean, BindingResult bindingResult, Model model) {
		regionValidator.validate(regionBean, bindingResult);

		if (bindingResult.hasErrors()) {
			System.out.println("errror addRegion ");
			return new ModelAndView("addRegion");
		}
		Region region=new Region();
		region.setRegion_territory(regionBean.getRegion_territory());
		region.setStatus(regionBean.isStatus());
		
		regionService.save(region);
		
	List<RegionBean> regionBeanList=new ArrayList<>();
	List<Region> regionList=regionService.findAll();
	
	for(Region reg:regionList){
		RegionBean regionBeans = new RegionBean();
		regionBeans.setRegion_id(reg.getRegion_id());
		regionBeans.setRegion_territory(reg.getRegion_territory());
		regionBeans.setStatus(reg.isStatus());
		
		
		if(reg.isStatus()==true){
			regionBeans.setStatus1("Active");
		}else{
			regionBeans.setStatus1("InActive");
		}
		//categoryBeans.setStatus(cate.isStatus());
		regionBeanList.add(regionBeans);
	}
		model.addAttribute("regionBeanList", regionBeanList);
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("viewRegion");
		
	}
	
	@RequestMapping(value = "/viewRegion", method = RequestMethod.GET)
    public String viewRegion(Model model) {
		
		
		List<RegionBean> regionBeanList=new ArrayList<>();
		List<Region> regionList=regionService.findAll();
		
		for(Region reg:regionList){
			RegionBean regionBean =new RegionBean();
			regionBean.setRegion_id(reg.getRegion_id());
			regionBean.setRegion_territory(reg.getRegion_territory());
			
			if(reg.isStatus()==true){
				regionBean.setStatus1("Active");
			}else{
				regionBean.setStatus1("InActive");
			}
			
			regionBeanList.add(regionBean);
		}
		
	     model.addAttribute("regionBeanList", regionBeanList);
	     model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return "viewRegion";
    }
	
	@RequestMapping(value = "/editRegion/{id}", method = RequestMethod.GET)
	public ModelAndView edit(@PathVariable Long id, @ModelAttribute("regionBean") RegionBean regionBean, Model model) {
		
		Region region=regionService.findById(id);
		regionBean.setRegion_id(region.getRegion_id());
		regionBean.setRegion_territory(region.getRegion_territory());
		regionBean.setStatus(region.isStatus());
		model.addAttribute("regionBean", regionBean);
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
	  return new ModelAndView("editRegion");
		
	}
	
	@RequestMapping(value = "/editRegion/{id}", method = RequestMethod.POST)
	public ModelAndView editUserDataSave(@PathVariable Long id, @ModelAttribute("regionBean") RegionBean regionBean,
			BindingResult bindingResult, Model model) 
	{
		regionValidator.validate(regionBean, bindingResult);

		if (bindingResult.hasErrors()) {
			return new ModelAndView("editRegion");
		}
		
		Region region=new Region();
		region.setRegion_id(regionBean.getRegion_id());
		region.setRegion_territory(regionBean.getRegion_territory());;
		region.setStatus(regionBean.isStatus());
		
		regionService.save(region);
		
		List<RegionBean> regionBeanList=new ArrayList<>();
		List<Region> regionList=regionService.findAll();
		
		for(Region reg:regionList){
			RegionBean regionBeans=new RegionBean();
			regionBeans.setRegion_id(reg.getRegion_id());
			regionBeans.setRegion_territory(reg.getRegion_territory());
			
			if(reg.isStatus()==true){
				regionBeans.setStatus1("Active");
			}else{
				regionBeans.setStatus1("InActive");
			}
			
			regionBeanList.add(regionBeans);
		}
		
	     model.addAttribute("regionBeanList", regionBeanList);
	     model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("viewRegion");
		
		
	}
}
