package com.account.service;

import java.util.List;

import com.account.model.EventEntry;
import com.account.model.EventPlanned;
import com.account.model.IncidentBean;
import com.accounts.dto.EventEntryBean;

public interface EventEntryService {

	public void save(EventEntryBean eventEntry);
	public void editSave(EventEntryBean eventEntry);
	public List<EventEntry> findAll();
	public EventEntry findById(Long id);
	public void saveOther(EventEntryBean eventEntry);
	public List<String> getEventName();
	public EventEntry findByEventName(String eventName);
	List<EventEntry> findAll(String calType);
	public List<EventEntry> findAllEventByResource(String id);
	public void deleteEventAppBeforeEditSaveApps(Long id);
	public void deleteEventUserBeforeEditSaveUsers(Long id);
	//public List<IncidentBean> getAllIncidents();
	public void saveIncidents(IncidentBean incidentBean);
	public void deleteCanceledEvent(Long Event_ID);
	public void saveCancelledEntry(EventEntry eventEntry);
	void savePlanned(EventPlanned eventPlanned);
	List<EventPlanned> getAllPlanned(Long eventId);
}
