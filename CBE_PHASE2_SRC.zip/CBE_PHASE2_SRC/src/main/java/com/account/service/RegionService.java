package com.account.service;

import java.util.List;
import com.account.model.Region;

public interface RegionService 
{
	public void save(Region region);
    public List<Region> findAll();
	public Region findById(Long id);
	List<String> getRegionTerritory();
	Region findByRegionTerritory(String regName);
	public Region findByRegionId(Long RegionId);
}
