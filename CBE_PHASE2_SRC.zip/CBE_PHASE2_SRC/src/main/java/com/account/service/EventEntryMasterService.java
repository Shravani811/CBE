package com.account.service;

import java.util.List;

import com.account.model.EventEntry;
import com.account.model.EventEntryMaster;
import com.accounts.dto.EventEntryBean;
import com.accounts.dto.EventEntryMasterBean;

public interface EventEntryMasterService {

	public void save(EventEntryMasterBean eventEntryMaster);
	public List<EventEntryMaster> findAll();
	public List<String> getEventName();
	/*public void editSave(EventEntryBean eventEntry);
	public List<EventEntry> findAll();*/
	public EventEntryMaster findById(Long id);
	public EventEntryMaster findByEventName(String catName);
	public void editSave(EventEntryMasterBean eventEntry);
	void save(EventEntryBean eventEntry);
	public void deleteEventUserBeforeEditSaveUsers(Long id);
	public void deleteEventAppBeforeEditSaveApps(Long id);
	public List<EventEntryMaster> findAllEventByResource(String userAccountName);
	public List<String> getEventNameByAcctName(String userAccountName);
	
	
}
