package com.account.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.account.model.CalendarType;
import com.account.model.Category;
import com.account.model.EventApplication;
import com.account.model.EventEntry;
import com.account.model.EventPlanned;
import com.account.model.EventUser;
import com.account.model.Incident;
import com.account.model.IncidentBean;
import com.account.model.Region;
import com.account.model.User;
import com.account.repository.EventApplicationRepository;
import com.account.repository.EventEntryRepository;
import com.account.repository.EventPlannedRepository;
import com.account.repository.EventUserMasterRepository;
import com.account.repository.IncidentRepository;
import com.account.repository.UserAccountRepository;
import com.account.repository.UserRepository;
import com.accounts.dto.EventEntryBean;
import com.mysql.jdbc.StringUtils;

/*
 * jaimishr
 * 
 */
@Service
public  class EventEntryServiceImpl implements EventEntryService {

	@Autowired
	IncidentRepository incidentRepository;

	@Autowired
	EventEntryRepository eventEntryRepository;
	
	@Autowired
	EventPlannedRepository eventPlannedRepository;
	
	@Autowired
	EventUserMasterRepository eventUserMasterRepository; 

	@Autowired
	EventApplicationRepository eventAppMasterRepository; 
	
	@Autowired
	UserAccountRepository userAccountRepository;
	
	@Autowired
	UserRepository userRepository;

	@Autowired
	UserService userService;
	
	@Autowired
	CategoryService categoryService;
	
	@Autowired
	RegionService regionService;
	
	@Autowired
	CalendarTypeService calendarTypeService;
	
	@Override
	@Transactional
	public void save(EventEntryBean eventEntry) {
		/*
		 * Page<EventEntry> page = eventEntryRepository.findAll(new
		 * PageRequest(0, 1, Direction.ASC, "Event_ID")); EventEntry entry2 =
		 * page.getContent().get(0); long maxEvent_Id = entry2.getEvent_ID();
		 */
		
		long maxEvent_Id = 0;
		EventEntry entry = new EventEntry();
		entry.setEventname(eventEntry.getEventName());
		entry.setEngagement_Name(eventEntry.getEngagement_Name());
		entry.setRisk_summary(eventEntry.getRisk_summary());
		//entry.setRegion_territory(eventEntry.getRegion_territory());
		entry.setDescription_details(eventEntry.getDescription_details());
		entry.setAdditional_receipients(eventEntry.getEmail_receipients());
		
		
		/*if(eventName.contains(",")){
			
        String st[]=eventName.split(",");
        
      //  String newEvName=st[0];
		
		//entry.setEventname(newEvName);
		}
		
		else{
			entry.setEventname(eventName);
		}*/
		
		
        String remarks=eventEntry.getRemarks();
 		
		
		String startDate=eventEntry.getStart_date();
		String startTime=eventEntry.getStart_time();
 		
		if(startDate.startsWith(",")){
 			String startDate1=startDate.substring(1);
 			entry.setStart_date(startDate1+" "+startTime);
 		}else{
 			entry.setStart_date(startDate+" "+startTime);
 		}
		
 		String endDate=eventEntry.getEnd_date();
 		String endTime=eventEntry.getEnd_time();
 		if(endDate.startsWith(",")){
 			String end=endDate.substring(1);
 			entry.setEnd_date(end+" "+endTime);
 		}
 		else{
 			entry.setEnd_date(endDate+" "+endTime);
 		}
 		
      /*  String email=eventEntry.getEmail_receipients();
 		
        if(email.startsWith(",")){
 			String email1=email.substring(1);
 			entry.setAdditional_receipients(email1);
 		}/*else if(!email.startsWith(",") && email.contains(",")){
 			
 			String st[]=email.split(",");
 	        
 	        String email1=st[0];
 	        
 	       entry.setAdditional_receipients(email1);
 		}*/
        
        
      //  else{
 		//	entry.setAdditional_receipients(email);
 		//}
 		entry.setRemarks(eventEntry.getRemarks());
		
		entry.setStart_date(eventEntry.getStart_date()+" "+eventEntry.getStart_time());
		
		
		entry.setEnd_date(eventEntry.getEnd_date()+" "+eventEntry.getEnd_time());
		entry.setAccountName(eventEntry.getAccount_name());
		
		entry.setEngagement_Name(eventEntry.getEngagement_Name());
		/*entry.setLast_Modified_Date(eventEntry.getStart_date());*/
		entry.setLast_Modified_by(eventEntry.getEventName());
		/*entry.setCreated_Date(eventEntry.getStart_date());*/
		entry.setCreated_By(eventEntry.getEventName());
		entry.setRisk_summary(eventEntry.getRisk_summary());
		//entry.setRegion_territory(eventEntry.getRegion_territory());
		/*char[] ch=eventEntry.getEvent_category_Name().toCharArray();
		entry.setEvent_category_id(String.valueOf(ch));*/
		
		
	/*	String evCatName=eventEntry.getEvent_category_Name();
		
		if(evCatName.startsWith(",")){
			String eveCat1 = evCatName.substring(1);
		Category category=categoryService.findByEventCategoryName(eveCat1);
		
		if(category!=null){
			entry.setEvent_category_id(category.getEvent_cat_id());
			
		}
		}else{
		
        Category category=categoryService.findByEventCategoryName(evCatName);
		
		if(category!=null){
			entry.setEvent_category_id(category.getEvent_cat_id());
			
		}
		}*/
		
		
		Region region = regionService.findByRegionTerritory(eventEntry.getRegion_territory());
		
        if(region!=null)
        {
        	entry.setRegion_id(region.getRegion_id());
        }
		 
		Category category = categoryService.findByEventCategoryName(eventEntry.getEvent_category_Name());

		if (category != null) {
			entry.setEvent_category_id(category.getEvent_cat_id());

		} 
		
		//entry.setAdditional_receipients(eventEntry.getEmail_receipients());
		
		entry.setRecurrence_type(eventEntry.getRecurrence_type());
		entry.setRecu_every_day(eventEntry.getRecu_every_day());
		entry.setRecu_every_weekday(eventEntry.getRecu_every_weekday());
		entry.setRecu_every_week(eventEntry.getRecu_every_week());
	  	entry.setRecurrence_dayName(eventEntry.getRecurrence_dayName());
		entry.setRecu_every_month(eventEntry.getRecu_every_month());
      	entry.setRecu_month_day(eventEntry.getRecu_month_day());
		entry.setEventstatus("Confirmed");
		EventEntry savedEvent = eventEntryRepository.save(entry);
		if (null != savedEvent) {
			maxEvent_Id = savedEvent.getEvent_ID();
		} else {
			maxEvent_Id = 1;
		}
		
		
		List<EventApplication> eventAppList = new ArrayList<>();
		for (String appName : eventEntry.getEventAppSet()) {
			EventApplication eventApp = new EventApplication();
			eventApp.setApplication(appName);
			eventApp.setEvent_ID(maxEvent_Id);
			eventAppList.add(eventApp);
		}
		
		entry.setEventAppSet(eventAppList);

		List<EventUser> eventUserList = new ArrayList<>();
		// List<User> userList=userEntryrepository.findAll();
		
		
		for (String Resourcename : eventEntry.getEventUserSet()) {

			
			User user=userService.findByResourcename(Resourcename);

			EventUser eventUser = new EventUser();
			
			eventUser.setResource(user.getResourcename());

			eventUser.setEvent_ID(maxEvent_Id);

			eventUserList.add(eventUser);
		}
		entry.setEventUserSet(eventUserList);
		entry.setEventstatus("Confirmed");
		eventEntryRepository.save(entry);

	}
	
	@Override
	public List<EventEntry> findAll() {
		
		return eventEntryRepository.findAll();
	}
	
	@Override
	public List<EventEntry> findAll(String calType) {
		
		List<EventEntry> eventList= eventEntryRepository.findAll();
		CalendarType caltypeObj = calendarTypeService.findByCalendarTypeName(calType);
		Long calTypeId = 0L;
		if(caltypeObj != null){
			calTypeId = caltypeObj.getCalendar_type_id();
		}
		List<EventEntry> eveMaintList = new ArrayList<EventEntry>();
		if(!StringUtils.isNullOrEmpty(calType)){
			for(EventEntry eve: eventList){
				if(calTypeId == eve.getCalendar_type_id()){
					eveMaintList.add(eve);
				}
			}
		} else {
			return eventList;
		}
		return eveMaintList;
	}
	
	

	@Override
	public EventEntry findById(Long id) {
		
		return eventEntryRepository.findOne(id);
	}
	
	
	@Override
	public List<String> getEventName() {
		
			List<EventEntry> eventEntryList=eventEntryRepository.findAll();
			List<String> eventList=new ArrayList<>();
			for(EventEntry eventEntry : eventEntryList){
				eventList.add(eventEntry.getEventname());
			}
			
			return eventList;
			
		}

	@Override
	public EventEntry findByEventName(String eventName) {
		EventEntry masterEvent=new EventEntry();
		List<EventEntry> eventEntryList=eventEntryRepository.findAll();
		
		for(EventEntry eventEntry : eventEntryList){
			if(eventName != null && eventName.equalsIgnoreCase(eventEntry.getEventname())){
				return eventEntry;
			}
		}
		
		return masterEvent;
	}
	
	//Save Data for Other Data
	@Override
	public void saveOther(EventEntryBean eventEntry) {
		/*
		 * Page<EventEntry> page = eventEntryRepository.findAll(new
		 * PageRequest(0, 1, Direction.ASC, "Event_ID")); EventEntry entry2 =
		 * page.getContent().get(0); long maxEvent_Id = entry2.getEvent_ID();
		 */
		
		long maxEvent_Id = 0;
		EventEntry entry = new EventEntry();
		
		String eventName=eventEntry.getEventName();
		
		
			entry.setEventname(eventName);
	
		entry.setDescription_details(eventEntry.getDescription_details());
        
      String remarks=eventEntry.getRemarks();
 		
		if(remarks != null && remarks.startsWith(",")){
 			String remarks1=remarks.substring(1);
 			entry.setRemarks(remarks1);
 		}else{
 			entry.setRemarks(remarks);
 		}
		
		String startDate=eventEntry.getStart_date();
		String startTime=eventEntry.getStart_time();
		
		if(startDate.startsWith(",")){
 			String startDate1=startDate.substring(1);
 			entry.setStart_date(startDate1+" "+startTime);
 		}else{
 			entry.setStart_date(startDate+" "+startTime);
 		}
		
 		String endDate=eventEntry.getEnd_date();
 		String endTime=eventEntry.getEnd_time();
 		if(endDate.startsWith(",")){
 			String end=endDate.substring(1);
 			entry.setEnd_date(end+" "+endTime);
 		}
 		else{
 			entry.setEnd_date(endDate+" "+endTime);
 		}
 		
 		entry.setEnd_date(endDate); //ADDED TEMPORARILY FOR TESTING BY BKM
 		entry.setStart_date(startDate);//ADDED TEMPORARILY FOR TESTING BY BKM
 		
        String email=eventEntry.getEmail_receipients();
 		
        if(email.startsWith(",")){
 			String email1=email.substring(1);
 			entry.setAdditional_receipients(email1);
 		}else{
 			entry.setAdditional_receipients(email);
 		}
		
		/*entry.setStart_date(eventEntry.getStart_date());
		
		
		entry.setEnd_date(eventEntry.getEnd_date());*/
		
        entry.setEmail_receipients1(eventEntry.getEmail_receipients1());
		entry.setEngagement_Name(eventEntry.getEngagement_Name());
		/*entry.setLast_Modified_Date(eventEntry.getStart_date());*/
		entry.setLast_Modified_by(eventEntry.getEventName());
		/*entry.setCreated_Date(eventEntry.getStart_date());*/
		entry.setCreated_By(eventEntry.getEventName());
		entry.setRisk_summary(eventEntry.getRisk_summary());
		//entry.setRegion_territory(eventEntry.getRegion_territory());
		/*char[] ch=eventEntry.getEvent_category_Name().toCharArray();
		entry.setEvent_category_id(String.valueOf(ch));*/
		entry.setRemarks(eventEntry.getRemarks());
		if(StringUtils.isNullOrEmpty(eventEntry.getRegion_id())){
			eventEntry.setRegion_id("0L");
		}
		//entry.setRegion_id(Long.parseLong(eventEntry.getRegion_id())); //BKM
		/*String regions=eventEntry.getRegion_territory();
		
		if(regions.startsWith(",")){
			String regions1 = regions.substring(1);
		Region region=regionService.findByRegionTerritory(regions1);
		
		if(region!=null){
			//entry.setRegion_id(region.getRegion_id());
			
		}
		else{
			//Region region1=regionService.findByRegionTerritory(regions);
		}
		if(region!=null){
			//entry.setRegion_id(region.getRegion_id());
			
		}
		}*/
		
		
		
		String evCatName=eventEntry.getEvent_category_Name();
		
		if(evCatName != null && evCatName.startsWith(",")){
			String eveCat1 = evCatName.substring(1);
		Category category=categoryService.findByEventCategoryName(eveCat1);
		
		if(category!=null){
			entry.setEvent_category_id(category.getEvent_cat_id());
			
		}
		}else{
		
        Category category=categoryService.findByEventCategoryName(evCatName);
		
		if(category!=null){
			entry.setEvent_category_id(category.getEvent_cat_id());
			
		}
		}
		entry.setAccountName(eventEntry.getAccount_name());
		//entry.setAdditional_receipients(eventEntry.getEmail_receipients());
		entry.setCalendar_type_id(eventEntry.getCalendar_type_id());
		entry.setEvent_file_name(eventEntry.getEvent_file_name());
		entry.setEvent_upld_fix(eventEntry.getEvent_upld_fix());

		//Satya Code added Here
		
		entry.setRecurrence_type(eventEntry.getRecurrence_type());
		entry.setRecu_every_day(eventEntry.getRecu_every_day());
		entry.setRecu_every_weekday(eventEntry.getRecu_every_weekday());
		entry.setRecu_every_week(eventEntry.getRecu_every_week());
	  	entry.setRecurrence_dayName(eventEntry.getRecurrence_dayName());
		entry.setRecu_every_month(eventEntry.getRecu_every_month());
      	entry.setRecu_month_day(eventEntry.getRecu_month_day());
      	entry.setMonthdd1(eventEntry.getMonthdd1());
      	entry.setMonthdd2(eventEntry.getMonthdd2());
      	entry.setMonthtext1(eventEntry.getMonthtext1());
      	entry.setRecu_month_day_radio(eventEntry.getRecu_month_day_radio());
      	entry.setEventstatus("Confirmed");
      	if(!StringUtils.isNullOrEmpty(eventEntry.getRegion_id())){
      		entry.setRegion_id(Long.parseLong(eventEntry.getRegion_id()));
      	}
      	entry.setEvent_category_id(eventEntry.getEvent_category_id());
      	entry.setCalendar_type_id(eventEntry.getCalendar_type_id());
      	
		EventEntry savedEvent = eventEntryRepository.save(entry);
		if (null != savedEvent) {
			maxEvent_Id = savedEvent.getEvent_ID();
		} else {
			maxEvent_Id = 1;
		}
		
		
		List<EventApplication> eventAppList = new ArrayList<>();
		if(eventEntry != null && eventEntry.getEventAppSet() != null){
		for (String appName : eventEntry.getEventAppSet()) {
			EventApplication eventApp = new EventApplication();
			eventApp.setApplication(appName);
			eventApp.setEvent_ID(maxEvent_Id);
			eventAppList.add(eventApp);
		}
		}
		
		entry.setEventAppSet(eventAppList);

		List<EventUser> eventUserList = new ArrayList<>();
		// List<User> userList=userEntryrepository.findAll();
		
		if(eventEntry != null && eventEntry.getEventUserSet() != null){
		for (String Resourcename : eventEntry.getEventUserSet()) {

			
			//User user=userService.findByResourcename(Resourcename);

			EventUser eventUser = new EventUser();
			
			//eventUser.setResource(user.getResourcename());
			eventUser.setResource(Resourcename);

			eventUser.setEvent_ID(maxEvent_Id);

			eventUserList.add(eventUser);
		}
		}
		entry.setEventUserSet(eventUserList);
		entry.setEventstatus("Confirmed");
		eventEntryRepository.save(entry);

	}
	
	@Override
	@Transactional
	public void editSave(EventEntryBean eventEntry) {
		/*
		 * Page<EventEntry> page = eventEntryRepository.findAll(new
		 * PageRequest(0, 1, Direction.ASC, "Event_ID")); EventEntry entry2 =
		 * page.getContent().get(0); long maxEvent_Id = entry2.getEvent_ID();
		 */
		//long maxEvent_Id = 0;
		EventEntry entry = new EventEntry();
		entry.setEvent_ID(eventEntry.getEvent_ID());
		entry.setEventname(eventEntry.getEventName());
		entry.setDescription_details(eventEntry.getDescription_details());
		entry.setStart_date(eventEntry.getStart_date()+" "+eventEntry.getStart_time());
		entry.setEnd_date(eventEntry.getEnd_date()+" "+eventEntry.getEnd_time());
		entry.setAdditional_receipients(eventEntry.getEmail_receipients());
		entry.setEmail_receipients1(eventEntry.getEmail_receipients1());
		entry.setEngagement_Name(eventEntry.getEngagement_Name());
		entry.setLast_Modified_Date(eventEntry.getStart_date()+" "+eventEntry.getStart_time());
		entry.setLast_Modified_by(eventEntry.getEventName());
		entry.setCreated_Date(eventEntry.getStart_date()+" "+eventEntry.getStart_time());
		entry.setCreated_By(eventEntry.getEventName());
        entry.setRemarks(eventEntry.getRemarks());
		entry.setRisk_summary(eventEntry.getRisk_summary());
		entry.setAccountName(eventEntry.getAccount_name());
		entry.setEvent_file_name(eventEntry.getEvent_file_name());
		entry.setEvent_upld_fix(eventEntry.getEvent_upld_fix());
		entry.setMonthdd1(eventEntry.getMonthdd1());
		entry.setMonthdd2(eventEntry.getMonthdd2());
		entry.setMonthtext1(eventEntry.getMonthtext1());
		entry.setRecu_month_day_radio(eventEntry.getRecu_month_day_radio());
		
		//entry.setRegion_territory(eventEntry.getRegion_territory());
		/*char[] ch=eventEntry.getEvent_category_Name().toCharArray();
		entry.setEvent_category_id(String.valueOf(ch));*/
		
		Region region = regionService.findByRegionTerritory(eventEntry.getRegion_territory());
		
        if(region!=null)
        {
        	entry.setRegion_id(region.getRegion_id());
        }
		
		Category category=categoryService.findByEventCategoryName(eventEntry.getEvent_category_Name());
		
		if(category!=null){
			entry.setEvent_category_id(category.getEvent_cat_id());
			
		}
		
		
		CalendarType calType =calendarTypeService.findByCalendarTypeName(eventEntry.getCalendar_type_name());
		
		if(calType!=null){
			entry.setCalendar_type_id(calType.getCalendar_type_id());
			
		}
		
		/*EventEntry savedEvent = eventEntryRepository.save(entry);
		if (null != savedEvent) {
			maxEvent_Id = savedEvent.getEvent_ID();
		} else {
			maxEvent_Id = 1;
		}*/
		List<EventApplication> eventAppList = new ArrayList<>();
		for (String appName : eventEntry.getEventAppSet()) {
			EventApplication eventApp = new EventApplication();
			eventApp.setEvent_ID(eventEntry.getEvent_ID());
			eventApp.setApplication(appName);
			//eventApp.setEvent_ID(maxEvent_Id);
			eventAppList.add(eventApp);
		}
		
		entry.setEventAppSet(eventAppList);

		List<EventUser> eventUserList = new ArrayList<>();
		// List<User> userList=userEntryrepository.findAll();
		
		
         for (String Resourcename : eventEntry.getEventUserSet())
         {
        	// User user=userService.findByResourcename(Resourcename);

			EventUser eventUser = new EventUser();
			
			eventUser.setResource(Resourcename);

			//eventUser.setEvent_ID(maxEvent_Id);
			 eventUser.setEvent_ID(eventEntry.getEvent_ID());

			eventUserList.add(eventUser);
		}
		entry.setEventUserSet(eventUserList);

		entry.setRecurrence_type(eventEntry.getRecurrence_type());
		entry.setRecu_every_day(eventEntry.getRecu_every_day());
		entry.setRecu_every_weekday(eventEntry.getRecu_every_weekday());
		entry.setRecu_every_week(eventEntry.getRecu_every_week());
	  	entry.setRecurrence_dayName(eventEntry.getRecurrence_dayName());
		entry.setRecu_every_month(eventEntry.getRecu_every_month());
      	entry.setRecu_month_day(eventEntry.getRecu_month_day());
      	entry.setEventstatus("Confirmed");
		eventEntryRepository.save(entry);
	

}

	@Override
	public List<EventEntry> findAllEventByResource(String accountName) {
		accountName = "DAC";
		List<EventEntry> eventList = new ArrayList<>();
		List<EventEntry> eventEntryList=eventEntryRepository.findAll();
		for (EventEntry eventEntry : eventEntryList) {
			if(eventEntry.getEngagement_Name() != null && accountName != null)
			{
				if(accountName.equalsIgnoreCase(eventEntry.getEngagement_Name())){
					eventList.add(eventEntry);
				}
			}
			
		}
		return eventList;
	}

	@Override
	@Transactional
	public void deleteEventUserBeforeEditSaveUsers(Long Event_ID) 
	{
			SessionFactory factory = new Configuration().configure().buildSessionFactory();
			Session session = factory.openSession();
			 session.getTransaction().begin();
			SQLQuery query = session.createSQLQuery("CALL deleteUsers(:Event_ID)");
			query.setParameter("Event_ID", Event_ID);
			int result=query.executeUpdate();
			session.getTransaction().commit();
			System.out.println("Completed");
	        session.clear();
	        session.close();
	}
	/*@Override
	@Transactional
	public List<IncidentBean> getAllIncidents() 
	{
		SessionFactory factory = new Configuration().configure("hibernate.cfg2.xml").buildSessionFactory();
		Session session = factory.openSession();
		session.getTransaction().begin();
		
		List employees = session.createQuery("FROM ikon_dev_test.all_incidents").list(); 
        for (Iterator iterator1 = employees.iterator(); iterator1.hasNext();)
        {
        	IncidentBean incidentBean = (IncidentBean) iterator1.next(); 
        	System.out.println(incidentBean.getIncident_ID());
        }
		
		session.getTransaction().commit();
	    session.clear();
	    session.close();
	    List<IncidentBean> incidentList = new ArrayList<>();
		return incidentList;
	}*/
	
	@Override
	@Transactional
	public void deleteEventAppBeforeEditSaveApps(Long Event_ID) 
	{
			SessionFactory factory = new Configuration().configure().buildSessionFactory();
			Session session = factory.openSession();
			 session.getTransaction().begin();
			SQLQuery query = session.createSQLQuery("CALL deleteApps(:Event_ID)");
			query.setParameter("Event_ID", Event_ID);
			int result=query.executeUpdate();
			session.getTransaction().commit();
			System.out.println("Completed");
	        session.clear();
	        session.close();
	}

	@Override
	public void saveIncidents(IncidentBean incidentBean) {
		Incident incident = new Incident();
		incident.setIncident_ID(incidentBean.getIncident_ID());
		incident.setStart_Date(incidentBean.getStartDate()+" "+incidentBean.getStartTime());
		incident.setEnd_Date(incidentBean.getEndDate()+" "+incidentBean.getEndTime());
		incident.setReported_Date(incidentBean.getReported_Date());
		/*incident.setSummary(incidentBean.getSummary());
		incident.setNotes(incidentBean.getNotes());*/
		incident.setCauseCodeId(incidentBean.getCausecode_id());
		incident.setApplication_name(incidentBean.getApp_Name());
		incidentRepository.save(incident);
	}	
	

	@Override
	@Transactional
	public void deleteCanceledEvent(Long Event_ID) 
	{
			SessionFactory factory = new Configuration().configure().buildSessionFactory();
			Session session = factory.openSession();
			 session.getTransaction().begin();
			SQLQuery query = session.createSQLQuery("CALL deleteCancelledEvent(:Event_ID)");
			query.setParameter("Event_ID", Event_ID);
			int result=query.executeUpdate();
			session.getTransaction().commit();
			System.out.println("Completed");
	        session.clear();
	        session.close();
	}

	@Override
	public void saveCancelledEntry(EventEntry entry) {
		entry.setEventstatus("Cancelled");
		eventEntryRepository.save(entry);
	}
	
	@Override
	  public void savePlanned(EventPlanned eventPlanned)
	  {
	    eventPlannedRepository.save(eventPlanned);

	  }
	
	@Override
	  public List<EventPlanned> getAllPlanned(Long eventId)
	  {
		List<EventPlanned> lep = eventPlannedRepository.findAll();
		List<EventPlanned> lepout = new ArrayList<EventPlanned>();
		for(EventPlanned ep: lep){
			if(eventId != null && ep.getEvent_ID().equalsIgnoreCase(String.valueOf(eventId))){
				lepout.add(ep);
			}
		}
	    return lepout;

	  }
}
