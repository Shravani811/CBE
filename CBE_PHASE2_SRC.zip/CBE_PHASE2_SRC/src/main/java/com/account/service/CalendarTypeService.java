package com.account.service;

import java.util.List;

import com.account.model.CalendarType;
import com.account.model.Region;

public interface CalendarTypeService 
{
	public void save(CalendarType calendartype);
   public List<CalendarType> findAll();
    public CalendarType findById(Long id);
    List<String> getCalendarTypeName();
    CalendarType findByCalendarTypeName(String caltyName);
	public CalendarType findByCalendarTypeId(Long caltyId);
	
}
