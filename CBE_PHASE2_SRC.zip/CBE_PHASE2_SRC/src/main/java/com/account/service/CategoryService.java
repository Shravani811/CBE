package com.account.service;


import java.util.HashMap;
import java.util.List;

import com.account.model.Category;

public interface CategoryService {
	public void save(Category category);
	public List<Category> findAll();
	public List<String> getCategoryName();
	Category findByEventCategoryName(String catName);
	//Category findByEventCategoryId(Long id);
	public Category findByCategoryId(Long id);
	Category findById(Long id);
	/*Category findByCategoryName(String catName);*/
	
	
	
	
	
}
