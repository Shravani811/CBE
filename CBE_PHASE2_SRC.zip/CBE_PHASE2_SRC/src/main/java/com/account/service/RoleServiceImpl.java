package com.account.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.account.model.Role;
import com.account.repository.RoleRepository;
@Service
public class RoleServiceImpl implements RoleService{
    @Autowired
	RoleRepository roleRepository;
		@Override
		public void save(Role role) {
			roleRepository.save(role);
			
		}
	
	@Override
	@Transactional
	public List<Role> findAll() {
		
		List<Role> roleList=roleRepository.findAll();
		return roleList;
	}

	@Override
	public Role findById(Long id) {
		
		return roleRepository.findOne((long) id);
	}

	@Override
	public Role findByName(String roleName) {
		List<Role> roleList=roleRepository.findAll();
		Role role = new Role();
		for (Role roleObj : roleList) {
			if(roleObj.getRole_Name().equalsIgnoreCase(roleName))
			{
				return roleObj;
			}
		}
		return role;
	}
}
