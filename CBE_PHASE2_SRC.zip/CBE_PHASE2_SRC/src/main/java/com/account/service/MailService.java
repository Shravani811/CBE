package com.account.service;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringBufferInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.MailParseException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

@Service
public class MailService
{
	
		/*private static final String SMTP_AUTH_USER = "ikon.in@capgemini.com";
	    private static final String SMTP_AUTH_PWD  = "white@123";*/
	
		private static final String SMTP_HOST_NAME = "ismtp.corp.capgemini.com";
		
		@Autowired
	    private JavaMailSender mailSender;
	     
	    @Autowired
	    private SimpleMailMessage preConfiguredMessage;
	 
	    /**
	     * This method will send compose and send the message 
	     * */
	    public void sendMail(String to, String subject, String body) 
	    {
	        SimpleMailMessage message = new SimpleMailMessage();
	        message.setTo(to);
	        message.setSubject(subject);
	        message.setText(body);
	        mailSender.send(message);
	    }
	    
	    /**
	     * This method will send a pre-configured message
	     * */
	    public void sendPreConfiguredMail(String message) 
	    {
	        SimpleMailMessage mailMessage = new SimpleMailMessage(preConfiguredMessage);
	        mailMessage.setText(message);
	        mailSender.send(mailMessage);
	    }
	    
		public void setMailSender(JavaMailSender mailSender) {
			this.mailSender = mailSender;
		}
		public void sendMail(String to ,String from,String dear, String content) {
		
		
			MimeMessage message =  mailSender.createMimeMessage();
			
			try{
				MimeMessageHelper helper = new MimeMessageHelper(message, true);
				
				helper.setFrom(preConfiguredMessage.getFrom());
				helper.setTo(to);
				helper.setSubject(preConfiguredMessage.getSubject());
				helper.setText(String.format(
						preConfiguredMessage.getText(), dear, content));
				
				ClassLoader classLoader = this.getClass().getClassLoader();  
				   // Getting resource(File) from class loader  
				   File configFile=new File(classLoader.getResource("EventInviteFromCBE.ics").getFile());  
				
				FileSystemResource file = new FileSystemResource(configFile);
				
				helper.addAttachment(file.getFilename(), file);
				
				
			}catch (MessagingException e) {
				throw new MailParseException(e);
			}
			mailSender.send(message);
			
			
		}
	    
	   public void sendInvitation( String organizer
	            , String[] to
	            , String subject
	            , Date start
	            , Date end
	            , String recurrence_type
                , String recu_every_day
                , String recu_every_weekday
                , String recu_every_week
                , String recurrence_dayName
                , String recu_every_month
                , String recu_month_day
                , String monthdd1
                , String monthdd2
                , String monthtext1
                , String recu_month_day_radio
                , String invitationId
	            , String location
	            , String description
	            , String attachfileName
	            ) throws Exception {

	try {
	
	 Properties prop = new Properties();
	 
	 //PROD
	 
	 prop.put("mail.smtp.port", "25" );
	 prop.put("mail.smtp.host", "ismtp.corp.capgemini.com" );
	 prop.put("mail.smtp.auth", "false");
	 prop.put("mail.smtp.starttls.enable", "false");
	 
	 Session session = null;
	 
	 	 session = Session.getDefaultInstance(prop);
		 session.setDebug(true);
		 
		 
		 //local code email send starts here
		 //DEV
		/* prop.put("mail.smtp.auth", "true");
		 prop.put("mail.smtp.starttls.enable", "true");
		 prop.put("mail.smtp.host", "smtp-mail.outlook.com");
		 prop.put("mail.smtp.port", "587");
		 
		 //final String username = "natools_support.in@capgemini.com";
		 final String username = "manikandan.bk@capgemini.com";
			final String password = "mdu@tn123";
			
			session = null;
			session = Session.getInstance(prop, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(username, password);
				}
			});*/
		 
		 
		 // local code email send ends here
		 
		 
	 // Define message
	 MimeMessage message = new MimeMessage(session);
	 
	 //PROD
	 message.setFrom(new InternetAddress("dactoolssupport.in@capgemini.com"));
	 
	 //DEV
	 //message.setFrom(new InternetAddress("manikandan.bk@capgemini.com"));

	 // Set TO
	 if( to != null && ( to.length > 0 ) ) {
		 to = to[0].split(",");
	     InternetAddress[] address = new InternetAddress[ to.length ] ;

	     for( int i = 0; i < to.length; i++ ) {
	         address[ i ] = new InternetAddress( to[ i ] ) ;
	     }

	     message.setRecipients( Message.RecipientType.TO, address ) ;
	 }

	 // Set subject
	 message.setSubject(subject);
	 // Create iCalendar message
	 String rrule = null;

	 SimpleDateFormat dateFormat = new SimpleDateFormat( "yyyyMMdd'T'HHmm'00'" ) ;
	 //daily basis:
	 if(recurrence_type != null && recu_every_day != null)
	 {
		 rrule  = "FREQ="+"DAILY"+";INTERVAL="+recu_every_day; 
	 }
	 else if(recurrence_type != null && recurrence_type.equalsIgnoreCase("daily") && recu_every_weekday != null)
	 {
		 rrule  = "FREQ="+"DAILY"+";BYDAY="+recu_every_weekday; 
	 }
	 
	 //weekly basis:
	 if(recurrence_type != null && recurrence_type.equalsIgnoreCase("weekly")  && recurrence_dayName != null && recu_every_week != null)
	 {
		 rrule  = "FREQ="+"WEEKLY"+";BYDAY="+recurrence_dayName+";"+"INTERVAL="+recu_every_week;
	 }
	 
	 //monthly basis:
	 if(recurrence_type != null && recurrence_type.equalsIgnoreCase("monthly") && !recu_month_day.equalsIgnoreCase("") && !recu_every_month.equalsIgnoreCase(""))
	 {
		 if(recu_month_day_radio != null && recu_month_day_radio.equalsIgnoreCase("1")){
			 rrule  = "FREQ="+"MONTHLY"+";BYMONTHDAY="+recu_month_day+";"+"INTERVAL="+recu_every_month+";"+"UNTIL="+dateFormat.format(end)+"Z";
		 } else {
			 String monthdd2Val = "";
			 if("1".equalsIgnoreCase(monthdd2)){
				 monthdd2Val = "SU"; 
			 } else if("2".equalsIgnoreCase(monthdd2)){
				 monthdd2Val = "MO"; 
			 } else if("3".equalsIgnoreCase(monthdd2)){
				 monthdd2Val = "TU"; 
			 } else if("4".equalsIgnoreCase(monthdd2)){
				 monthdd2Val = "WE"; 
			 } else if("5".equalsIgnoreCase(monthdd2)){
				 monthdd2Val = "TH"; 
			 } else if("6".equalsIgnoreCase(monthdd2)){
				 monthdd2Val = "FR"; 
			 } else {
				 monthdd2Val = "SA"; 
			 }
			 
			 rrule  = "FREQ="+"MONTHLY"+";BYDAY="+monthdd1+monthdd2Val+";"+"INTERVAL="+monthtext1+";"+"UNTIL="+dateFormat.format(end)+"Z";
		 }
		 //FREQ=MONTHLY;BYMONTHDAY=1;INTERVAL=1;UNTIL=20181115T183000Z
		 //FREQ=MONTHLY;BYMONTHDAY=1;INTERVAL=1;UNTIL=20190118T183300
	 }
	 
	
	 StringBuffer messageText = new StringBuffer();
	 /*String rrule1  =  "FREQ="+recurrence+";UNTIL="+dateFormat.format(untilDate)+"Z";*/
	 
	 //PROD
	 /*messageText.append("BEGIN:VCALENDAR\n" +
			 			"ATTENDEE;ROLE=REQ-PARTICIPANT;RSVP=TRUE:MAILTO:dactoolssupport.in@capgemini.com\n" +
	                    "PRODID:-//Microsoft Corporation//Outlook 9.0 MIMEDIR//EN\n" +
	                    "VERSION:2.0\n" +
	                    "METHOD:REQUEST\n" +
	                        "BEGIN:VEVENT\n" +
	                        "ORGANIZER:MAILTO:" ) ;*/
	 
	 //DEV
	 messageText.append("BEGIN:VCALENDAR\n" +
	 			"ATTENDEE;ROLE=REQ-PARTICIPANT;RSVP=TRUE:MAILTO:manikandan.bk@capgemini.com\n" +
             "PRODID:-//Microsoft Corporation//Outlook 9.0 MIMEDIR//EN\n" +
             "VERSION:2.0\n" +
             "METHOD:REQUEST\n" +
                 "BEGIN:VEVENT\n" +
                 "ORGANIZER:MAILTO:" ) ;
	 messageText.append(organizer) ;
	 messageText.append( "\n" +
	                     "DTSTART:");
	 messageText.append( dateFormat.format( start ) ) ;
	
	 /*Satya Code Starts Here*/
	 
	 messageText.append("\n" +
			 			"RRULE:" ) ;
	 messageText.append(rrule);
     
	 /*Satya Code ends here*/
	 
	 //messageText.append( start  ) ;
	 messageText.append( "\n" +
	                     "DTEND:" ) ;
	 messageText.append( dateFormat.format( end ) ) ;
	 
	 //added status
	 messageText.append("\n" +
	 			"STATUS:" ) ;
	 messageText.append("CONFIRMED");
	 
	 //messageText.append( end ) ;
	 messageText.append( "\n" +
	                     "LOCATION:" ) ;
	 messageText.append( location ) ;
	 messageText.append( "\n" +
	                      "UID:" ) ;
	 messageText.append( invitationId ) ;
	 messageText.append( "\n" +
	                     "DTSTAMP:" ) ;
	 messageText.append( dateFormat.format( new java.util.Date() ) ) ;
	 
	 //messageText.append( new java.util.Date()) ;
	 messageText.append( "\n" +
	                     "DESCRIPTION;ALTREP=\"CID:<eventDescriptionHTML>\"" ) ;
	 messageText.append( "\n" +
	                             "BEGIN:VALARM\n" +
	                             "TRIGGER:-PT15M\n" +
	                             "ACTION:DISPLAY\n" +
	                             "DESCRIPTION:Reminder\n" +
	                             "END:VALARM\n" +
	                        "END:VEVENT\n" +
	                    "END:VCALENDAR"
	                    ) ;

	 /*Multipart mp = new MimeMultipart();

	 MimeBodyPart meetingPart = new MimeBodyPart() ;
	 meetingPart.setDataHandler( new DataHandler( new StringDataSource( messageText.toString(), "text/calendar", "meetingRequest" ) ) ) ;
	 mp.addBodyPart( meetingPart ) ;*/
	 
	// Create the message part
     BodyPart messageBodyPart = new MimeBodyPart();

     // Fill the message
     messageBodyPart.setHeader("Content-Class", "urn:content-  classes:calendarmessage");
     messageBodyPart.setHeader("Content-ID", "calendar_message");
     messageBodyPart.setDataHandler(new DataHandler(
             new ByteArrayDataSource(messageText.toString(), "text/calendar")));// very important

     // Create a Multipart
     Multipart mp = new MimeMultipart();

     // Add part one
     mp.addBodyPart(messageBodyPart);
	 

     BodyPart descriptionPart = new MimeBodyPart() ;
	 descriptionPart.setDataHandler( new DataHandler( new StringDataSource( description, "text/html", "eventDescription" ) ) ) ;
	 descriptionPart.setHeader("Content-ID", "<eventDescriptionHTML>" ) ;
	 mp.addBodyPart( descriptionPart ) ;

	 /* Attachment part starts here */
	 
	 String rootPath = System.getProperty("catalina.home");
	    File dir = new File(rootPath + File.separator + "tmpFiles"+File.separator +attachfileName);
	   
	  if (!attachfileName.isEmpty()) 
	   {  
		  System.out.print(" <<<<<<<<<<<<<<<<<<<<<<<<<inside attachfileName-------------->>"+attachfileName); 		  
		 MimeBodyPart messageBodyPart2 = new MimeBodyPart(); 
		//String filename1 = "C:/Bala/sample attachment.txt";//change accordingly C:\Bala
		//String filename11 =filename;
		DataSource source1 = new FileDataSource(dir); 
		messageBodyPart2.setDataHandler(new DataHandler(source1)); 
		messageBodyPart2.setFileName(attachfileName); 
		mp.addBodyPart( messageBodyPart2);
	   }
	 
	 /* Attachment part ends here */
	 
	 message.setContent( mp ) ;
	 
	 
	 // send message
	 Transport.send(message);//BKM

	} catch (MessagingException me) {
	 me.printStackTrace();

	} catch (Exception ex) {
	 ex.printStackTrace();

	}
	}

	   public void sendCancelInvitation( String organizer
	            , String[] to
	            , String subject
	            , Date start
	            , Date end
	            , String recurrence_type
               , String recu_every_day
               , String recu_every_weekday
               , String recu_every_week
               , String recurrence_dayName
               , String recu_every_month
               , String recu_month_day
               , String invitationId
	            , String location
	            ) throws Exception {

	try {
	
	 Properties prop = new Properties();
	 prop.put("mail.smtp.port", "25" );
	 prop.put("mail.smtp.host", "ismtp.corp.capgemini.com" );

	 	Session session = Session.getDefaultInstance(prop);
		 session.setDebug(true);
	 // Define message
	 MimeMessage message = new MimeMessage(session);
	 message.setFrom(new InternetAddress("dactoolssupport.in@capgemini.com"));

	 // Set TO
	 if( to != null && ( to.length > 0 ) ) {
		 to = to[0].split(",");
	     InternetAddress[] address = new InternetAddress[ to.length ] ;

	     for( int i = 0; i < to.length; i++ ) {
	         address[ i ] = new InternetAddress( to[ i ] ) ;
	     }

	     message.setRecipients( Message.RecipientType.TO, address ) ;
	 }

	 // Set subject
	 message.setSubject("Canceled: "+subject);
	 // Create iCalendar message
	 String rrule = null;

	 SimpleDateFormat dateFormat = new SimpleDateFormat( "yyyyMMdd'T'HHmm'00'" ) ;
	 //daily basis:
	 if(recurrence_type != null && recu_every_day != null)
	 {
		 rrule  = "FREQ="+"DAILY"+";INTERVAL="+recu_every_day+";"+"UNTIL="+dateFormat.format(end)+"Z"; 
	 }
	 else if(recurrence_type != null && recurrence_type.equalsIgnoreCase("daily") && recu_every_weekday != null)
	 {
		 rrule  = "FREQ="+"DAILY"+";BYDAY="+recu_every_weekday+";"+"UNTIL="+dateFormat.format(end)+"Z"; 
	 }
	 
	 //weekly basis:
	 if(recurrence_type != null && recurrence_type.equalsIgnoreCase("weekly")  && recurrence_dayName != null && recu_every_week != null)
	 {
		 rrule  = "FREQ="+"WEEKLY"+";BYDAY="+recurrence_dayName+";"+"INTERVAL="+recu_every_week+";"+"UNTIL="+dateFormat.format(end)+"Z";
	 }
	 
	 //monthly basis:
	 if(recurrence_type != null && recurrence_type.equalsIgnoreCase("monthly") && !recu_month_day.equalsIgnoreCase("") && !recu_every_month.equalsIgnoreCase(""))
	 {
		 rrule  = "FREQ="+"MONTHLY"+";BYMONTHDAY="+recu_month_day+";"+"INTERVAL="+recu_every_month+";"+"UNTIL="+dateFormat.format(end)+"Z";
	 }
	
	 StringBuffer messageText = new StringBuffer();
	 /*String rrule1  =  "FREQ="+recurrence+";UNTIL="+dateFormat.format(untilDate)+"Z";*/
	 messageText.append("BEGIN:VCALENDAR\n" +
			 			"ATTENDEE;ROLE=REQ-PARTICIPANT;RSVP=TRUE:MAILTO:rajashreetha.s@capgemini.com;dactoolssupport.in@capgemini.com;anupam.a.kumari@capgemini.com\n" +
	                    "PRODID:-//Microsoft Corporation//Outlook 9.0 MIMEDIR//EN\n" +
	                    "VERSION:2.0\n" +
	                    "METHOD:CANCEL\n" +
	                        "BEGIN:VEVENT\n" +
	                        "ORGANIZER:MAILTO:" ) ;
	 messageText.append("dactoolssupport.in@capgemini.com") ;
	 messageText.append( "\n" +
	                     "DTSTART:");
	 messageText.append( dateFormat.format( start ) ) ;
	
	 messageText.append( "\n" +
             "DTSTAMP:" ) ;
	 messageText.append( dateFormat.format( new java.util.Date() ) ) ;
	 
	 messageText.append( "\n" +
             "DTEND:");
	 messageText.append( dateFormat.format( end ) ) ;

	 /*Satya Code Starts Here*/
	 
	messageText.append("\n" +
			 			"RRULE:" ) ;
	 messageText.append(rrule);
	 /*Satya Code ends here*/
	 
	 //added status
	 messageText.append("\n" +
	 			"STATUS:" ) ;
	 messageText.append("CANCELLED");
	 
	 //messageText.append( end ) ;
	 messageText.append( "\n" +
	                     "LOCATION:" ) ;
	 messageText.append( location ) ;
	 messageText.append( "\n" +
	                      "UID:" ) ;
	 messageText.append( invitationId ) ;
	 
	 //messageText.append( new java.util.Date()) ;
	 messageText.append( "\n" +
	                     "DESCRIPTION;ALTREP=\"CID:<eventDescriptionHTML>\"" ) ;
	 messageText.append( "\n" +
	                             "BEGIN:VALARM\n" +
	                             "TRIGGER:-PT15M\n" +
	                             "ACTION:DISPLAY\n" +
	                             "DESCRIPTION:Reminder\n" +
	                             "END:VALARM\n" +
	                        "END:VEVENT\n" +
	                    "END:VCALENDAR"
	                    ) ;

	 /*Multipart mp = new MimeMultipart();

	 MimeBodyPart meetingPart = new MimeBodyPart() ;
	 meetingPart.setDataHandler( new DataHandler( new StringDataSource( messageText.toString(), "text/calendar", "meetingRequest" ) ) ) ;
	 mp.addBodyPart( meetingPart ) ;*/
	 
	// Create the message part
     BodyPart messageBodyPart = new MimeBodyPart();

     // Fill the message
     messageBodyPart.setHeader("Content-Class", "urn:content-  classes:calendarmessage");
     messageBodyPart.setHeader("Content-ID", "calendar_message");
     messageBodyPart.setDataHandler(new DataHandler(
             new ByteArrayDataSource(messageText.toString(), "text/calendar")));// very important
     // Create a Multipart
     Multipart mp = new MimeMultipart();

     // Add part one
     mp.addBodyPart(messageBodyPart);

	 BodyPart descriptionPart = new MimeBodyPart() ;
	 String description = "hello to all";
	 descriptionPart.setDataHandler( new DataHandler( new StringDataSource( description , "text/html", "eventDescription" ) ) ) ;
	 descriptionPart.setHeader("Content-ID", "<eventDescriptionHTML>" ) ;
	 mp.addBodyPart( descriptionPart ) ;

	 message.setContent( mp ) ;

	 // send message
	 Transport.send(message);

	} catch (MessagingException me) {
	 me.printStackTrace();

	} catch (Exception ex) {
	 ex.printStackTrace();

	}
	}

	   
	    private static class StringDataSource implements DataSource {
	        private String contents ;
	        private String mimetype ;
	        private String name ;


	        public StringDataSource( String contents
	                               , String mimetype
	                               , String name
	                               ) {
	            this.contents = contents ;
	            this.mimetype = mimetype ;
	            this.name = name ;
	        }

	        public String getContentType() {
	            return( mimetype ) ;
	        }

	        public String getName() {
	            return( name ) ;
	        }

	        public InputStream getInputStream() {
	            return( new StringBufferInputStream( contents ) ) ;
	        }

	        public OutputStream getOutputStream() {
	            throw new IllegalAccessError( "This datasource cannot be written to" ) ;
	        }
	    }    
	    
	    public String sendEmail(String email,String subject, String body)
	    {
	    	Properties props = new Properties();
	        props.put("mail.transport.protocol", "smtp");
	        props.put("mail.smtp.host", SMTP_HOST_NAME);
	        //props.put("mail.smtp.auth", "true");

	        /*Authenticator auth = new SMTPAuthenticator();
	        Session mailSession = Session.getDefaultInstance(props, auth);*/
	        Session mailSession = Session.getDefaultInstance(props, null);
	        Transport transport = null;
	        try
	        {
	        	transport = mailSession.getTransport();
		        MimeMessage message = new MimeMessage(mailSession);
		        message.setFrom(new InternetAddress(email));
		        message.addRecipient(Message.RecipientType.TO,new InternetAddress(email));
		        message.setSubject(subject);
		        message.setText(body);
		        transport.connect();
		        transport.sendMessage(message, message.getRecipients(Message.RecipientType.TO));
		        transport.close();
	        }
	        catch (MessagingException e) {
	        	return "smtpErrorPage";
			}
			return "success";
	    }
	    
	    /*private class SMTPAuthenticator extends javax.mail.Authenticator {
	        public PasswordAuthentication getPasswordAuthentication() {
	           String username = SMTP_AUTH_USER;
	           String password = SMTP_AUTH_PWD;
	           return new PasswordAuthentication(username, password);
	        }
	    }*/
}
