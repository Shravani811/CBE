package com.account.service;

import java.util.List;

import com.account.model.Role;
import com.account.model.User;

public interface RoleService {
	
   void save(Role role);
   List<Role> findAll();
   Role findById(Long id);
   Role findByName(String roleName);
}
