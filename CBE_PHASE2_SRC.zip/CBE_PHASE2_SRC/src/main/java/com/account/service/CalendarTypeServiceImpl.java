package com.account.service;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.account.model.CalendarType;
import com.account.model.Region;
import com.account.repository.CalendarTypeRepository;


@Service
public class CalendarTypeServiceImpl implements CalendarTypeService
{

	@Autowired
	CalendarTypeRepository calendarTypeRepository;
	
	@Override
	public void save(CalendarType calendartype) {
		calendarTypeRepository.save(calendartype);
		
	}
	
	@Override
	public List<CalendarType> findAll() {
		return calendarTypeRepository.findAll();
	}

	@Override
	public CalendarType findById(Long id) {
		return calendarTypeRepository.findOne(id);
	}
	
	@Override
	public List<String> getCalendarTypeName() {
		List<CalendarType> calendartypeList=calendarTypeRepository.findAll();
		
		List<String> caltyNameList=new ArrayList<>();
		for(CalendarType calendartype : calendartypeList){
			if(calendartype.isStatus()){
				caltyNameList.add(calendartype.getCalendar_type_name());
			}
		}
		
		return caltyNameList;
	}
	
	@Override	
	public CalendarType findByCalendarTypeName(String caltyName) {
		CalendarType calendartype1=new CalendarType();
		/*category.setEvent_category_name(catName);*/
		List<CalendarType> calendartypeList=calendarTypeRepository.findAll();
        
        	for(CalendarType calendartype : calendartypeList){
    			if(caltyName != null && caltyName.trim().equalsIgnoreCase(calendartype.getCalendar_type_name())){
				return calendartype;
			}
        	}
		
		return calendartype1;
	}
	
	
	@Override
	public CalendarType findByCalendarTypeId(Long caltyId){
		CalendarType calendartype=null;
		if(caltyId != null){
			calendartype= calendarTypeRepository.findOne(caltyId);	
		}
		
		if(calendartype != null && calendartype.getCalendar_type_id() != null && caltyId.equals(calendartype.getCalendar_type_id())){
			return calendartype;
		}
		return null;
	}
	
}
