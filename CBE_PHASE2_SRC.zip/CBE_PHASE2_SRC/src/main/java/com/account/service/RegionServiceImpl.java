package com.account.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.account.model.Region;

import com.account.repository.RegionRepository;


@Service
public class RegionServiceImpl implements RegionService
{

	@Autowired
	RegionRepository regionRepository;
	;
	@Override
	public void save(Region region) {
		regionRepository.save(region);
		
	}

	@Override
	public List<Region> findAll() {
		return regionRepository.findAll();
	}

	@Override
	public Region findById(Long id) {
		return regionRepository.findOne(id);
	}
	
	@Override
	public List<String> getRegionTerritory() {
		List<Region> regionList=regionRepository.findAll();
		
		List<String> regNameList=new ArrayList<>();
		for(Region region : regionList){
			if(region.isStatus()){
				regNameList.add(region.getRegion_territory());
			}
		}
		
		return regNameList;
	}
	@Override
	
	public Region findByRegionTerritory(String regName) {
		Region region1=new Region();
		/*category.setEvent_category_name(catName);*/
		List<Region> regionList=regionRepository.findAll();
        
        	for(Region region : regionList){
    			if(regName != null && regName.trim().equalsIgnoreCase(region.getRegion_territory())){
				return region;
			}
        	}
		
		return region1;
	}
	
	
	@Override
	public Region findByRegionId(Long RegionId) {
		Region region = null;
		if(RegionId != null){
			region= regionRepository.findOne(RegionId);
		}
		if(RegionId != null && RegionId.equals(region.getRegion_id())){
			return region;
		}
		return null;
	}

}
