package com.account.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.account.model.Category;
import com.account.repository.CategoryRepository;


@Service
public class CategoryServiceImpl implements CategoryService{

	@Autowired
	CategoryRepository categoryRepository;
	
	public void save(Category category) {
		
		categoryRepository.save(category);
	}

	@Override
	public List<Category> findAll() {
		
		return categoryRepository.findAll();
	}

	
	@Override
	public List<String> getCategoryName() {
		List<Category> categoryList=categoryRepository.findAll();
		
		List<String> catNameList=new ArrayList<>();
		for(Category category : categoryList){
			if(category.isStatus()){
				catNameList.add(category.getEvent_category_name());
			}
		}
		
		return catNameList;
	}
	

	@Override
	public Category findByEventCategoryName(String catName) {
		Category category1=new Category();
		/*category.setEvent_category_name(catName);*/
		List<Category> categoryList=categoryRepository.findAll();
        
        	for(Category category : categoryList){
    			if(catName != null && catName.trim().equalsIgnoreCase(category.getEvent_category_name())){
				return category;
			}
        	}
		
		return category1;
	}

	@Override
	public Category findById(Long id) {
		
		return categoryRepository.findOne(id);
	}

	@Override
	public Category findByCategoryId(Long CategoryId) {
		
		Category category= categoryRepository.findOne(CategoryId);
		if( CategoryId.equals(category.getEvent_cat_id())){
			return category;
		}
		return null;
	}
}

	

	
	

	
	

	


