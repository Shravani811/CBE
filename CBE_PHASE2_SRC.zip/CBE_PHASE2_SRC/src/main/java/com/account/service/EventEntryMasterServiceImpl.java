package com.account.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.account.model.Category;
import com.account.model.EventApplication;
import com.account.model.EventApplicationMaster;
import com.account.model.EventEntry;
import com.account.model.EventEntryMaster;
import com.account.model.EventUser;
import com.account.model.EventUserMaster;
import com.account.model.Region;
import com.account.model.CalendarType;
import com.account.model.User;
import com.account.repository.EventEntryMasterRepository;
import com.account.repository.EventEntryRepository;
import com.account.repository.UserRepository;
import com.accounts.dto.EventEntryBean;
import com.accounts.dto.EventEntryMasterBean;

/*
 * jaimishr
 * 
 */
@Service
public class EventEntryMasterServiceImpl implements EventEntryMasterService {

	@Autowired
	EventEntryMasterRepository eventEntryRepository;

	@Autowired
	UserRepository userRepository;

	@Autowired
	UserService userService;

	@Autowired
	CategoryService categoryService;
	
	@Autowired
	EventEntryRepository eventEntryRepository1;
	
	@Autowired
    private RegionService regionService;
	
	@Autowired
    private CalendarTypeService calendartypeService;

	@Override
	@Transactional
	public void save(EventEntryMasterBean eventEntryMaster) {
		/*
		 * Page<EventEntry> page = eventEntryRepository.findAll(new
		 * PageRequest(0, 1, Direction.ASC, "Event_ID")); EventEntry entry2 =
		 * page.getContent().get(0); long maxEvent_Id = entry2.getEvent_ID();
		 */

		
		/*String eventName=eventEntry.getEventName();
		String description = eventEntry.getDescription_details();
		String engagement=eventEntry.getEngagement_Name();
		String risk=eventEntry.getRisk_summary();
		String territory=eventEntry.getRegion_territory();
		String email=eventEntry.getEmail_receipients();
		String catName = eventEntry.getEvent_category_Name();
		
		 if(eventName.startsWith(",") || description.startsWith(",") || engagement.startsWith(",") || risk.startsWith(",") || territory.startsWith(",") || email.startsWith(",") || catName.startsWith(",")){
			 
		 
	 			
	 			String name=eventName.substring(1);
	 			String desc=description.substring(1);
	 			String engage=engagement.substring(1);
	 			String ristsummay=risk.substring(1);
	 			String region=territory.substring(1);
	 			String reciepent=email.substring(1);
	 			String catnames=catName.substring(1);
	 			
	 			
	 			
	 			
		entry.setEventname(name);
		entry.setDescription_details(desc);

		entry.setEngagement_Name(engage);

		entry.setLast_Modified_by(name);

		entry.setCreated_By(name);
		entry.setRisk_summary(ristsummay);
		entry.setRegion_territory(region);
		entry.setAdditional_receipients(reciepent);
		
		 * char[] ch=eventEntry.getEvent_category_Name().toCharArray();
		 * entry.setEvent_category_id(String.valueOf(ch));
		 
		
		 
		Category category = categoryService.findByEventCategoryName(catnames);

		if (category != null) {
			entry.setEvent_category_id(category.getEvent_cat_id());

		}

		 }
		 else{*/
			 
		long maxEvent_Id = 0;
		EventEntryMaster entry = new EventEntryMaster();
			     entry.setEventname(eventEntryMaster.getEventName());
				entry.setDescription_details(eventEntryMaster.getDescription_details());
				entry.setEngagement_Name(eventEntryMaster.getEngagement_Name());
				entry.setLast_Modified_by(eventEntryMaster.getEventName());
				entry.setCreated_By(eventEntryMaster.getEventName());
				entry.setRisk_summary(eventEntryMaster.getRisk_summary());
				//entry.setRegion_territory(eventEntryMaster.getRegion_territory());
				entry.setAdditional_receipients(eventEntryMaster.getEmail_receipients());
				entry.setAdditional_receipients1(eventEntryMaster.getEmail_receipients1());
				/*
				 * char[] ch=eventEntry.getEvent_category_Name().toCharArray();
				 * entry.setEvent_category_id(String.valueOf(ch));
				 */				
              Region region = regionService.findByRegionTerritory(eventEntryMaster.getRegion_territory());
				
                if(region!=null)
                {
                	entry.setRegion_id(region.getRegion_id());
                }
               	 
				Category category = categoryService.findByEventCategoryName(eventEntryMaster.getEvent_category_Name());

				if (category != null) {
					entry.setEvent_category_id(category.getEvent_cat_id());

				} 			 
				/*CalendarType calendartype=calendartypeService.findByCalendarTypeName(eventEntryMaster.getCalendar_type_name());
				if (calendartype != null) {
					entry.setCalendar_type_id(calendartype.getCalendar_type_id());
				} */
		
		EventEntryMaster savedEvent = eventEntryRepository.save(entry);
		if (null != savedEvent) {
			maxEvent_Id = savedEvent.getEvent_ID();
		} else {
			maxEvent_Id = 1;
		}
		List<EventApplicationMaster> eventAppList = new ArrayList<>();
		for (String appName : eventEntryMaster.getEventAppSet()) {
			EventApplicationMaster eventApp = new EventApplicationMaster();
			System.out.println("#########inside EventApplicationMaster ##############");
			eventApp.setApplication(appName);
			System.out.println("appName---->"+appName);
			eventApp.setEvent_ID(maxEvent_Id);
			//eventApp.setEvent_ID(eventEntryMaster.getEvent_ID());
			System.out.println("maxEvent_Id--->"+maxEvent_Id);
			eventAppList.add(eventApp);
		}
		entry.setEventAppSet(eventAppList);

		List<EventUserMaster> eventUserList = new ArrayList<>();
		// List<User> userList=userEntryrepository.findAll();
		System.out.println("###inside EventApplicationMaster  eventEntryMaster.getEventUserSet()####"+ eventEntryMaster.getEventUserSet().length);
		for (String Resourcename1 : eventEntryMaster.getEventUserSet()) {
			//User user = userRepository.findByResourcename(Resourcename);
			EventUserMaster eventUser = new EventUserMaster();
			System.out.println("#########inside EventApplicationMaster Resourcename##############");
			//eventUser.setResource(user.getUsername());
			eventUser.setResource(Resourcename1);
			System.out.println("Resourcename---->"+Resourcename1);
			eventUser.setEvent_ID(maxEvent_Id);
			System.out.println("maxEvent_Id--->"+maxEvent_Id);
			eventUserList.add(eventUser);
		}
		entry.setEventUserSet(eventUserList);

		eventEntryRepository.save(entry);

	}

	@Override
	public List<EventEntryMaster> findAll() {
		
		return eventEntryRepository.findAll();
	}

	@Override
	public List<String> getEventName() {
		List<EventEntryMaster> eventEntryMasterList=eventEntryRepository.findAll();
		List<String> eventList=new ArrayList<>();
		for(EventEntryMaster eventEntryMaster : eventEntryMasterList){
			eventList.add(eventEntryMaster.getEventname());
		}
		
		return eventList;
		
	}

	@Override
	public EventEntryMaster findById(Long id) {
		return eventEntryRepository.findOne(id);
	}

	@Override
	public EventEntryMaster findByEventName(String eventMasterName) {
		EventEntryMaster masterEvent=new EventEntryMaster();
		List<EventEntryMaster> eventEntryMasterList=eventEntryRepository.findAll();
		
		for(EventEntryMaster eventEntryMaster : eventEntryMasterList){
			if(eventMasterName.equalsIgnoreCase(eventEntryMaster.getEventname())){
				return eventEntryMaster;
			}
		}
		
		return masterEvent;
	}

	@Override
	public void editSave(EventEntryMasterBean eventEntry) {

		/*
		 * Page<EventEntry> page = eventEntryRepository.findAll(new
		 * PageRequest(0, 1, Direction.ASC, "Event_ID")); EventEntry entry2 =
		 * page.getContent().get(0); long maxEvent_Id = entry2.getEvent_ID();
		 */
		/*long maxEvent_Id = 0;*/
		EventEntryMaster entry = new EventEntryMaster();
		entry.setEvent_ID(eventEntry.getEvent_ID());
		entry.setEventname(eventEntry.getEventName());
		entry.setDescription_details(eventEntry.getDescription_details());
		/*entry.setStart_date(eventEntry.getStart_date());
		entry.setEnd_date(eventEntry.getEnd_date());*/
		entry.setAdditional_receipients(eventEntry.getEmail_receipients());
		entry.setAdditional_receipients1(eventEntry.getEmail_receipients1());
		entry.setEngagement_Name(eventEntry.getEngagement_Name());
		/*entry.setLast_Modified_Date(eventEntry.getStart_date());*/
		entry.setLast_Modified_by(eventEntry.getEventName());
		/*entry.setCreated_Date(eventEntry.getStart_date());*/
		entry.setCreated_By(eventEntry.getEventName());

		entry.setRisk_summary(eventEntry.getRisk_summary());
		//entry.setRegion_territory(eventEntry.getRegion_territory());
		/*char[] ch=eventEntry.getEvent_category_Name().toCharArray();
		entry.setEvent_category_id(String.valueOf(ch));*/
		
		 Region region = regionService.findByRegionTerritory(eventEntry.getRegion_territory());
			
         if(region!=null)
         {
         	entry.setRegion_id(region.getRegion_id());
         }
		
		Category category=categoryService.findByEventCategoryName(eventEntry.getEvent_category_Name());
		
		if(category!=null){
			entry.setEvent_category_id(category.getEvent_cat_id());
			
		}
		
		/*CalendarType calendartype=calendartypeService.findByCalendarTypeName(eventEntry.getCalendar_type_name());
		if (calendartype != null) {
			entry.setCalendar_type_id(calendartype.getCalendar_type_id());
		} */
		
		
		/*EventEntryMaster savedEvent = eventEntryRepository.save(entry);
		if (null != savedEvent) {
			maxEvent_Id = savedEvent.getEvent_ID();
		} else {
			maxEvent_Id = 1;
		}*/
		
		
		List<EventApplicationMaster> eventAppList = new ArrayList<>();
		System.out.println("#########inside Edit EventApplicationMaster ##############>>"+eventEntry.getEventAppSet().length);
		for (String appName : eventEntry.getEventAppSet()) {
			EventApplicationMaster eventApp = new EventApplicationMaster();		
			eventApp.setEvent_ID(eventEntry.getEvent_ID());
			eventApp.setApplication(appName);
			System.out.println("appName---->"+appName);			
			eventAppList.add(eventApp);
		}
		entry.setEventAppSet(eventAppList);
		
		/*
		List<EventApplicationMaster> eventAppList = new ArrayList<>();
		for (String appName : eventEntry.getEventAppSet()) {
			EventApplicationMaster eventApp = new EventApplicationMaster();
			eventApp.setEvent_ID(eventEntry.getEvent_ID());
			eventApp.setApplication(appName);
			//eventApp.setEvent_ID(maxEvent_Id);
			
			eventAppList.add(eventApp);
		}
		entry.setEventAppSet(eventAppList);*/

		List<EventUserMaster> eventUserList = new ArrayList<>();
		// List<User> userList=userEntryrepository.findAll();
		
		System.out.println("###inside edit eventEntryMaster.getEventUserSet()####"+ eventEntry.getEventUserSet().length);
		for (String Resourcename : eventEntry.getEventUserSet()) {
			
			User user=userRepository.findByResourcename(Resourcename);
			EventUserMaster eventUser = new EventUserMaster();			
			//eventUser.setResource(user.getResourcename());
			eventUser.setEvent_ID(eventEntry.getEvent_ID());
			eventUser.setResource(Resourcename);
			System.out.println("Resourcename---->"+Resourcename);
			/*eventUser.setEvent_ID(maxEvent_Id);*/
			//eventUser.setEvent_ID(eventEntry.getEvent_ID());

			eventUserList.add(eventUser);
		}
		entry.setEventUserSet(eventUserList);

		eventEntryRepository.save(entry);

	
		
	}

	@Override
	public void save(EventEntryBean eventEntry) {
		
			
			long maxEvent_Id = 0;
			EventEntry entry = new EventEntry();
			entry.setEventname(eventEntry.getEventName());
			entry.setEngagement_Name(eventEntry.getEngagement_Name());
			entry.setRisk_summary(eventEntry.getRisk_summary());
			//entry.setRegion_territory(eventEntry.getRegion_territory());
			entry.setDescription_details(eventEntry.getDescription_details());
			entry.setAdditional_receipients(eventEntry.getEmail_receipients());
			
			/*if(eventName.contains(",")){
				
	        String st[]=eventName.split(",");
	        
	      //  String newEvName=st[0];
			
			//entry.setEventname(newEvName);
			}
			
			else{
				entry.setEventname(eventName);
			}*/
			
			
	        
			
			String startDate=eventEntry.getStart_date();
	 		
			if(startDate.startsWith(",")){
	 			String startDate1=startDate.substring(1);
	 			entry.setStart_date(startDate1);
	 		}else{
	 			entry.setStart_date(startDate);
	 		}
			
	 		String endDate=eventEntry.getEnd_date();
	 		if(endDate.startsWith(",")){
	 			String end=endDate.substring(1);
	 			entry.setEnd_date(end);
	 		}
	 		else{
	 			entry.setEnd_date(endDate);
	 		}
	 		
	      /*  String email=eventEntry.getEmail_receipients();
	 		
	        if(email.startsWith(",")){
	 			String email1=email.substring(1);
	 			entry.setAdditional_receipients(email1);
	 		}/*else if(!email.startsWith(",") && email.contains(",")){
	 			
	 			String st[]=email.split(",");
	 	        
	 	        String email1=st[0];
	 	        
	 	       entry.setAdditional_receipients(email1);
	 		}*/
	        
	        
	      //  else{
	 		//	entry.setAdditional_receipients(email);
	 		//}
			
			entry.setStart_date(eventEntry.getStart_date());
			
			
			entry.setEnd_date(eventEntry.getEnd_date());
			
			
			entry.setEngagement_Name(eventEntry.getEngagement_Name());
			/*entry.setLast_Modified_Date(eventEntry.getStart_date());*/
			entry.setLast_Modified_by(eventEntry.getEventName());
			/*entry.setCreated_Date(eventEntry.getStart_date());*/
			entry.setCreated_By(eventEntry.getEventName());
			entry.setRisk_summary(eventEntry.getRisk_summary());
			//entry.setRegion_territory(eventEntry.getRegion_territory());
			/*char[] ch=eventEntry.getEvent_category_Name().toCharArray();
			entry.setEvent_category_id(String.valueOf(ch));*/
			
			
		/*	String evCatName=eventEntry.getEvent_category_Name();
			
			if(evCatName.startsWith(",")){
				String eveCat1 = evCatName.substring(1);
			Category category=categoryService.findByEventCategoryName(eveCat1);
			
			if(category!=null){
				entry.setEvent_category_id(category.getEvent_cat_id());
				
			}
			}else{
			
	        Category category=categoryService.findByEventCategoryName(evCatName);
			
			if(category!=null){
				entry.setEvent_category_id(category.getEvent_cat_id());
				
			}
			}*/
			
			 Region region = regionService.findByRegionTerritory(eventEntry.getRegion_territory());
				
             if(region!=null)
             {
             	entry.setRegion_id(region.getRegion_id());
             }
			
			 
			Category category = categoryService.findByEventCategoryName(eventEntry.getEvent_category_Name());

			if (category != null) {
				entry.setEvent_category_id(category.getEvent_cat_id());

			} 
			
			CalendarType calendartype=calendartypeService.findByCalendarTypeName(eventEntry.getCalendar_type_name());
			if (calendartype != null) {
				entry.setCalendar_type_id(calendartype.getCalendar_type_id());
			} 
			
			//entry.setAdditional_receipients(eventEntry.getEmail_receipients());
			
			EventEntry savedEvent = eventEntryRepository1.save(entry);
			if (null != savedEvent) {
				maxEvent_Id = savedEvent.getEvent_ID();
			} else {
				maxEvent_Id = 1;
			}
			
			
			List<EventApplication> eventAppList = new ArrayList<>();
			for (String appName : eventEntry.getEventAppSet()) {
				EventApplication eventApp = new EventApplication();
				eventApp.setApplication(appName);
				eventApp.setEvent_ID(maxEvent_Id);
				eventAppList.add(eventApp);
			}
			
			entry.setEventAppSet(eventAppList);

			List<EventUser> eventUserList = new ArrayList<>();
			// List<User> userList=userEntryrepository.findAll();
			
			
			for (String Resourcename : eventEntry.getEventUserSet()) {

				
				User user=userRepository.findByResourcename(Resourcename);

				EventUser eventUser = new EventUser();
				
				eventUser.setResource(user.getUsername());

				eventUser.setEvent_ID(maxEvent_Id);

				eventUserList.add(eventUser);
			}
			entry.setEventUserSet(eventUserList);

			eventEntryRepository1.save(entry);

		}

	@Override
	@Transactional
	public void deleteEventUserBeforeEditSaveUsers(Long Event_ID) 
	{
			SessionFactory factory = new Configuration().configure().buildSessionFactory();
			Session session = factory.openSession();
			 session.getTransaction().begin();
			SQLQuery query = session.createSQLQuery("CALL deleteEventEntryMasterUsers(:Event_ID)");
			query.setParameter("Event_ID", Event_ID);
			int result=query.executeUpdate();
			session.getTransaction().commit();
			System.out.println("Completed");
	        session.clear();
	        session.close();
	}

	@Override
	@Transactional
	public void deleteEventAppBeforeEditSaveApps(Long Event_ID) 
	{
			SessionFactory factory = new Configuration().configure().buildSessionFactory();
			Session session = factory.openSession();
			 session.getTransaction().begin();
			SQLQuery query = session.createSQLQuery("CALL deleteEventEntryMasterApps(:Event_ID)");
			query.setParameter("Event_ID", Event_ID);
			int result=query.executeUpdate();
			session.getTransaction().commit();
			System.out.println("Completed");
	        session.clear();
	        session.close();
	}

	@Override
	public List<EventEntryMaster> findAllEventByResource(String userAccountName) {
		List<EventEntryMaster> eventList = new ArrayList<>();
		List<EventEntryMaster> eventEntryList= eventEntryRepository.findAll();
		for (EventEntryMaster eventEntry : eventEntryList) {
			if(eventEntry.getEngagement_Name() != null && userAccountName != null)
			{
				if(userAccountName.equalsIgnoreCase(eventEntry.getEngagement_Name())){
					eventList.add(eventEntry);
				}
			}
			
		}
		return eventList;
	}

	@Override
	public List<String> getEventNameByAcctName(String userAccountName) {
		List<EventEntryMaster> eventEntryMasterList=eventEntryRepository.findAll();
		List<String> eventList=new ArrayList<>();
		for(EventEntryMaster eventEntryMaster : eventEntryMasterList){
			if(userAccountName != null && eventEntryMaster.getEngagement_Name() != null && eventEntryMaster.getEngagement_Name().equalsIgnoreCase(userAccountName))
			eventList.add(eventEntryMaster.getEventname());
		}
		
		return eventList;
	}	
		
}
	
	
	
	
	
	
	



	/*
	 * @Override
	 * 
	 * @Transactional
	 *  public void editSave(EventEntryBean eventEntry) {
	 * 
	 * Page<EventEntry> page = eventEntryRepository.findAll(new PageRequest(0,
	 * 1, Direction.ASC, "Event_ID")); EventEntry entry2 =
	 * page.getContent().get(0); long maxEvent_Id = entry2.getEvent_ID();
	 * 
	 * long maxEvent_Id = 0; EventEntry entry = new EventEntry();
	 * entry.setEvent_ID(eventEntry.getEvent_ID());
	 * entry.setEventname(eventEntry.getEventName());
	 * entry.setDescription_details(eventEntry.getDescription_details());
	 * entry.setStart_date(eventEntry.getStart_date());
	 * entry.setEnd_date(eventEntry.getEnd_date());
	 * entry.setAdditional_receipients(eventEntry.getEmail_receipients());
	 * entry.setEngagement_Name(eventEntry.getEngagement_Name());
	 * entry.setLast_Modified_Date(eventEntry.getStart_date());
	 * entry.setLast_Modified_by(eventEntry.getEventName());
	 * entry.setCreated_Date(eventEntry.getStart_date());
	 * entry.setCreated_By(eventEntry.getEventName());
	 * 
	 * entry.setRisk_summary(eventEntry.getRisk_summary());
	 * entry.setRegion_territory(eventEntry.getRegion_territory()); char[]
	 * ch=eventEntry.getEvent_category_Name().toCharArray();
	 * entry.setEvent_category_id(String.valueOf(ch)); Category
	 * category=categoryService.findByEventCategoryName(eventEntry.
	 * getEvent_category_Name());
	 * 
	 * if(category!=null){
	 * entry.setEvent_category_id(category.getEvent_cat_id());
	 * 
	 * }
	 * 
	 * 
	 * 
	 * EventEntry savedEvent = eventEntryRepository.save(entry); if (null !=
	 * savedEvent) { maxEvent_Id = savedEvent.getEvent_ID(); } else {
	 * maxEvent_Id = 1; } List<EventApplication> eventAppList = new
	 * ArrayList<>(); for (String appName : eventEntry.getEventAppSet()) {
	 * EventApplication eventApp = new EventApplication();
	 * eventApp.setApplication(appName); eventApp.setEvent_ID(maxEvent_Id);
	 * eventAppList.add(eventApp); }
	 * 
	 * entry.setEventAppSet(eventAppList);
	 * 
	 * List<EventUser> eventUserList = new ArrayList<>(); // List<User>
	 * userList=userEntryrepository.findAll();
	 * 
	 * 
	 * for (String Resourcename : eventEntry.getEventUserSet()) {
	 * 
	 * 
	 * User user=userRepository.findByResourcename(Resourcename);
	 * 
	 * EventUser eventUser = new EventUser();
	 * 
	 * eventUser.setResource(user.getUsername());
	 * 
	 * eventUser.setEvent_ID(maxEvent_Id);
	 * 
	 * eventUserList.add(eventUser); } entry.setEventUserSet(eventUserList);
	 * 
	 * eventEntryRepository.save(entry);
	 * 
	 * }
	 * 
	 * 
	 * 
	 * 
	 * @Override public List<EventEntry> findAll() {
	 * 
	 * return eventEntryRepository.findAll(); }
	 * 
	 * @Override public EventEntry findById(Long id) {
	 * 
	 * return eventEntryRepository.findOne(id); }
	 */


