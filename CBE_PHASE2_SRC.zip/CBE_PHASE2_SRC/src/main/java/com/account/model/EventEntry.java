package com.account.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * jaimishr
 * 
 */

@Entity
@Table(name = "tbl_event_master")
public class EventEntry {

@Id
@GeneratedValue(strategy = GenerationType.AUTO)	
private Long Event_ID;
private String Eventname;
private String Description_details;
private String Start_date;
private String End_date;
private String Additional_receipients;
private String Email_receipients1;
private String Engagement_Name;


private Long   Event_category_id;
private String Risk_summary;
private Long Region_id;
private String Last_Modified_Date;
private String Last_Modified_by;
private String Created_Date;
private String Created_By;
private String Remarks;
private String File_upload;
private Long calendar_type_id;
private String accountName;
private String event_upld_fix;
private String event_file_name;

//Satya Code starts here
private String recurrence_type;

//added for Daily Recurrence
private String recu_every_weekday;
private String recu_every_day;

//added for Weekly Recurrence
private String recurrence_dayName;
private String recu_every_week;

//added for Monthly Recurrence
private String recu_month_day;
private String recu_every_month;

private String eventstatus;

private String monthdd1;
private String monthdd2;
private String monthtext1;
private String recu_month_day_radio;

public String getRecu_month_day_radio() {
	return recu_month_day_radio;
}

public void setRecu_month_day_radio(String recu_month_day_radio) {
	this.recu_month_day_radio = recu_month_day_radio;
}

public String getMonthdd1() {
	return monthdd1;
}

public void setMonthdd1(String monthdd1) {
	this.monthdd1 = monthdd1;
}

public String getMonthdd2() {
	return monthdd2;
}

public void setMonthdd2(String monthdd2) {
	this.monthdd2 = monthdd2;
}

public String getMonthtext1() {
	return monthtext1;
}

public void setMonthtext1(String monthtext1) {
	this.monthtext1 = monthtext1;
}

public String getAccountName() {
	return accountName;
}

public void setAccountName(String accountName) {
	this.accountName = accountName;
}

public String getEvent_upld_fix() {
	return event_upld_fix;
}

public void setEvent_upld_fix(String event_upld_fix) {
	this.event_upld_fix = event_upld_fix;
}

public String getEvent_file_name() {
	return event_file_name;
}

public void setEvent_file_name(String event_file_name) {
	this.event_file_name = event_file_name;
}

@OneToMany(cascade=CascadeType.ALL,mappedBy = "eventEntry",fetch = FetchType.EAGER)
private List<EventApplication> eventAppSet;


@OneToMany(cascade=CascadeType.ALL, mappedBy="eventEntry",fetch = FetchType.EAGER)
private List<EventUser> eventUserSet;

public EventEntry(){}

public String getFile_upload() {
	return File_upload;
}

public String getEmail_receipients1() {
	return Email_receipients1;
}

public void setEmail_receipients1(String email_receipients1) {
	Email_receipients1 = email_receipients1;
}


public Long getCalendar_type_id() {
	return calendar_type_id;
}

public void setCalendar_type_id(Long calendar_type_id) {
	this.calendar_type_id = calendar_type_id;
}

public void setFile_upload(String file_upload) {
	File_upload = file_upload;
}

public Long getEvent_ID() {
	return Event_ID;
}
public void setEvent_ID(Long event_ID) {
	Event_ID = event_ID;
}
public String getEventname() {
	return Eventname;
}
public void setEventname(String eventname) {
	Eventname = eventname;
}
public String getDescription_details() {
	return Description_details;
}
public void setDescription_details(String description_details) {
	Description_details = description_details;
}
public String getStart_date() {
	return Start_date;
}
public void setStart_date(String start_date) {
	Start_date = start_date;
}
public String getEnd_date() {
	return End_date;
}
public void setEnd_date(String end_date) {
	End_date = end_date;
}

public String getEngagement_Name() {
	return Engagement_Name;
}
public void setEngagement_Name(String engagement_Name) {
	Engagement_Name = engagement_Name;
}
public List<EventApplication> getEventAppSet() {
	return eventAppSet;
}
public void setEventAppSet(List<EventApplication> eventAppSet) {
	this.eventAppSet = eventAppSet;
}
public List<EventUser> getEventUserSet() {
	return eventUserSet;
}
public void setEventUserSet(List<EventUser> eventUserSet) {
	this.eventUserSet = eventUserSet;
}
public String getLast_Modified_Date() {
	return Last_Modified_Date;
}
public void setLast_Modified_Date(String last_Modified_Date) {
	Last_Modified_Date = last_Modified_Date;
}
public String getLast_Modified_by() {
	return Last_Modified_by;
}
public void setLast_Modified_by(String last_Modified_by) {
	Last_Modified_by = last_Modified_by;
}
public String getCreated_Date() {
	return Created_Date;
}
public void setCreated_Date(String created_Date) {
	Created_Date = created_Date;
}
public String getCreated_By() {
	return Created_By;
}
public void setCreated_By(String created_By) {
	Created_By = created_By;
}

public String getAdditional_receipients() {
	return Additional_receipients;
}

public void setAdditional_receipients(String additional_receipients) {
	Additional_receipients = additional_receipients;
}


public Long getEvent_category_id() {
	return Event_category_id;
}

public void setEvent_category_id(Long event_category_id) {
	Event_category_id = event_category_id;
}




public String getRisk_summary() {
	return Risk_summary;
}

public void setRisk_summary(String risk_summary) {
	Risk_summary = risk_summary;
}

/*public String getRegion_territory() {
	return Region_territory;
}

public void setRegion_territory(String region_territory) {
	Region_territory = region_territory;
}*/


public String getRemarks() {
	return Remarks;
}



public Long getRegion_id() {
	return Region_id;
}

public void setRegion_id(Long region_id) {
	Region_id = region_id;
}

public void setRemarks(String remarks) {
	Remarks = remarks;
}

public String getRecurrence_type() {
	return recurrence_type;
}

public void setRecurrence_type(String recurrence_type) {
	this.recurrence_type = recurrence_type;
}

public String getRecu_every_weekday() {
	return recu_every_weekday;
}

public void setRecu_every_weekday(String recu_every_weekday) {
	this.recu_every_weekday = recu_every_weekday;
}

public String getRecu_every_day() {
	return recu_every_day;
}

public void setRecu_every_day(String recu_every_day) {
	this.recu_every_day = recu_every_day;
}

public String getRecurrence_dayName() {
	return recurrence_dayName;
}

public void setRecurrence_dayName(String recurrence_dayName) {
	this.recurrence_dayName = recurrence_dayName;
}

public String getRecu_every_week() {
	return recu_every_week;
}

public void setRecu_every_week(String recu_every_week) {
	this.recu_every_week = recu_every_week;
}

public String getRecu_month_day() {
	return recu_month_day;
}

public void setRecu_month_day(String recu_month_day) {
	this.recu_month_day = recu_month_day;
}

public String getRecu_every_month() {
	return recu_every_month;
}

public void setRecu_every_month(String recu_every_month) {
	this.recu_every_month = recu_every_month;
}

public String getEventstatus() {
	return eventstatus;
}

public void setEventstatus(String eventstatus) {
	this.eventstatus = eventstatus;
}


/*@Override
public String toString() {
	return "EventEntry [Eventname=" + Eventname + ", Description_details=" + Description_details + ", Start_date="
			+ Start_date + ", End_date=" + End_date + ", Engagement_Name=" + Engagement_Name + ", eventAppSet="
			+ eventAppSet + ", eventUserSet=" + eventUserSet + ", Last_Modified_Date=" + Last_Modified_Date
			+ ", Last_Modified_by=" + Last_Modified_by + ", Created_Date=" + Created_Date + ", Created_By=" + Created_By
			+ "]";
}*/

}
