package com.account.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="tbl_user_account_details")
public class UserAccount implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long user_account_id;
	private String accountName;
	private Long User_ID;
	
	@ManyToOne    
	@JoinColumn(name = "User_ID",nullable=false,insertable=false, updatable=false )
	private User user;

	public UserAccount(){}
	
	public Long getUser_account_id() {
		return user_account_id;
	}

	public void setUser_account_id(Long user_account_id) {
		this.user_account_id = user_account_id;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public Long getUser_ID() {
		return User_ID;
	}

	public void setUser_ID(Long user_ID) {
		User_ID = user_ID;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
		
}
