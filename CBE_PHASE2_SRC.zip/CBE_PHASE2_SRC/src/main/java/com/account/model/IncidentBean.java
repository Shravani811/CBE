package com.account.model;

import javax.persistence.Entity;
import javax.persistence.Table;

public class IncidentBean {

       String Incident_ID;
       String Summary;
       String Assigned_Group;
       String Environment;
       String Priority;
       String App_Tier;
       String Product_Name;
       String App_Name;
       String Service_Type;
       String Reported_Date;
       String Notes;
       String Relev_Perc;
       String Usage_Perc;
       String Status;
       String Last_Modified_Date;
       String Resolved_Date;
       String Tower;
       String CC;
       String Cluster;
       String Assignee;
       String startDate;
       String startTime;
       String endDate;
       String endTime;
       String causecode_id;
       
	public String getIncident_ID() {
		return Incident_ID;
	}
	public void setIncident_ID(String incident_ID) {
		Incident_ID = incident_ID;
	}
	public String getSummary() {
		return Summary;
	}
	public void setSummary(String summary) {
		Summary = summary;
	}
	public String getAssigned_Group() {
		return Assigned_Group;
	}
	public void setAssigned_Group(String assigned_Group) {
		Assigned_Group = assigned_Group;
	}
	public String getEnvironment() {
		return Environment;
	}
	public void setEnvironment(String environment) {
		Environment = environment;
	}
	public String getPriority() {
		return Priority;
	}
	public void setPriority(String priority) {
		Priority = priority;
	}
	public String getApp_Tier() {
		return App_Tier;
	}
	public void setApp_Tier(String app_Tier) {
		App_Tier = app_Tier;
	}
	public String getProduct_Name() {
		return Product_Name;
	}
	public void setProduct_Name(String product_Name) {
		Product_Name = product_Name;
	}
	public String getApp_Name() {
		return App_Name;
	}
	public void setApp_Name(String app_Name) {
		App_Name = app_Name;
	}
	public String getService_Type() {
		return Service_Type;
	}
	public void setService_Type(String service_Type) {
		Service_Type = service_Type;
	}
	public String getReported_Date() {
		return Reported_Date;
	}
	public void setReported_Date(String reported_Date) {
		Reported_Date = reported_Date;
	}
	public String getNotes() {
		return Notes;
	}
	public void setNotes(String notes) {
		Notes = notes;
	}
	public String getRelev_Perc() {
		return Relev_Perc;
	}
	public void setRelev_Perc(String relev_Perc) {
		Relev_Perc = relev_Perc;
	}
	public String getUsage_Perc() {
		return Usage_Perc;
	}
	public void setUsage_Perc(String usage_Perc) {
		Usage_Perc = usage_Perc;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getLast_Modified_Date() {
		return Last_Modified_Date;
	}
	public void setLast_Modified_Date(String last_Modified_Date) {
		Last_Modified_Date = last_Modified_Date;
	}
	public String getResolved_Date() {
		return Resolved_Date;
	}
	public void setResolved_Date(String resolved_Date) {
		Resolved_Date = resolved_Date;
	}
	public String getTower() {
		return Tower;
	}
	public void setTower(String tower) {
		Tower = tower;
	}
	public String getCC() {
		return CC;
	}
	public void setCC(String cC) {
		CC = cC;
	}
	public String getCluster() {
		return Cluster;
	}
	public void setCluster(String cluster) {
		Cluster = cluster;
	}
	public String getAssignee() {
		return Assignee;
	}
	public void setAssignee(String assignee) {
		Assignee = assignee;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getCausecode_id() {
		return causecode_id;
	}
	public void setCausecode_id(String causecode_id) {
		this.causecode_id = causecode_id;
	}
}
