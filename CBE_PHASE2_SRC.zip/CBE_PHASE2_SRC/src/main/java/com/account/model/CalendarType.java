package com.account.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * @author Balasubramanian
 *
 */
@Entity
@Table(name="tbl_calendar_type_master")
public class CalendarType  implements Serializable
{

	private static final long serialVersionUID = 1L;
	private Long calendar_type_id;
    private String calendar_type_name;
    private boolean status;
    
    @Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getCalendar_type_id() {
		return calendar_type_id;
	}
	public void setCalendar_type_id(Long calendar_type_id) {
		this.calendar_type_id = calendar_type_id;
	}
	public String getCalendar_type_name() {
		return calendar_type_name;
	}
	public void setCalendar_type_name(String calendar_type_name) {
		this.calendar_type_name = calendar_type_name;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
    

}
