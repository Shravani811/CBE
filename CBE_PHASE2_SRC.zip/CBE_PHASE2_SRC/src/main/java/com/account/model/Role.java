package com.account.model;

import javax.persistence.*;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "tbl_role_master")
public class Role  {
	
	private static final long serialVersionUID = 1L;
	private Long role_Id;
   // private String role_Name;
	private String Role_Name;
    private boolean Status;
////////////////////////////////
	/*@Column(name="Role_ID")
    private Long Role_ID;
	
	@Column(name = "Role_Name")
    private String Role_Name;
	
	@Column(name="Status")
    private boolean Status;*/
    
    ///////////////////////////////////////////////////////
    private Set<User> users;

    
  /*  public Role(String role_Name, String status) {
		super();
		
		Role_Name = role_Name;
		Status = status;
	}*/

	
/////////////////////////////////////////////////////////	
 /*   public Long getRole_ID() {
		return Role_ID;
	}
*/
	/*public void setRole_ID(Long role_ID) {
		Role_ID = role_ID;
	}

	public String getRole_Name() {
		return Role_Name;
	}

	public void setRole_Name(String role_Name) {
		Role_Name = role_Name;
	}*/

	/*public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}	
	
	public boolean isStatus() {
		return Status;
	}

	public void setStatus(boolean status) {
		Status = status;
	}

	public void setUsers(Set<User> users) {
        this.users = users;
    }
	*/


	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)	

	public Long getRole_Id() {
		return role_Id;
	}


	public void setRole_Id(Long role_Id) {
		this.role_Id = role_Id;
	}




	public String getRole_Name() {
		return Role_Name;
	}


	public void setRole_Name(String role_Name) {
		Role_Name = role_Name;
	}


	public boolean isStatus() {
		return Status;
	}


	public void setStatus(boolean status) {
		Status = status;
	}
	


	
}
