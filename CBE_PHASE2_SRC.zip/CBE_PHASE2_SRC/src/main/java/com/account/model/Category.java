package com.account.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * @author jaimishr
 *
 */
@Entity
@Table(name="tbl_event_category")
public class Category implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long event_cat_id;
    private String event_category_name;
    private boolean status;
    
    
    @Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getEvent_cat_id() {
		return event_cat_id;
	}
	public void setEvent_cat_id(Long event_cat_id) {
		this.event_cat_id = event_cat_id;
	}
	public String getEvent_category_name() {
		return event_category_name;
	}
	public void setEvent_category_name(String event_category_name) {
		this.event_category_name = event_category_name;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
