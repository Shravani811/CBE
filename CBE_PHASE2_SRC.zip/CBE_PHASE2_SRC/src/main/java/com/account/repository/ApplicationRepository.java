package com.account.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.account.model.Application;

public interface ApplicationRepository extends JpaRepository<Application, Long>{
	/*List<Application> findByApp_NameAsc(String app_Name);*/
	//public void findAllOrderByIdAsc();
}
