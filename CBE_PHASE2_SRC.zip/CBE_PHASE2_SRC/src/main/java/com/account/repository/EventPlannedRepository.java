package com.account.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.account.model.EventPlanned;

public interface EventPlannedRepository extends JpaRepository<EventPlanned, Long> {

}
