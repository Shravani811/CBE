package com.account.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.account.model.EventApplicationMaster;

public interface ApplicationMasterRepository extends JpaRepository<EventApplicationMaster, Long> {

}
