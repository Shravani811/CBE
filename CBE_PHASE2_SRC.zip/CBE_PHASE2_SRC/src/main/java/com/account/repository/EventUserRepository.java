package com.account.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.account.model.EventUser;

public interface EventUserRepository extends JpaRepository<EventUser, Long>{

}
