package com.account.validator;

import com.account.model.User;
import com.account.service.ApplicationService;
import com.account.service.UserService;
import com.accounts.dto.ApplicationBean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class ApplicationValidator implements Validator {
    @Autowired
    private ApplicationService appService;

    @Override
    public boolean supports(Class<?> aClass) {
        return ApplicationBean.class.equals(aClass);
    }

    @Override
    public void validate(Object o, Errors errors) {
        ApplicationBean appBean = (ApplicationBean) o;

        //ValidationUtils.rejectIfEmptyOrWhitespace(errors, "appName", "NotEmptyAppName");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "primaryResource", "NotEmptyPrimary");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "secondaryResource", "NotEmptySecondry");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "tower", "NotEmptytower");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "ccname", "NotEmptyCcName");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "cluster", "NotEmptyCluster");
        
        /*if (user.getUsername().length() < 6 || user.getUsername().length() > 32) {
            errors.rejectValue("Username", "Size.userForm.username");
        }*/
        /*if (userService.findByUsername(user.getUsername()) != null) {
            errors.rejectValue("Username", "Duplicate.userForm.username");
        }*/
        
       /* if(appService.findByAppName(appBean.getAppName()) != null){
        	errors.rejectValue("appName", "Duplicate.appForm.apprname");
        	
        }*/
        
        
        if(appBean.getPrimaryResource().equals(appBean.getSecondaryResource())){
        	errors.rejectValue("primaryResource", "primary.secondary.resource");
        }
       /*if(appBean.getPrimaryResource()=="NONE"){
    	   errors.rejectValue("primaryResource", "primary.secondary.resource.required");
       }*/
        /*if (!user.getPasswordConfirm().equals(user.getPassword())) {
            errors.rejectValue("passwordConfirm", "Diff.userForm.passwordConfirm");
        }*/
    }
}
//Your username and password is invalid