package com.account.validator;

import com.account.model.EventEntry;
import com.account.model.User;
import com.account.service.ApplicationService;
import com.account.service.EventEntryMasterService;
import com.account.service.UserService;
import com.accounts.dto.EventEntryBean;
import com.accounts.dto.EventEntryMasterBean;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;


@Component
public class EventEntryMasterValidator implements Validator {
    @Override
    public boolean supports(Class<?> aClass) {
    	return EventEntry.class.equals(aClass);
    }

    @Override
    public void validate(Object o, Errors errors) {
    	
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "EventName", "EventNameNotEmpty");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "Description_details", "DescriptionEventNotEmpty");
        
        
        ///////////////////////////////////////////////////////////////////////////////////////
        
        /*    if (user.getUsername().length() < 6 || user.getUsername().length() > 32) {
            errors.rejectValue("username", "Size.userForm.username");
        }
        if(eventEntry.getEventName().length() <2  || eventEntry.getEventName().length() < 30){
        	errors.rejectValue("eventName", "Size.userForm.eventName");
        }
        if (userService.findByUsername(user.getUsername()) != null) {
            errors.rejectValue("username", "Duplicate.userForm.username");
        }*/

        /*ValidationUtils.rejectIfEmptyOrWhitespace(errors, "Start_date", "StartDateNotEmpty");*/
        /*if (user.getPassword().length() < 8 || user.getPassword().length() > 32) {
            errors.rejectValue("password", "Size.userForm.password");
        }*/
        
        
        /*if(eventEntryMasterService.findByEventName(eventEntryBean.getEventName()) != null){
        	errors.rejectValue("EventName", "Duplicate.addEntryForm.eventname");
        }*/
        
        
        ///////////////////////////////////////////////////

         ValidationUtils.rejectIfEmptyOrWhitespace(errors, "eventAppSet", "EventAppNotEmpty");
         ValidationUtils.rejectIfEmptyOrWhitespace(errors, "eventUserSet", "EventUserNotEmpty");
         ValidationUtils.rejectIfEmptyOrWhitespace(errors, "Engagement_Name", "EngagementEventNotEmpty");        
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "Event_category_Name", "EventcategoryNameNotEmpty");        
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "Risk_summary", "RiskSummaryNotEmpty");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "Region_territory", "RegionTerritoryNotEmpty");
       // ValidationUtils.rejectIfEmptyOrWhitespace(errors, "calendar_type_name", "CalendarTypeNotEmpty");
        
        /*if (!user.getPasswordConfirm().equals(user.getPassword())) {
            errors.rejectValue("passwordConfirm", "Diff.userForm.passwordConfirm");
        }*/
    }
}
