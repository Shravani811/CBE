package com.account.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.account.service.AccountService;
import com.accounts.dto.AccountBean;
import com.accounts.dto.ApplicationBean;

@Component
public class AccountValidator implements Validator {
    @Autowired
    private AccountService accService;

    @Override
    public boolean supports(Class<?> aClass) {
        return AccountBean.class.equals(aClass);
    }

    @Override
    public void validate(Object o, Errors errors) {
        AccountBean appBean = (AccountBean) o;

        //ValidationUtils.rejectIfEmptyOrWhitespace(errors, "appName", "NotEmptyAppName");
       /* if(appService.findByAppName(appBean.getAppName()) != null){
        	errors.rejectValue("appName", "Duplicate.appForm.apprname");
        	
        }*/
        
        
        
    }
}
//Your username and password is invalid