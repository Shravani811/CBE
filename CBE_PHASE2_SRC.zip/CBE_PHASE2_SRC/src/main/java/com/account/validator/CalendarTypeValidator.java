package com.account.validator;

import com.account.model.User;
import com.account.service.CalendarTypeService;

import com.account.service.UserService;
import com.accounts.dto.CalendarTypeBean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.account.model.User;

@Component
public class CalendarTypeValidator implements Validator
{
	
	   @Autowired
	    private CalendarTypeService categoryTypeService;

	    @Override
    public boolean supports(Class<?> aClass) {
        return User.class.equals(aClass);
    }

    @Override
    public void validate(Object o, Errors errors) {
       ValidationUtils.rejectIfEmptyOrWhitespace(errors, "calendar_type_name", "NotEmpty_Calendar_Type_name");
        
    }
      
}
