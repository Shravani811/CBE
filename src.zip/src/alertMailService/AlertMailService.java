
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

//import org.apache.log4j.Logger;


public class AlertMailService {

	//private static final Logger LOGGER = Logger.getLogger(AlertMailService.class);

	public static final LocalDateTime currD = LocalDateTime.now();
	static Connection conn, conn1;
	static CallableStatement stmt, stmt1, stmt2;
	static ResultSet resultset, resultset1;
	//static PreparedStatement prepared;
	public static Properties props = new Properties();

	public static void main(String[] args) throws FileNotFoundException, IOException, SQLException, ParseException {
		//LOGGER.info("Main");
		loadProps();
		//LOGGER.info(props.values());
		conn1 = getcon();
		String query = "{CALL getEventData()}";
		stmt1 = conn1.prepareCall(query);
		//String sql = "update tbl_event_master set emailflag=? where event_id=?";
		//prepared = conn1.prepareStatement(sql);
		conn1.toString();
		resultset1 = stmt1.executeQuery();
		while (resultset1.next()) {
			EventEntry event = new EventEntry();
			try {
				
			event.setEventID(resultset1.getLong("Event_Id"));
			event.setStartDate(resultset1.getString("Start_Date"));
			event.setEndDate(resultset1.getString("End_date"));
			event.setRecurrenceType(resultset1.getString("Recurrence_type"));
			event.setEventName(resultset1.getString("eventName"));
			event.setEventDesc(resultset1.getString("Description_details"));
			event.setRecuEveryDay(resultset1.getString("recu_every_day"));
			event.setRecurrenceDayName(resultset1.getString("recurrence_dayName"));
			event.setRecuEveryWeek(resultset1.getString("recu_every_week"));
			event.setRecuMonthDay(resultset1.getString("recu_month_day"));
			event.setRecuEveryMonth(resultset1.getString("recu_every_month"));
			event.setMonthdd1(resultset1.getString("monthdd1"));
			event.setMonthdd2(resultset1.getString("monthdd2"));
			event.setMonthtext1(resultset1.getString("monthtext1"));
			event.setRecuMonthDayRadio(resultset1.getString("recu_month_day_radio"));
			event.setAttachment(resultset1.getString("file_upload"));
			
			//LOGGER.info("Event name:" +event.getEventName());
			
			String currDate = Long.toString(System.currentTimeMillis());
			
			String startDate = event.getStartDate();
			String endDate = event.getEndDate();
			
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S");
			
			final LocalDateTime start = LocalDateTime.parse(startDate, formatter);
			final LocalDateTime end = LocalDateTime.parse(endDate, formatter);
			final LocalDateTime compMin = currD.plusMinutes(15);
			//LOGGER.info("Recurrence type of this event:" +event.getRecurrenceType());
			if(null == event.getRecurrenceType()) {
				//LOGGER.info("Null Recurrence Type for event : "+ event.getEventID());
				continue;
			}
			
		switch(event.getRecurrenceType()) {
			case "weekly":
				List<LocalDateTime> eventStTymLstWeek = getWeekRecur(event, start, end);
				//LOGGER.info("Event Id : " +event.getEventID()+ " Total Weekly Events : "+eventStTymLstWeek.size());
				
				final LocalDateTime compOneDay = currD.plusDays(1);				
				for(LocalDateTime lcl : eventStTymLstWeek){
					//if(compOneDay.toLocalDate().compareTo(lcl.toLocalDate()) == 0) {
						if(lcl.compareTo(compOneDay.plusMinutes(15)) < 0 &&
								lcl.compareTo(compOneDay)>0
								) {
							try {
								//LOGGER.info("Event name:" +event.getEventName() + " Event Start time:" +lcl);
								sendMail(start, end,lcl,event);
							} catch (SQLException e) {
								e.printStackTrace();
							}
							
						}
					//}	
					
					//if(currD.toLocalDate().compareTo(lcl.toLocalDate()) == 0) {
						if(lcl.compareTo(compMin) < 0 &&
								lcl.compareTo(currD)>0
								) {
							try {
								//LOGGER.info("Event name:" +event.getEventName() + " Event Start time:" +lcl);
								sendMail(start, end,lcl,event);
							} catch (SQLException e) {
								e.printStackTrace();
							}
						}
					//}	
				}
				break;
				
			case "monthly":			

				
				List<LocalDateTime> eventStTymLstMonth = getMonthRecur(event, start, end);
				//LOGGER.info("Event Id : " +event.getEventID()+ " Total Monthly Events : "+eventStTymLstMonth.size());
				
				final LocalDateTime compSevenDay = currD.plusDays(7);
				for(LocalDateTime lcl : eventStTymLstMonth){
					//if(compSevenDay.toLocalDate().compareTo(lcl.toLocalDate()) == 0) {
						if(lcl.compareTo(compSevenDay.plusMinutes(15)) < 0 &&
								lcl.compareTo(compSevenDay)>0
								) {
							try {
								//LOGGER.info("Event name:" +event.getEventName() + " Event Start time:" +lcl);
								sendMail(start, end,lcl,event);
							} catch (SQLException e) {
								e.printStackTrace();
							}
							
						}
					//}	
					
					//if(currD.toLocalDate().compareTo(lcl.toLocalDate()) == 0) {
						if(lcl.compareTo(compMin) < 0 &&
								lcl.compareTo(currD)>0
								) {
							try {
								//LOGGER.info("Event name:" +event.getEventName() + " Event Start time:" +lcl);
								sendMail(start, end,lcl,event);
							} catch (SQLException e) {
								e.printStackTrace();
							}
						}
					//}	
				}
				break;
				
			default: 
				LocalDateTime lcl = LocalDateTime.of(currD.toLocalDate(),start.toLocalTime());
				sendMail(start, end,lcl,event);
				if (endDate.compareTo(currDate) > 0) {
					
					//LOGGER.info("Event Id : " +event.getEventID()+ " a daily event");
					//LocalDateTime lcl = LocalDateTime.of(currD.toLocalDate(),start.toLocalTime());
					if (lcl.compareTo(compMin) < 0 &&
							lcl.compareTo(currD)>0
							) {
						try {
							//LOGGER.info("Event name:" +event.getEventName() + " Event Start time:" +start);
							sendMail(start, end,lcl,event);
						} catch (SQLException e) {
							e.printStackTrace();
						}
						
					}
				}
				break;
			}

		}catch (Exception e) {
			//LOGGER.info("Exception : "+e+" Event Id :"+event.getEventID());
		}
		}
	}
	private static void loadProps() throws FileNotFoundException, IOException {
	
		//System.out.println(AlertMailService.class.getClassLoader().getResource("application.properties").getPath());
			props.load(AlertMailService.class.getClassLoader().getResourceAsStream("application.properties"));			
		 
		    
	}
public static Connection getcon() {
		Connection con = null;
		try {
			String driver = "com.mysql.jdbc.Driver";
			/*String jdbcURL = props.getProperty("url");//"jdbc:mysql://in-blr-natools:3306/cbe_bd_refactoring";
			String jdbcUsername = props.getProperty("username");//"ikon_na";
			String jdbcPassword = props.getProperty("password");//"ikonna@123";*/			
			
			String jdbcURL = props.getProperty("jdbc.url");//"jdbc:mysql://in-blr-natools:3306/cbe_bd_refactoring";
			String jdbcUsername = props.getProperty("jdbc.username");//"ikon_na";
			String jdbcPassword = props.getProperty("jdbc.password");//"ikonna@123";
			
			Class.forName(driver);
			con = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		} catch (Exception e) {
			System.out.println("exception" + e);
		}
		return con;
	}

	public static void sendMail(LocalDateTime start,
			LocalDateTime end, LocalDateTime lcl, EventEntry event) throws SQLException, IOException {

		//LOGGER.info("In SendMail for Event Id : "+event.getEventID());
		System.out.println("In SendMail for Event Id : "+event.getEventID());
		conn = getcon();

		String query = "{CALL getRecipients(?)}";
		stmt = conn.prepareCall(query);
		stmt.setLong(1, event.getEventID());
		resultset = stmt.executeQuery();

		String recipients = "";
		while (resultset.next()) {
			recipients = resultset.getString("Additional_receipients");
			//System.out.println("Name of event:" + event.getEventName());
		}
		String to = recipients;
		// String to= "vidushi.razdan@capgemini.com";
		//LOGGER.info("Mail will go to: " + to);

		String from = "dactoolssupport.in@capgemini.com";
		
		
		
		Properties properties = System.getProperties();
		
		// Prod email starts here
		
	     /* properties.put("mail.smtp.starttls.enable", "true");
	      properties.put("mail.smtp.host", "ismtp.corp.capgemini.com");
	      properties.put("mail.smtp.user", "anima.prasad@capgemini.com");
	      properties.put("mail.smtp.port", "25");
	      properties.put("mail.smtp.auth", "false");
	      properties.put("mail.smtp.starttls.enable","false");
	      // Setup mail server
	      properties.setProperty("mail.smtp.host", "ismtp.corp.capgemini.com");
	      Session session = Session.getInstance(properties);*/
	      
	    // Prod email ends here
		
		
		 //local code email send starts here
		 //DEV
		properties.put("mail.smtp.auth", "true");
		properties.put("mail.smtp.starttls.enable", "true");
		properties.put("mail.smtp.host", "smtp-mail.outlook.com");
		properties.put("mail.smtp.port", "587");
		 
		 //final String username = "natools_support.in@capgemini.com";
		 final String username = "manikandan.bk@capgemini.com";
			final String password = "bkmsg@123";
			
			Session session = null;
			
			session = null;
			session = Session.getInstance(properties, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(username, password);
				}
			});
		 
		 
		 // local code email send ends here
		
		
	      DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern( "yyyyMMdd'T'HHmm'00'" ) ;
	      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	      String eventDate = lcl.format(formatter);
	      System.out.println(eventDate);

		try {

			Message message = new MimeMessage(session);

			message.setFrom(new InternetAddress(from));

			// Set To: header field of the header.
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse("manikandan.bk@capgemini.com"));
			//message.setRecipients(Message.RecipientType.BCC, InternetAddress.parse("santhosh.a.moorthy@capgemini.com,vidushi.razdan@capgemini.com,manikandan.bk@capgemini.com"));
			// message.setRecipients(Message.RecipientType.CC, InternetAddress.parse(CC));
			// Set Subject: header field
			message.setSubject("CBE Event Alert: " + event.getEventName());

			// Create the message part
			BodyPart messageBodyPart = new MimeBodyPart();
			messageBodyPart.setContent("Hello,<br><br>" + "This is a "
					+ "reminder as per your scheduled events, the following event is coming up. Please find the details below:<br> "
					+ " Event Name: " + event.getEventName() + "<br>Recurrence Type: " + event.getRecurrenceType() + "<br>Start Date of Event: "
					+ eventDate + "<br> End Date: " + eventDate + "<br> Event Time: "
					+ lcl.toLocalTime() + " <br><br><br>Regards," + "<br><br> <br>Team CBE",
					"text/html; charset=utf-8");

			Multipart multipart = new MimeMultipart();
			
			StringBuffer messageText = new StringBuffer();
			
			//DEV
			 messageText.append("BEGIN:VCALENDAR\n" +
			 			"ATTENDEE;ROLE=REQ-PARTICIPANT;RSVP=TRUE:MAILTO:manikandan.bk@capgemini.com\n" +
		             "PRODID:-//Microsoft Corporation//Outlook 9.0 MIMEDIR//EN\n" +
		             "VERSION:2.0\n" +
		             "METHOD:REQUEST\n" +
		                 "BEGIN:VEVENT\n" +
		                 "ORGANIZER:MAILTO:dactoolssupport.in@capgemini.com" ) ;
			 messageText.append( "\n" +
			                     "DTSTART:");
			 messageText.append(lcl.format(dateFormat) ) ;
			
			 
//			 messageText.append("\n" +"RRULE:" ) ;
//			 messageText.append(rrule);
		     
			 
			 //messageText.append( start  ) ;
			 messageText.append( "\n" +"DTEND:" ) ;
			 messageText.append( ( start.toLocalTime().compareTo(end.toLocalTime()) >= 0 ? lcl.plusHours(1) : LocalDateTime.of(lcl.toLocalDate(),end.toLocalTime()) ).format(dateFormat) ) ;
			 
			 //added status
			 messageText.append("\n" +"STATUS:" ) ;
			 messageText.append("CONFIRMED");
			 messageText.append("\n" +"DESCRIPTION:" ) ;
			 messageText.append("Event Name: " + event.getEventName() + "\\r\\nEvent Description: " + event.getEventDesc()+"\\r\\nReminder From,\\r\\nDAC TOOLs.");
			 messageText.append("\n" +"SUMMARY:" ) ;
			 messageText.append(event.getEventName());
			 
			 //messageText.append( end ) ;
//			 messageText.append( "\n" +"LOCATION:" ) ;
//			 messageText.append( location ) ;
			 messageText.append( "\n" +"UID:" ) ;
			 messageText.append(event.getEventID()+lcl.toLocalDate().toEpochDay()+"cbe@dactools") ;
			 
			 messageText.append( "\n" +"DTSTAMP:" ) ;
			 messageText.append( currD.format(dateFormat) ) ;
			 
			 //messageText.append( new java.util.Date()) ;
			 messageText.append( "\n" +
			                             "BEGIN:VALARM\n" +
			                             "TRIGGER:-PT15M\n" +
			                             "ACTION:DISPLAY\n" +
			                             "DESCRIPTION:Reminder\n" +
			                             "SUMMARY:"+event.getEventName()+"\n" +
			                             "END:VALARM\n" +
			                        "END:VEVENT\n" +
			                    "END:VCALENDAR"
			                    ) ;

			
			 BodyPart messageBodyPartCal = new MimeBodyPart();
			// Fill the message
		     messageBodyPartCal.setHeader("Content-Class", "urn:content-  classes:calendarmessage");
		     messageBodyPartCal.setHeader("Content-ID", "calendar_message");
		     messageBodyPartCal.setDataHandler(new DataHandler(
		             new ByteArrayDataSource(messageText.toString(), "text/calendar")));// very important

		     multipart.addBodyPart(messageBodyPartCal);
		    multipart.addBodyPart(messageBodyPart);   
		    
		    
		  if (null != event.getAttachment() && !event.getAttachment().isEmpty()) 
		   {  
			 File file = new File(props.getProperty("filePath")+File.separator +event.getAttachment());	
			// LOGGER.info("filepath : "+file.getAbsolutePath());
			    if(file.exists()) {
			    	MimeBodyPart messageBodyPart2 = new MimeBodyPart(); 
					DataSource source1 = new FileDataSource(file); 
					messageBodyPart2.setDataHandler(new DataHandler(source1)); 
					messageBodyPart2.setFileName(event.getAttachment()); 
					multipart.addBodyPart( messageBodyPart2);
			    }
			 
		   }
		   
			 
			message.setContent(multipart);

			Transport.send(message);
		//	LOGGER.info("Mail has been sent with this message:" +message);
		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}

	}
	private static List<LocalDateTime> getWeekRecur(EventEntry event, LocalDateTime startlcl, LocalDateTime endlcl){
		
		String recurWeekDay = !isEmpty(event.getRecurrenceDayName()) ?event.getRecurrenceDayName().replace("MO", "2").replace("TU", "3").replace("WE", "4").replace("TH", "5").replace("FR", "6").replace("SA", "7").replace("SU", "1") : "";
		Calendar cal = Calendar.getInstance();
		Calendar calEnd = Calendar.getInstance();
		Date st = new Date(startlcl.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());
		Date end = new Date(endlcl.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());
		int recurWeek = !isEmpty(event.getRecuEveryWeek()) ? Integer.parseInt(event.getRecuEveryWeek()) : 1;
		List<LocalDateTime> lstDateTime = new ArrayList<LocalDateTime>();
		for(String s : recurWeekDay.split(",")){
			cal.setTimeInMillis(st.getTime());
			calEnd.setTimeInMillis(end.getTime());			
			int weekDay = !isEmpty(s) ? Integer.parseInt(s) : 0;
		if(cal.get(Calendar.DAY_OF_WEEK)==weekDay) {
			lstDateTime.add(LocalDateTime.ofInstant(cal.toInstant(), cal.getTimeZone().toZoneId()));			
		}
		cal.add(Calendar.WEEK_OF_YEAR, recurWeek);
		cal.set(Calendar.DAY_OF_WEEK, weekDay);			
		while(calEnd.getTimeInMillis()>cal.getTimeInMillis()){
			lstDateTime.add(LocalDateTime.ofInstant(cal.toInstant(), cal.getTimeZone().toZoneId()));
			cal.add(Calendar.WEEK_OF_YEAR, recurWeek);
			cal.set(Calendar.DAY_OF_WEEK, weekDay);			
			
		}
		}
		
		return lstDateTime;
	}
	private static List<LocalDateTime> getMonthRecur(EventEntry event, LocalDateTime startlcl, LocalDateTime endlcl) throws ParseException {
		
		Calendar cal = Calendar.getInstance();
		Calendar calEnd = Calendar.getInstance();
		Date st = new Date(startlcl.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());
		Date end = new Date(endlcl.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());
		cal.setTimeInMillis(st.getTime());
		calEnd.setTimeInMillis(end.getTime());
		List<LocalDateTime> lstDateTime = new ArrayList<LocalDateTime>();
		
		if("2".equalsIgnoreCase(event.getRecuMonthDayRadio())) {
			

			int recurWeek = !isEmpty(event.getMonthdd1()) ? Integer.parseInt(event.getMonthdd1()) : 1;
			int weekday = !isEmpty(event.getMonthdd2()) ? Integer.parseInt(event.getMonthdd2()) : 1;
			int recurMonth = !isEmpty(event.getMonthtext1()) ? Integer.parseInt(event.getMonthtext1()) : 1;
			
		if(weekday == cal.get(Calendar.DAY_OF_WEEK)) {
			recurWeek = recurWeek < 5 ? recurWeek : getLastWeekday(weekday,cal);
			cal.set(Calendar.WEEK_OF_MONTH, recurWeek);
		}else if(weekday < cal.get(Calendar.DAY_OF_WEEK)){
			recurWeek = recurWeek < 5 ? recurWeek+1 : getLastWeekday(weekday,cal);			
			cal.set(Calendar.DAY_OF_WEEK, weekday);
			cal.set(Calendar.WEEK_OF_MONTH, recurWeek);
		}else if(weekday <= Calendar.SATURDAY){
			recurWeek = recurWeek < 5 ? recurWeek : getLastWeekday(weekday,cal);			
			cal.set(Calendar.DAY_OF_WEEK, weekday);
			cal.set(Calendar.WEEK_OF_MONTH, recurWeek);			
		}else if(weekday == 9){			
				cal.set(Calendar.DAY_OF_MONTH, getNthWeekDay(recurWeek,cal));			
		}else if(weekday == 8){			
			cal.set(Calendar.DAY_OF_MONTH, getNthWeekEndDay(recurWeek,cal));			
		}
		//cal.add(Calendar.MONTH, recurMonth);
		while(calEnd.getTimeInMillis()>cal.getTimeInMillis()){
			
			lstDateTime.add(LocalDateTime.ofInstant(cal.toInstant(), cal.getTimeZone().toZoneId()));
			
			cal.add(Calendar.MONTH, recurMonth);
			if(weekday == cal.get(Calendar.DAY_OF_WEEK)) {
				recurWeek = recurWeek < 5 ? recurWeek : getLastWeekday(weekday,cal);
				cal.set(Calendar.WEEK_OF_MONTH, recurWeek);
			}else if(weekday < cal.get(Calendar.DAY_OF_WEEK)){
				recurWeek = recurWeek < 5 ? recurWeek+1 : getLastWeekday(weekday,cal);				
				cal.set(Calendar.DAY_OF_WEEK, weekday);
				cal.set(Calendar.WEEK_OF_MONTH, recurWeek);
			}else if(weekday <= Calendar.SATURDAY){
				recurWeek = recurWeek < 5 ? recurWeek : getLastWeekday(weekday,cal);			
				cal.set(Calendar.DAY_OF_WEEK, weekday);
				cal.set(Calendar.WEEK_OF_MONTH, recurWeek);			
			}else if(weekday == 9){			
					cal.set(Calendar.DAY_OF_MONTH, getNthWeekDay(recurWeek,cal));			
			}else if(weekday == 8){			
				cal.set(Calendar.DAY_OF_MONTH, getNthWeekEndDay(recurWeek,cal));			
			}
						
		}
		
			
		}else {

			int monthDay = !isEmpty(event.getRecuMonthDay()) ? Integer.parseInt(event.getRecuMonthDay()) : 1;
			int recurMonth = !isEmpty(event.getRecuEveryMonth()) ? Integer.parseInt(event.getRecuEveryMonth()) : 1;
		if(cal.get(Calendar.DAY_OF_MONTH)==monthDay) {
			lstDateTime.add(LocalDateTime.ofInstant(cal.toInstant(), cal.getTimeZone().toZoneId()));
				
		}
		cal.add(Calendar.MONTH, recurMonth);
		cal.set(Calendar.DAY_OF_MONTH, monthDay);
		while(calEnd.getTimeInMillis()>cal.getTimeInMillis()){
			lstDateTime.add(LocalDateTime.ofInstant(cal.toInstant(), cal.getTimeZone().toZoneId()));
			cal.add(Calendar.MONTH, recurMonth);
			cal.set(Calendar.DAY_OF_MONTH, monthDay);			
						
		}
		
		}
		return lstDateTime;
		
	}

	private static int getNthWeekEndDay(int recurWeek, Calendar cal3) {
		Calendar cal2 = (Calendar) cal3.clone();
		   cal2.set( Calendar.DAY_OF_MONTH, 1);
		   if(recurWeek<5) {
			   int cnt=1;
			   while ((cal2.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY
			           && cal2.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) || cnt<recurWeek){				   
			       if((cal2.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY
				           || cal2.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY)) {
			    	   cnt++;
			       }
			         cal2.add(Calendar.DATE, 1);			       
			   } 		   	       
		   }else {
			   cal2.add( Calendar.MONTH, 1);
			   do{
			       cal2.add(Calendar.DATE, -1);			       
			   } while (cal2.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY
			           && cal2.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY );
		   
			}
		   return cal2.get(Calendar.DAY_OF_MONTH);
		   }

	private static int getNthWeekDay(int recurWeek, Calendar cal3) {
		Calendar cal2 = (Calendar) cal3.clone();
	   cal2.set( Calendar.DAY_OF_MONTH, 1);
	   if(recurWeek<21) {
		   int cnt=1;
		   
		   while ((cal2.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY
	           || cal2.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) || cnt<recurWeek){
			   if((cal2.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY
			           && cal2.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY)) {
		    	   cnt++;
			   }
			   cal2.add(Calendar.DATE, 1);			       
	   } 
	   }else {
		   cal2.add( Calendar.MONTH, 1);
		   do{
			   cal2.add(Calendar.DATE, -1);
		       
		   } while (cal2.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY
		           || cal2.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY );
		}
	   return cal2.get(Calendar.DAY_OF_MONTH);
	   }

	private static int getLastWeekday(int weekday, Calendar cal2) {
		   Calendar cal = (Calendar) cal2.clone();
		   cal.add( Calendar.MONTH, 1);
		   cal.set(Calendar.DAY_OF_MONTH, 1);
		   cal.add( Calendar.DAY_OF_MONTH, -(( cal.get( Calendar.DAY_OF_WEEK ) % 7 + (7-weekday) )%7) );
		   return cal.get(Calendar.WEEK_OF_MONTH);
		}
	public static boolean isEmpty(Object str) {
		return (str == null || "".equals(str));
	}
	
	
}
