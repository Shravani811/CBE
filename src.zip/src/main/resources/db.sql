CREATE TABLE `role_master` (
  `Role_ID` int(20) NOT NULL AUTO_INCREMENT,
  `Role_Name` varchar(50) DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Role_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `app_master` (
  `User_ID` int(20) NOT NULL AUTO_INCREMENT,
  `ID` int(50) DEFAULT NULL,
   `Username` varchar(50) DEFAULT NULL,
  `Primary` varchar(50) DEFAULT NULL,
  `Secondary` varchar(50) DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`User_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `user_master` (
  `User_ID` int(20) NOT NULL AUTO_INCREMENT,
  `Username` varchar(50) DEFAULT NULL, 
  `Password` varchar(50) DEFAULT NULL,
  `Email_ID` varchar(50) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
   `Status` varchar(50) DEFAULT NULL,
   `Role_Name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`User_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `user_role` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `User_ID` int(20) DEFAULT NULL,
  `Role_ID` int(20)  DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `event_detail` (
  `Eventname` varchar(100) DEFAULT NULL, 
  `Description_details` varchar(200) DEFAULT NULL,
  `Start_date` varchar(50) DEFAULT NULL,
  `End_date` varchar(50) DEFAULT NULL,
   `Application` varchar(50) DEFAULT NULL,
   `Resource` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
