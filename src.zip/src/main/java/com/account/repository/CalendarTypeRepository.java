package com.account.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.account.model.CalendarType;;

public interface CalendarTypeRepository extends JpaRepository<CalendarType, Long>{

}
