package com.account.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.account.model.EventEntry;

public interface EventEntryRepository extends JpaRepository<EventEntry, Long> {

}
