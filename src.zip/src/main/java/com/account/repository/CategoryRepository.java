package com.account.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.account.model.Category;

public interface CategoryRepository extends JpaRepository<Category, Long>{
	//Category findByEvent_category_id(String catName);
	
}
