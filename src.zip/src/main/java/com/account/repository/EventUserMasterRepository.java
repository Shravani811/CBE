package com.account.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.account.model.EventUser;
import com.account.model.EventUserMaster;

public interface EventUserMasterRepository extends JpaRepository<EventUserMaster, Long>{

}
