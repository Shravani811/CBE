package com.account.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.account.model.Account;
import com.account.model.EventUser;
import com.account.model.Role;
import com.account.model.User;
import com.account.model.UserAccount;
import com.account.repository.AccountRepository;
import com.account.repository.RoleRepository;
import com.account.repository.UserAccountRepository;
import com.account.repository.UserRepository;
import com.accounts.dto.UserBean;

/*
 * jaimishr
 * 
 */

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private RoleRepository roleRepository;
	@Autowired
	private AccountRepository accountRepository;
	@Autowired
	private UserAccountRepository userAccountRepository;
	/*
	 * @Autowired private BCryptPasswordEncoder bCryptPasswordEncoder;
	 */
	
	/** The entity manager. */
    @PersistenceContext
	EntityManager entityManager;

	@Override
	@Transactional
	public void save(User user) {
		// user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
		 //user.setRoles(new HashSet<>(roleRepository.findAll()));
		
		 User savedUser =  userRepository.save(user);
			long maxUser_Id = 0;
			if (null != savedUser) {
				maxUser_Id = savedUser.getUser_ID();
			} else {
				maxUser_Id = 1;
			}
			if(user.getUser_Account() != null)
			{
				SessionFactory factory = new Configuration().configure().buildSessionFactory();
				Session session = factory.openSession();
				 session.getTransaction().begin();
				SQLQuery query = session.createSQLQuery("CALL deleteUser_account(:User_ID)");
				query.setParameter("User_ID", maxUser_Id);
				int result=query.executeUpdate();
				session.getTransaction().commit();
				System.out.println("Completed");
		        session.clear();
		        session.close();
		        
				List<String> accNameList = Arrays.asList(user.getUser_Account().split("\\s*,\\s*"));
				List<UserAccount> accounts = new ArrayList<>();
				for (String accName : accNameList) {
					UserAccount account = new UserAccount();
					account.setAccountName(accName);
					account.setUser_ID(maxUser_Id);
					userAccountRepository.save(account);
					accounts.add(account);
				}
				
				user.setEventAccSet(accounts);
			}
	}

	@Override
	public User findByUsername(String username) {
		return userRepository.findByUsername(username);
	}
	@Override
	@Transactional
	public List<User> findAll() {

		return userRepository.findAll();

	}

	@Override
	@Transactional
	public User findById(Long id) {

		return userRepository.findOne((long) id);
	}

	@Override
	public List<String> getResourceNames() {
		List<User> userList = userRepository.findAll();
		List<String> rescList = new ArrayList<>();
		for(User user : userList){
			if(user.isStatus()){
			rescList.add(user.getResourcename());
			}
		}
		return rescList;
	}
	
	
	@Override
	public User findByPrimaryResoureName(String primary) {
		User user=new User();
		List<User> userList=userRepository.findAll();
		for(User user1:userList){
			if(primary.equalsIgnoreCase(user1.getResourcename())){
				return user1;
			}
		}
		return user;
	}

	@Override
	public User findBySecondryResoureName(String secondry) {
		
		User user=new User();
		List<User> userList=userRepository.findAll();
		for(User user1:userList){
			if(secondry.equalsIgnoreCase(user1.getResourcename())){
				return user1;
			}
		}
		return user;
	}

	@Override
	public User findByUserNameForPrimary(String username) {
		User user=new User();
		List<User> userList=userRepository.findAll();
		for(User user1:userList){
			if(username.equals(user1.getUsername())){
				return user1;
			}
		}
		
		return user;
	}

	@Override
	public User findByUserNameForSecondry(String username) {
		User user=new User();
		List<User> userList=userRepository.findAll();
		for(User user1:userList){
			if(username.equals(user1.getUsername())){
				return user1;
			}
		}
		
		return user;
	}

	@Override
	public List<User> getUserNames() {
		
		return null;
	}

	@Override
	public List<UserBean> findAllUserBean() {
		
		List<User> userList=userRepository.findAll();
		List<UserBean> userBeantList=new ArrayList<>();
		for(User user : userList){
			UserBean userBean=new UserBean();
			userBean.setEmailID(user.getEmail_ID());
			userBean.setResourceName(user.getResourcename());
			userBean.setUsername(user.getUsername());
		    userBean.setRoleName(user.getRole_Name());
			userBeantList.add(userBean);
		}
		
		return userBeantList;
		
		//return userRepository.findAll();
	}

	@Override
	public User findByUsername(EventUser eventUser) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getRoleName() {
          List<Role> roleList=roleRepository.findAll();
		
		List<String> roleNameList=new ArrayList<>();
		for(Role role : roleList){
			if(role.isStatus())
			{
			roleNameList.add(role.getRole_Name());
			System.out.println(roleNameList.toString());
		}
		}
		
		return roleNameList;
	}

	@Override
	public List<String> getUserAccountList() {
          List<Account> accountList=accountRepository.findAll();
		
		List<String> accountNameList=new ArrayList<>();
		for(Account account : accountList){
			accountNameList.add(account.getAccount_Name());
			System.out.println(accountNameList.toString());
		}
		return accountNameList;
	}

	@Override
	public void save(UserBean userBean) {
		User user = new User();
		user.setUsername(userBean.getUsername());
		user.setPassword(userBean.getPassword());
		user.setResourcename(userBean.getResourceName());
		user.setEmail_ID(userBean.getEmailID());
		user.setStatus(userBean.isStatus());
		user.setRole_Name(userBean.getRoleName());
		user.setUser_Account(userBean.getUser_account());
		userRepository.save(user);
		User savedUser = userRepository.save(user);
		long maxUser_Id = 0;
		if (null != savedUser) {
			maxUser_Id = savedUser.getUser_ID();
		} else {
			maxUser_Id = 1;
		}
		
		List<UserAccount> accounts = new ArrayList<>();
		for (String appName : userBean.getUser_account_list()) {
			UserAccount account = new UserAccount();
			account.setAccountName(appName);
			account.setUser_ID(maxUser_Id);
			accounts.add(account);
		}
		
		user.setEventAccSet(accounts);

		userRepository.save(user);
	}

	@Override
	public User findByResourcename(String resourcename) {
			User user=new User();
			/*category.setEvent_category_name(catName);*/
			List<User> userList=userRepository.findAll();
	        
	        	for(User userData : userList){
	    			if(resourcename.equalsIgnoreCase(userData.getUsername())){
					return userData;
				}
	        	}
			
			return user;
		}

	@Override
	public List<String> findAccountsByUserID(Long userID) {
		List<String> accountList = new ArrayList<>();
		List<UserAccount> userAccList=userAccountRepository.findAll();
		for(UserAccount userAccount : userAccList){
			if(userAccount.getUser_ID() == 499){
				System.out.println("Test");
			}
    		if(userID == userAccount.getUser_ID())
   			{
    			accountList.add(userAccount.getAccountName());
   			}
       	}
		return accountList;
	}

	@Override
	public List<HashMap<String, Object>> getAllIncidents(String accountName,String applicationName, String startDate, String endDate) {
	
		String startDate1 = "2018-01-18";
		String endDate1 = "2018-01-19";
		List<HashMap<String, Object>> all_incidents = null;
		SessionFactory factory = null;
		Session session = null;

		try {
			factory = new Configuration().configure().buildSessionFactory();
			session = factory.openSession();
			Query query = session.createSQLQuery("CALL sp_getAllIncidentList(:accountName,:applicationName,:startDate,:endDate)");
			query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			new StringBuilder()
	        .append('\'')
	        .append(accountName)
	        .append('\'');
			query.setParameter("accountName", accountName);
			new StringBuilder()
	        .append('\'')
	        .append(applicationName)
	        .append('\'');
			query.setParameter("applicationName", applicationName);
			new StringBuilder()
	        .append('\'')
	        .append(startDate)
	        .append('\'');
			query.setParameter("startDate", startDate);
	        new StringBuilder()
	        .append('\'')
	        .append(endDate)
	        .append('\'');
	        query.setParameter("endDate", endDate);
			all_incidents = query.list();
			return all_incidents;
		} catch (HibernateException e) {
			//logger.error("Unexpected error", e);
		} finally{
		if(factory != null)
		{
		if (session.isOpen()){
			session.close();
		}if (!factory.isClosed()) {
			factory.close();
		} 
		}
	}
		return all_incidents;
	}

	@Override
	public List<HashMap<String, Object>> getAllIncidentsUpdating(String accountName, String applicationName,
			String startDate, String endDate) {
		String startDate1 = "2018-01-18";
		String endDate1 = "2018-01-19";
		List<HashMap<String, Object>> all_incidents = null;
		SessionFactory factory = null;
		Session session = null;

		try {
			factory = new Configuration().configure().buildSessionFactory();
			session = factory.openSession();
			Query query = session.createSQLQuery("CALL sp_getAllIncidentList(:accountName,:applicationName,:startDate,:endDate)");
			query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			new StringBuilder()
	        .append('\'')
	        .append(accountName)
	        .append('\'');
			query.setParameter("accountName", accountName);
			new StringBuilder()
	        .append('\'')
	        .append(applicationName)
	        .append('\'');
			query.setParameter("applicationName", applicationName);
			new StringBuilder()
	        .append('\'')
	        .append(startDate)
	        .append('\'');
			query.setParameter("startDate", startDate);
	        new StringBuilder()
	        .append('\'')
	        .append(endDate)
	        .append('\'');
	        query.setParameter("endDate", endDate);
			all_incidents = query.list();
			return all_incidents;
		} catch (HibernateException e) {
			//logger.error("Unexpected error", e);
		} finally{
		if(factory != null)
		{
		if (session.isOpen()){
			session.close();
		}if (!factory.isClosed()) {
			factory.close();
		} 
		}
	}
		return all_incidents;
}

	public static void main(String[] args) {
		UserServiceImpl userService = new UserServiceImpl();
		HashMap<String, String> map =  new HashMap<>();
		map.put("2018-01-06 13:47:34", "2018-01-06 16:40:15");
		map.put("2018-01-07 13:47:34", "2018-01-07 16:40:15");
		map.put("2018-01-08 13:47:34", "2018-01-08 16:40:15");
		/*map.put("2018-01-09 13:47:34", "2018-01-09 16:40:15");
		map.put("2018-01-10 13:47:34", "2018-01-10 16:40:15");
		map.put("2018-01-11 13:47:34", "2018-01-11 16:40:15");
		map.put("2018-01-12 13:47:34", "2018-01-12 16:40:15");*/
		// using for-each loop for iteration over Map.entrySet() 
		List list  = new ArrayList<>();
        for (Map.Entry<String,String> entry : map.entrySet()) 
        {
        	list.addAll(userService.getAllIncidentsByDaily("DEV_TEST","ERP Logistics", entry.getKey(), entry.getValue(),"daily","MO,TU,WE,TH,FR,SA,SU"));
        	
        }
        System.out.println(list);
        System.out.println(list.size());
	}
	@Override
	public List<HashMap<String, String>> getAllIncidentsByDaily(String accountName, String applicationName,
		String startDate, String endDate, String recurrence_type, String recu_every_day) {
		String startDate1 = "2018-01-03 01:42:00";
		String endDate1 = "2018-01-03 04:42:30";
		List<HashMap<String, String>> all_incidents = new ArrayList<>();
		SessionFactory factory = null;
		Session session = null;

		try {
			factory = new Configuration().configure().buildSessionFactory();
			session = factory.openSession();
			Query query = session.createSQLQuery("CALL sp_getAllIncidentList(:accountName,:applicationName,:startDate,:endDate)");
			query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			new StringBuilder()
	        .append('\'')
	        .append(accountName)
	        .append('\'');
			query.setParameter("accountName", accountName);
			new StringBuilder()
	        .append('\'')
	        .append(applicationName)
	        .append('\'');
			query.setParameter("applicationName", applicationName);
			new StringBuilder()
	        .append('\'')
	        .append(startDate)
	        .append('\'');
			query.setParameter("startDate", startDate);
	        new StringBuilder()
	        .append('\'')
	        .append(endDate)
	        .append('\'');
	        query.setParameter("endDate", endDate);
			all_incidents = query.list();
			return all_incidents;
		} catch (HibernateException e) {
			//logger.error("Unexpected error", e);
		} finally{
		if(factory != null)
		{
		if (session.isOpen()){
			session.close();
		}if (!factory.isClosed()) {
			factory.close();
		} 
		}
	}
		return all_incidents;
	}

	/*@Override
	public List<HashMap<String, Object>> getAllIncidentsByDaily(String accountName, String applicationName,
		String startDate, String endDate, String recurrence_type, String recu_every_day) {
		String startDate1 = "2018-01-03 01:42:00";
		String endDate1 = "2018-01-03 04:42:30";
		List<HashMap<String, Object>> all_incidents = null;
		SessionFactory factory = null;
		Session session = null;

		try {
			factory = new Configuration().configure().buildSessionFactory();
			session = factory.openSession();
			Query query = session.createSQLQuery("CALL sp_getAllIncidentList(:accountName,:applicationName,:startDate,:endDate)");
			query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			new StringBuilder()
	        .append('\'')
	        .append(accountName)
	        .append('\'');
			query.setParameter("accountName", accountName);
			new StringBuilder()
	        .append('\'')
	        .append(applicationName)
	        .append('\'');
			query.setParameter("applicationName", applicationName);
			new StringBuilder()
	        .append('\'')
	        .append(startDate)
	        .append('\'');
			query.setParameter("startDate", startDate);
	        new StringBuilder()
	        .append('\'')
	        .append(endDate)
	        .append('\'');
	        query.setParameter("endDate", endDate);
			all_incidents = query.list();
			return all_incidents;
		} catch (HibernateException e) {
			//logger.error("Unexpected error", e);
		} finally{
		if(factory != null)
		{
		if (session.isOpen()){
			session.close();
		}if (!factory.isClosed()) {
			factory.close();
		} 
		}
	}
		return all_incidents;
	}*/

	@Override
	public List<HashMap<String, Object>> getAllIncidentsByWeekly(String accName, String applicationName,
			String startDate, String endDate, String recurrence_type, String recurrence_dayName,
			String recu_every_week) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<HashMap<String, Object>> getAllIncidentsByMonthly(String accName, String applicationName,
			String startDate, String endDate, String recurrence_type, String recu_month_day, String recu_every_month) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	@Transactional
	public List<String> getUserAccounts(String userId) {
		List<UserBean> accessControlBeanList = null;
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("CALL sp_get_user_accounts(:userId)").setResultTransformer(Transformers.aliasToBean(UserBean.class));
		query.setParameter("userId", userId);
		accessControlBeanList = query.list();
		List<String> acctList = new ArrayList<String>();
		if(accessControlBeanList != null && accessControlBeanList.size()>0){
			for(UserBean acctNameBean:accessControlBeanList){
			acctList.add(acctNameBean.getAccount_Name());
			}
			return acctList;			
		} else {
			new ArrayList<String>();
		}
		session.close();
		return null;
	}
	
	/**
	 * Insert user login.
	 *
	 * @param userID the user ID
	 * @param accountID the account ID
	 * @param errorMessage the error message
	 * @return the string
	 */
	@Override
	@Transactional
	public String insertUserLogin(String userID,String accountID,String errorMessage) {
		Session session = entityManager.unwrap( Session.class );
		Query query = session.createSQLQuery("CALL sp_insert_user_login(:userID, :accountID,:errorMessage)").setResultTransformer(Transformers.aliasToBean(UserBean.class));

		query.setParameter("userID", userID);
		query.setParameter("accountID", accountID);
		query.setParameter("errorMessage", errorMessage);

		query.executeUpdate(); 	
		session.close();
		return "";
	}


	/*@Override
	public List<User> getUserNames() {
		List<User> userList = userRepository.findAll();
		List<String> resList = new ArrayList<>();
		for(User user : userList){
			resList.add(user.getUsername());
		}
		return resList;
	}*/

	/*@Override
	public List<String> getUserNames() {
		List<User> userForNameList = userRepository.findAll();
		List<String> userNameList = new ArrayList<>();
		for(User userNames : userForNameList){
			userNameList.add(userNames.getUsername());
			
		}
		return userNameList;
	}
	*/
	
}
