package com.account.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.account.model.Account;
import com.account.model.Application;
import com.account.repository.AccountRepository;
import com.accounts.dto.AccountBean;

@Service
public class AccountServiceImpl implements AccountService{

	@Autowired
	AccountRepository accountRepository;

	@Override
	public void save(Account account) {
		accountRepository.save(account);
	}

	@Override
	public List<Account> findAll() {
		List<Account> accounts = accountRepository.findAll();
		return accounts;
	}

	@Override
	public void save(AccountBean accountBean) {
		Account account = new Account();
		account.setAccount_Name(accountBean.getAccName());
		accountRepository.save(account);
	}

	@Override
	public Account findById(Long id) {
		return accountRepository.findOne(id);
	}

	@Override
	public List<String> getAccountNames() {
		List<Account> accList = accountRepository.findAll();
		List<String> accNameList = new ArrayList<>();
		for(Account acc :accList){
			accNameList.add(acc.getAccount_Name());
		}
		return accNameList;
	}
}
