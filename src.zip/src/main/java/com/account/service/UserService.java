package com.account.service;

import java.util.HashMap;
import java.util.List;

import com.account.model.EventUser;
import com.account.model.Role;
import com.account.model.User;
import com.accounts.dto.UserBean;

public interface UserService {
    void save(User user);

    User findByUsername(EventUser eventUser);
    public List<User> findAll();
    public List<UserBean> findAllUserBean();
    User findById(Long id);
    /*User findByResourcename(String Resource_Name);*/
    public List<String> getResourceNames();
    User findByPrimaryResoureName(String primary);
    User findBySecondryResoureName(String secondry);
    User findByUserNameForPrimary(String username);
    User findByUserNameForSecondry(String username);
   // public List<String> getUserNames();
    public List<User> getUserNames();
    /*public List<String> getUserNames();*/

	User findByUsername(String username);

	public List<String> getRoleName();

	List<String> getUserAccountList();

	void save(UserBean userForm);

	User findByResourcename(String resourcename);

	List<String> findAccountsByUserID(Long userID);

	List<HashMap<String, Object>> getAllIncidents(String accountName, String applicationName, String startDate, String endDate);
	
	List<HashMap<String, Object>> getAllIncidentsUpdating(String accountName, String applicationName, String startDate, String endDate);

	List<HashMap<String, String>> getAllIncidentsByDaily(String accName, String applicationName, String startDate,
			String endDate, String recurrence_type, String recu_every_day);

	List<HashMap<String, Object>> getAllIncidentsByWeekly(String accName, String applicationName, String startDate,
			String endDate, String recurrence_type, String recurrence_dayName, String recu_every_week);

	List<HashMap<String, Object>> getAllIncidentsByMonthly(String accName, String applicationName, String startDate,
			String endDate, String recurrence_type, String recu_month_day, String recu_every_month);

	List<String> getUserAccounts(String userId);

	String insertUserLogin(String userID, String accountID, String errorMessage);

	//public List<String> getRoleName();

//	List<User> getUserNames1();
    

	
}
