package com.account.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import net.fortuna.ical4j.data.CalendarOutputter;
import net.fortuna.ical4j.model.Dur;
import net.fortuna.ical4j.model.Property;
import net.fortuna.ical4j.model.ValidationException;
import net.fortuna.ical4j.model.component.VEvent;
import net.fortuna.ical4j.model.property.CalScale;
import net.fortuna.ical4j.model.property.Description;
import net.fortuna.ical4j.model.property.Location;
import net.fortuna.ical4j.model.property.Organizer;
import net.fortuna.ical4j.model.property.ProdId;
import net.fortuna.ical4j.model.property.Version;

public class CalendarService {

	
	
	public void createCalendar(String startDate, String endDate, String meetingSubjet, String Desc,String Engage,String Risk) {

		// Initilize values
	/*	String calFile = "src//main//resources//TestCalendar.ics";*/

		
		ClassLoader classLoader = this.getClass().getClassLoader();  
		   // Getting resource(File) from class loader  
		   File configFile=new File(classLoader.getResource("EventInviteFromCBE.ics").getFile());
		
		   
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy-mm-dd hh:mm", Locale.ENGLISH);
		try {
			Calendar myCal = new GregorianCalendar();
			startDate = startDate.replace("T", " ");
			Date theDate = format.parse(startDate);
			myCal.setTime(theDate);
			// start time
			java.util.Calendar startCal = java.util.Calendar.getInstance();
			startCal.set(myCal.get(Calendar.YEAR), myCal.get(Calendar.MONTH)+1, myCal.get(Calendar.DAY_OF_MONTH),
					myCal.get(Calendar.HOUR), myCal.get(Calendar.MINUTE));

			// end time
			endDate = endDate.replace("T", " ");
			theDate = format.parse(endDate);
			myCal.setTime(theDate);
			java.util.Calendar endCal = java.util.Calendar.getInstance();
			endCal.set(myCal.get(Calendar.YEAR), myCal.get(Calendar.MONTH)+1, myCal.get(Calendar.DAY_OF_MONTH),
					myCal.get(Calendar.HOUR), myCal.get(Calendar.MINUTE));

		//	String subject = "Meeting Subject";
			String location = "Location - Bangalore";
			//String description = "This goes in decription section of the metting like agenda etc.";

			//String hostEmail = "jaiprakash.mishra@gmail.com";

			String hostEmail = "natools_devteam.in@capgemini.com";
			// Creating a new calendar
			net.fortuna.ical4j.model.Calendar calendar = new net.fortuna.ical4j.model.Calendar();
			calendar.getProperties().add(new ProdId("-//Ben Fortuna//iCal4j 1.0//EN"));
			calendar.getProperties().add(Version.VERSION_2_0);
			calendar.getProperties().add(CalScale.GREGORIAN);

			SimpleDateFormat sdFormat = new SimpleDateFormat("yyyyMMdd'T'hhmmss'Z'");

			// sdFormat.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			// sdFormat.setTimeZone(TimeZone.getTimeZone("America/Los_Angeles"));

			String strDate = sdFormat.format(startCal.getTime());

			net.fortuna.ical4j.model.Date startDt = null;
			try {
				startDt = new net.fortuna.ical4j.model.Date(strDate, "yyyyMMdd'T'hhmmss'Z'");
			} catch (ParseException e) {
				e.printStackTrace();
			}

			long diff = endCal.getTimeInMillis() - startCal.getTimeInMillis();
			int min = (int) (diff / (1000 * 60));

			Dur dur = new Dur(0, 0, min, 0);

			// Creating a meeting event
			VEvent meeting = new VEvent(startDt, dur, meetingSubjet);
              System.out.println(startDt.getTime());
			meeting.getProperties().add(new Location(location));
			meeting.getProperties().add(new Description());

			try {
				meeting.getProperties().getProperty(Property.DESCRIPTION).setValue(meetingSubjet);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (URISyntaxException e) {
				e.printStackTrace();
			} catch (ParseException e) {
				e.printStackTrace();
			}

			try {
				meeting.getProperties().getProperty(Property.DESCRIPTION).setValue(Desc);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (URISyntaxException e) {
				e.printStackTrace();
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			
			/*try {
				meeting.getProperties().getProperty(Property.DESCRIPTION).setValue(Engage);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (URISyntaxException e) {
				e.printStackTrace();
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			try {
				meeting.getProperties().getProperty(Property.DESCRIPTION).setValue(Risk);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (URISyntaxException e) {
				e.printStackTrace();
			} catch (ParseException e) {
				e.printStackTrace();
			}*/
			
			
			
			try {
				meeting.getProperties().add(new Organizer("MAILTO:" + hostEmail));
			} catch (URISyntaxException e) {
				e.printStackTrace();
			}

			calendar.getComponents().add(meeting);

			FileOutputStream fout = null;

			try {
				fout = new FileOutputStream(configFile);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}

			CalendarOutputter outputter = new CalendarOutputter();
			outputter.setValidating(false);

			try {
				outputter.output(calendar, fout);

			} catch (IOException e) {
				e.printStackTrace();
			} catch (ValidationException e) {
				e.printStackTrace();
			}
			System.out.println(meeting);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void createUploadCalendar(String startDate, String endDate, String meetingSubjet, String Desc,String Engage,String Risk) {

		// Initilize values
	/*	String calFile = "src//main//resources//TestCalendar.ics";*/

		
		ClassLoader classLoader = this.getClass().getClassLoader();  
		   // Getting resource(File) from class loader  
		   File configFile=new File(classLoader.getResource("EventInviteFromCBE.ics").getFile());
		
		   
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy-mm-dd hh:mm", Locale.ENGLISH);
		try {
			Calendar myCal = new GregorianCalendar();
			//startDate = startDate.replace("T", " ");
			Date theDate = null;
			if(startDate != null && startDate != ""){
				theDate = format.parse(startDate);
				myCal.setTime(theDate);
			}
			// start time
			java.util.Calendar startCal = java.util.Calendar.getInstance();
			startCal.set(myCal.get(Calendar.YEAR), myCal.get(Calendar.MONTH)+1, myCal.get(Calendar.DAY_OF_MONTH),
					myCal.get(Calendar.HOUR), myCal.get(Calendar.MINUTE));

			// end time
		//	endDate = endDate.replace("T", " ");
			if(endDate != null && endDate != ""){
				theDate = format.parse(endDate);
				myCal.setTime(theDate);
			}
			java.util.Calendar endCal = java.util.Calendar.getInstance();
			endCal.set(myCal.get(Calendar.YEAR), myCal.get(Calendar.MONTH)+1, myCal.get(Calendar.DAY_OF_MONTH),
					myCal.get(Calendar.HOUR), myCal.get(Calendar.MINUTE));

		//	String subject = "Meeting Subject";
			String location = "Location - Bangalore";
			//String description = "This goes in decription section of the metting like agenda etc.";

			//String hostEmail = "jaiprakash.mishra@gmail.com";

			String hostEmail = "natools_devteam.in@capgemini.com";
			// Creating a new calendar
			net.fortuna.ical4j.model.Calendar calendar = new net.fortuna.ical4j.model.Calendar();
			calendar.getProperties().add(new ProdId("-//Ben Fortuna//iCal4j 1.0//EN"));
			calendar.getProperties().add(Version.VERSION_2_0);
			calendar.getProperties().add(CalScale.GREGORIAN);

			SimpleDateFormat sdFormat = new SimpleDateFormat("yyyyMMdd'T'hhmmss'Z'");

			// sdFormat.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			// sdFormat.setTimeZone(TimeZone.getTimeZone("America/Los_Angeles"));

			String strDate = sdFormat.format(startCal.getTime());

			net.fortuna.ical4j.model.Date startDt = null;
			try {
				startDt = new net.fortuna.ical4j.model.Date(strDate, "yyyyMMdd'T'hhmmss'Z'");
			} catch (ParseException e) {
				e.printStackTrace();
			}

			long diff = endCal.getTimeInMillis() - startCal.getTimeInMillis();
			int min = (int) (diff / (1000 * 60));

			Dur dur = new Dur(0, 0, min, 0);

			// Creating a meeting event
			VEvent meeting = new VEvent(startDt, dur, meetingSubjet);
              System.out.println(startDt.getTime());
			meeting.getProperties().add(new Location(location));
			meeting.getProperties().add(new Description());

			try {
				meeting.getProperties().getProperty(Property.DESCRIPTION).setValue(meetingSubjet);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (URISyntaxException e) {
				e.printStackTrace();
			} catch (ParseException e) {
				e.printStackTrace();
			}

			try {
				meeting.getProperties().getProperty(Property.DESCRIPTION).setValue(Desc);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (URISyntaxException e) {
				e.printStackTrace();
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			
			/*try {
				meeting.getProperties().getProperty(Property.DESCRIPTION).setValue(Engage);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (URISyntaxException e) {
				e.printStackTrace();
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			try {
				meeting.getProperties().getProperty(Property.DESCRIPTION).setValue(Risk);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (URISyntaxException e) {
				e.printStackTrace();
			} catch (ParseException e) {
				e.printStackTrace();
			}*/
			
			
			
			try {
				meeting.getProperties().add(new Organizer("MAILTO:" + hostEmail));
			} catch (URISyntaxException e) {
				e.printStackTrace();
			}

			calendar.getComponents().add(meeting);

			FileOutputStream fout = null;

			try {
				fout = new FileOutputStream(configFile);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}

			CalendarOutputter outputter = new CalendarOutputter();
			outputter.setValidating(false);

//			try {
//				outputter.output(calendar, fout);
//
//			} catch (IOException e) {
//				e.printStackTrace();
//			} catch (ValidationException e) {
//				e.printStackTrace();
//			}
			System.out.println(meeting);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
/*	public static void main(String[] args) {
		String path = getRootPath();
		System.out.println("Path =:= " + path);
	}
*/
	public static String getRootPath() {
		String path = null;
		try {
			path = new File(".").getCanonicalPath();

		} catch (IOException e) {
			e.printStackTrace();
		}
		return path;
	}
}
