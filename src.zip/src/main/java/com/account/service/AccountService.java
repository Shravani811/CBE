package com.account.service;

import java.util.List;

import com.account.model.Account;
import com.accounts.dto.AccountBean;

public interface AccountService {

public void save(Account account);
public void save(AccountBean accountBean);
public List<Account> findAll();
public Account findById(Long id);
public List<String> getAccountNames();
}
