package com.account.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.account.model.Application;
import com.account.model.Category;
import com.account.model.EventEntryMaster;
import com.account.model.User;
import com.account.repository.ApplicationRepository;
import com.account.repository.UserRepository;
import com.accounts.dto.ApplicationBean;

@Service
public class ApplicationServiceImpl implements ApplicationService{

	@Autowired
	ApplicationRepository applicationRepository;
	
	@Autowired
    private UserService userService;
	
	@Autowired
    private UserRepository userRepository;
	
	
	@Transactional
	@Override
	public void save(ApplicationBean applicationBean) {
		Application application=new Application();
		
		
		application.setApp_Name(applicationBean.getAppName());
		/*application.setPrimary_resource(applicationBean.getPrimaryResource());
		application.setSecondary_resource(applicationBean.getSecondaryResource());*/
       /*Category category=categoryService.findByEventCategoryName(eventEntry.getEvent_category_Name());
		
		if(category!=null){
			entry.setEvent_category_id(category.getEvent_cat_id());
			
		}*/
		
		User userPrimary=userService.findByPrimaryResoureName(applicationBean.getPrimaryResource());
		if(userPrimary!=null){
			application.setPrimary_resource(userPrimary.getResourcename());
		}
		User userSecondry=userService.findByPrimaryResoureName(applicationBean.getSecondaryResource());
		if(userSecondry!=null){
			application.setSecondary_resource(userSecondry.getResourcename());
		}
		
		application.setStatus(applicationBean.isStatus());
		application.setTower(applicationBean.getTower());
		application.setCC_name(applicationBean.getCcname());
		application.setCluster(applicationBean.getCluster());
		application.setLast_Modified_by(applicationBean.getLastModified_by());
		application.setLast_Modified_date(applicationBean.getLastModified_date());
		//application.setPrimary_resource(application.getPrimary_resource());
		//application.setSecondary_resource(application.getSecondary_resource());
		
		applicationRepository.save(application);
	}


	
	@Override
	public List<String> getAppNames() {
		
		List<Application> appList = applicationRepository.findAll();
		List<String> appNameList = new ArrayList<>();
		for(Application app :appList){
			if(app.isStatus()){
			appNameList.add(app.getApp_Name());
		}
		}
		return appNameList;
	}



	@Override
	public List<Application> findAll() {
	
		return applicationRepository.findAll();
	}



	@Override
	public Application findById(Long id) {
		
		return applicationRepository.findOne(id);
	}



	



	@Override
	public void save(Long id) {
		
		/*applicationRepository.save(entity);*/
	}



	@Override
	public void save(Application application) {
		
		application.setApp_ID(application.getApp_ID());   
		
		applicationRepository.save(application);
	}



	@Override
	public Application findByApplicationName(String[] appName) {
		
		Application application=new Application();
		
		List<Application> appList =applicationRepository.findAll();
		
		for(Application app: appList){
			for(int i=0;i<appName.length ;i++){
				
			
			if(appName[i].equalsIgnoreCase(app.getApp_Name())){
				return app;
			}
		}
		}
		return application;
	}



	@Override
	public Application findByAppName(String aapName) {
		
		Application application=new Application();
		List<Application> appList = applicationRepository.findAll();
		for(Application app : appList){
			if(aapName.equals(app.getApp_Name())){
				return app;
			}
		}
		return null;
		
	}



	@Override
	public List<HashMap<String, String>> getPriAndSecResourceName() {
		
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
		
		Query query = session.createSQLQuery("CALL sp_get_resources()");
		//query.setParameter("region", region);
		query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
		
		/*String sql = "select r.region,ag.year,ag.month, sum(ag.target_goal) as target from auto_tracker.tbl_region r, "
				+ "auto_tracker.tbl_account_goals ag where r.region='NA' group by ag.month order by year desc;";
		SQLQuery query = session.createSQLQuery(sql);*/
		List<HashMap<String, String>> regStrList = query.list();
		
		return regStrList;
	}
	
	@Override
	public List<HashMap<String, String>> getPriAndSecResourceEmailIds() {
		
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
		
		Query query = session.createSQLQuery("CALL sp_get_resources_EmailIds()");
		//query.setParameter("region", region);
		query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
		
		/*String sql = "select r.region,ag.year,ag.month, sum(ag.target_goal) as target from auto_tracker.tbl_region r, "
				+ "auto_tracker.tbl_account_goals ag where r.region='NA' group by ag.month order by year desc;";
		SQLQuery query = session.createSQLQuery(sql);*/
		List<HashMap<String, String>> regStrList = query.list();
		
		return regStrList;
	}

/*	@Override
	public User findByPrimaryResoureName(String primary) {
		User user=new User();
		List<User> userList=userRepository.findAll();
		for(User user1:userList){
			if(primary.equalsIgnoreCase(user1.getResourcename())){
				return user1;
			}
		}
		return user;*/

	/*@Override
	public List<Application> findByApp_NameAsc(String app_Name) {
		
		return applicationRepository.findByApp_NameAsc(app_Name);
	}*/

}
