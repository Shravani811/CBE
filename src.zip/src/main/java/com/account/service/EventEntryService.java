package com.account.service;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import com.account.model.EventActual;
import com.account.model.EventEntry;
import com.account.model.EventPlanned;
import com.account.model.IncidentBean;
import com.accounts.dto.EventEntryBean;

public interface EventEntryService {

	public void save(EventEntryBean eventEntry);
	public void editSave(EventEntryBean eventEntry);
	public List<EventEntry> findAll();
	public EventEntry findById(Long id);
	public void saveOther(EventEntryBean eventEntry);
	public List<String> getEventName();
	public EventEntry findByEventName(String eventName);
	List<EventEntry> findAll(String calType);
	public List<EventEntry> findAllEventByResource(String id);
	public void deleteEventAppBeforeEditSaveApps(Long id);
	public void deleteEventUserBeforeEditSaveUsers(Long id);
	//public List<IncidentBean> getAllIncidents();
	public void saveIncidents(IncidentBean incidentBean);
	public void deleteCanceledEvent(Long Event_ID);
	public void saveCancelledEntry(EventEntry eventEntry);
	void savePlanned(EventPlanned eventPlanned);
	List<EventPlanned> getAllPlanned(Long eventId);
	public List<EventPlanned> highestVersion(String event_Name);
	public String getCategoryName(Long CategoryId);
	public String getRegionName(Long region_id);
	public String getApplicationName(Long event_id);
	public String getResourceName(Long event_id);
	public String getCalendarType(Long event_calendar_id);
	public void saveUpdateOther(EventEntryBean eventEntry);
	/*String getActualEndTime(Long plannedSeqId);
	String getActualStartTime(Long plannedSeqId);*/
	EventActual getActuals(Long plannedSeqId, Date dateSel);
	String getActualEndTime(Long plannedSeqId);
	public int getAllId(Long event_id);
	public List<EventActual> getActual(Long event_id, String eventDate);
	public List<Long> getActualEvent(String eventID, String startDate);
	EventActual getActualsWithoutDate(Long plannedSeqId, Date date1);
	public List<EventActual> getActualEvent(String eventID, String startDate, List<Integer> daynew) throws ParseException;
	public Boolean getPlannedSeqID(Long long1, String eventDate);
	public List<EventActual> getActualData(List<Long> plannedSeqIdList, String eventDate, List<Integer> newdayList) throws Exception;
}
