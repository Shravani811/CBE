package com.account.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.account.model.CalendarType;
import com.account.model.Category;
import com.account.model.EventApplication;
import com.account.model.EventEntry;
import com.account.model.EventEntryMaster;
import com.account.model.EventPlanned;
import com.account.model.EventActual;
import com.account.model.EventUser;
import com.account.model.Incident;
import com.account.model.IncidentBean;
import com.account.model.Region;
import com.account.model.User;
import com.account.repository.ApplicationRepository;
import com.account.repository.CalendarTypeRepository;
import com.account.repository.EventApplicationRepository;
import com.account.repository.EventEntryRepository;
import com.account.repository.CategoryRepository;
import com.account.repository.EventActualRepository;
import com.account.repository.EventPlannedRepository;
import com.account.repository.EventUserMasterRepository;
import com.account.repository.EventUserRepository;
import com.account.repository.IncidentRepository;
import com.account.repository.RegionRepository;
import com.account.repository.UserAccountRepository;
import com.account.repository.UserRepository;
import com.accounts.dto.EventEntryBean;
import com.mysql.jdbc.StringUtils;

/*
 * jaimishr
 * 
 */
@Service
public  class EventEntryServiceImpl implements EventEntryService {

	@Autowired
	IncidentRepository incidentRepository;

	@Autowired
	EventEntryRepository eventEntryRepository;
	
	@Autowired
	EventEntryMasterService eventEntryMasterService;
	
	@Autowired
	EventPlannedRepository eventPlannedRepository;
	
	@Autowired
	EventUserMasterRepository eventUserMasterRepository; 

	@Autowired
	EventApplicationRepository eventAppMasterRepository; 
	
	@Autowired
	UserAccountRepository userAccountRepository;
	
	@Autowired
	UserRepository userRepository;

	@Autowired
	CategoryRepository categoryRepository;
	
	@Autowired
	ApplicationRepository applicationRepository;
	
	@Autowired
	RegionRepository regionRepository;
	
	@Autowired
	EventActualRepository eventActualRepository;
	
	@Autowired
	EventApplicationRepository eventapplicationRepository;
	
	@Autowired
	UserService userService;
	
	@Autowired
	CategoryService categoryService;
	
	@Autowired
	RegionService regionService;
	
	@Autowired
	CalendarTypeRepository calendarTypeRepository;
	
	@Autowired
	EventUserRepository eventUserRepository;
	
	@Autowired
	CalendarTypeService calendarTypeService;
	
	@Autowired
	EventActualRepository eventActualReporsitory;
	
	@Override
	@Transactional
	public void save(EventEntryBean eventEntry) {
		/*
		 * Page<EventEntry> page = eventEntryRepository.findAll(new
		 * PageRequest(0, 1, Direction.ASC, "Event_ID")); EventEntry entry2 =
		 * page.getContent().get(0); long maxEvent_Id = entry2.getEvent_ID();
		 */
		
		long maxEvent_Id = 0;
		EventEntry entry = new EventEntry();
		entry.setEventname(eventEntry.getEventName());
		entry.setEngagement_Name(eventEntry.getEngagement_Name());
		entry.setRisk_summary(eventEntry.getRisk_summary());
		//entry.setRegion_territory(eventEntry.getRegion_territory());
		entry.setDescription_details(eventEntry.getDescription_details());
		entry.setAdditional_receipients(eventEntry.getEmail_receipients());
		
		
		/*if(eventName.contains(",")){
			
        String st[]=eventName.split(",");
        
      //  String newEvName=st[0];
		
		//entry.setEventname(newEvName);
		}
		
		else{
			entry.setEventname(eventName);
		}*/
		
		
        String remarks=eventEntry.getRemarks();
 		
		
		String startDate=eventEntry.getStart_date();
		String startTime=eventEntry.getStart_time();
 		
		if(startDate.startsWith(",")){
 			String startDate1=startDate.substring(1);
 			entry.setStart_date(startDate1+" "+startTime);
 		}else{
 			entry.setStart_date(startDate+" "+startTime);
 		}
		
 		String endDate=eventEntry.getEnd_date();
 		String endTime=eventEntry.getEnd_time();
 		if(endDate.startsWith(",")){
 			String end=endDate.substring(1);
 			entry.setEnd_date(end+" "+endTime);
 		}
 		else{
 			entry.setEnd_date(endDate+" "+endTime);
 		}
 		
      /*  String email=eventEntry.getEmail_receipients();
 		
        if(email.startsWith(",")){
 			String email1=email.substring(1);
 			entry.setAdditional_receipients(email1);
 		}/*else if(!email.startsWith(",") && email.contains(",")){
 			
 			String st[]=email.split(",");
 	        
 	        String email1=st[0];
 	        
 	       entry.setAdditional_receipients(email1);
 		}*/
        
        
      //  else{
 		//	entry.setAdditional_receipients(email);
 		//}
 		entry.setRemarks(eventEntry.getRemarks());
		
		entry.setStart_date(eventEntry.getStart_date()+" "+eventEntry.getStart_time());
		
		
		entry.setEnd_date(eventEntry.getEnd_date()+" "+eventEntry.getEnd_time());
		entry.setAccountName(eventEntry.getAccount_name());
		
		entry.setEngagement_Name(eventEntry.getEngagement_Name());
		/*entry.setLast_Modified_Date(eventEntry.getStart_date());*/
		entry.setLast_Modified_by(eventEntry.getEventName());
		/*entry.setCreated_Date(eventEntry.getStart_date());*/
		entry.setCreated_By(eventEntry.getEventName());
		entry.setRisk_summary(eventEntry.getRisk_summary());
		//entry.setRegion_territory(eventEntry.getRegion_territory());
		/*char[] ch=eventEntry.getEvent_category_Name().toCharArray();
		entry.setEvent_category_id(String.valueOf(ch));*/
		
		
	/*	String evCatName=eventEntry.getEvent_category_Name();
		
		if(evCatName.startsWith(",")){
			String eveCat1 = evCatName.substring(1);
		Category category=categoryService.findByEventCategoryName(eveCat1);
		
		if(category!=null){
			entry.setEvent_category_id(category.getEvent_cat_id());
			
		}
		}else{
		
        Category category=categoryService.findByEventCategoryName(evCatName);
		
		if(category!=null){
			entry.setEvent_category_id(category.getEvent_cat_id());
			
		}
		}*/
		
		
		Region region = regionService.findByRegionTerritory(eventEntry.getRegion_territory());
		
        if(region!=null)
        {
        	entry.setRegion_id(region.getRegion_id());
        }
		 
		Category category = categoryService.findByEventCategoryName(eventEntry.getEvent_category_Name());

		if (category != null) {
			entry.setEvent_category_id(category.getEvent_cat_id());

		} 
		
		//entry.setAdditional_receipients(eventEntry.getEmail_receipients());
		
		entry.setRecurrence_type(eventEntry.getRecurrence_type());
		entry.setRecu_every_day(eventEntry.getRecu_every_day());
		entry.setRecu_every_weekday(eventEntry.getRecu_every_weekday());
		entry.setRecu_every_week(eventEntry.getRecu_every_week());
	  	entry.setRecurrence_dayName(eventEntry.getRecurrence_dayName());
		entry.setRecu_every_month(eventEntry.getRecu_every_month());
      	entry.setRecu_month_day(eventEntry.getRecu_month_day());
		entry.setEventstatus("Confirmed");
		EventEntry savedEvent = eventEntryRepository.save(entry);
		if (null != savedEvent) {
			maxEvent_Id = savedEvent.getEvent_ID();
		} else {
			maxEvent_Id = 1;
		}
		
		
		List<EventApplication> eventAppList = new ArrayList<>();
		for (String appName : eventEntry.getEventAppSet()) {
			EventApplication eventApp = new EventApplication();
			eventApp.setApplication(appName);
			eventApp.setEvent_ID(maxEvent_Id);
			eventAppList.add(eventApp);
		}
		
		entry.setEventAppSet(eventAppList);

		List<EventUser> eventUserList = new ArrayList<>();
		// List<User> userList=userEntryrepository.findAll();
		
		
		for (String Resourcename : eventEntry.getEventUserSet()) {

			
			User user=userService.findByResourcename(Resourcename);

			EventUser eventUser = new EventUser();
			
			eventUser.setResource(user.getResourcename());

			eventUser.setEvent_ID(maxEvent_Id);

			eventUserList.add(eventUser);
		}
		entry.setEventUserSet(eventUserList);
		entry.setEventstatus("Confirmed");
		eventEntryRepository.save(entry);

	}
	
	@Override
	public List<EventEntry> findAll() {
		
		return eventEntryRepository.findAll();
	}
	
	@Override
	public List<EventEntry> findAll(String calType) {
		
		List<EventEntry> eventList= eventEntryRepository.findAll();
		CalendarType caltypeObj = calendarTypeService.findByCalendarTypeName(calType);
		Long calTypeId = 0L;
		if(caltypeObj != null){
			calTypeId = caltypeObj.getCalendar_type_id();
		}
		List<EventEntry> eveMaintList = new ArrayList<EventEntry>();
		if(!StringUtils.isNullOrEmpty(calType)){
			for(EventEntry eve: eventList){
				if(calTypeId == eve.getCalendar_type_id()){
					eveMaintList.add(eve);
				}
			}
		} else {
			return eventList;
		}
		return eveMaintList;
	}
	
	

	@Override
	public EventEntry findById(Long id) {
		
		return eventEntryRepository.findOne(id);
	}
	
	
	@Override
	public List<String> getEventName() {
		
			List<EventEntry> eventEntryList=eventEntryRepository.findAll();
			List<String> eventList=new ArrayList<>();
			for(EventEntry eventEntry : eventEntryList){
				eventList.add(eventEntry.getEventname());
			}
			
			return eventList;
			
		}

	@Override
	public EventEntry findByEventName(String eventName) {
		EventEntry masterEvent=new EventEntry();
		List<EventEntry> eventEntryList=eventEntryRepository.findAll();
		
		for(EventEntry eventEntry : eventEntryList){
			if(eventName != null && eventName.equalsIgnoreCase(eventEntry.getEventname())){
				return eventEntry;
			}
		}
		
		return masterEvent;
	}
	
	//Save Data for Other Data
	@Override
	public void saveOther(EventEntryBean eventEntry) {
		/*
		 * Page<EventEntry> page = eventEntryRepository.findAll(new PageRequest(0, 1,
		 * Direction.ASC, "Event_ID")); EventEntry entry2 = page.getContent().get(0);
		 * long maxEvent_Id = entry2.getEvent_ID();
		 */
		Long event_id = 0L;
		List<EventEntry> eveEntry = eventEntryRepository.findAll();
		for(EventEntry ee:eveEntry) {
			if(ee.getEventname().equalsIgnoreCase(eventEntry.getEventName())) {
				event_id = ee.getEvent_ID();
			}
		}
		long maxEvent_Id = 0;
		//EventEntry entryMaster = eventEntryService.findByEventName(eventEntry.getEventName());
		EventEntry entryMaster = eventEntryRepository.findOne(event_id);
		EventEntry entry = null;
		if (entryMaster != null) {
			entry = eventEntryRepository.findOne(entryMaster.getEvent_ID());
		} else {
			entry = new EventEntry();
		}
		String eventName = eventEntry.getEventName();

		entry.setEventname(eventName);

		entry.setDescription_details(eventEntry.getDescription_details());

		String remarks = eventEntry.getRemarks();

		if (remarks != null && remarks.startsWith(",")) {
			String remarks1 = remarks.substring(1);
			entry.setRemarks(remarks1);
		} else {
			entry.setRemarks(remarks);
		}

		String startDate = eventEntry.getStart_date();
		String startTime = eventEntry.getStart_time();

		if (startDate.startsWith(",")) {
			String startDate1 = startDate.substring(1);
			entry.setStart_date(startDate1 + " " + startTime);
		} else {
			entry.setStart_date(startDate + " " + startTime);
		}

		String endDate = eventEntry.getEnd_date();
		String endTime = eventEntry.getEnd_time();
		if (endDate.startsWith(",")) {
			String end = endDate.substring(1);
			entry.setEnd_date(end + " " + endTime);
		} else {
			entry.setEnd_date(endDate + " " + endTime);
		}

		entry.setEnd_date(endDate); // ADDED TEMPORARILY FOR TESTING BY BKM
		entry.setStart_date(startDate);// ADDED TEMPORARILY FOR TESTING BY BKM

		String email = eventEntry.getEmail_receipients();

		if (email.startsWith(",")) {
			String email1 = email.substring(1);
			entry.setAdditional_receipients(email1);
		} else {
			entry.setAdditional_receipients(email);
		}

		/*
		 * entry.setStart_date(eventEntry.getStart_date());
		 * 
		 * 
		 * entry.setEnd_date(eventEntry.getEnd_date());
		 */

		entry.setEmail_receipients1(eventEntry.getEmail_receipients1());
		entry.setEngagement_Name(eventEntry.getEngagement_Name());
		/* entry.setLast_Modified_Date(eventEntry.getStart_date()); */
		entry.setLast_Modified_by(eventEntry.getEventName());
		/* entry.setCreated_Date(eventEntry.getStart_date()); */
		entry.setCreated_By(eventEntry.getEventName());
		entry.setRisk_summary(eventEntry.getRisk_summary());
		// entry.setRegion_territory(eventEntry.getRegion_territory());
		/*
		 * char[] ch=eventEntry.getEvent_category_Name().toCharArray();
		 * entry.setEvent_category_id(String.valueOf(ch));
		 */
		entry.setRemarks(eventEntry.getRemarks());
		if (StringUtils.isNullOrEmpty(eventEntry.getRegion_id())) {
			eventEntry.setRegion_id("0L");
		}
		// entry.setRegion_id(Long.parseLong(eventEntry.getRegion_id())); //BKM
		/*
		 * String regions=eventEntry.getRegion_territory();
		 * 
		 * if(regions.startsWith(",")){ String regions1 = regions.substring(1); Region
		 * region=regionService.findByRegionTerritory(regions1);
		 * 
		 * if(region!=null){ //entry.setRegion_id(region.getRegion_id());
		 * 
		 * } else{ //Region region1=regionService.findByRegionTerritory(regions); }
		 * if(region!=null){ //entry.setRegion_id(region.getRegion_id());
		 * 
		 * } }
		 */

		String evCatName = eventEntry.getEvent_category_Name();

		if (evCatName != null && evCatName.startsWith(",")) {
			String eveCat1 = evCatName.substring(1);
			Category category = categoryService.findByEventCategoryName(eveCat1);

			if (category != null) {
				entry.setEvent_category_id(category.getEvent_cat_id());

			}
		} else {

			Category category = categoryService.findByEventCategoryName(evCatName);

			if (category != null) {
				entry.setEvent_category_id(category.getEvent_cat_id());

			}
		}
		entry.setAccountName(eventEntry.getAccount_name());
		// entry.setAdditional_receipients(eventEntry.getEmail_receipients());
		entry.setCalendar_type_id(eventEntry.getCalendar_type_id());
		entry.setEvent_file_name(eventEntry.getEvent_file_name());
		entry.setEvent_upld_fix(eventEntry.getEvent_upld_fix());

		// Satya Code added Here

		entry.setRecurrence_type(eventEntry.getRecurrence_type());
		entry.setRecu_every_day(eventEntry.getRecu_every_day());
		entry.setRecu_every_weekday(eventEntry.getRecu_every_weekday());
		entry.setRecu_every_week(eventEntry.getRecu_every_week());
		entry.setRecurrence_dayName(eventEntry.getRecurrence_dayName());
		entry.setRecu_every_month(eventEntry.getRecu_every_month());
		entry.setRecu_month_day(eventEntry.getRecu_month_day());
		entry.setMonthdd1(eventEntry.getMonthdd1());
		entry.setMonthdd2(eventEntry.getMonthdd2());
		entry.setMonthtext1(eventEntry.getMonthtext1());
		entry.setRecu_month_day_radio(eventEntry.getRecu_month_day_radio());
		entry.setEventstatus("Confirmed");
		if (!StringUtils.isNullOrEmpty(eventEntry.getRegion_id())) {
			entry.setRegion_id(Long.parseLong(eventEntry.getRegion_id()));
		}
		entry.setEvent_category_id(eventEntry.getEvent_category_id());
		entry.setCalendar_type_id(eventEntry.getCalendar_type_id());
		entry.setTime_zone(eventEntry.getTime_zone());
		
		EventEntry savedEvent = eventEntryRepository.save(entry);
		if (null != savedEvent) {
			maxEvent_Id = savedEvent.getEvent_ID();
		} else {
			maxEvent_Id = 1;
		}

		List<EventApplication> eventAppList = new ArrayList<>();
		if (eventEntry != null && eventEntry.getEventAppSet() != null) {
			for (String appName : eventEntry.getEventAppSet()) {
				EventApplication eventApp = new EventApplication();
				eventApp.setApplication(appName);
				eventApp.setEvent_ID(maxEvent_Id);
				eventAppList.add(eventApp);
			}
		}

		entry.setEventAppSet(eventAppList);

		List<EventUser> eventUserList = new ArrayList<>();
		// List<User> userList=userEntryrepository.findAll();

		if (eventEntry != null && eventEntry.getEventUserSet() != null) {
			for (String Resourcename : eventEntry.getEventUserSet()) {

				// User user=userService.findByResourcename(Resourcename);

				EventUser eventUser = new EventUser();

				// eventUser.setResource(user.getResourcename());
				eventUser.setResource(Resourcename);

				eventUser.setEvent_ID(maxEvent_Id);

				eventUserList.add(eventUser);
			}
		}
		entry.setEventUserSet(eventUserList);
		entry.setEventstatus("Confirmed");
		eventEntryRepository.save(entry);

	}
	
	@Override
	@Transactional
	public void editSave(EventEntryBean eventEntry) {
		/*
		 * Page<EventEntry> page = eventEntryRepository.findAll(new
		 * PageRequest(0, 1, Direction.ASC, "Event_ID")); EventEntry entry2 =
		 * page.getContent().get(0); long maxEvent_Id = entry2.getEvent_ID();
		 */
		//long maxEvent_Id = 0;
		EventEntry entry = new EventEntry();
		entry.setEvent_ID(eventEntry.getEvent_ID());
		entry.setEventname(eventEntry.getEventName());
		entry.setDescription_details(eventEntry.getDescription_details());
		entry.setStart_date(eventEntry.getStart_date()+" "+eventEntry.getStart_time());
		entry.setEnd_date(eventEntry.getEnd_date()+" "+eventEntry.getEnd_time());
		entry.setAdditional_receipients(eventEntry.getEmail_receipients());
		entry.setEmail_receipients1(eventEntry.getEmail_receipients1());
		entry.setEngagement_Name(eventEntry.getEngagement_Name());
		entry.setLast_Modified_Date(eventEntry.getStart_date()+" "+eventEntry.getStart_time());
		entry.setLast_Modified_by(eventEntry.getEventName());
		entry.setCreated_Date(eventEntry.getStart_date()+" "+eventEntry.getStart_time());
		entry.setCreated_By(eventEntry.getEventName());
        entry.setRemarks(eventEntry.getRemarks());
		entry.setRisk_summary(eventEntry.getRisk_summary());
		entry.setAccountName(eventEntry.getAccount_name());
		entry.setEvent_file_name(eventEntry.getEvent_file_name());
		entry.setEvent_upld_fix(eventEntry.getEvent_upld_fix());
		entry.setMonthdd1(eventEntry.getMonthdd1());
		entry.setMonthdd2(eventEntry.getMonthdd2());
		entry.setMonthtext1(eventEntry.getMonthtext1());
		entry.setRecu_month_day_radio(eventEntry.getRecu_month_day_radio());
		
		//entry.setRegion_territory(eventEntry.getRegion_territory());
		/*char[] ch=eventEntry.getEvent_category_Name().toCharArray();
		entry.setEvent_category_id(String.valueOf(ch));*/
		
		Region region = regionService.findByRegionTerritory(eventEntry.getRegion_territory());
		
        if(region!=null)
        {
        	entry.setRegion_id(region.getRegion_id());
        }
		
		Category category=categoryService.findByEventCategoryName(eventEntry.getEvent_category_Name());
		
		if(category!=null){
			entry.setEvent_category_id(category.getEvent_cat_id());
			
		}
		
		
		CalendarType calType =calendarTypeService.findByCalendarTypeName(eventEntry.getCalendar_type_name());
		
		if(calType!=null){
			entry.setCalendar_type_id(calType.getCalendar_type_id());
			
		}
		
		/*EventEntry savedEvent = eventEntryRepository.save(entry);
		if (null != savedEvent) {
			maxEvent_Id = savedEvent.getEvent_ID();
		} else {
			maxEvent_Id = 1;
		}*/
		List<EventApplication> eventAppList = new ArrayList<>();
		for (String appName : eventEntry.getEventAppSet()) {
			EventApplication eventApp = new EventApplication();
			eventApp.setEvent_ID(eventEntry.getEvent_ID());
			eventApp.setApplication(appName);
			//eventApp.setEvent_ID(maxEvent_Id);
			eventAppList.add(eventApp);
		}
		
		entry.setEventAppSet(eventAppList);

		List<EventUser> eventUserList = new ArrayList<>();
		// List<User> userList=userEntryrepository.findAll();
		
		
         for (String Resourcename : eventEntry.getEventUserSet())
         {
        	// User user=userService.findByResourcename(Resourcename);

			EventUser eventUser = new EventUser();
			
			eventUser.setResource(Resourcename);

			//eventUser.setEvent_ID(maxEvent_Id);
			 eventUser.setEvent_ID(eventEntry.getEvent_ID());

			eventUserList.add(eventUser);
		}
		entry.setEventUserSet(eventUserList);
		entry.setTime_zone(eventEntry.getTime_zone());
		
		entry.setRecurrence_type(eventEntry.getRecurrence_type());
		entry.setRecu_every_day(eventEntry.getRecu_every_day());
		entry.setRecu_every_weekday(eventEntry.getRecu_every_weekday());
		entry.setRecu_every_week(eventEntry.getRecu_every_week());
	  	entry.setRecurrence_dayName(eventEntry.getRecurrence_dayName());
		entry.setRecu_every_month(eventEntry.getRecu_every_month());
      	entry.setRecu_month_day(eventEntry.getRecu_month_day());
      	entry.setEventstatus("Confirmed");
		eventEntryRepository.save(entry);
	

}

	@Override
	public List<EventEntry> findAllEventByResource(String accountName) {
		accountName = "DAC";
		List<EventEntry> eventList = new ArrayList<>();
		List<EventEntry> eventEntryList=eventEntryRepository.findAll();
		for (EventEntry eventEntry : eventEntryList) {
			if(eventEntry.getEngagement_Name() != null && accountName != null)
			{
				if(accountName.equalsIgnoreCase(eventEntry.getEngagement_Name())){
					eventList.add(eventEntry);
				}
			}
			
		}
		return eventList;
	}
	
	@Override
	public Boolean getPlannedSeqID(Long plannedSeqId,String eventDate) {
		List<EventActual> evententryActualList = eventActualReporsitory.findAll();
		List<EventActual> eventActualList = new ArrayList<>();
		Boolean flag = false;
		for(EventActual ee: evententryActualList){
			if(ee.getPlanned_Seq_ID().equals(plannedSeqId)) {
				eventActualList.add(ee);
			}
		}
		for(EventActual ee: eventActualList){
			if(eventDate != null && ee.getActual_Start_Date().equalsIgnoreCase(eventDate)) {
				flag = true;
			}
			
		}
		return flag;
	}
	
	@Override
	public List<EventActual> getActualData(List<Long> plannedSeqIdList,String startDate, List<Integer> numDay) throws Exception{
		List<EventActual> evententryActualList = eventActualReporsitory.findAll();
		List<EventActual> eventActualList = new ArrayList<>();
		HashMap<Integer, String> hMap = new HashMap<Integer, String>();
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		
		int size = numDay.size();
		int maxnumDay = numDay.get(size-1);
		
		int i1 = 1;
		for (int k = 0; k < maxnumDay; k++) {
			hMap.put(i1, startDate);
			i1++;
			Calendar c = Calendar.getInstance();
			c.setTime(sdf.parse(startDate));
			c.add(Calendar.DATE, 1); // number of days to add
			startDate = sdf.format(c.getTime());
		}
		
		List<String> list = new ArrayList<String>(hMap.values());
		
		
		for(EventActual ee: evententryActualList){
			if(plannedSeqIdList.contains(ee.getPlanned_Seq_ID()) && list.contains(ee.getActual_Start_Date())) {
				eventActualList.add(ee);
			}
		}
		return eventActualList;
		
	}

	@Override
	@Transactional
	public void deleteEventUserBeforeEditSaveUsers(Long Event_ID) 
	{
			SessionFactory factory = new Configuration().configure().buildSessionFactory();
			Session session = factory.openSession();
			 session.getTransaction().begin();
			SQLQuery query = session.createSQLQuery("CALL deleteUsers(:Event_ID)");
			query.setParameter("Event_ID", Event_ID);
			int result=query.executeUpdate();
			session.getTransaction().commit();
			System.out.println("Completed");
	        session.clear();
	        session.close();
	}
	/*@Override
	@Transactional
	public List<IncidentBean> getAllIncidents() 
	{
		SessionFactory factory = new Configuration().configure("hibernate.cfg2.xml").buildSessionFactory();
		Session session = factory.openSession();
		session.getTransaction().begin();
		
		List employees = session.createQuery("FROM ikon_dev_test.all_incidents").list(); 
        for (Iterator iterator1 = employees.iterator(); iterator1.hasNext();)
        {
        	IncidentBean incidentBean = (IncidentBean) iterator1.next(); 
        	System.out.println(incidentBean.getIncident_ID());
        }
		
		session.getTransaction().commit();
	    session.clear();
	    session.close();
	    List<IncidentBean> incidentList = new ArrayList<>();
		return incidentList;
	}*/
	
	@Override
	@Transactional
	public void deleteEventAppBeforeEditSaveApps(Long Event_ID) 
	{
			SessionFactory factory = new Configuration().configure().buildSessionFactory();
			Session session = factory.openSession();
			 session.getTransaction().begin();
			SQLQuery query = session.createSQLQuery("CALL deleteApps(:Event_ID)");
			query.setParameter("Event_ID", Event_ID);
			int result=query.executeUpdate();
			session.getTransaction().commit();
			System.out.println("Completed");
	        session.clear();
	        session.close();
	}

	@Override
	public void saveIncidents(IncidentBean incidentBean) {
		Incident incident = new Incident();
		incident.setIncident_ID(incidentBean.getIncident_ID());
		incident.setStart_Date(incidentBean.getStartDate()+" "+incidentBean.getStartTime());
		incident.setEnd_Date(incidentBean.getEndDate()+" "+incidentBean.getEndTime());
		incident.setReported_Date(incidentBean.getReported_Date());
		/*incident.setSummary(incidentBean.getSummary());
		incident.setNotes(incidentBean.getNotes());*/
		incident.setCauseCodeId(incidentBean.getCausecode_id());
		incident.setApplication_name(incidentBean.getApp_Name());
		incidentRepository.save(incident);
	}	
	

	@Override
	@Transactional
	public void deleteCanceledEvent(Long Event_ID) 
	{
			SessionFactory factory = new Configuration().configure().buildSessionFactory();
			Session session = factory.openSession();
			 session.getTransaction().begin();
			SQLQuery query = session.createSQLQuery("CALL deleteCancelledEvent(:Event_ID)");
			query.setParameter("Event_ID", Event_ID);
			int result=query.executeUpdate();
			session.getTransaction().commit();
			System.out.println("Completed");
	        session.clear();
	        session.close();
	}

	@Override
	public void saveCancelledEntry(EventEntry entry) {
		entry.setEventstatus("Cancelled");
		eventEntryRepository.save(entry);
	}
	
	@Override
	  public void savePlanned(EventPlanned eventPlanned)
	  {
	    eventPlannedRepository.save(eventPlanned);

	  }
	
	/*@Override
	  public List<EventPlanned> getAllPlanned(Long eventId)
	  {
		List<EventPlanned> lep = eventPlannedRepository.findAll();
		List<EventPlanned> lepout = new ArrayList<EventPlanned>();
		for(EventPlanned ep: lep){
			if(eventId != null && ep.getEvent_ID().equalsIgnoreCase(String.valueOf(eventId))){
				lepout.add(ep);
			}
		}
	    return lepout;

	  }*/
	
	@Override
	  public List<EventPlanned> getAllPlanned(Long eventId)
	  {

		int highestVersion = 0;
		List<EventPlanned> lep = eventPlannedRepository.findAll();
		List<EventPlanned> lepout = new ArrayList<EventPlanned>();
		List<EventPlanned> eveSize = new ArrayList<EventPlanned>();
		for (EventPlanned ep : lep) {
			if (eventId != null && ep.getEvent_ID().equalsIgnoreCase(String.valueOf(eventId))) {
				eveSize.add(ep);
			}
		}
		
		//code to get highest version
		
		List<Integer> versionList = new ArrayList<Integer>();
		
		int count = 1;
		int incCPCnt = 1;
		boolean eventCricPathFlag = false;
		int loopCnt = 0;
		boolean loopBreakFlag = false;
		
		for (EventPlanned ep : lep) {
			if (Long.parseLong(ep.getEvent_ID()) == eventId) {
				versionList.add(ep.getVersion());
			}
			if(!loopBreakFlag && Long.parseLong(ep.getEvent_ID()) == eventId) {
				count = loopCnt;
				loopBreakFlag = true;
			}
			loopCnt++;
		}

		Collections.sort(versionList);
		int size = versionList.size();
		if(size >= 1) {
		highestVersion = versionList.get(size - 1);

		
		//code to get highest version ends here
		
		for (EventPlanned ep : lep) {
			//if(ep.getEvent_ID().equalsIgnoreCase("64")) {
			if (eventId != null && ep.getEvent_ID().equalsIgnoreCase(String.valueOf(eventId)) && ep.getVersion() == highestVersion) {
				if (!eventCricPathFlag && ep.getCritical_Path().equalsIgnoreCase("")) {
					eventCricPathFlag = true;
				}
				if (!eventCricPathFlag) {
					if (lep.size() == count+1 ||((lep.size() > count+1 && lep.get(count+1) != null
							&& !StringUtils.isNullOrEmpty(lep.get(count+1).getCritical_Path())
							&& lep.get(count+1).getCritical_Path().split("_").length > 1
							&& (Integer.parseInt(lep.get(count+1).getCritical_Path().split("_")[1]) != incCPCnt
									|| !lep.get(count+1).getEvent_ID().equalsIgnoreCase(String.valueOf(eventId)))))) {
						// ep.setCritical_Path("");
						incCPCnt++;
					} else {
						if (eveSize != null && eveSize.size() != count) {
							ep.setCritical_Path("");
						}
					}
					count++;
				}
				lepout.add(ep);
			}
		//}
		}
		}
		return lepout;
	  }
	
	@Override
	  public EventActual getActuals(Long plannedSeqId, Date dateSel)
	  {
		List<EventActual> lep = eventActualReporsitory.findAll();
		String lepout = "";
		String actualDt = "";
		for(EventActual ep: lep){
			actualDt = new SimpleDateFormat("dd-MM-yyyy").format(dateSel);
			if(plannedSeqId != null && ep.getPlanned_Seq_ID() != null && 
					String.valueOf(ep.getPlanned_Seq_ID()).equalsIgnoreCase(String.valueOf(plannedSeqId)) && 
					(ep.getActual_Start_Date() != null && ep.getActual_Start_Date().equalsIgnoreCase(actualDt))){
				return ep;
			}
		}
	    return new EventActual();

	  }
	
	@Override
	  public EventActual getActualsWithoutDate(Long plannedSeqId, Date date1)
	  {
		
		EventActual eal = null;
		
		List<EventPlanned> lep = eventPlannedRepository.findAll();
		for(EventPlanned ep: lep){
			if(plannedSeqId != null && ep.getPlanned_Seq_ID() != null && 
					String.valueOf(ep.getPlanned_Seq_ID()).equalsIgnoreCase(String.valueOf(plannedSeqId))){
				eal = new EventActual();
				if(ep.getEvent_ID() != null){
					eal.setEvent_ID(Integer.parseInt(ep.getEvent_ID()));
				}
				eal.setPlanned_Seq_ID(ep.getPlanned_Seq_ID());
				eal.setEvent_Frequency_ID(1);
				eal.setPlanned_Start_Date(new SimpleDateFormat("dd-MM-yyyy").format(date1));
				eal.setPlanned_End_Date(new SimpleDateFormat("dd-MM-yyyy").format(date1));
				eal.setActual_Start_Date(new SimpleDateFormat("dd-MM-yyyy").format(date1));
				eal.setActual_End_Date(new SimpleDateFormat("dd-MM-yyyy").format(date1));
				eal.setActual_Seq_ID(null);
				eal.setJob_Name(ep.getJob_Name());
				return eal;
			}
		}
	    return new EventActual();

	  }
	
	@Override
	  public List<Long> getActualEvent(String eventID, String startDate)
	  {
		List<EventActual> lep = eventActualReporsitory.findAll();
		List<Long> eventActualSeqIDList = new ArrayList<Long>();
		for(EventActual ep: lep){
			if(eventID != null && String.valueOf(ep.getEvent_ID()) != null &&
				String.valueOf(ep.getEvent_ID()).equalsIgnoreCase(eventID) && 
				(ep.getActual_Start_Date() != null && ep.getActual_Start_Date().equalsIgnoreCase(startDate))){
				eventActualSeqIDList.add(ep.getActual_Seq_ID());
				System.out.println(eventActualSeqIDList+"eventActualSeqIDList=================================");
			}
			
		}
		 return eventActualSeqIDList;
	  }
	
	/*@Override
	  public String getActualStartTime(Long plannedSeqId)
	  {
		List<EventActual> lep = eventActualReporsitory.findAll();
		String lepout = "";
		for(EventActual ep: lep){
			if(plannedSeqId != null && ep.getPlanned_Seq_ID() != null && 
					String.valueOf(ep.getPlanned_Seq_ID()).equalsIgnoreCase(String.valueOf(plannedSeqId))){
				lepout = ep.getActual_Start_Time();
			}
		}
	    return lepout;

	  }*/
	
	@Override
	  public String getCategoryName(Long CategoryId)
	  {
		String category_name ="";
		List<Category> categoryList = categoryRepository.findAll();
		for(Category cl: categoryList){
			if(CategoryId != 0 && (cl.getEvent_cat_id() == CategoryId)){
				category_name = cl.getEvent_category_name();
			}
		}
	    return category_name;

	  }
	
	@Override
	  public String getRegionName(Long region_id)
	  {
		String region_name ="";
		List<Region> regionList = regionRepository.findAll();
		for(Region rl: regionList){
			if(region_id != 0 && (rl.getRegion_id() == region_id)){
				region_name = rl.getRegion_territory();
			}
		}
	    return region_name;
	  }
	
	@Override
	public String getApplicationName(Long event_id) {
		String app_name ="";
		List<EventApplication> evententryList = eventapplicationRepository.findAll();
		for(EventApplication ee: evententryList){
			if(event_id != 0 && (ee.getEvent_ID() == event_id)){
				app_name = ee.getApplication();
			}
		}
	    return app_name;		
	}
	
	@Override
	public String getResourceName(Long event_id) {
		
		String resource_name ="";
		List<EventUser> evententryList = eventUserRepository.findAll();
		for(EventUser ee: evententryList){
			if(event_id != 0 && (ee.getEvent_ID() == event_id)){
				resource_name = ee.getResource();
			}
		}
	    return resource_name;			
	}
	
	@Override
	public String getCalendarType(Long event_calendar_id) {
		String calendar_type ="";
		List<CalendarType> evententryList = calendarTypeRepository.findAll();
		for(CalendarType ee: evententryList){
			if(event_calendar_id != 0 && (ee.getCalendar_type_id() == event_calendar_id)){
				calendar_type = ee.getCalendar_type_name();
			}
		}
	    return calendar_type;			
	}

	@Override
	public List<EventPlanned> highestVersion(String event_Name) {
		
		int highestVersion = 0;
		Long event_id = 0L;
		List<EventEntry> eeList = eventEntryRepository.findAll();
		for(EventEntry ee: eeList){
			if(event_Name != null && (ee.getEventname().equalsIgnoreCase(event_Name))){
				event_id = ee.getEvent_ID();
			}
		}		
		EventPlanned eventPlanned = new EventPlanned();
		List<EventPlanned> epList1 = eventPlannedRepository.findAll();
		List<Integer> versionList = new ArrayList<Integer>();
		for(EventPlanned ep: epList1){
			if(Long.parseLong(ep.getEvent_ID()) == event_id){
				versionList.add(ep.getVersion());
			}
		}
		
		Collections.sort(versionList);
		int size = versionList.size();
		highestVersion = versionList.get(size-1); 
		
		EventPlanned eventPlanned1 = new EventPlanned();
		List<EventPlanned> epList2 = eventPlannedRepository.findAll();
		List<EventPlanned> finalList = new ArrayList<EventPlanned>();
		String eventid = String.valueOf(event_id);
		for(EventPlanned ep: epList2){			
			eventPlanned1 = new EventPlanned();
			if(ep.getEvent_ID().equalsIgnoreCase(eventid) && ep.getVersion() == highestVersion) {
				eventPlanned1.setEvent_ID(ep.getEvent_ID());
				eventPlanned1.setPlanned_Seq_ID(ep.getPlanned_Seq_ID());
				eventPlanned1.setStep_Number(ep.getStep_Number());
				eventPlanned1.setCritical_Path(ep.getCritical_Path());
				eventPlanned1.setApplication_Name(ep.getApplication_Name());
				eventPlanned1.setJob_Name(ep.getJob_Name());
				eventPlanned1.setOwner(ep.getOwner());
				eventPlanned1.setTechnology(ep.getTechnology());
				eventPlanned1.setDay(ep.getDay());
				eventPlanned1.setPlanned_Start_Time(ep.getPlanned_Start_Time());
				eventPlanned1.setPlanned_End_Time(ep.getPlanned_End_Time());
				eventPlanned1.setPlanned_Run_Time(ep.getPlanned_Run_Time());
				eventPlanned1.setSupport_Team_Email_ID(ep.getSupport_Team_Email_ID());
				eventPlanned1.setEscalation_Email_Group(ep.getEscalation_Email_Group());
				eventPlanned1.setBusiness_Contact_Email(ep.getBusiness_Contact_Email());
				eventPlanned1.setThresold_Alert_Time(ep.getThresold_Alert_Time());	
				finalList.add(eventPlanned1);
			}
		}	
		return finalList;
	}

	//Save Data for Other Data
			@Override
			public void saveUpdateOther(EventEntryBean eventEntry) {

				//long maxEvent_Id = 0;
				EventEntry entry = eventEntryRepository.findOne(eventEntry.getEvent_ID());
				
				String eventName=eventEntry.getEventName();
				
				 // entry.setEvent_ID(eventEntry.getEvent_ID());
					entry.setEventname(eventName);
			
				entry.setDescription_details(eventEntry.getDescription_details());
		        
		      String remarks=eventEntry.getRemarks();
		 		
				if(remarks != null && remarks.startsWith(",")){
		 			String remarks1=remarks.substring(1);
		 			entry.setRemarks(remarks1);
		 		}else{
		 			entry.setRemarks(remarks);
		 		}
				
				String startDate=eventEntry.getStart_date();
				String startTime=eventEntry.getStart_time();
				
				if(startDate.startsWith(",")){
		 			String startDate1=startDate.substring(1);
		 			entry.setStart_date(startDate1+" "+startTime);
		 		}else{
		 			entry.setStart_date(startDate+" "+startTime);
		 		}
				
		 		String endDate=eventEntry.getEnd_date();
		 		String endTime=eventEntry.getEnd_time();
		 		if(endDate.startsWith(",")){
		 			String end=endDate.substring(1);
		 			entry.setEnd_date(end+" "+endTime);
		 		}
		 		else{
		 			entry.setEnd_date(endDate+" "+endTime);
		 		}
		 		
		 		entry.setEnd_date(endDate); //ADDED TEMPORARILY FOR TESTING BY BKM
		 		entry.setStart_date(startDate);//ADDED TEMPORARILY FOR TESTING BY BKM
		 		
		        String email=eventEntry.getEmail_receipients();
		 		
		        if(email.startsWith(",")){
		 			String email1=email.substring(1);
		 			entry.setAdditional_receipients(email1);
		 		}else{
		 			entry.setAdditional_receipients(email);
		 		}
				
		        entry.setEmail_receipients1(eventEntry.getEmail_receipients1());
				entry.setEngagement_Name(eventEntry.getEngagement_Name());
				entry.setLast_Modified_by(eventEntry.getEventName());
				entry.setCreated_By(eventEntry.getEventName());
				entry.setRisk_summary(eventEntry.getRisk_summary());
			
				entry.setRemarks(eventEntry.getRemarks());
				if(StringUtils.isNullOrEmpty(eventEntry.getRegion_id())){
					eventEntry.setRegion_id("0L");
				}
				
				String evCatName=eventEntry.getEvent_category_Name();
				
				if(evCatName != null && evCatName.startsWith(",")){
					String eveCat1 = evCatName.substring(1);
				Category category=categoryService.findByEventCategoryName(eveCat1);
				
				if(category!=null){
					entry.setEvent_category_id(category.getEvent_cat_id());			
				}
				}else{
				
		        Category category=categoryService.findByEventCategoryName(evCatName);
				
				if(category!=null){
					entry.setEvent_category_id(category.getEvent_cat_id());		
				}
				}
				entry.setAccountName(eventEntry.getAccount_name());
				//entry.setAdditional_receipients(eventEntry.getEmail_receipients());
				entry.setCalendar_type_id(eventEntry.getCalendar_type_id());
				entry.setEvent_file_name(eventEntry.getEvent_file_name());
				entry.setEvent_upld_fix(eventEntry.getEvent_upld_fix());
				
				entry.setRecurrence_type(eventEntry.getRecurrence_type());
				entry.setRecu_every_day(eventEntry.getRecu_every_day());
				entry.setRecu_every_weekday(eventEntry.getRecu_every_weekday());
				entry.setRecu_every_week(eventEntry.getRecu_every_week());
			  	entry.setRecurrence_dayName(eventEntry.getRecurrence_dayName());
				entry.setRecu_every_month(eventEntry.getRecu_every_month());
		      	entry.setRecu_month_day(eventEntry.getRecu_month_day());
		      	entry.setMonthdd1(eventEntry.getMonthdd1());
		      	entry.setMonthdd2(eventEntry.getMonthdd2());
		      	entry.setMonthtext1(eventEntry.getMonthtext1());
		      	entry.setRecu_month_day_radio(eventEntry.getRecu_month_day_radio());
		      	entry.setEventstatus("Confirmed");
		      	if(!StringUtils.isNullOrEmpty(eventEntry.getRegion_id())){
		      		entry.setRegion_id(Long.parseLong(eventEntry.getRegion_id()));
		      	}
		      	entry.setEvent_category_id(eventEntry.getEvent_category_id());
		      	entry.setCalendar_type_id(eventEntry.getCalendar_type_id());
		      	
			/*	EventEntry savedEvent = eventEntryRepository.save(entry);
				if (null != savedEvent) {
					maxEvent_Id = savedEvent.getEvent_ID();
				} else {
					maxEvent_Id = 1;
				}*/
				
				List<EventApplication> eventAppList = new ArrayList<>();
				if(eventEntry != null && eventEntry.getEventAppSet() != null){
				for (String appName : eventEntry.getEventAppSet()) {
					EventApplication eventApp = new EventApplication();
					eventApp.setApplication(appName);
					eventApp.setEvent_ID(entry.getEvent_ID());
					eventAppList.add(eventApp);
				}
				}			
				entry.setEventAppSet(eventAppList);
				List<EventUser> eventUserList = new ArrayList<>();
				// List<User> userList=userEntryrepository.findAll();
				
				if(eventEntry != null && eventEntry.getEventUserSet() != null){
				for (String Resourcename : eventEntry.getEventUserSet()) {
					EventUser eventUser = new EventUser();
					eventUser.setResource(Resourcename);
					eventUser.setEvent_ID(entry.getEvent_ID());
					eventUserList.add(eventUser);
				}
				}
				entry.setEventUserSet(eventUserList);
				entry.setEventstatus("Confirmed");
				eventEntryRepository.save(entry);
			}
			
			@Override
			public String getActualEndTime(Long plannedSeqId) {
				List<EventActual> lep = eventActualReporsitory.findAll();
				String lepout = "";
				for (EventActual ep : lep) {
					if (plannedSeqId != null && ep.getPlanned_Seq_ID() != null
							&& String.valueOf(ep.getPlanned_Seq_ID()).equalsIgnoreCase(String.valueOf(plannedSeqId))) {
						lepout = ep.getActual_End_Time();
					}
				}
				return lepout;

			}
			
			@Override
			public int getAllId(Long event_id) {
				List<EventPlanned> eventPlannedList = eventPlannedRepository.findAll();
				int version=0;

				for (EventPlanned ep : eventPlannedList) {
					System.out.println(event_id + "::" + ep.getEvent_ID());
					if (event_id == Long.parseLong(ep.getEvent_ID())) {
						if(ep.getVersion()>version)
							version=ep.getVersion();
					}
				}
				return version;
				

			}
			@Override
			public List<EventActual> getActual(Long event_id, String Date) {
				List<EventActual> eA = null;
				List<EventActual> eventActualList = eventActualRepository.findAll();
				for (EventActual eventActual : eventActualList) {
					if (event_id != 0 && (eventActual.getEvent_ID() == event_id)
							&& (eventActual.getActual_Start_Date().equalsIgnoreCase(Date))) {
						eA.add(eventActual);
					}
				}
				return eA;

			}
			
			@Override
			  public List<EventActual> getActualEvent(String eventID, String startDate, List<Integer> numDay) throws ParseException
			  {
				List<EventActual> lep = eventActualReporsitory.findAll();
				List<EventActual> eventActualList = new ArrayList<>();
				HashMap<Integer, String> hMap = new HashMap<Integer, String>();
				SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
				
				int size = numDay.size();
				int maxnumDay = numDay.get(size-1);
				
				int i1 = 1;
				for (int k = 0; k <= maxnumDay; k++) {
					hMap.put(i1, startDate);
					i1++;
					Calendar c = Calendar.getInstance();
					c.setTime(sdf.parse(startDate));
					c.add(Calendar.DATE, 1); // number of days to add
					startDate = sdf.format(c.getTime());
				}
				
				List<String> list = new ArrayList<String>(hMap.values());
				
				for(EventActual ep: lep){
					if(eventID != null && String.valueOf(ep.getEvent_ID()) != null &&
						String.valueOf(ep.getEvent_ID()).equalsIgnoreCase(eventID) && 
						(ep.getActual_Start_Date() != null && list.contains(ep.getActual_Start_Date()))){
						EventActual eventActual = new EventActual();
						eventActual.setEvent_ID(ep.getEvent_ID());
						eventActual.setActual_Seq_ID(ep.getActual_Seq_ID());
						eventActual.setPlanned_Seq_ID(ep.getPlanned_Seq_ID());
						eventActual.setStep_Number(ep.getStep_Number());
						eventActual.setActual_Start_Date(ep.getActual_Start_Date());
						eventActual.setActual_End_Date(ep.getActual_End_Time());
						eventActual.setActual_Run_Time(ep.getActual_Run_Time());
						eventActual.setActual_Start_Time(ep.getActual_Start_Time());
						eventActual.setActual_Start_Time(ep.getActual_End_Time());
						eventActual.setFailure_Reason(ep.getFailure_Reason());
						eventActual.setPreventive_Measure(ep.getPreventive_Measure());
						eventActual.setJob_Status(ep.getJob_Status());
						eventActual.setEvent_Frequency_ID(ep.getEvent_Frequency_ID());
						eventActualList.add(eventActual);
					}
				}
				 return eventActualList;
			  }
}
