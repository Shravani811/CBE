package com.account.service;

import java.util.HashMap;
import java.util.List;

import com.account.model.Application;
import com.account.model.EventEntryMaster;
import com.account.model.User;
import com.accounts.dto.ApplicationBean;

public interface ApplicationService {
public void save(ApplicationBean application);
public void save(Application application);
public void save(Long id);
//Application findById(Long id);
public List<String> getAppNames();
public List<Application> findAll();
Application findById(Long id);
public Application findByApplicationName(String[] appName);
/*List<Application> findByApp_NameAsc(String app_Name);*/
public Application findByAppName(String aapName);
public List<HashMap<String, String>> getPriAndSecResourceName();
//public User findByPrimaryResoureName(String primary);
public List<HashMap<String, String>> getPriAndSecResourceEmailIds();

}
