package com.account.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_ikon_incidents")
public class Incident {

	private static final long serialVersionUID = 1L;
	/*@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long Id;*/
	@Id
	private String Incident_ID;
	private String Start_Date;
	private String End_Date;
	private String Reported_Date;
	private String Summary;
	private String Notes;
	private String application_name;
	private String causeCodeId;
    
	
	public String getApplication_name() {
		return application_name;
	}
	public void setApplication_name(String application_name) {
		this.application_name = application_name;
	}
	public String getCauseCodeId() {
		return causeCodeId;
	}
	public void setCauseCodeId(String causeCodeId) {
		this.causeCodeId = causeCodeId;
	}
	/*public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}*/
	public String getIncident_ID() {
		return Incident_ID;
	}
	public void setIncident_ID(String incident_ID) {
		Incident_ID = incident_ID;
	}
	public String getStart_Date() {
		return Start_Date;
	}
	public void setStart_Date(String start_Date) {
		Start_Date = start_Date;
	}
	public String getEnd_Date() {
		return End_Date;
	}
	public void setEnd_Date(String end_Date) {
		End_Date = end_Date;
	}
	public String getReported_Date() {
		return Reported_Date;
	}
	public void setReported_Date(String reported_Date) {
		Reported_Date = reported_Date;
	}
	public String getSummary() {
		return Summary;
	}
	public void setSummary(String summary) {
		Summary = summary;
	}
	public String getNotes() {
		return Notes;
	}
	public void setNotes(String notes) {
		Notes = notes;
	}  
}
