package com.account.model;


import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_user_master")
public class User  {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="User_ID")
    private Long User_ID;
	
    @Column(name="Username")
    private String Username;
	
    @Column(name="Password")
    private String Password;
	
    @Column(name="Email_ID")
    private String Email_ID;
	
    @Column(name="Resourcename")
    private String Resourcename;
	
    @Column(name="Status")
    private boolean Status;
    
    @Column(name="Role_Name")
    private String Role_Name;

    @Column(name="User_Account")
    private String user_Account;
	
    @OneToMany(cascade=CascadeType.ALL,mappedBy = "user",fetch = FetchType.EAGER)
    @ElementCollection(targetClass=UserAccount.class)
    private List<UserAccount> eventAccSet;
    
    /*public List<UserAccount> getEventAccSet() {
		return eventAccSet;
	}*/

	public void setEventAccSet(List<UserAccount> eventAccSet) {
		this.eventAccSet = eventAccSet;
	}

	public String getUser_Account() {
		return user_Account;
	}

	public void setUser_Account(String user_Account) {
		this.user_Account = user_Account;
	}

	private Set<Role> roles;
	
	/*@OneToMany(cascade=CascadeType.ALL,mappedBy = "user",fetch = FetchType.EAGER)
	private List<Account> accountsSet;


    @ManyToOne(optional = false)
    private EventEntry eventEntry;
   

	public List<Account> getAccountsSet() {
		return accountsSet;
	}

	public void setAccountsSet(List<Account> accountsSet) {
		this.accountsSet = accountsSet;
	}*/

	@Id 
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long getUser_ID() {
		return User_ID;
	}

	public void setUser_ID(Long user_ID) {
		User_ID = user_ID;
	}

	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getEmail_ID() {
		return Email_ID;
	}

	public void setEmail_ID(String email_ID) {
		Email_ID = email_ID;
	}


	public String getResourcename() {
		return Resourcename;
	}

	public void setResourcename(String resourcename) {
		Resourcename = resourcename;
	}

	

	public boolean isStatus() {
		return Status;
	}

	public void setStatus(boolean status) {
		Status = status;
	}
	
	public String getRole_Name() {
		return Role_Name;
	    }

	    public void setRole_Name(String role_Name) {
		Role_Name = role_Name;
	    }

	@ManyToMany(fetch = FetchType.EAGER)
	   // @ManyToMany(fetch = FetchType.LAZY)
	// @JoinColumn(name = "Role_Name")
    @JoinTable(name = "tbl_user_role", joinColumns = @JoinColumn(name = "User_ID"),
                                       inverseJoinColumns = @JoinColumn(name = "Role_ID"))
    public Set<Role> getRoles() {
        return roles;
    }

    public void setRoles(Set<Role> roles) {
        this.roles = roles;

    }
    
}
