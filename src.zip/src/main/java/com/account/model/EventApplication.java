package com.account.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author jaimishr
 *
 */
@Entity
@Table(name="tbl_event_detail_app")
public class EventApplication implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long Event_det_a_id;
	private String Application;
	private Long Event_ID;
	
	@ManyToOne    
	@JoinColumn(name = "Event_ID",nullable=false,insertable=false, updatable=false )
	
	private EventEntry eventEntry;
	public EventApplication(){}
	
	public Long getEvent_det_a_id() {
		return Event_det_a_id;
	}

	public void setEvent_det_a_id(Long event_det_a_id) {
		Event_det_a_id = event_det_a_id;
	}

	public String getApplication() {
		return Application;
	}
	public void setApplication(String application) {
		Application = application;
	}
	public Long getEvent_ID() {
		return Event_ID;
	}
	public void setEvent_ID(Long event_ID) {
		Event_ID = event_ID;
	}
	public EventEntry getEventEntry() {
		return eventEntry;
	}
	public void setEventEntry(EventEntry eventEntry) {
		this.eventEntry = eventEntry;
	}
    
	
	
}
