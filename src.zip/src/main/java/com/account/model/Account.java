package com.account.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_account_master")
public class Account  {
	
	private static final long serialVersionUID = 1L;
	@Column(name="Account_ID")
	private Long account_Id;
	@Column(name="Account_Name")
	private String account_Name;
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long getAccount_Id() {
		return account_Id;
	}
	public void setAccount_Id(Long account_Id) {
		this.account_Id = account_Id;
	}
	public String getAccount_Name() {
		return account_Name;
	}
	public void setAccount_Name(String account_Name) {
		this.account_Name = account_Name;
	}
	
}
