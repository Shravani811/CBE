package com.account.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Bala
 * 
 */

@Entity
@Table(name = "tbl_event_entry_master")
public class EventEntryMaster {
	

@Id
@GeneratedValue(strategy = GenerationType.AUTO)	
private Long Event_ID;
private String Eventname;
private String Description_details;
private String Engagement_Name;
private Long   Event_category_id;
private String Risk_summary;
private Long Region_id;
private String Last_Modified_Date;
private String Last_Modified_by;
private String Created_Date;
private String Created_By;
private String Additional_receipients;
private String Additional_receipients1;
private String Remarks;
private Long calendar_type_id;



public String getAdditional_receipients1() {
	return Additional_receipients1;
}

public void setAdditional_receipients1(String additional_receipients1) {
	Additional_receipients1 = additional_receipients1;
}

public String getRemarks() {
	return Remarks;
}

public void setRemarks(String remarks) {
	Remarks = remarks;
}

@OneToMany(cascade=CascadeType.ALL,mappedBy = "eventEntry",fetch = FetchType.EAGER)
private List<EventApplicationMaster> eventAppSet;


@OneToMany(cascade=CascadeType.ALL, mappedBy="eventEntry",fetch = FetchType.EAGER)
private List<EventUserMaster> eventUserSet;

public EventEntryMaster(){}

public Long getEvent_ID() {
	return Event_ID;
}
public void setEvent_ID(Long event_ID) {
	Event_ID = event_ID;
}


public Long getCalendar_type_id() {
	return calendar_type_id;
}

public void setCalendar_type_id(Long calendar_type_id) {
	this.calendar_type_id = calendar_type_id;
}

public String getEventname() {
	return Eventname;
}
public void setEventname(String eventname) {
	Eventname = eventname;
}
public String getDescription_details() {
	return Description_details;
}
public void setDescription_details(String description_details) {
	Description_details = description_details;
}

public String getEngagement_Name() {
	return Engagement_Name;
}
public void setEngagement_Name(String engagement_Name) {
	Engagement_Name = engagement_Name;
}

public List<EventApplicationMaster> getEventAppSet() {
	return eventAppSet;
}

public void setEventAppSet(List<EventApplicationMaster> eventAppSet) {
	this.eventAppSet = eventAppSet;
}

public List<EventUserMaster> getEventUserSet() {
	return eventUserSet;
}

public void setEventUserSet(List<EventUserMaster> eventUserSet) {
	this.eventUserSet = eventUserSet;
}

public String getLast_Modified_Date() {
	return Last_Modified_Date;
}
public void setLast_Modified_Date(String last_Modified_Date) {
	Last_Modified_Date = last_Modified_Date;
}
public String getLast_Modified_by() {
	return Last_Modified_by;
}
public void setLast_Modified_by(String last_Modified_by) {
	Last_Modified_by = last_Modified_by;
}
public String getCreated_Date() {
	return Created_Date;
}
public void setCreated_Date(String created_Date) {
	Created_Date = created_Date;
}
public String getCreated_By() {
	return Created_By;
}
public void setCreated_By(String created_By) {
	Created_By = created_By;
}

public Long getEvent_category_id() {
	return Event_category_id;
}

public void setEvent_category_id(Long event_category_id) {
	Event_category_id = event_category_id;
}


public String getRisk_summary() {
	return Risk_summary;
}

public void setRisk_summary(String risk_summary) {
	Risk_summary = risk_summary;
}

/*public String getRegion_territory() {
	return Region_territory;
}

public void setRegion_territory(String region_territory) {
	Region_territory = region_territory;
}*/



public String getAdditional_receipients() {
	return Additional_receipients;
}

public Long getRegion_id() {
	return Region_id;
}

public void setRegion_id(Long region_id) {
	Region_id = region_id;
}

public void setAdditional_receipients(String additional_receipients) {
	Additional_receipients = additional_receipients;
}



/*@Override
public String toString() {
	return "EventEntry [Eventname=" + Eventname + ", Description_details=" + Description_details + ", Start_date="
			+ Start_date + ", End_date=" + End_date + ", Engagement_Name=" + Engagement_Name + ", eventAppSet="
			+ eventAppSet + ", eventUserSet=" + eventUserSet + ", Last_Modified_Date=" + Last_Modified_Date
			+ ", Last_Modified_by=" + Last_Modified_by + ", Created_Date=" + Created_Date + ", Created_By=" + Created_By
			+ "]";
}*/

}
