package com.account.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * jaimishr
 * 
 */

@Entity
@Table(name = "tbl_event_critical_path_planned")
public class EventPlanned {

@Id
@GeneratedValue(strategy = GenerationType.AUTO)	
private Long Planned_Seq_ID;
private String Event_ID;
private String Step_Number;
private String Critical_Path;
private String Application_Name;
private String Job_Name;
private String Process_Description;
private String Owner;
private String Technology;
private String Day;
private String Planned_Start_Time;
private String Planned_End_Time;
private String Planned_Run_Time;
private String Support_Team_Email_ID;
private String Escalation_Email_Group;
private String Business_Contact_Email;
private String Thresold_Alert_Time;
private Integer Version;
private String Business_Impact;
private String isNotificationRequired;
private String Effective_Date;

@Transient
private String styleCollapse;

@Transient
private String actualStartTime;

@Transient
private String actualEndTime;

@Transient
private String actualStartDate;

@Transient
private String actualEndDate;

public String getProcess_Description() {
	return Process_Description;
}
public void setProcess_Description(String process_Description) {
	Process_Description = process_Description;
}

public String getStyleCollapse() {
	return styleCollapse;
}
public void setStyleCollapse(String styleCollapse) {
	this.styleCollapse = styleCollapse;
}
public Long getPlanned_Seq_ID() {
	return Planned_Seq_ID;
}
public void setPlanned_Seq_ID(Long planned_Seq_ID) {
	Planned_Seq_ID = planned_Seq_ID;
}
public String getStep_Number() {
	return Step_Number;
}
public void setStep_Number(String step_Number) {
	Step_Number = step_Number;
}
public String getCritical_Path() {
	return Critical_Path;
}
public void setCritical_Path(String critical_Path) {
	Critical_Path = critical_Path;
}
public String getApplication_Name() {
	return Application_Name;
}
public void setApplication_Name(String application_Name) {
	Application_Name = application_Name;
}
public String getJob_Name() {
	return Job_Name;
}
public void setJob_Name(String job_Name) {
	Job_Name = job_Name;
}
public String getOwner() {
	return Owner;
}
public void setOwner(String owner) {
	Owner = owner;
}
public String getTechnology() {
	return Technology;
}
public void setTechnology(String technology) {
	Technology = technology;
}
public String getPlanned_Start_Time() {
	return Planned_Start_Time;
}
public void setPlanned_Start_Time(String planned_Start_Time) {
	Planned_Start_Time = planned_Start_Time;
}
public String getPlanned_End_Time() {
	return Planned_End_Time;
}
public void setPlanned_End_Time(String planned_End_Time) {
	Planned_End_Time = planned_End_Time;
}
public String getPlanned_Run_Time() {
	return Planned_Run_Time;
}
public void setPlanned_Run_Time(String planned_Run_Time) {
	Planned_Run_Time = planned_Run_Time;
}
public String getSupport_Team_Email_ID() {
	return Support_Team_Email_ID;
}
public void setSupport_Team_Email_ID(String support_Team_Email_ID) {
	Support_Team_Email_ID = support_Team_Email_ID;
}
public String getEscalation_Email_Group() {
	return Escalation_Email_Group;
}
public void setEscalation_Email_Group(String escalation_Email_Group) {
	Escalation_Email_Group = escalation_Email_Group;
}
public String getBusiness_Contact_Email() {
	return Business_Contact_Email;
}
public void setBusiness_Contact_Email(String business_Contact_Email) {
	Business_Contact_Email = business_Contact_Email;
}
public String getThresold_Alert_Time() {
	return Thresold_Alert_Time;
}
public void setThresold_Alert_Time(String thresold_Alert_Time) {
	Thresold_Alert_Time = thresold_Alert_Time;
}
public String getEvent_ID() {
	return Event_ID;
}
public void setEvent_ID(String event_ID) {
	Event_ID = event_ID;
}
public Integer getVersion() {
	return Version;
}
public void setVersion(Integer version) {
	Version = version;
}
/**
 * @return the business_Impact
 */
public String getBusiness_Impact() {
	return Business_Impact;
}
/**
 * @param business_Impact the business_Impact to set
 */
public void setBusiness_Impact(String business_Impact) {
	Business_Impact = business_Impact;
}
/**
 * @return the day
 */
public String getDay() {
	return Day;
}
/**
 * @param day the day to set
 */
public void setDay(String day) {
	Day = day;
}
public String getActualStartTime() {
	return actualStartTime;
}
public void setActualStartTime(String actualStartTime) {
	this.actualStartTime = actualStartTime;
}
public String getActualEndTime() {
	return actualEndTime;
}
public void setActualEndTime(String actualEndTime) {
	this.actualEndTime = actualEndTime;
}
public String getActualStartDate() {
	return actualStartDate;
}
public void setActualStartDate(String actualStartDate) {
	this.actualStartDate = actualStartDate;
}
public String getActualEndDate() {
	return actualEndDate;
}
public void setActualEndDate(String actualEndDate) {
	this.actualEndDate = actualEndDate;
}
/**
 * @return the isNotificationRequired
 */
public String getIsNotificationRequired() {
	return isNotificationRequired;
}
/**
 * @param isNotificationRequired the isNotificationRequired to set
 */
public void setIsNotificationRequired(String isNotificationRequired) {
	this.isNotificationRequired = isNotificationRequired;
}
public String getEffective_Date() {
	return Effective_Date;
}
public void setEffective_Date(String effective_Date) {
	Effective_Date = effective_Date;
}

}
