package com.account.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * @author jaimishr
 *
 */

@Entity
@Table(name="tbl_app_master")
public class Application implements Comparable<Application>{
	private Long App_ID;
	
	//OrderBy(CriteriaBuilder.asc)
	private String App_Name;
	private String Primary_resource;
	private String Secondary_resource;
	private boolean Status;
	private String Tower;
	private String CC_name;
	private String Cluster;
	private String Last_Modified_date;
	private String Last_Modified_by;
	/*@ManyToOne(optional = false)
	private EventEntry eventEntry;
	*/
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getApp_ID() {
		return App_ID;
	}
	public void setApp_ID(Long app_ID) {
		App_ID = app_ID;
	}
	public String getApp_Name() {
		return App_Name;
	}
	public void setApp_Name(String app_Name) {
		App_Name = app_Name;
	}
	public String getPrimary_resource() {
		return Primary_resource;
	}
	public void setPrimary_resource(String primary_resource) {
		Primary_resource = primary_resource;
	}
	public String getSecondary_resource() {
		return Secondary_resource;
	}
	public void setSecondary_resource(String secondary_resource) {
		Secondary_resource = secondary_resource;
	}
	
	
	
	public boolean isStatus() {
		return Status;
	}
	public void setStatus(boolean status) {
		Status = status;
	}
	public String getTower() {
		return Tower;
	}
	public void setTower(String tower) {
		Tower = tower;
	}
	public String getCC_name() {
		return CC_name;
	}
	public void setCC_name(String cC_name) {
		CC_name = cC_name;
	}
	public String getCluster() {
		return Cluster;
	}
	public void setCluster(String cluster) {
		Cluster = cluster;
	}
	public String getLast_Modified_date() {
		return Last_Modified_date;
	}
	public void setLast_Modified_date(String last_Modified_date) {
		Last_Modified_date = last_Modified_date;
	}
	public String getLast_Modified_by() {
		return Last_Modified_by;
	}
	public void setLast_Modified_by(String last_Modified_by) {
		Last_Modified_by = last_Modified_by;
	}
	@Override
	public int compareTo(Application a) {
		
		//return this.App_Name.compareTo(a.App_Name);
		return this.getApp_Name().compareTo(a.getApp_Name());
	}
	

	
}
