package com.account.model;

public class EventActualBean {

private Long Actual_Seq_ID;
private int Event_ID;
private Long Planned_Seq_ID;
private int Event_Frequency_ID;

private String Actual_Start_Date;
private String Actual_End_Date;

private String Step_Number;
private String Planned_Start_Date;
private String Planned_End_Date;

private String Actual_Run_Time;
private String Actual_Start_Time;
private String Actual_End_Time;
private String Failure_Reason;
private String Preventive_Measure;
private String Job_Status;
public Long getActual_Seq_ID() {
	return Actual_Seq_ID;
}
public void setActual_Seq_ID(Long actual_Seq_ID) {
	Actual_Seq_ID = actual_Seq_ID;
}
public int getEvent_ID() {
	return Event_ID;
}
public void setEvent_ID(int event_ID) {
	Event_ID = event_ID;
}
public Long getPlanned_Seq_ID() {
	return Planned_Seq_ID;
}
public void setPlanned_Seq_ID(Long planned_Seq_ID) {
	Planned_Seq_ID = planned_Seq_ID;
}
public int getEvent_Frequency_ID() {
	return Event_Frequency_ID;
}
public void setEvent_Frequency_ID(int event_Frequency_ID) {
	Event_Frequency_ID = event_Frequency_ID;
}



public String getActual_Start_Date() {
	return Actual_Start_Date;
}
public void setActual_Start_Date(String actual_Start_Date) {
	Actual_Start_Date = actual_Start_Date;
}
public String getActual_End_Date() {
	return Actual_End_Date;
}
public void setActual_End_Date(String actual_End_Date) {
	Actual_End_Date = actual_End_Date;
}
public String getStep_Number() {
	return Step_Number;
}
public void setStep_Number(String step_Number) {
	Step_Number = step_Number;
}
public String getPlanned_Start_Date() {
	return Planned_Start_Date;
}
public void setPlanned_Start_Date(String planned_Start_Date) {
	Planned_Start_Date = planned_Start_Date;
}
public String getPlanned_End_Date() {
	return Planned_End_Date;
}
public void setPlanned_End_Date(String planned_End_Date) {
	Planned_End_Date = planned_End_Date;
}
public String getActual_Run_Time() {
	return Actual_Run_Time;
}
public void setActual_Run_Time(String actual_Run_Time) {
	Actual_Run_Time = actual_Run_Time;
}
public String getActual_Start_Time() {
	return Actual_Start_Time;
}
public void setActual_Start_Time(String actual_Start_Time) {
	Actual_Start_Time = actual_Start_Time;
}
public String getActual_End_Time() {
	return Actual_End_Time;
}
public void setActual_End_Time(String actual_End_Time) {
	Actual_End_Time = actual_End_Time;
}
public String getFailure_Reason() {
	return Failure_Reason;
}
public void setFailure_Reason(String failure_Reason) {
	Failure_Reason = failure_Reason;
}
public String getPreventive_Measure() {
	return Preventive_Measure;
}
public void setPreventive_Measure(String preventive_Measure) {
	Preventive_Measure = preventive_Measure;
}
public String getJob_Status() {
	return Job_Status;
}
public void setJob_Status(String job_Status) {
	Job_Status = job_Status;
}


}
