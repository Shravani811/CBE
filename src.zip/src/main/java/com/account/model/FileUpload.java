package com.account.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.extractor.WordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.springframework.web.multipart.MultipartFile;


public class FileUpload {
    //private static final String[] ALLOWED_FILE_TYPES = {"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel"};
    private static final Long MAX_FILE_SIZE = 5242880L; //1MB
    static String KO_fix="";
    
 
    //private static final String UPLOAD_FILE_PATH = "C:/Bala/apache-tomcat-7.0.37/UploadFiles/";
    
    public String process(MultipartFile file) throws java.io.FileNotFoundException {
        if (!file.isEmpty()) {
        	
     	   String rootPath = System.getProperty("catalina.home");
     	    File dir = new File(rootPath + "/webapps/CBE-ARMS/resources/documents/");
     	   //final String UPLOAD_FILE_PATH  = "/apache-tomcat-8.0.36_AT/webapps/CBE-ARMS/resources/documents/";
     	    
     	    
     	    if (!dir.exists())
     	    	dir.mkdirs();
     	    
     	System.out.println("inside try file is empty");
       /*  if (isValidContentType(contentType)) {*/
             if (belowMaxFileSize(file.getSize())) {
                 String newFile = dir + file.getOriginalFilename();
                 System.out.println("newFile--->"+newFile);
                 try {
                 	System.out.println("inside try file upload");
                    file.transferTo(new File(newFile));
                    return newFile;
                 } catch (IllegalStateException e) {
                     return "There was an error uploading " + file.getOriginalFilename() + " => " + e.getMessage();
                 } catch (IOException e) {
                     return "There was an error uploading " + file.getOriginalFilename() + " => " + e.getMessage();
                 } 
                 
             } else {
                 return "Error. " + file.getOriginalFilename() + " file size (" + file.getSize() + ") exceeds " + MAX_FILE_SIZE + " limit.";
             }
       /*  } else {
             return "Error. " + contentType + " is not a valid content type.";
         }*/
     } else {
         return "Error. No file choosen.";
     }
 }
    
    public String processEventUpload(MultipartFile file) throws java.io.FileNotFoundException {
        if (!file.isEmpty()) {
        	
     	   String rootPath = System.getProperty("catalina.home");
     	    File dir = new File(rootPath + "/webapps/CBE_V2/resources/files/");
     	  //File dir = new File("D:/opt/file/");
     	   //final String UPLOAD_FILE_PATH  = "/apache-tomcat-8.0.36_AT/webapps/CBE-ARMS/resources/documents/";
     	    
     	    
     	    if (!dir.exists())
     	    	dir.mkdirs();
     	    
     	System.out.println("inside try file is empty");
       /*  if (isValidContentType(contentType)) {*/
             if (belowMaxFileSize(file.getSize())) {
                 String newFile = dir + "/" + file.getOriginalFilename();
                 System.out.println("newFile--->"+newFile);
                 try {
                 	System.out.println("inside try file upload");
                    file.transferTo(new File(newFile));
                    return newFile;
                 } catch (IllegalStateException e) {
                     return "There was an error uploading " + file.getOriginalFilename() + " => " + e.getMessage();
                 } catch (IOException e) {
                     return "There was an error uploading " + file.getOriginalFilename() + " => " + e.getMessage();
                 } 
                 
             } else {
                 return "Error. " + file.getOriginalFilename() + " file size (" + file.getSize() + ") exceeds " + MAX_FILE_SIZE + " limit.";
             }
       /*  } else {
             return "Error. " + contentType + " is not a valid content type.";
         }*/
     } else {
         return "Error. No file choosen.";
     }
 }
    
 /*   private Boolean isValidContentType(String contentType) {
        if (!Arrays.asList(ALLOWED_FILE_TYPES).contains(contentType)) {
            return false;
        }
        
        return true;
    }*/
    
    private Boolean belowMaxFileSize(Long fileSize) {
        if (fileSize > MAX_FILE_SIZE) {
            return false;
        }
        
        return true;
    }
    
	public String readWordFile(String filePath)
	{
		String fileContent = null;
		File file = new File(filePath);

		String fileName = file.getName();
		System.out.println("filename " +fileName);
		System.out.println("file extension "+fileName.substring(fileName.indexOf(".")+1));

		if(fileName.substring(fileName.lastIndexOf(".")+1).equalsIgnoreCase("Doc"))
		{
			System.out.println("This is Doc file");
			fileContent = readDocFile(filePath);
		}
		else if(fileName.substring(fileName.lastIndexOf(".")+1).equalsIgnoreCase("Docx"))
		{
			System.out.println("This is other file");
			fileContent = readDocxFile(filePath);
		} else {
			fileContent = "";
		}
		
		return fileContent;
	} 
    
	public  String readDocFile(String fileName)
	{
		StringBuffer wordContent = null;

		try
		{
			System.out.println(" inside of readdoc file "+fileName);
			File file = new File(fileName);
			FileInputStream fis = new FileInputStream(file.getAbsolutePath());

			HWPFDocument doc = new HWPFDocument(fis);
			WordExtractor we = new WordExtractor(doc);

			String[] paragraphs = we.getParagraphText();
			wordContent = new StringBuffer(); 

			System.out.println("Total no of paragraph " + paragraphs.length);
			
			for (String para : paragraphs)
				wordContent.append(para);
			
			we.close();
			fis.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		return wordContent.toString();
	}
	public  String readDocxFile(String fileName)
	{
		StringBuffer wordContent = null;

		try
		{
			File file = new File(fileName);
			FileInputStream fis = new FileInputStream(file.getAbsolutePath());

			XWPFDocument document = new XWPFDocument(fis);
			wordContent = new StringBuffer();

			List<XWPFParagraph> paragraphs = document.getParagraphs();

			System.out.println("Total no of paragraph "+paragraphs.size());
			
			for (XWPFParagraph para : paragraphs)
				wordContent.append(para.getText());

			fis.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		return wordContent.toString();
	}
}