package com.account.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * @author kimallap
 *
 */
@Entity
@Table(name="tbl_event_region")
public class Region  implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long region_id;
    private String Region_territory;
    private boolean status;
    
    
    @Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getRegion_id() {
		return region_id;
	}
	public void setRegion_id(Long region_id) {
		this.region_id = region_id;
	}
	
	public String getRegion_territory() {
		return Region_territory;
	}
	public void setRegion_territory(String region_territory) {
		Region_territory = region_territory;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
    



    
}
