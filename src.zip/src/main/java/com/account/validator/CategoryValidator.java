package com.account.validator;

import com.account.model.User;
import com.account.service.CategoryService;
import com.account.service.UserService;
import com.accounts.dto.CategoryBean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class CategoryValidator implements Validator {
    @Autowired
    private CategoryService categoryService;

    @Override
    public boolean supports(Class<?> aClass) {
        return User.class.equals(aClass);
    }

    @Override
    public void validate(Object o, Errors errors) {
       // User user = (User) o;
    	CategoryBean categoryBean=(CategoryBean) o;

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "event_category_name", "NotEmptyCategory");
       
    }
}
//Your username and password is invalid