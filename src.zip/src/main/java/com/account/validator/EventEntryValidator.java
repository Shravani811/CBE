package com.account.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.account.model.EventEntry;
import com.account.service.UserService;
import com.accounts.dto.EventEntryBean;

@Component
public class EventEntryValidator implements Validator {
    
    @Override
    public boolean supports(Class<?> aClass) {
    	return EventEntry.class.equals(aClass);
    }

    @Override
    public void validate(Object o, Errors errors) {
    	EventEntryBean eventEntryBean = (EventEntryBean) o;

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "EventName", "EventNameNotEmpty");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "Description_details", "DescriptionEventNotEmpty");
        
        /*    if (user.getUsername().length() < 6 || user.getUsername().length() > 32) {
            errors.rejectValue("username", "Size.userForm.username");
        }
        if(eventEntry.getEventName().length() <2  || eventEntry.getEventName().length() < 30){
        	errors.rejectValue("eventName", "Size.userForm.eventName");
        }
        if (userService.findByUsername(user.getUsername()) != null) {
            errors.rejectValue("username", "Duplicate.userForm.username");
        }*/

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "Start_date", "StartDateNotEmpty");
        /*if (user.getPassword().length() < 8 || user.getPassword().length() > 32) {
            errors.rejectValue("password", "Size.userForm.password");
        }*/
        
        String dateEnd=eventEntryBean.getEnd_date();
        String dateStart=eventEntryBean.getStart_date();
        if(dateStart.startsWith(",") || dateEnd.startsWith(",")){
 			String startDate1=dateStart.substring(1);
 			String startEnd1=dateEnd.substring(1);
 			
 			if (startDate1.compareTo(startEnd1) > 0) {
 				  errors.rejectValue("Start_date", "Size.EventEntry.Start_date");
 			}
 	          
 			
 		}else {
			
 			if (dateStart.compareTo(dateEnd) > 0) {
				  errors.rejectValue("Start_date", "Size.EventEntry.Start_date");
			}
		}

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "End_date", "EndDateNotEmpty");
        
        /*try {
			Date start = new SimpleDateFormat("yyyy-mm-dd hh:mm", Locale.ENGLISH)
			        .parse(eventEntryBean.getStart_date());
			Date end = new SimpleDateFormat("yyyy-mm-dd hh:mm", Locale.ENGLISH)
			        .parse(eventEntryBean.getEnd_date());
			
			if (start.compareTo(end) > 0){
				errors.rejectValue("Start_date", "Size.EventEntry.Start_date");
			}
			
		} catch (ParseException e) {
			
			e.printStackTrace();
		}*/
        
        /* if (eventEntryBean.getStart_date().compareTo(eventEntryBean.getEnd_date().length())) {
            errors.rejectValue("Start_date", "Size.EventEntry.Start_date");
        }*/
        
        if(eventEntryBean.getStart_date().equals(",")){ 
        	errors.rejectValue("Start_date", "EventEntry.Start_date");
    	}
        
         if(eventEntryBean.getEnd_date().equals(",")){ 
        	 errors.rejectValue("End_date", "EventEntry.End_date");
        	 
    	  }
        
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "eventAppSet", "EventAppNotEmpty");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "eventUserSet", "EventUserNotEmpty");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "Engagement_Name", "EngagementEventNotEmpty");
        
        /*ValidationUtils.rejectIfEmptyOrWhitespace(errors, "Email_receipients", "EmailEventNotEmpty");*/
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "Risk_summary", "RiskSummaryNotEmpty");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "Region_territory", "RegionTerritoryNotEmpty");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "calendar_type_name", "CalendarTypeNameNotEmpty");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "Event_category_Name", "EventCategoryNameNotEmpty");
        
        /*ValidationUtils.rejectIfEmptyOrWhitespace(errors, "recu_every_weekday_radio", "recu_every_weekday_radio");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "recu_every_day", "recu_every_day");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "recu_every_weekday", "recu_every_weekday");*/
        /*if (!user.getPasswordConfirm().equals(user.getPassword())) {
            errors.rejectValue("passwordConfirm", "Diff.userForm.passwordConfirm");
        }*/
    }
}
