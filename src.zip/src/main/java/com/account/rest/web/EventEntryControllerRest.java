package com.account.rest.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.mail.internet.ParseException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.account.model.CalendarType;
import com.account.model.Category;
import com.account.model.EventApplication;
import com.account.model.EventApplicationMaster;
import com.account.model.EventEntry;
import com.account.model.EventEntryMaster;
import com.account.model.EventPlanned;
import com.account.model.EventPlannedBean;
import com.account.model.EventUser;
import com.account.model.FileUpload;
import com.account.model.Region;
import com.account.repository.UserRepository;
import com.account.service.AccountService;
import com.account.service.ApplicationService;
import com.account.service.CalendarService;
import com.account.service.CalendarTypeService;
import com.account.service.CategoryService;
import com.account.service.EventEntryMasterService;
import com.account.service.EventEntryService;
import com.account.service.MailService;
import com.account.service.RegionService;
import com.account.service.UserService;
import com.account.validator.EventEntryValidator;
import com.accounts.dto.CalendarBean;
import com.accounts.dto.EventEntryBean;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.Gson;




/**
 * 
 * @author jaimishr
 *
 */

@Controller
public class EventEntryControllerRest {
	@Autowired
    private EventEntryService eventEntryService;
	
	@Autowired
    private EventEntryMasterService eventEntryServiceMaster;

    @Autowired
    private ApplicationService applicationService;
    
    @Autowired
    private UserService userService;

    @Autowired
    private EventEntryValidator eventEntryValidator;
  
    @Autowired
    private CategoryService categoryService;
    
    @Autowired
    MailService mailService ;
    
    @Autowired
	UserRepository userRepository;
    
    @Autowired
    private RegionService regionService;
    
    @Autowired
    private JavaMailSender mailSender;
    
    @Autowired
    private CalendarTypeService calendartypeService;
    
    @Autowired
    private CalendarTypeService calendarTypeService;
    
    @Autowired
    private AccountService accountService;
    
    String emailid=null;
    
    @Autowired
    private HttpServletRequest httpServletRequest;
    
    
    @RequestMapping(value = "/api/viewEvents", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @JsonIgnoreProperties(ignoreUnknown = true)
	public ResponseEntity<List<EventEntryBean>> viewEvents(HttpServletResponse response) {
       
    	List<EventEntryBean> evnetEntryBeanList=new ArrayList<>();
    	HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		List<EventEntry> eventList = eventEntryService.findAllEventByResource(userAccountName);
    	for(EventEntry event:eventList){
    		if(event.getEventstatus()!=null && !event.getEventstatus().equalsIgnoreCase("Cancelled"))
	    	{
	    		EventEntryBean eventEntryBean=new EventEntryBean();
	    		eventEntryBean.setEvent_ID(event.getEvent_ID());
	    		eventEntryBean.setEventName(event.getEventname());
	    		eventEntryBean.setDescription_details(event.getDescription_details());
	    		eventEntryBean.setStart_date(event.getStart_date());
	    		eventEntryBean.setEnd_date(event.getEnd_date());
	    		//eventEntryBean.setRegion_territory(event.getRegion_territory());
	    		eventEntryBean.setRisk_summary(event.getRisk_summary());
	    		eventEntryBean.setRemarks(event.getRemarks());
	    		if(event.getEvent_file_name() != null) 
	    		{
		    		List<String> fileNameList = Arrays.asList(event.getEvent_file_name().split("\\s*,\\s*"));
		    		eventEntryBean.setEvent_list(fileNameList);
	    		}
	    		//eventEntryBean.setEvent_file_name(event.getEvent_file_name());
	    		//eventEntryBean.setEvent_upld_fix(event.getEvent_upld_fix());
	    		
	    		Region region = regionService.findByRegionId(event.getRegion_id());
				
	            if(region!=null)
	            {
	            	eventEntryBean.setRegion_territory(region.getRegion_territory());
	            }
	    		
	           	Category category=categoryService.findByCategoryId(event.getEvent_category_id());
	    		//System.out.print(category);
	    		
	    		if(category!=null){
	    			eventEntryBean.setEvent_category_Name(category.getEvent_category_name());
	    		}
	    		
	    		String[] eventAppSet =new String[event.getEventAppSet().size()];
	    		int i=0;
	    		
	    		for (EventApplication eventApp : event.getEventAppSet() ) {
	    			
	    			eventAppSet[i]=eventApp.getApplication();
	    			i++;
	    			
	
	    			/*if(i==0){
	    				eventAppStr.append(eventAppSet[i]);
	    				eventAppStr.append(",");
	    			} else {
	    				eventAppStr.append(eventAppSet[i]);
	    			}*/
	    		}
	    		eventEntryBean.setEventAppSet(eventAppSet);
	    		
	    		String[] eventUserSet=new String[event.getEventUserSet().size()];
	    		int j=0;
	    		for(EventUser eventUser:event.getEventUserSet()){
	    			//for(String Username: userService.findByUsername(eventUser))
	    			eventUserSet[j] = eventUser.getResource();
	    			j++;
	    		}
	    		eventUserSet = Arrays.stream(eventUserSet)
	                    .filter(s -> (s != null && s.length() > 0))
	                    .toArray(String[]::new);
	    		
	    		Set<String> userSet = new HashSet<String>(Arrays.asList(eventUserSet));    		
	    		eventUserSet= userSet.toArray(new String[userSet.size()]);
	    		String eventUsersString = String.join(",", eventUserSet);
	    		eventEntryBean.setEventUsers(eventUsersString);
	      		eventEntryBean.setEventUserSet(eventUserSet);
	    		eventEntryBean.setEmail_receipients(event.getAdditional_receipients());
	    		eventEntryBean.setEngagement_Name(event.getEngagement_Name());
	    		evnetEntryBeanList.add(eventEntryBean);
	    	}
    	}
    	
    	 
    /*	List<CalendarBean> evnetCalendarBeanList=new ArrayList<>();
		List<EventEntry> eventList1 = eventEntryService.findAll();
    	for(EventEntry event:eventList){
    		CalendarBean calendarBean=new CalendarBean();
    		//eventEntryBean.setEvent_ID(event.getEvent_ID());
    		calendarBean.setTitle(event.getEventname());
    		//eventEntryBean.setDescription_details(event.getDescription_details());
    		calendarBean.setDescription(event.getDescription_details());
    		calendarBean.setStart(event.getStart_date());
    		calendarBean.setEnd(event.getEnd_date());
    		calendarBean.setEngagement(event.getEngagement_Name());
    		//eventEntryBean.setRegion_territory(event.getRegion_territory());
    		//eventEntryBean.setRisk_summary(event.getRisk_summary());
    		
    		String[] eventAppSet =new String[event.getEventAppSet().size()];
    		int i=0;
    		
    		for (EventApplication eventApp : event.getEventAppSet() ) {
    			
    			eventAppSet[i]=eventApp.getApplication();
    			i++;
    			
    			/*if(i==0){
    				eventAppStr.append(eventAppSet[i]);
    				eventAppStr.append(",");
    			} else {
    				eventAppStr.append(eventAppSet[i]);
    			}
    		}
    		calendarBean.setEventAppSet(eventAppSet);
    		
    		String[] eventUserSet=new String[event.getEventUserSet().size()];
    		int j=0;
    		for(EventUser eventUser:event.getEventUserSet()){
    			/*for(String Username: userService.findByUsername(eventUser))
    			eventUserSet[j] = eventUser.getResource();
    			j++;
    		}
    		calendarBean.setEventUserSet(eventUserSet);
    		
    		evnetCalendarBeanList.add(calendarBean);
    		
    	}
    	
    	
    	Gson gson = new Gson();
    	String calendarJSON=gson.toJson(evnetCalendarBeanList);
    	
    	
      	  model.addAttribute("calendarJSON", calendarJSON);
      	// model.addAttribute("evnetEntryBeanList", evnetCalendarBeanList);*/
    	
    	//model.addAttribute("evnetEntryBeanList", evnetEntryBeanList);
		//model.addAttribute("filePath", dir + File.separator);
    	//model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
         // return new ModelAndView("viewEntry");
    	return new ResponseEntity<>(evnetEntryBeanList, HttpStatus.OK);
    	
    }
    
    @RequestMapping(value = "/api/viewEvents/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @JsonIgnoreProperties(ignoreUnknown = true)
	public ResponseEntity<List<EventEntryBean>> viewEvents(@PathVariable String id, HttpServletResponse response) {
       
    	List<EventEntryBean> evnetEntryBeanList=new ArrayList<>();
    	HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		List<EventEntry> eventList = eventEntryService.findAllEventByResource(userAccountName);
    	for(EventEntry event:eventList){
    		if(event.getEventstatus()!=null && !event.getEventstatus().equalsIgnoreCase("Cancelled"))
	    	{
	    		EventEntryBean eventEntryBean=new EventEntryBean();
	    		eventEntryBean.setEvent_ID(event.getEvent_ID());
	    		eventEntryBean.setEventName(event.getEventname());
	    		eventEntryBean.setDescription_details(event.getDescription_details());
	    		eventEntryBean.setStart_date(event.getStart_date());
	    		eventEntryBean.setEnd_date(event.getEnd_date());
	    		//eventEntryBean.setRegion_territory(event.getRegion_territory());
	    		eventEntryBean.setRisk_summary(event.getRisk_summary());
	    		eventEntryBean.setRemarks(event.getRemarks());
	    		if(event.getEvent_file_name() != null) 
	    		{
		    		List<String> fileNameList = Arrays.asList(event.getEvent_file_name().split("\\s*,\\s*"));
		    		eventEntryBean.setEvent_list(fileNameList);
	    		}
	    		//eventEntryBean.setEvent_file_name(event.getEvent_file_name());
	    		//eventEntryBean.setEvent_upld_fix(event.getEvent_upld_fix());
	    		
	    		Region region = regionService.findByRegionId(event.getRegion_id());
				
	            if(region!=null)
	            {
	            	eventEntryBean.setRegion_territory(region.getRegion_territory());
	            }
	    		
	           	Category category=categoryService.findByCategoryId(event.getEvent_category_id());
	    		//System.out.print(category);
	    		
	    		if(category!=null){
	    			eventEntryBean.setEvent_category_Name(category.getEvent_category_name());
	    		}
	    		
	    		String[] eventAppSet =new String[event.getEventAppSet().size()];
	    		int i=0;
	    		
	    		for (EventApplication eventApp : event.getEventAppSet() ) {
	    			
	    			eventAppSet[i]=eventApp.getApplication();
	    			i++;
	    			
	
	    			/*if(i==0){
	    				eventAppStr.append(eventAppSet[i]);
	    				eventAppStr.append(",");
	    			} else {
	    				eventAppStr.append(eventAppSet[i]);
	    			}*/
	    		}
	    		eventEntryBean.setEventAppSet(eventAppSet);
	    		
	    		String[] eventUserSet=new String[event.getEventUserSet().size()];
	    		int j=0;
	    		for(EventUser eventUser:event.getEventUserSet()){
	    			//for(String Username: userService.findByUsername(eventUser))
	    			eventUserSet[j] = eventUser.getResource();
	    			j++;
	    		}
	    		eventUserSet = Arrays.stream(eventUserSet)
	                    .filter(s -> (s != null && s.length() > 0))
	                    .toArray(String[]::new);
	    		
	    		Set<String> userSet = new HashSet<String>(Arrays.asList(eventUserSet));    		
	    		eventUserSet= userSet.toArray(new String[userSet.size()]);
	    		String eventUsersString = String.join(",", eventUserSet);
	    		eventEntryBean.setEventUsers(eventUsersString);
	      		eventEntryBean.setEventUserSet(eventUserSet);
	    		eventEntryBean.setEmail_receipients(event.getAdditional_receipients());
	    		eventEntryBean.setEngagement_Name(event.getEngagement_Name());
	    		evnetEntryBeanList.add(eventEntryBean);
	    	}
    	}
    	
    	 
    /*	List<CalendarBean> evnetCalendarBeanList=new ArrayList<>();
		List<EventEntry> eventList1 = eventEntryService.findAll();
    	for(EventEntry event:eventList){
    		CalendarBean calendarBean=new CalendarBean();
    		//eventEntryBean.setEvent_ID(event.getEvent_ID());
    		calendarBean.setTitle(event.getEventname());
    		//eventEntryBean.setDescription_details(event.getDescription_details());
    		calendarBean.setDescription(event.getDescription_details());
    		calendarBean.setStart(event.getStart_date());
    		calendarBean.setEnd(event.getEnd_date());
    		calendarBean.setEngagement(event.getEngagement_Name());
    		//eventEntryBean.setRegion_territory(event.getRegion_territory());
    		//eventEntryBean.setRisk_summary(event.getRisk_summary());
    		
    		String[] eventAppSet =new String[event.getEventAppSet().size()];
    		int i=0;
    		
    		for (EventApplication eventApp : event.getEventAppSet() ) {
    			
    			eventAppSet[i]=eventApp.getApplication();
    			i++;
    			
    			/*if(i==0){
    				eventAppStr.append(eventAppSet[i]);
    				eventAppStr.append(",");
    			} else {
    				eventAppStr.append(eventAppSet[i]);
    			}
    		}
    		calendarBean.setEventAppSet(eventAppSet);
    		
    		String[] eventUserSet=new String[event.getEventUserSet().size()];
    		int j=0;
    		for(EventUser eventUser:event.getEventUserSet()){
    			/*for(String Username: userService.findByUsername(eventUser))
    			eventUserSet[j] = eventUser.getResource();
    			j++;
    		}
    		calendarBean.setEventUserSet(eventUserSet);
    		
    		evnetCalendarBeanList.add(calendarBean);
    		
    	}
    	
    	
    	Gson gson = new Gson();
    	String calendarJSON=gson.toJson(evnetCalendarBeanList);
    	
    	
      	  model.addAttribute("calendarJSON", calendarJSON);
      	// model.addAttribute("evnetEntryBeanList", evnetCalendarBeanList);*/
    	
    	//model.addAttribute("evnetEntryBeanList", evnetEntryBeanList);
		//model.addAttribute("filePath", dir + File.separator);
    	//model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
         // return new ModelAndView("viewEntry");
    	List<EventEntryBean> eve = new ArrayList<EventEntryBean>();
    	for(EventEntryBean e: evnetEntryBeanList){
    		if(!StringUtils.isEmpty(id) && e.getEvent_ID() == Long.parseLong(id)){
    			eve.add(e);
    		}
    	}
    	
    	return new ResponseEntity<>(eve, HttpStatus.OK);
    	
    }
    
}
