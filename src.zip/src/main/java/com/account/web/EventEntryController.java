package com.account.web;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.ParseException;
import javax.persistence.Column;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.format.CellFormatType;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFDataFormat;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.account.model.CalendarType;
import com.account.model.Category;
import com.account.model.EventActual;
import com.account.model.EventApplication;
import com.account.model.EventApplicationMaster;
import com.account.model.EventEntry;
import com.account.model.EventEntryMaster;
import com.account.model.EventPlanned;
import com.account.model.EventUser;
import com.account.model.FileUpload;
import com.account.model.Region;
import com.account.repository.EventActualRepository;
import com.account.repository.EventEntryRepository;
import com.account.repository.EventPlannedRepository;
import com.account.repository.UserRepository;
import com.account.service.AccountService;
import com.account.service.ApplicationService;
import com.account.service.CalendarService;
import com.account.service.CalendarTypeService;
import com.account.service.CategoryService;
import com.account.service.EventEntryMasterService;
import com.account.service.EventEntryService;
import com.account.service.MailService;
import com.account.service.RegionService;
import com.account.service.UserService;
import com.account.validator.EventEntryValidator;
import com.accounts.dto.CalendarBean;
import com.accounts.dto.EventEntryBean;
import com.accounts.emailService.ReportMailService;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.Gson;

import edu.emory.mathcs.backport.java.util.Collections;

/**
 * 
 * @author jaimishr
 *
 */

@Controller
public class EventEntryController {
	private static final int CELL_TYPE_STRING = 0;
	
	public static final LocalDateTime currD = LocalDateTime.now();

	@Autowired
	private EventEntryService eventEntryService;

	@Autowired
	private EventEntryMasterService eventEntryServiceMaster;

	@Autowired
	private ApplicationService applicationService;

	@Autowired
	private UserService userService;

	@Autowired
	private EventEntryValidator eventEntryValidator;

	@Autowired
	private CategoryService categoryService;

	@Autowired
	MailService mailService;

	@Autowired
	UserRepository userRepository;

	@Autowired
	private RegionService regionService;

	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	private CalendarTypeService calendartypeService;

	@Autowired
	private CalendarTypeService calendarTypeService;

	@Autowired
	private AccountService accountService;

	@Autowired
	private EventEntryMasterService eventEntryMasterService;

	@Autowired
	private EventEntryRepository eventEntryRepository;

	@Autowired
	private EventActualRepository eventActualRepository;

	@Autowired
	private EventPlannedRepository eventPlannedRepository;

	String emailid = null;

	@Autowired
	private HttpServletRequest httpServletRequest;

	/*
	 * @Configuration public class RestSecurityConfig extends
	 * WebSecurityConfigurerAdapter {
	 * 
	 * @Override protected void configure(HttpSecurity http) throws Exception {
	 * http.csrf().disable(); } }
	 */

	String rootPath = System.getProperty("catalina.home");
	// File dir = new File(rootPath + File.separator + "tmpFiles");
	File dir = new File(rootPath + "\\webapps\\CBE_V2\\resources\\files\\");

	@RequestMapping(value = "/addEntry", method = RequestMethod.GET)
	public ModelAndView addEntry(Model model, @ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean) {
		List<String> appList = applicationService.getAppNames();
		List<String> rescList = userService.getResourceNames();
		List<String> catList = categoryService.getCategoryName();
		// account based select eventList
		HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");

		List<String> eventList = eventEntryServiceMaster.getEventNameByAcctName(userAccountName);
		List<String> regList = regionService.getRegionTerritory();
		List<String> caltypList = calendartypeService.getCalendarTypeName();
		List<String> accList = accountService.getAccountNames();
		// EventEntryBean eventEntry = new EventEntryBean();
		model.addAttribute("eventEntryBean", eventEntryBean);
		model.addAttribute("eventList", eventList);
		model.addAttribute("appNameList", appList);
		model.addAttribute("rescNameList", rescList);
		model.addAttribute("catgoryList", catList);
		model.addAttribute("regionList", regList);
		model.addAttribute("caltypList", caltypList);
		model.addAttribute("accountList", accList);

		model.addAttribute("userAccountName", userAccountName);

		/*
		 * Gson gson = new Gson(); String calendarJSON=gson.toJson(eventList);
		 */

		List<HashMap<String, String>> listMastp = applicationService.getPriAndSecResourceName();
		Gson gson = new Gson();
		String applicationEventJson = gson.toJson(listMastp);
		model.addAttribute("eventEntryJsonStr", applicationEventJson);
		model.addAttribute("filePath", dir + File.separator);
		model.addAttribute("calendarType",
				StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("addEntry");
	}

	@RequestMapping(value = "/searchIncidents", method = RequestMethod.GET)
	public ModelAndView searchIncidentsUpdating(Model model,
			@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean) {
		// account based select eventList
		HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		List<String> appList = applicationService.getAppNames();
		model.addAttribute("eventEntryBean", eventEntryBean);
		model.addAttribute("userAccountName", userAccountName);
		model.addAttribute("appNameList", appList);
		return new ModelAndView("searchIncidents");
	}

	@RequestMapping(value = "/searchIncidentsNew", method = RequestMethod.POST)
	public ModelAndView searchIncidents(@RequestParam("event") EventEntry event, Model model,
			@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean) {
		// account based select eventList
		HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		List<String> appList = applicationService.getAppNames();
		model.addAttribute("eventEntryBean", eventEntryBean);
		model.addAttribute("userAccountName", userAccountName);
		model.addAttribute("appNameList", appList);
		return new ModelAndView("searchIncidents");
	}

	/*
	 * @RequestMapping(value = "/searchIncidents", method = RequestMethod.GET)
	 * public ModelAndView searchIncidents(Model
	 * model,@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean) {
	 * //account based select eventList HttpSession httpSession =
	 * httpServletRequest.getSession(); String userAccountName = (String)
	 * httpSession.getAttribute("userAcctName"); List<String> appList =
	 * applicationService.getAppNames(); model.addAttribute("eventEntryBean",
	 * eventEntryBean); model.addAttribute("userAccountName",userAccountName);
	 * model.addAttribute("appNameList",appList); return new
	 * ModelAndView("searchIncidents"); }
	 * 
	 * @RequestMapping(value = "/allIncidentsList", method = RequestMethod.POST)
	 * public String allIncidentsList(@ModelAttribute("eventEntryBean")
	 * EventEntryBean eventEntryBean, BindingResult bindingResult, Model model) {
	 * String accName = eventEntryBean.getEngagement_Name(); String startDate =
	 * eventEntryBean.getStart_date(); String endDate =
	 * eventEntryBean.getEnd_date(); String applicationName =
	 * eventEntryBean.getApplicationName(); //List<HashMap<String, Object>>
	 * all_incidents = userService.getAllIncidents(accName,applicationName,
	 * startDate, endDate); List<HashMap<String, Object>> all_incidents =
	 * userService.getAllIncidents(accName,applicationName, startDate, endDate);
	 * List allIncidentsList = new ArrayList<>(); if(!all_incidents.isEmpty() &&
	 * all_incidents != null) { for (HashMap<String, Object> allIncidentsMap :
	 * all_incidents) { Iterator<Entry<String, Object>> it =
	 * allIncidentsMap.entrySet().iterator(); IncidentBean incidentBean = new
	 * IncidentBean(); while (it.hasNext()) { Map.Entry pair = (Map.Entry)it.next();
	 * if(checkKeyValueNull(pair) &&
	 * "Incident_ID".equalsIgnoreCase(pair.getKey().toString()))
	 * incidentBean.setIncident_ID(pair.getValue().toString());
	 * if(checkKeyValueNull(pair) &&
	 * "Reported_Date".equalsIgnoreCase(pair.getKey().toString()))
	 * incidentBean.setReported_Date(pair.getValue().toString());
	 * if(checkKeyValueNull(pair) &&
	 * "Summary".equalsIgnoreCase(pair.getKey().toString()))
	 * incidentBean.setSummary(pair.getValue().toString());
	 * if(checkKeyValueNull(pair) &&
	 * "Notes".equalsIgnoreCase(pair.getKey().toString()))
	 * incidentBean.setNotes(pair.getValue().toString()); }
	 * incidentBean.setStartDate(startDate); incidentBean.setEndDate(endDate);
	 * eventEntryService.saveIncidents(incidentBean);
	 * allIncidentsList.add(incidentBean); } }
	 * 
	 * mailService.sendMail("dactoolssupport.in@capgemini.com",
	 * "dactoolssupport.in@capgemini.com",
	 * +allIncidentsList.size()+" incidents occured in period "+startDate+" to "
	 * +endDate);
	 * 
	 * model.addAttribute("allIncidentsList", allIncidentsList); return
	 * "allIncidents"; }
	 */

	public static HashMap<String, String> getWorkingDaysBetweenTwoDates(Date startDate, Date endDate, boolean isWeekDay,
			String recurrenceDays) throws java.text.ParseException {
		Calendar startCal = Calendar.getInstance();
		startCal.setTime(startDate);
		Integer recDays = Integer.parseInt(recurrenceDays);
		Calendar endCal = Calendar.getInstance();
		endCal.setTime(endDate);

		// Return 0 if start and end are the same
		HashMap<String, String> map = new HashMap<>();
		if (startCal.getTimeInMillis() == endCal.getTimeInMillis()) {
			return map;
		}

		if (startCal.getTimeInMillis() > endCal.getTimeInMillis()) {
			startCal.setTime(endDate);
			endCal.setTime(startDate);
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		String pattern = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String date = simpleDateFormat.format(startCal.getTime());
		System.out.println(date);

		String pattern2 = "HH:mm:ss";
		SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat(pattern2);
		String time = simpleDateFormat2.format(endCal.getTime());

		/*
		 * if (isWeekDay == true && startCal.get(Calendar.DAY_OF_WEEK) !=
		 * Calendar.SATURDAY && startCal.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
		 * String date1 = simpleDateFormat.format(startCal.getTime());
		 * System.out.println(": weekdays only :");
		 * System.out.println(sdf.format(startCal.getTime()) +"= "+date1+" "+time);
		 * map.put(sdf.format(startCal.getTime()), date1+" "+time); } if (isWeekDay ==
		 * false) { String date1 = simpleDateFormat.format(startCal.getTime());
		 * System.out.println(": all days :");
		 * System.out.println(sdf.format(startCal.getTime()) +"= "+date1+" "+time);
		 * map.put(sdf.format(startCal.getTime()), date1+" "+time); }
		 */

		do {
			// excluding start date
			if (isWeekDay == true && startCal.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY
					&& startCal.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
				String date1 = simpleDateFormat.format(startCal.getTime());
				System.out.println(": weekdays only :");
				System.out.println(sdf.format(startCal.getTime()) + "= " + date1 + " " + time);
				map.put(sdf.format(startCal.getTime()), date1 + " " + time);
				// startCal.add(Calendar.DATE, recDays);
			}
			if (isWeekDay == false) {
				String date1 = simpleDateFormat.format(startCal.getTime());
				System.out.println(": all days :");
				System.out.println(sdf.format(startCal.getTime()) + "= " + date1 + " " + time);
				map.put(sdf.format(startCal.getTime()), date1 + " " + time);

			}
			startCal.add(Calendar.DATE, recDays);
		} while (startCal.getTimeInMillis() < endCal.getTimeInMillis()); // excluding end date
		return map;
	}

	/*
	 * @RequestMapping(value = "/allCauseCodes", method = RequestMethod.POST) public
	 * String allIncidentsListUpdating(@ModelAttribute("eventEntryBean")
	 * EventEntryBean eventEntryBean, BindingResult bindingResult, Model model)
	 * throws java.text.ParseException { String accName =
	 * eventEntryBean.getEngagement_Name(); //String startDate =
	 * eventEntryBean.getStart_date(); //String endDate =
	 * eventEntryBean.getEnd_date(); //List<HashMap<String, Object>> all_incidents =
	 * userService.getAllIncidents(accName,applicationName, startDate, endDate);
	 * 
	 * List<HashMap<String, String>> all_incidents1 = new ArrayList<HashMap<String,
	 * String>>(); HashMap<String, String> map = new HashMap<>(); //SimpleDateFormat
	 * sdf = new SimpleDateFormat("dd-M-yyyy hh:mm:ss"); SimpleDateFormat sdf = new
	 * SimpleDateFormat( "yyyy-MM-dd'T'HH:mm" ); //String dateInString =
	 * "6-12-2018 10:20:56"; String dateInString =
	 * eventEntryBean.getStart_date()+"T"+eventEntryBean.getStart_time(); Date
	 * startDate = sdf.parse(dateInString);
	 * 
	 * //String dateInEndString = "12-12-2018 12:40:56"; String dateInEndString =
	 * eventEntryBean.getEnd_date()+"T"+eventEntryBean.getEnd_time(); Date endDate =
	 * sdf.parse(dateInEndString); HashMap<String, String> weekdaysList = new
	 * HashMap<>(); boolean isWeekDay = false; List<HashMap<String, String>>
	 * all_incidents = new ArrayList<>(); if(eventEntryBean.getRecurrence_type() !=
	 * null && eventEntryBean.getRecurrence_type().equalsIgnoreCase("daily") &&
	 * eventEntryBean.getRecu_every_day() != null) { isWeekDay = false; weekdaysList
	 * = EventEntryController.getWorkingDaysBetweenTwoDates(startDate,
	 * endDate,isWeekDay, eventEntryBean.getRecu_every_day()); for
	 * (Map.Entry<String,String> entry : weekdaysList.entrySet()) { all_incidents1 =
	 * userService.getAllIncidentsByDaily(accName,eventEntryBean.getApplicationName(
	 * ), entry.getKey(),
	 * entry.getValue(),eventEntryBean.getRecurrence_type(),eventEntryBean.
	 * getRecu_every_day()); all_incidents.addAll(all_incidents1); }
	 * System.out.println(all_incidents.size()); } else
	 * if(eventEntryBean.getRecurrence_type() != null &&
	 * eventEntryBean.getRecurrence_type().equalsIgnoreCase("daily") &&
	 * eventEntryBean.getRecu_every_weekday() != null) { isWeekDay = true; String
	 * defaultValue = "1"; weekdaysList =
	 * EventEntryController.getWorkingDaysBetweenTwoDates(startDate,
	 * endDate,isWeekDay,defaultValue); for (Map.Entry<String,String> entry :
	 * weekdaysList.entrySet()) { all_incidents1 =
	 * userService.getAllIncidentsByDaily(accName,eventEntryBean.getApplicationName(
	 * ), entry.getKey(),
	 * entry.getValue(),eventEntryBean.getRecurrence_type(),eventEntryBean.
	 * getRecu_every_day()); all_incidents.addAll(all_incidents1); }
	 * System.out.println(all_incidents.size()); }
	 * 
	 * else if(eventEntryBean.getRecurrence_type() != null &&
	 * eventEntryBean.getRecurrence_type().equalsIgnoreCase("weekly") &&
	 * eventEntryBean.getRecurrence_dayName() != null &&
	 * eventEntryBean.getRecu_every_week() != null) { String days =
	 * eventEntryBean.getRecurrence_dayName(); String recurrenceWeeks =
	 * eventEntryBean.getRecu_every_week(); weekdaysList =
	 * EventEntryController.getPerticualerWeekOfDaysBetweenTwoDates(startDate,
	 * endDate,days,recurrenceWeeks); for (Map.Entry<String,String> entry :
	 * weekdaysList.entrySet()) { all_incidents1 =
	 * userService.getAllIncidentsByDaily(accName,eventEntryBean.getApplicationName(
	 * ), entry.getKey(),
	 * entry.getValue(),eventEntryBean.getRecurrence_type(),eventEntryBean.
	 * getRecu_every_day()); all_incidents.addAll(all_incidents1); }
	 * System.out.println(all_incidents.size()); } else
	 * if(eventEntryBean.getRecurrence_type() != null &&
	 * eventEntryBean.getRecurrence_type().equalsIgnoreCase("monthly") &&
	 * !eventEntryBean.getRecu_month_day().equalsIgnoreCase("") &&
	 * !eventEntryBean.getRecu_every_month().equalsIgnoreCase("")) { String days =
	 * eventEntryBean.getRecu_month_day(); String recurrenceMonths =
	 * eventEntryBean.getRecu_every_month(); weekdaysList =
	 * EventEntryController.getPerticualerMonthDaysBetweenTwoDates(startDate,
	 * endDate,days,recurrenceMonths); for (Map.Entry<String,String> entry :
	 * weekdaysList.entrySet()) { all_incidents1 =
	 * userService.getAllIncidentsByDaily(accName,eventEntryBean.getApplicationName(
	 * ), entry.getKey(),
	 * entry.getValue(),eventEntryBean.getRecurrence_type(),eventEntryBean.
	 * getRecu_every_day()); all_incidents.addAll(all_incidents1); }
	 * System.out.println(all_incidents.size()); }
	 * 
	 * List<IncidentBean> allIncidentsList = new ArrayList<>(); HashMap<String,
	 * List> incidentsList = new HashMap<>(); if(!all_incidents.isEmpty() &&
	 * all_incidents != null) { for (HashMap<String, String> allIncidentsMap :
	 * all_incidents) { Iterator<Entry<String, String>> it =
	 * allIncidentsMap.entrySet().iterator(); IncidentBean incidentBean = new
	 * IncidentBean(); while (it.hasNext()) { Map.Entry pair = (Map.Entry)it.next();
	 * if(checkKeyValueNull(pair) &&
	 * "Incident_ID".equalsIgnoreCase(pair.getKey().toString()))
	 * incidentBean.setIncident_ID(pair.getValue().toString());
	 * if(checkKeyValueNull(pair) &&
	 * "Reported_Date".equalsIgnoreCase(pair.getKey().toString()))
	 * incidentBean.setReported_Date(pair.getValue().toString());
	 * if(checkKeyValueNull(pair) &&
	 * "appName".equalsIgnoreCase(pair.getKey().toString()))
	 * incidentBean.setApp_Name(pair.getValue().toString());
	 * if(checkKeyValueNull(pair) &&
	 * "token".equalsIgnoreCase(pair.getKey().toString()))
	 * incidentBean.setCausecode_id(pair.getValue().toString()); }
	 * incidentBean.setStartDate(startDate.toString());
	 * incidentBean.setEndDate(endDate.toString());
	 * eventEntryService.saveIncidents(incidentBean);
	 * allIncidentsList.add(incidentBean); } }
	 * 
	 * Map<String,List<String>> map1 = new HashMap<String,List<String>>();
	 * List<String> list = new ArrayList<>(); List<String> dummy=new ArrayList<>();
	 * 
	 * for (IncidentBean incidentBean : allIncidentsList) {
	 * if(!dummy.contains(incidentBean.getCausecode_id())) {
	 * dummy.add(incidentBean.getCausecode_id());
	 * 
	 * for (IncidentBean incidentBeann : allIncidentsList) {
	 * if(incidentBean.getCausecode_id().equalsIgnoreCase(incidentBeann.
	 * getCausecode_id())) { list.add(incidentBeann.getIncident_ID());
	 * map1.put(incidentBean.getCausecode_id(), list); } } } list = new
	 * ArrayList<>(); } String sendMailReturnValue = null;
	 * //mailService.sendMail("dactoolssupport.in@capgemini.com", "Incidents List",
	 * +allIncidentsList.size()+" incidents occured in period "+startDate+" to "
	 * +endDate); sendMailReturnValue =
	 * mailService.sendEmail("dactoolssupport.in@capgemini.com","Incidents List",
	 * +allIncidentsList.size()+" incidents occured in period "+startDate+" to "
	 * +endDate); if(sendMailReturnValue.equalsIgnoreCase("smtpErrorPage")) {
	 * model.addAttribute("mailserverIssue",
	 * "There is an Error Connecting to Mail Server, Kindly wait for some time and try again!! If the problem persist, Please Contact Technical Support Team na-am-industrialization-bangalore.in@capgemini.com"
	 * ); List<String> appList = applicationService.getAppNames();
	 * model.addAttribute("appNameList",appList); return "searchIncidents"; } Gson
	 * gson = new Gson(); if(eventEntryBean.getRecurrence_dayName() != null) {
	 * List<String> recurrence_dayNameList = new
	 * ArrayList<String>(Arrays.asList(eventEntryBean.getRecurrence_dayName().split(
	 * ","))); String recurrence_dayNamesJson = gson.toJson(recurrence_dayNameList);
	 * model.addAttribute("recurrence_dayNamesJson", recurrence_dayNamesJson); }
	 * model.addAttribute("allIncidentsList", allIncidentsList); HttpSession
	 * httpSession = httpServletRequest.getSession();
	 * httpSession.setAttribute("map1",map1); model.addAttribute("causecodeList",
	 * map1);
	 * 
	 * return "allIncidents"; }
	 */

	@RequestMapping(value = "/searchIncidentsUpdating", method = RequestMethod.GET)
	public ModelAndView displayIncidents(Model model, @ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean) {
		String hiddenIncident = eventEntryBean.getHiddenIncidentValue();
		// account based select eventList
		HttpSession httpSession = httpServletRequest.getSession();
		Map<String, List<String>> map1 = new HashMap<String, List<String>>();
		map1 = (Map<String, List<String>>) httpSession.getAttribute("map1");
		// using for-each loop for iteration over Map.entrySet()
		/*
		 * for (Entry<String, List<String>> entry : map1.entrySet()) {
		 * if(entry.getKey().equalsIgnoreCase(id)) {
		 * model.addAttribute("incidentsList",entry.getValue()); }
		 * System.out.println("Key = " + entry.getKey() + ", Value = " +
		 * entry.getValue()); }
		 */
		model.addAttribute("causecodeMap", map1);
		return new ModelAndView("causeCodeIncidents");
	}

	/*
	 * private static HashMap<String, String>
	 * getPerticualerWeekOfDaysBetweenTwoDates(Date startDate, Date endDate) { //
	 * TODO Auto-generated method stub return null; }
	 */

	public static HashMap<String, String> getPerticualerMonthDaysBetweenTwoDates(Date startDate, Date endDate,
			String day, String recurrenceMonths) {
		Integer recDays = Integer.parseInt(recurrenceMonths);
		Calendar startCal = Calendar.getInstance();
		startCal.setTime(startDate);

		Calendar endCal = Calendar.getInstance();
		endCal.setTime(endDate);

		// Return 0 if start and end are the same
		if (startCal.getTimeInMillis() == endCal.getTimeInMillis()) {
			return new HashMap<>();
		}

		if (startCal.getTimeInMillis() > endCal.getTimeInMillis()) {
			startCal.setTime(endDate);
			endCal.setTime(startDate);
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		String pattern = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String date = simpleDateFormat.format(startCal.getTime());
		System.out.println(date);

		String pattern2 = "HH:mm:ss";
		SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat(pattern2);
		String time = simpleDateFormat2.format(endCal.getTime());
		System.out.println(time);
		HashMap<String, String> map = new HashMap<>();
		do {
			if (startCal.get(Calendar.DAY_OF_MONTH) == Integer.parseInt(day)) {
				String date11 = simpleDateFormat.format(startCal.getTime());
				System.out.println("startDate: " + startCal.getTime() + " EndDate: " + date11 + " " + time);
				map.put(sdf.format(startCal.getTime()), date11 + " " + time);
				startCal.add(Calendar.MONTH, recDays - 1);
			}
			startCal.add(Calendar.DATE, 1);

		} while (startCal.getTimeInMillis() < endCal.getTimeInMillis()); // excluding end date
		return map;

	}

	public static HashMap<String, String> getPerticualerWeekOfDaysBetweenTwoDates(Date startDate, Date endDate,
			String days, String recurrenceWeeks) throws java.text.ParseException {

		Integer recDays = Integer.parseInt(recurrenceWeeks);
		Calendar startCal = Calendar.getInstance();
		startCal.setTime(startDate);

		Calendar endCal = Calendar.getInstance();
		endCal.setTime(endDate);

		// Return 0 if start and end are the same
		if (startCal.getTimeInMillis() == endCal.getTimeInMillis()) {
			return new HashMap<>();
		}

		if (startCal.getTimeInMillis() > endCal.getTimeInMillis()) {
			startCal.setTime(endDate);
			endCal.setTime(startDate);
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		String pattern = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String date = simpleDateFormat.format(startCal.getTime());
		System.out.println(date);

		String pattern2 = "HH:mm:ss";
		SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat(pattern2);
		String time = simpleDateFormat2.format(endCal.getTime());
		HashMap<String, String> map = new HashMap<>();
		String[] day_of_weeks = days.split(",");
		long l = startCal.getTimeInMillis();
		int defaultValue = 1;
		for (String day_of_week : day_of_weeks) {
			do {
				if ("MO".equalsIgnoreCase(day_of_week)) {
					day_of_week = "1";
				} else if ("TU".equalsIgnoreCase(day_of_week)) {
					day_of_week = "2";
				} else if ("WE".equalsIgnoreCase(day_of_week)) {
					day_of_week = "3";
				} else if ("TH".equalsIgnoreCase(day_of_week)) {
					day_of_week = "4";
				} else if ("FR".equalsIgnoreCase(day_of_week)) {
					day_of_week = "5";
				} else if ("SA".equalsIgnoreCase(day_of_week)) {
					day_of_week = "6";
				} else if ("SU".equalsIgnoreCase(day_of_week)) {
					day_of_week = "7";
				}

				if (startCal.get(Calendar.DAY_OF_WEEK) == Integer.parseInt(day_of_week)) {
					String date11 = simpleDateFormat.format(startCal.getTime());
					System.out.println("startDate: " + startCal.getTime() + " EndDate: " + date11 + " " + time);
					map.put(sdf.format(startCal.getTime()), date11 + " " + time);
					startCal.add(Calendar.WEEK_OF_MONTH, recDays - 1);
				}
				startCal.add(Calendar.DATE, defaultValue);
			} while (startCal.getTimeInMillis() < endCal.getTimeInMillis());
			startCal.setTimeInMillis(l);
		}
		return map;
	}

	private boolean checkKeyValueNull(Map.Entry pair) {
		return (null != pair.getKey() && !com.mysql.jdbc.StringUtils.isNullOrEmpty(String.valueOf(pair.getKey()))
				&& null != pair.getValue()
				&& !com.mysql.jdbc.StringUtils.isNullOrEmpty(String.valueOf(pair.getValue())));
	}

	@RequestMapping(value = "/addEntryLoad", method = RequestMethod.GET)
	public ModelAndView addEntryLoad(@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean,
			BindingResult bindingResult, Model model) {
		List<String> appList = applicationService.getAppNames();
		List<String> rescList = userService.getResourceNames();
		List<String> catList = categoryService.getCategoryName();
		List<String> eventEntryMaster = eventEntryServiceMaster.getEventName();
		List<String> regList = regionService.getRegionTerritory();

		// eventEntryBean.setRemarks(eventEntryBean.getRemarks());
		String name = eventEntryBean.getEventName();
		// String remarks = eventEntryBean.getRemarks();
		// String eventName = name.substring( 0, name.length( ) - ", ".length( ) );
		/*
		 * if (name.endsWith(",")) { String names = name.substring(0, name.length() -
		 * 1);
		 */
		if (name.contains(",")) {

			String st[] = name.split(", ");

			String names = st[0];

			EventEntryMaster eventEntryMasterByName = eventEntryServiceMaster.findByEventName(names);

			if (eventEntryMasterByName != null) {
				eventEntryBean.setEvent_ID(eventEntryMasterByName.getEvent_ID());
				eventEntryBean.setEventName(eventEntryMasterByName.getEventname());
				eventEntryBean.setDescription_details(eventEntryMasterByName.getDescription_details());
				eventEntryBean.setEmail_receipients(eventEntryMasterByName.getAdditional_receipients());
				eventEntryBean.setEngagement_Name(eventEntryMasterByName.getEngagement_Name());
				eventEntryBean.setRemarks(eventEntryMasterByName.getRemarks());

				Region region = regionService.findByRegionId(eventEntryMasterByName.getRegion_id());

				if (region != null) {
					eventEntryBean.setRegion_territory(region.getRegion_territory());
				}

				Category category = categoryService.findByCategoryId(eventEntryMasterByName.getEvent_category_id());

				if (category != null) {
					eventEntryBean.setEvent_category_Name(category.getEvent_category_name());
				}

				String[] eventAppSet = new String[eventEntryMasterByName.getEventAppSet().size()];
				int i = 0;

				for (EventApplicationMaster eventApp : eventEntryMasterByName.getEventAppSet()) {

					eventAppSet[i] = eventApp.getApplication();
					i++;

					/*
					 * if(i==0){ eventAppStr.append(eventAppSet[i]); eventAppStr.append(","); } else
					 * { eventAppStr.append(eventAppSet[i]); }
					 */
				}
				eventEntryBean.setEventAppSet(eventAppSet);

				// eventEntryBean.setRegion_territory(eventEntryMasterByName.getRegion_territory());

				eventEntryBean.setRisk_summary(eventEntryMasterByName.getRisk_summary());

			}

		} else {
			EventEntryMaster eventEntryMasterByName = eventEntryServiceMaster.findByEventName(name);

			if (eventEntryMasterByName != null) {
				eventEntryBean.setEvent_ID(eventEntryMasterByName.getEvent_ID());
				eventEntryBean.setEventName(eventEntryMasterByName.getEventname());
				eventEntryBean.setDescription_details(eventEntryMasterByName.getDescription_details());
				eventEntryBean.setEmail_receipients(eventEntryMasterByName.getAdditional_receipients());
				eventEntryBean.setEngagement_Name(eventEntryMasterByName.getEngagement_Name());
				eventEntryBean.setRemarks(eventEntryMasterByName.getRemarks());

				Region region = regionService.findByRegionId(eventEntryMasterByName.getRegion_id());

				if (region != null) {
					eventEntryBean.setRegion_territory(region.getRegion_territory());
				}

				Category category = categoryService.findByCategoryId(eventEntryMasterByName.getEvent_category_id());

				if (category != null) {
					eventEntryBean.setEvent_category_Name(category.getEvent_category_name());
				}

				String[] eventAppSet = new String[eventEntryMasterByName.getEventAppSet().size()];
				int i = 0;

				for (EventApplicationMaster eventApp : eventEntryMasterByName.getEventAppSet()) {

					eventAppSet[i] = eventApp.getApplication();
					i++;
				}
				eventEntryBean.setEventAppSet(eventAppSet);
				eventEntryBean.setRisk_summary(eventEntryMasterByName.getRisk_summary());
			}

		}

		model.addAttribute("eventList", eventEntryMaster);
		model.addAttribute("appNameList", appList);
		model.addAttribute("rescNameList", rescList);
		model.addAttribute("catgoryList", catList);
		model.addAttribute("eventEntryBean", eventEntryBean);
		model.addAttribute("regionList", regList);
		model.addAttribute("filePath", dir + File.separator);
		/*
		 * Gson gson = new Gson(); String calendarJSON=gson.toJson(eventList);
		 */
		model.addAttribute("calendarType",
				StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("addEntry");
	}

	@RequestMapping(value = "/addEntryLoad", method = RequestMethod.POST)
	public ModelAndView addEntryLoad1(@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean,
			BindingResult bindingResult, Model model) {
		eventEntryBean.setEventUserSet(eventEntryBean.getHiddenuser());
		eventEntryValidator.validate(eventEntryBean, bindingResult);
		if (bindingResult.hasErrors()) {
			// @PathVariable Long id,
			List<String> appList = applicationService.getAppNames();
			List<String> rescList = userService.getResourceNames();
			List<String> catList = categoryService.getCategoryName();
			List<String> eventList = eventEntryServiceMaster.getEventName();
			List<String> regList = regionService.getRegionTerritory();

			model.addAttribute("eventEntryBean", eventEntryBean);
			model.addAttribute("eventList", eventList);
			model.addAttribute("appNameList", appList);
			model.addAttribute("rescNameList", rescList);
			model.addAttribute("catgoryList", catList);
			model.addAttribute("regionList", regList);

			return new ModelAndView("addEntry");
		}

		eventEntryService.save(eventEntryBean);

		String remarks = eventEntryBean.getRemarks();
		String startSate = eventEntryBean.getStart_date() + "T" + eventEntryBean.getStart_time();
		String endDate = eventEntryBean.getEnd_date() + "T" + eventEntryBean.getEnd_time();
		String emailID = eventEntryBean.getEmail_receipients();

		if (emailID.startsWith(",") || endDate.startsWith(",") || startSate.startsWith(",")
				|| remarks.startsWith(".")) {

			String startDate1 = startSate.substring(1);
			String end = endDate.substring(1);
			String remarks1 = remarks.substring(1);
			String email1 = emailID.substring(1);
			String eventName = eventEntryBean.getEventName();
			String st[] = eventName.split(",");
			String newEvName = st[0];

			/*
			 * String startSate=eventEntryBean.getStart_date(); String endDate =
			 * eventEntryBean.getEnd_date();
			 */

			/* String emailID=eventEntryBean.getEmail_receipients(); */
			model.addAttribute("eventName", newEvName);
			model.addAttribute("remarks", remarks1);
			model.addAttribute("startSate", startDate1);
			model.addAttribute("endDate", end);

			CalendarService calService = new CalendarService();
			calService.createCalendar(startSate, endDate, eventName, eventEntryBean.getDescription_details(),
					eventEntryBean.getEngagement_Name(), eventEntryBean.getRisk_summary());
			mailService.sendMail(email1, null, newEvName, eventEntryBean.getDescription_details());

		} else {

			String eventName = eventEntryBean.getEventName();

			model.addAttribute("eventName", eventName);
			model.addAttribute("remarks", remarks);
			model.addAttribute("startSate", startSate);
			model.addAttribute("endDate", endDate);

			CalendarService calService = new CalendarService();
			calService.createCalendar(startSate, endDate, eventName, eventEntryBean.getDescription_details(),
					eventEntryBean.getEngagement_Name(), eventEntryBean.getRisk_summary());
			mailService.sendMail(emailID, null, eventName, eventEntryBean.getDescription_details());

		}

		List<CalendarBean> evnetCalendarBeanList = new ArrayList<>();
		HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		List<EventEntry> eventList = eventEntryService.findAllEventByResource(userAccountName);
		// List<EventEntry> eventList = eventEntryService.findAll();
		for (EventEntry event : eventList) {
			if (event.getEventstatus() != null && !event.getEventstatus().equalsIgnoreCase("Cancelled")) {
				CalendarBean calendarBean = new CalendarBean();
				// eventEntryBean.setEvent_ID(event.getEvent_ID());
				calendarBean.setTitle(event.getEventname());
				// eventEntryBean.setDescription_details(event.getDescription_details());
				calendarBean.setDescription(event.getDescription_details());
				calendarBean.setStart(event.getStart_date());
				calendarBean.setEnd(event.getEnd_date());
				calendarBean.setEngagement(event.getEngagement_Name());
				calendarBean.setRemarks(event.getRemarks());
				calendarBean.setAdditional_recipients(event.getEmail_receipients1());
				// eventEntryBean.setRegion_territory(event.getRegion_territory());
				// eventEntryBean.setRisk_summary(event.getRisk_summary());

				// String[] eventAppSet =new String[event.getEventAppSet().size()];
				Set<String> eventAppSet = new HashSet<String>();
				int i = 0;

				for (EventApplication eventApp : event.getEventAppSet()) {

					// eventAppSet[i]=eventApp.getApplication();
					eventAppSet.add(eventApp.getApplication());
					i++;

					/*
					 * if(i==0){ eventAppStr.append(eventAppSet[i]); eventAppStr.append(","); } else
					 * { eventAppStr.append(eventAppSet[i]); }
					 */
				}
				calendarBean.setEventAppSet(eventAppSet);

				Set<String> eventUserSet = new HashSet<String>();
				// String[] eventUserSet=new String[event.getEventUserSet().size()];
				int j = 0;
				for (EventUser eventUser : event.getEventUserSet()) {
					// for(String Username: userService.findByUsername(eventUser))
					// eventUserSet[j] = eventUser.getResource();
					eventUserSet.add(eventUser.getResource());
					j++;
				}
				calendarBean.setEventUserSet(eventUserSet);

				evnetCalendarBeanList.add(calendarBean);

			}
		}

		Gson gson = new Gson();
		String calendarJSON = gson.toJson(evnetCalendarBeanList);

		model.addAttribute("calendarJSON", calendarJSON);
		// model.addAttribute("evnetEntryBeanList", evnetCalendarBeanList);
		model.addAttribute("filePath", dir + File.separator);
		model.addAttribute("calendarType",
				StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("viewCalendar");

	}

	// String saveDirectory = "C:/Bala/apache-tomcat-7.0.37/Uploaded_files/";

	@RequestMapping(value = "/addEntry", method = RequestMethod.POST)
	public ModelAndView aaEntry(@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean,
			BindingResult bindingResult, Model model,
			final @RequestParam("File_upload") List<MultipartFile> File_upload) {
		eventEntryValidator.validate(eventEntryBean, bindingResult);
		List<MultipartFile> files = eventEntryBean.getFile_upload();

		ModelAndView model1 = new ModelAndView();
		FileUpload fileUpload = new FileUpload();
		String fileContent = null;
		String attachfileName = null;
		String getEvent_file_name = null;
		List<String> fileNames = new ArrayList<String>();
		try {
			if (null != files && files.size() > 0) {
				for (MultipartFile multipartFile : files) {
					fileContent = fileUpload.process(multipartFile).toString();
					// String getEvent_upld_fix_content=fileContent;
					// getEvent_file_name = multipartFile.getOriginalFilename();
					// eventEntryBean.setEvent_file_name(getEvent_file_name);
					// eventEntryBean.setEvent_upld_fix(getEvent_upld_fix_content);
					attachfileName = multipartFile.getOriginalFilename();
					fileNames.add(attachfileName);
					System.out.print("attachName-------------->>" + attachfileName);
				}
			}
			model1.addObject("message", fileContent);

		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		getEvent_file_name = fileNames.toString().replaceAll("[\\[.\\].\\s+]", "");

		eventEntryBean.setEvent_file_name(getEvent_file_name);

		if (bindingResult.hasErrors()) {
			// @PathVariable Long id,
			List<String> appList = applicationService.getAppNames();
			List<String> rescList = userService.getResourceNames();
			List<String> catList = categoryService.getCategoryName();
			List<String> eventList = eventEntryServiceMaster.getEventName();
			List<String> regList = regionService.getRegionTerritory();
			List<String> caltypList = calendartypeService.getCalendarTypeName();

			model.addAttribute("eventEntryBean", eventEntryBean);
			model.addAttribute("eventList", eventList);
			model.addAttribute("appNameList", appList);
			model.addAttribute("rescNameList", rescList);
			model.addAttribute("catgoryList", catList);
			model.addAttribute("regionList", regList);
			model.addAttribute("caltypList", caltypList);

			return new ModelAndView("addEntry");
		}
		HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		eventEntryBean.setAccount_name(userAccountName);

		// will update once UI changes done.

		/*
		 * eventEntryBean.setRecurrence_type("Daily");
		 * 
		 * if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("Daily")) {
		 * eventEntryBean.setRecu_every_day("1");
		 * eventEntryBean.setRecu_every_weekday("MO,TU,WE,TH,FR"); } else
		 * if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("Weekly")) {
		 * eventEntryBean.setRecu_every_week("1");
		 * eventEntryBean.setRecurrence_dayName("MO,TU,WE,TH,FR,SU,SA"); } else
		 * if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("Monthly")) {
		 * eventEntryBean.setRecu_every_month("1");
		 * eventEntryBean.setRecu_month_day("20"); }
		 */

		// will update above code once UI changes done.

		eventEntryService.saveOther(eventEntryBean);
		String eventName = eventEntryBean.getEventName();
		String remarks = eventEntryBean.getRemarks();
		String startDate = eventEntryBean.getStart_date() + "T" + eventEntryBean.getStart_time();
		String endDate = eventEntryBean.getEnd_date() + "T" + eventEntryBean.getEnd_time();
		String emailID = eventEntryBean.getEmail_receipients();
		String emailID1 = eventEntryBean.getEmail_receipients1();

		if (emailID != null && emailID1 != null) {
			emailid = emailID + "," + emailID1;
		} else {

			emailid = emailID;
		}

		String file_upload = String.valueOf(eventEntryBean.getFile_upload());
		eventEntryBean.setFile_upload(eventEntryBean.getFile_upload());

		if (emailID.startsWith(",") || endDate.startsWith(",") || startDate.startsWith(",")
				|| remarks.startsWith(".")) {

			String startDate1 = startDate.substring(1);
			String end = endDate.substring(1);
			String remark = remarks.substring(1);
			String email1 = emailID.substring(1);

			/*
			 * String startSate=eventEntryBean.getStart_date(); String endDate =
			 * eventEntryBean.getEnd_date();
			 */

			/* String emailID=eventEntryBean.getEmail_receipients(); */
			eventEntryBean.setFile_upload(eventEntryBean.getFile_upload());
			model.addAttribute("file_upload", file_upload);

			model.addAttribute("eventName", eventName);
			model.addAttribute("remarks", remark);
			model.addAttribute("startSate", startDate1);
			model.addAttribute("endDate", endDate);

			// emailID,null,eventName, eventEntryBean.getDescription_details()

			CalendarService calService = new CalendarService();
			calService.createCalendar(startDate, endDate, eventName, eventEntryBean.getDescription_details(),
					eventEntryBean.getEngagement_Name(), eventEntryBean.getRisk_summary());
			// mailService.sendMail(email1,null,eventName,
			// eventEntryBean.getDescription_details());

		} else {

			// model.addAttribute("remarks", remarks);
			model.addAttribute("eventName", eventName);
			model.addAttribute("remarks", remarks);
			model.addAttribute("startSate", startDate);
			model.addAttribute("endDate", endDate);

			CalendarService calService = new CalendarService();
			calService.createCalendar(startDate, endDate, eventName, eventEntryBean.getDescription_details(),
					eventEntryBean.getEngagement_Name(), eventEntryBean.getRisk_summary());
			// mailService.sendMail(emailID,null,eventName,
			// eventEntryBean.getDescription_details());

		}

		/* Email code starts here */
		SimpleDateFormat dateParser = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");

		try {
			mailService.sendInvitation("DL IN NATools_Support", new String[] { emailid }, eventEntryBean.getEventName()
			/*
			 * , dateParser.parse( "28-08-2006 18:00" ) , dateParser.parse(
			 * "28-08-2006 21:00" )
			 */
			/* , eventEntryBean.getRecurrence() */
					, dateParser.parse(eventEntryBean.getStart_date() + "T" + eventEntryBean.getStart_time()),
					dateParser.parse(eventEntryBean.getEnd_date() + "T" + eventEntryBean.getEnd_time())

					, eventEntryBean.getRecurrence_type()

					, eventEntryBean.getRecu_every_day(), eventEntryBean.getRecu_every_weekday()

					, eventEntryBean.getRecu_every_week(), eventEntryBean.getRecurrence_dayName()

					, eventEntryBean.getRecu_every_month(), eventEntryBean.getRecu_month_day(),
					eventEntryBean.getMonthdd1(), eventEntryBean.getMonthdd2(), eventEntryBean.getMonthtext1(),
					eventEntryBean.getRecu_month_day_radio(), "LIS-42", "TBD"
					/*
					 * , "<font color=\"Black\">"+eventEntryBean.getDescription_details()+"</font>"
					 */
					,
					"<body bgcolor='#E6E6FA'> <table align='center' border='2' ><tr><td>EventName :</td><td><font color=\"Blue\">"
							+ eventEntryBean.getEventName() + "</font></td></tr>"
							+ "<tr><td>Description_details :</td><td><font color=\"Blue\">"
							+ eventEntryBean.getDescription_details() + "</font></td></tr>"
							+ "<tr><td>Category Name :</td><td><font color=\"Blue\">"
							+ eventEntryBean.getEvent_category_Name() + "</font></td></tr>"
							+ "<tr><td>Engagement Name :</td><td><font color=\"Blue\">"
							+ eventEntryBean.getEngagement_Name() + "</font></td></tr>"
							+ "<tr><td>Risk Summary :</td><td><font color=\"Blue\">" + eventEntryBean.getRisk_summary()
							+ "</font></td></tr>" + "<tr><td>Region territory :</td><td><font color=\"Blue\">"
							+ eventEntryBean.getEventName() + "</font></td></tr></table></body>",
					getEvent_file_name);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		/* Email code ends here */

		/* Email code ends here */

		List<CalendarBean> evnetCalendarBeanList = new ArrayList<>();
		List<EventEntry> eventList = eventEntryService.findAllEventByResource(userAccountName);

		// List<EventEntry> eventList = eventEntryService.findAll();
		for (EventEntry event : eventList) {
			if (event.getEventstatus() != null && !event.getEventstatus().equalsIgnoreCase("Cancelled")) {
				CalendarBean calendarBean = new CalendarBean();
				// eventEntryBean.setEvent_ID(event.getEvent_ID());
				calendarBean.setTitle(event.getEventname());
				// eventEntryBean.setDescription_details(event.getDescription_details());
				calendarBean.setDescription(event.getDescription_details());
				calendarBean.setStart(event.getStart_date());
				calendarBean.setEnd(event.getEnd_date());
				calendarBean.setEngagement(event.getEngagement_Name());
				calendarBean.setRemarks(event.getRemarks());
				calendarBean.setAdditional_recipients(event.getEmail_receipients1());

				// eventEntryBean.setRegion_territory(event.getRegion_territory());
				// eventEntryBean.setRisk_summary(event.getRisk_summary());

				Set<String> eventAppSet = new HashSet<String>();
				int i = 0;

				for (EventApplication eventApp : event.getEventAppSet()) {

					// eventAppSet[i]=eventApp.getApplication();
					eventAppSet.add(eventApp.getApplication());
					i++;

					/*
					 * if(i==0){ eventAppStr.append(eventAppSet[i]); eventAppStr.append(","); } else
					 * { eventAppStr.append(eventAppSet[i]); }
					 */
				}
				calendarBean.setEventAppSet(eventAppSet);

				Set<String> eventUserSet = new HashSet<String>();
				// String[] eventUserSet=new String[event.getEventUserSet().size()];
				int j = 0;
				for (EventUser eventUser : event.getEventUserSet()) {
					// for(String Username: userService.findByUsername(eventUser))
					// eventUserSet[j] = eventUser.getResource();
					eventUserSet.add(eventUser.getResource());
					j++;
				}
				calendarBean.setEventUserSet(eventUserSet);

				evnetCalendarBeanList.add(calendarBean);

			}
		}

		Gson gson = new Gson();
		String calendarJSON = gson.toJson(evnetCalendarBeanList);
		model.addAttribute("calendarJSON", calendarJSON);
		// model.addAttribute("evnetEntryBeanList", evnetCalendarBeanList);
		model.addAttribute("filePath", dir + File.separator);
		model.addAttribute("calendarType",
				StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("viewCalendar");

	}

	/*
	 * @RequestMapping(value = "/spellCheck", method = RequestMethod.POST) public
	 * ModelAndView spellCheck(@ModelAttribute("eventEntryBean") EventEntryBean
	 * eventEntryBean, BindingResult bindingResult, Model model) { SpellCheckExample
	 * checkExample = new SpellCheckExample(); HashMap<Object, List> suggestions2 =
	 * checkExample.SpellCheckExample(eventEntryBean.getDescription_details());
	 * HashMap suggestions = new HashMap<>(); List<String> values = new
	 * ArrayList<>(); values.add("vara"); values.add("satya");
	 * suggestions.put("satya", values); suggestions.put("vara", values);
	 * model.addAttribute("eventDescDetails", values); return new
	 * ModelAndView("addEntry"); }
	 */

	@RequestMapping(value = "/spellCheck", headers = "Accept=*/*", method = RequestMethod.GET)
	public @ResponseBody String spellCheck(@RequestParam(value = "descDetails", required = true) String descDetails,
			Model model) throws IllegalStateException {

		SpellCheckExample checkExample = new SpellCheckExample();
		HashMap<String, List<String>> suggestions2 = checkExample.SpellCheckExample(descDetails);
		model.addAttribute("descDetailsHidden", descDetails);
		HashMap suggestions = new HashMap<>();
		List<String> values = new ArrayList<>();
		values.add("vara");
		values.add("satya");
		suggestions.put("satya", values);
		suggestions.put("vara", values);
		Gson gson = new Gson();
		String sugession = gson.toJson(suggestions2);
		model.addAttribute("eventDescDetails", sugession);

		return sugession;
	}

	@RequestMapping(value = "/editEntryMasterPopulate", method = RequestMethod.POST)
	public ModelAndView editEntryMasterPopulate(@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean,
			BindingResult bindingResult, Model model,
			final @RequestParam("File_upload") List<MultipartFile> File_upload) {
		SpellCheckExample checkExample = new SpellCheckExample();
		HashMap<String, List<String>> suggestions = checkExample
				.SpellCheckExample(eventEntryBean.getDescription_details());

		if (com.mysql.jdbc.StringUtils.isNullOrEmpty(eventEntryBean.getEventNameOthers())) {
			if (eventEntryBean.getEvent_ID() != null) {
				EventEntryMaster eventEntry = eventEntryServiceMaster.findById(eventEntryBean.getEvent_ID());
				if (eventEntry.getEventname() != null) {
					eventEntryBean.setEventName(eventEntry.getEventname());
				}
			}

		} else {
			eventEntryBean.setEventName(eventEntryBean.getEventNameOthers());
		}

		if (!(eventEntryBean.getHiddenuser().length <= 0)) {
			eventEntryBean.setEventUserSet(eventEntryBean.getHiddenuser());
		}
		eventEntryValidator.validate(eventEntryBean, bindingResult);

		if (bindingResult.hasErrors()) {
			System.out.println("@@@@@@@@@@@@@@@@@@@@@@inside bindingResult@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
			// @PathVariable Long id,
			List<String> appList = applicationService.getAppNames();
			List<String> rescList = userService.getResourceNames();
			List<String> catList = categoryService.getCategoryName();
			HttpSession httpSession = httpServletRequest.getSession();
			String userAccountName = (String) httpSession.getAttribute("userAcctName");
			List<String> eventList = eventEntryServiceMaster.getEventNameByAcctName(userAccountName);
			List<String> regList = regionService.getRegionTerritory();
			List<String> caltypList = calendartypeService.getCalendarTypeName();
			List<String> accList = accountService.getAccountNames();

			model.addAttribute("eventList", eventList);
			model.addAttribute("appNameList", appList);
			model.addAttribute("rescNameList", rescList);
			model.addAttribute("catgoryList", catList);
			model.addAttribute("regionList", regList);
			model.addAttribute("caltypList", caltypList);
			model.addAttribute("accountList", accList);
			model.addAttribute("eventAppSet", eventEntryBean.getEventAppSet());
			model.addAttribute("eventUserSet", eventEntryBean.getEventUserSet());
			List<HashMap<String, String>> listMastp = applicationService.getPriAndSecResourceName();
			Gson gson = new Gson();
			String applicationEventJson = gson.toJson(listMastp);
			model.addAttribute("eventEntryJsonStr", applicationEventJson);

			// added code start for Recurrence

			/*
			 * eventEntryBean.setRecu_every_day(event.getRecu_every_day());
			 * eventEntryBean.setRecu_every_month(event.getRecu_every_month());
			 * eventEntryBean.setRecu_every_week(event.getRecu_every_week());
			 * eventEntryBean.setRecu_every_weekday(event.getRecu_every_weekday());
			 * eventEntryBean.setRecu_every_weekday_radio(event.getRecu_every_weekday());
			 * 
			 * eventEntryBean.setRecu_month_day(event.getRecu_month_day());
			 * eventEntryBean.setRecurrence_dayName(event.getRecurrence_dayName());
			 * eventEntryBean.setRecurrence_type(event.getRecurrence_type());
			 */
			if (eventEntryBean.getRecurrence_dayName() != null) {
				List<String> recurrence_dayNameList = new ArrayList<String>(
						Arrays.asList(eventEntryBean.getRecurrence_dayName().split(",")));
				String recurrence_dayNamesJson = gson.toJson(recurrence_dayNameList);
				model.addAttribute("recurrence_dayNamesJson", recurrence_dayNamesJson);
			}
			model.addAttribute("eventEntryBean", eventEntryBean);

			return new ModelAndView("addEntry");
		}

		if (eventEntryBean.getRecurrence_type().equalsIgnoreCase("weekly")
				&& eventEntryBean.getRecu_every_week().equalsIgnoreCase("")) {
			model.addAttribute("recerrorMsg", "Please provide the Recur every week");
			model.addAttribute("recType", "weekly");
			List<String> appList = applicationService.getAppNames();
			List<String> rescList = userService.getResourceNames();
			List<String> catList = categoryService.getCategoryName();
			HttpSession httpSession = httpServletRequest.getSession();
			String userAccountName = (String) httpSession.getAttribute("userAcctName");
			List<String> eventList = eventEntryServiceMaster.getEventNameByAcctName(userAccountName);
			List<String> regList = regionService.getRegionTerritory();
			List<String> caltypList = calendartypeService.getCalendarTypeName();
			List<String> accList = accountService.getAccountNames();
			model.addAttribute("eventEntryBean", eventEntryBean);
			model.addAttribute("eventList", eventList);
			model.addAttribute("appNameList", appList);
			model.addAttribute("rescNameList", rescList);
			model.addAttribute("catgoryList", catList);
			model.addAttribute("regionList", regList);
			model.addAttribute("caltypList", caltypList);
			model.addAttribute("accountList", accList);
			model.addAttribute("eventAppSet", eventEntryBean.getEventAppSet());
			model.addAttribute("eventUserSet", eventEntryBean.getEventUserSet());
			List<HashMap<String, String>> listMastp = applicationService.getPriAndSecResourceName();
			Gson gson = new Gson();
			String applicationEventJson = gson.toJson(listMastp);
			model.addAttribute("eventEntryJsonStr", applicationEventJson);
			return new ModelAndView("addEntry");

		}
		if (eventEntryBean.getRecurrence_type().equalsIgnoreCase("weekly")
				&& !eventEntryBean.getRecu_every_week().equalsIgnoreCase("")
				&& eventEntryBean.getRecurrence_dayName() == null) {
			model.addAttribute("recDayerrorMsg", "Please Select atleast a day");
			model.addAttribute("recType", "weekly");
			List<String> appList = applicationService.getAppNames();
			List<String> rescList = userService.getResourceNames();
			List<String> catList = categoryService.getCategoryName();
			HttpSession httpSession = httpServletRequest.getSession();
			String userAccountName = (String) httpSession.getAttribute("userAcctName");
			List<String> eventList = eventEntryServiceMaster.getEventNameByAcctName(userAccountName);
			List<String> regList = regionService.getRegionTerritory();
			List<String> caltypList = calendartypeService.getCalendarTypeName();
			List<String> accList = accountService.getAccountNames();
			model.addAttribute("eventEntryBean", eventEntryBean);
			model.addAttribute("eventList", eventList);
			model.addAttribute("appNameList", appList);
			model.addAttribute("rescNameList", rescList);
			model.addAttribute("catgoryList", catList);
			model.addAttribute("regionList", regList);
			model.addAttribute("caltypList", caltypList);
			model.addAttribute("accountList", accList);
			model.addAttribute("eventAppSet", eventEntryBean.getEventAppSet());
			model.addAttribute("eventUserSet", eventEntryBean.getEventUserSet());
			List<HashMap<String, String>> listMastp = applicationService.getPriAndSecResourceName();
			Gson gson = new Gson();
			String applicationEventJson = gson.toJson(listMastp);
			model.addAttribute("eventEntryJsonStr", applicationEventJson);
			return new ModelAndView("addEntry");
		}

		ModelAndView model1 = new ModelAndView();
		FileUpload fileUpload = new FileUpload();
		String fileContent = null;
		String attachfileName = null;
		String getEvent_file_name = null;
		List<String> fileNames = new ArrayList<String>();
		try {
			for (MultipartFile multipartFile : File_upload) {
				fileContent = fileUpload.process(multipartFile).toString();
				attachfileName = multipartFile.getOriginalFilename();
				fileNames.add(attachfileName);
				System.out.print("attachName-------------->>" + attachfileName);
			}

			model1.addObject("message", fileContent);

		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		getEvent_file_name = fileNames.toString().replaceAll("[\\[\\]+]", "");
		eventEntryBean.setEvent_file_name(getEvent_file_name);

		if (!com.mysql.jdbc.StringUtils.isNullOrEmpty(eventEntryBean.getRegion_territory())) {
			eventEntryBean.setRegion_id(String
					.valueOf(regionService.findByRegionTerritory(eventEntryBean.getRegion_territory()).getRegion_id()));
		}

		if (!com.mysql.jdbc.StringUtils.isNullOrEmpty(eventEntryBean.getRegion_territory())) {
			eventEntryBean.setCalendar_type_id(calendartypeService
					.findByCalendarTypeName(eventEntryBean.getCalendar_type_name()).getCalendar_type_id());
		}

		System.out.println("%%%%%%%%%%%%%%%%inside editEntryMasterPopulate%%%%%%%%%%%%%%%%%%%%%%%%%%%% ");

		/*
		 * HttpSession httpSession = httpServletRequest.getSession(); String
		 * userAccountName = (String) httpSession.getAttribute("userAcctName");
		 */
		eventEntryBean.setAccount_name(eventEntryBean.getEngagement_Name());

		// will update the below code once UI changes done.

		/*
		 * eventEntryBean.setRecurrence_type("Daily");
		 * 
		 * if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("Daily")) {
		 * eventEntryBean.setRecu_every_day("1");
		 * eventEntryBean.setRecu_every_weekday("MO,TU,WE,TH,FR"); } else
		 * if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("Weekly")) {
		 * eventEntryBean.setRecu_every_week("1");
		 * eventEntryBean.setRecurrence_dayName("MO,TU,WE,TH,FR,SA,SU"); } else
		 * if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("Monthly")) {
		 * eventEntryBean.setRecu_every_month("1");
		 * eventEntryBean.setRecu_month_day("20"); }
		 */
		// will update above code once UI changes done.

		eventEntryService.saveOther(eventEntryBean);

		List<CalendarBean> evnetCalendarBeanList = new ArrayList<>();
		List<EventEntry> eventList = eventEntryService.findAllEventByResource(eventEntryBean.getAccount_name());

		// List<EventEntry> eventList = eventEntryService.findAll();
		for (EventEntry event : eventList) {
			if (event.getEventstatus() != null && !event.getEventstatus().equalsIgnoreCase("Cancelled")) {
				CalendarBean calendarBean = new CalendarBean();
				// eventEntryBean.setEvent_ID(event.getEvent_ID());
				calendarBean.setTitle(event.getEventname());
				// eventEntryBean.setDescription_details(event.getDescription_details());
				calendarBean.setDescription(event.getDescription_details());
				calendarBean.setStart(event.getStart_date());
				calendarBean.setEnd(event.getEnd_date());
				calendarBean.setEngagement(event.getEngagement_Name());
				calendarBean.setRemarks(event.getRemarks());
				calendarBean.setAdditional_recipients(event.getEmail_receipients1());
				// eventEntryBean.setRegion_territory(event.getRegion_territory());
				// eventEntryBean.setRisk_summary(event.getRisk_summary());

				Set<String> eventAppSet = new HashSet<String>();
				int i = 0;

				for (EventApplication eventApp : event.getEventAppSet()) {

					// eventAppSet[i]=eventApp.getApplication();
					eventAppSet.add(eventApp.getApplication());
					i++;

					/*
					 * if(i==0){ eventAppStr.append(eventAppSet[i]); eventAppStr.append(","); } else
					 * { eventAppStr.append(eventAppSet[i]); }
					 */
				}
				calendarBean.setEventAppSet(eventAppSet);

				Set<String> eventUserSet = new HashSet<String>();
				// String[] eventUserSet=new String[event.getEventUserSet().size()];
				int j = 0;
				for (EventUser eventUser : event.getEventUserSet()) {
					// for(String Username: userService.findByUsername(eventUser))
					// eventUserSet[j] = eventUser.getResource();
					eventUserSet.add(eventUser.getResource());
					j++;
				}

				// create an iterator
				Iterator iterator = eventUserSet.iterator();

				// check values
				while (iterator.hasNext()) {
					System.out.println(
							"Value:---------------------> " + iterator.next() + "<---------------------------- ");
				}

				System.out.println("eventUserSet Value:------> " + eventUserSet + "<------ ");

				calendarBean.setEventUserSet(eventUserSet);
				System.out.println("calendarBean Value:------> " + calendarBean + "<------ ");

				evnetCalendarBeanList.add(calendarBean);
			}
		}

		Gson gson = new Gson();
		String calendarJSON = gson.toJson(evnetCalendarBeanList);

		System.out.println("--------------------after eventEntryService--------------------- ");

		/*
		 * String start_dt = eventEntryBean.getStart_date(); String end_dt =
		 * eventEntryBean.getEnd_date();
		 */

		// securityService.autologin(userForm.getUsername(),
		// userForm.getPasswordConfirm());

		// eventEntryBean.setRemarks(eventEntryBean.getRemarks());
		String remarks = eventEntryBean.getRemarks();
		String eventName = eventEntryBean.getEventNameOthers();
		String startSate = eventEntryBean.getStart_date() + "T" + eventEntryBean.getStart_time();
		String endDate = eventEntryBean.getEnd_date() + "T" + eventEntryBean.getEnd_time();
		String emailID = eventEntryBean.getEmail_receipients();
		String emailID1 = eventEntryBean.getEmail_receipients1();

		if (emailID != null && emailID1 != null) {
			emailid = emailID + "," + emailID1;
		} else {

			emailid = emailID;
		}

		if (emailID.startsWith(",") || endDate.startsWith(",") || startSate.startsWith(",")
				|| remarks.startsWith(",")) {

			String startDate1 = startSate.substring(1);
			String end = endDate.substring(1);

			/*
			 * String startSate=eventEntryBean.getStart_date(); String endDate =
			 * eventEntryBean.getEnd_date();
			 */

			/* String emailID=eventEntryBean.getEmail_receipients(); */
			// model.addAttribute("regionList",regList);
			model.addAttribute("eventName", eventName);
			model.addAttribute("remarks", remarks);
			model.addAttribute("startSate", startDate1);
			model.addAttribute("endDate", endDate);

			// emailID,null,eventName, eventEntryBean.getDescription_details()

			CalendarService calService = new CalendarService();
			calService.createCalendar(startSate, endDate, eventName, eventEntryBean.getDescription_details(),
					eventEntryBean.getEngagement_Name(), eventEntryBean.getRisk_summary());
			// mailService.sendMail(email1,null,eventName,
			// eventEntryBean.getDescription_details());

		} else {

			model.addAttribute("remarks", remarks);
			model.addAttribute("eventName", eventName);
			model.addAttribute("startSate", startSate);
			model.addAttribute("endDate", endDate);

			CalendarService calService = new CalendarService();
			calService.createCalendar(startSate, endDate, eventName, eventEntryBean.getDescription_details(),
					eventEntryBean.getEngagement_Name(), eventEntryBean.getRisk_summary());
			// mailService.sendMail(emailID,null,eventName,
			// eventEntryBean.getDescription_details());

		}
		/* Email code starts here */
		/*
		 * SimpleDateFormat dateParser = new SimpleDateFormat( "yyyy-MM-dd'T'HH:mm" ) ;
		 * 
		 * try { mailService.sendInvitation( "DL IN NATools_Support" , new String[] {
		 * eventEntryBean.getEmail_receipients() } , eventEntryBean.getEventName() ,
		 * dateParser.parse( "28-08-2006 18:00" ) , dateParser.parse( "28-08-2006 21:00"
		 * ) , dateParser.parse(eventEntryBean.getStart_date()) ,
		 * dateParser.parse(eventEntryBean.getEnd_date()) , "LIS-42" , "TBD" ,
		 * "<body bgcolor='#E6E6FA'> <table align='center' border='2' ><tr><td>EventName :</td><td><font color=\"Blue\">"
		 * + eventEntryBean.getEventName() + "</font></td></tr>"+
		 * "<tr><td>Description_details :</td><td><font color=\"Blue\">" +
		 * eventEntryBean.getDescription_details() + "</font></td></tr>"+
		 * "<tr><td>Category Name :</td><td><font color=\"Blue\">" +
		 * eventEntryBean.getEvent_category_Name() + "</font></td></tr>"+
		 * "<tr><td>Engagement Name :</td><td><font color=\"Blue\">" +
		 * eventEntryBean.getEngagement_Name() + "</font></td></tr>"+
		 * "<tr><td>Risk Summary :</td><td><font color=\"Blue\">" +
		 * eventEntryBean.getRisk_summary() + "</font></td></tr>"+
		 * "<tr><td>Region territory :</td><td><font color=\"Blue\">" +
		 * eventEntryBean.getEventName() +
		 * "</font></td></tr></table></body>",attachfileName );
		 * 
		 * } catch (ParseException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); } catch (Exception e) { // TODO Auto-generated catch
		 * block e.printStackTrace(); }
		 */

		/* Email code starts here */
		SimpleDateFormat dateParser = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");

		try {
			mailService.sendInvitation("DL IN NATools_Support", new String[] { emailid }, eventEntryBean.getEventName()
			/* , eventEntryBean.getRecurrence() */
			/*
			 * , dateParser.parse( "28-08-2006 18:00" ) , dateParser.parse(
			 * "28-08-2006 21:00" )
			 */
					, dateParser.parse(eventEntryBean.getStart_date() + "T" + eventEntryBean.getStart_time()),
					dateParser.parse(eventEntryBean.getEnd_date() + "T" + eventEntryBean.getEnd_time()),
					eventEntryBean.getRecurrence_type()

					, eventEntryBean.getRecu_every_day(), eventEntryBean.getRecu_every_weekday()

					, eventEntryBean.getRecu_every_week(), eventEntryBean.getRecurrence_dayName()

					, eventEntryBean.getRecu_every_month(), eventEntryBean.getRecu_month_day(),
					eventEntryBean.getMonthdd1(), eventEntryBean.getMonthdd2(), eventEntryBean.getMonthtext1(),
					eventEntryBean.getRecu_month_day_radio(), "LIS-42", "TBD"
					/*
					 * , "<font color=\"Black\">"+eventEntryBean.getDescription_details()+"</font>"
					 */
					,
					"<body bgcolor='#E6E6FA'> <table align='center' border='2' ><tr><td>EventName :</td><td><font color=\"Blue\">"
							+ eventEntryBean.getEventName() + "</font></td></tr>"
							+ "<tr><td>Description_details :</td><td><font color=\"Blue\">"
							+ eventEntryBean.getDescription_details() + "</font></td></tr>"
							+ "<tr><td>Category Name :</td><td><font color=\"Blue\">"
							+ eventEntryBean.getEvent_category_Name() + "</font></td></tr>"
							+ "<tr><td>Engagement Name :</td><td><font color=\"Blue\">"
							+ eventEntryBean.getEngagement_Name() + "</font></td></tr>"
							+ "<tr><td>Risk Summary :</td><td><font color=\"Blue\">" + eventEntryBean.getRisk_summary()
							+ "</font></td></tr>" + "<tr><td>Region territory :</td><td><font color=\"Blue\">"
							+ eventEntryBean.getEventName() + "</font></td></tr></table></body>",
					getEvent_file_name

			);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		/* Email code ends here */

		/* Email code ends here */

		model.addAttribute("calendarJSON", calendarJSON);
		model.addAttribute("calendarid", "Consolidated");

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		model.addAttribute("userRoleName", auth.getAuthorities());

		// model.addAttribute("evnetEntryBeanList", evnetCalendarBeanList);
		model.addAttribute("filePath", dir + File.separator);
		model.addAttribute("calendarType",
				StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("viewCalendar");

	}

	@RequestMapping(value = "/viewEntry", method = RequestMethod.GET)
	public ModelAndView viewEntry(Model model) {

		List<EventEntryBean> evnetEntryBeanList = new ArrayList<>();
		HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		List<EventEntry> eventList = eventEntryService.findAllEventByResource(userAccountName);
		for (EventEntry event : eventList) {
			if (event.getEventstatus() != null && !event.getEventstatus().equalsIgnoreCase("Cancelled")) {
				EventEntryBean eventEntryBean = new EventEntryBean();
				eventEntryBean.setEvent_ID(event.getEvent_ID());
				eventEntryBean.setEventName(event.getEventname());
				eventEntryBean.setDescription_details(event.getDescription_details());
				eventEntryBean.setStart_date(event.getStart_date());
				eventEntryBean.setEnd_date(event.getEnd_date());
				// eventEntryBean.setRegion_territory(event.getRegion_territory());
				eventEntryBean.setRisk_summary(event.getRisk_summary());
				eventEntryBean.setRemarks(event.getRemarks());
				if (event.getEvent_file_name() != null) {
					List<String> fileNameList = Arrays.asList(event.getEvent_file_name().split("\\s*,\\s*"));
					eventEntryBean.setEvent_list(fileNameList);
				}
				// eventEntryBean.setEvent_file_name(event.getEvent_file_name());
				// eventEntryBean.setEvent_upld_fix(event.getEvent_upld_fix());

				Region region = regionService.findByRegionId(event.getRegion_id());

				if (region != null) {
					eventEntryBean.setRegion_territory(region.getRegion_territory());
				}

				Category category = categoryService.findByCategoryId(event.getEvent_category_id());
				// System.out.print(category);

				if (category != null) {
					eventEntryBean.setEvent_category_Name(category.getEvent_category_name());
				}

				String[] eventAppSet = new String[event.getEventAppSet().size()];
				int i = 0;

				for (EventApplication eventApp : event.getEventAppSet()) {

					eventAppSet[i] = eventApp.getApplication();
					i++;

					/*
					 * if(i==0){ eventAppStr.append(eventAppSet[i]); eventAppStr.append(","); } else
					 * { eventAppStr.append(eventAppSet[i]); }
					 */
				}
				eventEntryBean.setEventAppSet(eventAppSet);

				String[] eventUserSet = new String[event.getEventUserSet().size()];
				int j = 0;
				for (EventUser eventUser : event.getEventUserSet()) {
					// for(String Username: userService.findByUsername(eventUser))
					eventUserSet[j] = eventUser.getResource();
					j++;
				}
				eventUserSet = Arrays.stream(eventUserSet).filter(s -> (s != null && s.length() > 0))
						.toArray(String[]::new);

				Set<String> userSet = new HashSet<String>(Arrays.asList(eventUserSet));
				eventUserSet = userSet.toArray(new String[userSet.size()]);
				String eventUsersString = String.join(",", eventUserSet);
				eventEntryBean.setEventUsers(eventUsersString);
				eventEntryBean.setEventUserSet(eventUserSet);
				eventEntryBean.setEmail_receipients(event.getAdditional_receipients());
				eventEntryBean.setEngagement_Name(event.getEngagement_Name());
				evnetEntryBeanList.add(eventEntryBean);
			}
		}

		/*
		 * List<CalendarBean> evnetCalendarBeanList=new ArrayList<>(); List<EventEntry>
		 * eventList1 = eventEntryService.findAll(); for(EventEntry event:eventList){
		 * CalendarBean calendarBean=new CalendarBean();
		 * //eventEntryBean.setEvent_ID(event.getEvent_ID());
		 * calendarBean.setTitle(event.getEventname());
		 * //eventEntryBean.setDescription_details(event.getDescription_details());
		 * calendarBean.setDescription(event.getDescription_details());
		 * calendarBean.setStart(event.getStart_date());
		 * calendarBean.setEnd(event.getEnd_date());
		 * calendarBean.setEngagement(event.getEngagement_Name());
		 * //eventEntryBean.setRegion_territory(event.getRegion_territory());
		 * //eventEntryBean.setRisk_summary(event.getRisk_summary());
		 * 
		 * String[] eventAppSet =new String[event.getEventAppSet().size()]; int i=0;
		 * 
		 * for (EventApplication eventApp : event.getEventAppSet() ) {
		 * 
		 * eventAppSet[i]=eventApp.getApplication(); i++;
		 * 
		 * /*if(i==0){ eventAppStr.append(eventAppSet[i]); eventAppStr.append(","); }
		 * else { eventAppStr.append(eventAppSet[i]); } }
		 * calendarBean.setEventAppSet(eventAppSet);
		 * 
		 * String[] eventUserSet=new String[event.getEventUserSet().size()]; int j=0;
		 * for(EventUser eventUser:event.getEventUserSet()){ /*for(String Username:
		 * userService.findByUsername(eventUser)) eventUserSet[j] =
		 * eventUser.getResource(); j++; } calendarBean.setEventUserSet(eventUserSet);
		 * 
		 * evnetCalendarBeanList.add(calendarBean);
		 * 
		 * }
		 * 
		 * 
		 * Gson gson = new Gson(); String
		 * calendarJSON=gson.toJson(evnetCalendarBeanList);
		 * 
		 * 
		 * model.addAttribute("calendarJSON", calendarJSON); //
		 * model.addAttribute("evnetEntryBeanList", evnetCalendarBeanList);
		 */

		model.addAttribute("evnetEntryBeanList", evnetEntryBeanList);
		model.addAttribute("filePath", dir + File.separator);
		model.addAttribute("calendarType",
				StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("viewEntry");

	}

	@RequestMapping(value = "/editEntry/{id}", method = RequestMethod.GET)
	public ModelAndView editEntry(@PathVariable Long id,
			@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean, BindingResult bindingResult, Model model)
			throws java.text.ParseException {

		EventEntry event = eventEntryService.findById(id);

		eventEntryBean.setEvent_ID(event.getEvent_ID());
		eventEntryBean.setEventName(event.getEventname());
		eventEntryBean.setDescription_details(event.getDescription_details());

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

		Date theStartDate = format.parse(event.getStart_date());
		Calendar startCal = Calendar.getInstance();
		startCal.setTime(theStartDate);

		String pattern = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String pattern2 = "HH:mm:ss";
		SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat(pattern2);

		String startDate = simpleDateFormat.format(startCal.getTime());
		eventEntryBean.setStart_date(startDate);

		String startTime = simpleDateFormat2.format(startCal.getTime());
		eventEntryBean.setStart_time(startTime);

		Date theEndDate = format.parse(event.getEnd_date());
		Calendar endCal = Calendar.getInstance();
		endCal.setTime(theEndDate);

		String endDate = simpleDateFormat.format(endCal.getTime());
		eventEntryBean.setEnd_date(endDate);

		String endTime = simpleDateFormat2.format(endCal.getTime());
		eventEntryBean.setEnd_time(endTime);

		eventEntryBean.setEmail_receipients(event.getAdditional_receipients());
		eventEntryBean.setEmail_receipients1(event.getEmail_receipients1());
		eventEntryBean.setEngagement_Name(event.getEngagement_Name());
		// eventEntryBean.setRegion_territory(event.getRegion_territory());
		eventEntryBean.setRisk_summary(event.getRisk_summary());
		CalendarType calType = calendartypeService.findByCalendarTypeId(event.getCalendar_type_id());
		if (calType != null && calType.getCalendar_type_id() != null)
			eventEntryBean.setCalendar_type_name(calType.getCalendar_type_name());
		eventEntryBean.setRemarks(event.getRemarks());
		eventEntryBean.setEvent_file_name(event.getEvent_file_name());
		if (event.getEvent_file_name() != null) {
			List<String> fileNameList = Arrays.asList(event.getEvent_file_name().split("\\s*,\\s*"));
			eventEntryBean.setEvent_list(fileNameList);
		}
		eventEntryBean.setEvent_upld_fix(event.getEvent_upld_fix());

		Region region = regionService.findByRegionId(event.getRegion_id());

		if (region != null) {
			eventEntryBean.setRegion_territory(region.getRegion_territory());
		}

		Category category = categoryService.findByCategoryId(event.getEvent_category_id());

		if (category != null) {
			eventEntryBean.setEvent_category_Name(category.getEvent_category_name());
		}

		String[] eventAppSet = new String[event.getEventAppSet().size()];
		int i = 0;

		for (EventApplication eventApp : event.getEventAppSet()) {

			eventAppSet[i] = eventApp.getApplication();
			i++;

		}
		eventEntryBean.setEventAppSet(eventAppSet);

		String[] eventUserSet = new String[event.getEventUserSet().size()];
		int j = 0;
		for (EventUser eventUser : event.getEventUserSet()) {

			eventUserSet[j] = eventUser.getResource();
			j++;
		}

		eventEntryBean.setEventUserSet(eventUserSet);

		/*
		 * String s1 = eventEntryBean.getStart_date(); String s2 =
		 * eventEntryBean.getEnd_date(); Date d = null; Date d1 = null; try { d = (new
		 * SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")).parse(s1); d1 = (new
		 * SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")).parse(s2); } catch
		 * (java.text.ParseException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); } String convStartDate = (new
		 * SimpleDateFormat("yyyy-MM-dd'T'HH:mm")).format(d); String convEndDate = (new
		 * SimpleDateFormat("yyyy-MM-dd'T'HH:mm")).format(d1);
		 * 
		 * eventEntryBean.setStart_date(convStartDate);
		 * eventEntryBean.setEnd_date(convEndDate);
		 */

		// added code start for Recurrence

		eventEntryBean.setRecu_every_day(event.getRecu_every_day());
		eventEntryBean.setRecu_every_month(event.getRecu_every_month());
		eventEntryBean.setRecu_every_week(event.getRecu_every_week());
		eventEntryBean.setRecu_every_weekday(event.getRecu_every_weekday());
		eventEntryBean.setRecu_every_weekday_radio(event.getRecu_every_weekday());

		eventEntryBean.setRecu_month_day(event.getRecu_month_day());
		eventEntryBean.setRecurrence_dayName(event.getRecurrence_dayName());
		eventEntryBean.setRecurrence_type(event.getRecurrence_type());
		eventEntryBean.setMonthdd1(event.getMonthdd1());
		eventEntryBean.setMonthdd2(event.getMonthdd2());
		eventEntryBean.setMonthtext1(event.getMonthtext1());
		eventEntryBean.setRecu_month_day_radio(event.getRecu_month_day_radio());
		if (event.getRecurrence_dayName() != null) {
			List<String> recurrence_dayNameList = new ArrayList<String>(
					Arrays.asList(event.getRecurrence_dayName().split(",")));
			Gson gson = new Gson();
			String recurrence_dayNamesJson = gson.toJson(recurrence_dayNameList);
			model.addAttribute("recurrence_dayNamesJson", recurrence_dayNamesJson);
		}

		// code completed for Recurrence

		List<String> catList = categoryService.getCategoryName();
		List<String> appList = applicationService.getAppNames();
		List<String> rescList = userService.getResourceNames();
		List<String> regList = regionService.getRegionTerritory();

		model.addAttribute("catgoryList", catList);
		model.addAttribute("appNameList", appList);
		model.addAttribute("rescNameList", rescList);
		model.addAttribute("eventEntryBean", eventEntryBean);

		List<HashMap<String, String>> listMastp = applicationService.getPriAndSecResourceName();
		Gson gson = new Gson();
		String applicationEventJson = gson.toJson(listMastp);
		model.addAttribute("eventEntryJsonStr", applicationEventJson);
		Set<HashMap<String, String>> setMast1 = new HashSet<>();
		for (String eventApp : eventAppSet) {
			HashMap<String, String> h = new HashMap<>();
			h.put("App_name", eventApp);
			setMast1.add(h);
		}
		String applicationEventJson1 = gson.toJson(setMast1);
		model.addAttribute("selectedeventAppJsonStr", applicationEventJson1);

		model.addAttribute("regionList", regList);
		List<String> caltypList = calendartypeService.getCalendarTypeName();
		model.addAttribute("caltypList", caltypList);
		model.addAttribute("filePath", dir + File.separator);
		model.addAttribute("calendarType",
				StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("editEntry");
	}

	@RequestMapping(value = "/cancelEntry/{id}", method = RequestMethod.GET)
	public ModelAndView cancelEntry(@PathVariable Long id,
			@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean, BindingResult bindingResult, Model model)
			throws java.text.ParseException {

		EventEntry eventEntry = eventEntryService.findById(id);

		/* Email code starts here */

		String emailid = eventEntry.getAdditional_receipients();

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		SimpleDateFormat dateParser = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
		Date theStartDate = format.parse(eventEntry.getStart_date());
		Calendar startCal = Calendar.getInstance();
		startCal.setTime(theStartDate);

		String pattern = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String pattern2 = "HH:mm";
		SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat(pattern2);

		String startDate = simpleDateFormat.format(startCal.getTime());

		String startTime = simpleDateFormat2.format(startCal.getTime());

		eventEntry.setStart_date(startDate + 'T' + startTime);

		Date theEndDate = format.parse(eventEntry.getEnd_date());
		Calendar endCal = Calendar.getInstance();
		endCal.setTime(theEndDate);

		String endDate = simpleDateFormat.format(endCal.getTime());
		String endTime = simpleDateFormat2.format(endCal.getTime());
		eventEntry.setEnd_date(endDate + 'T' + endTime);

		try {
			mailService.sendCancelInvitation("DL IN NATools_Support", new String[] { emailid },
					eventEntry.getEventname(), dateParser.parse(eventEntry.getStart_date()),
					dateParser.parse(eventEntry.getEnd_date()), eventEntry.getRecurrence_type(),
					eventEntry.getRecu_every_day(), eventEntry.getRecu_every_weekday(), eventEntry.getRecu_every_week(),
					eventEntry.getRecurrence_dayName(), eventEntry.getRecu_every_month(),
					eventEntry.getRecu_month_day(), "LIS-42", "TBD");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/* Email code ends here */

		// once cancelled the event delete the record from database.
		/* eventEntryService.deleteCanceledEvent(id); */
		eventEntryService.saveCancelledEntry(eventEntry);

		List<EventEntryBean> evnetEntryBeanList = new ArrayList<>();
		HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		List<EventEntry> eventList = eventEntryService.findAllEventByResource(userAccountName);
		for (EventEntry event : eventList) {
			if (event.getEventstatus() != null && !event.getEventstatus().equalsIgnoreCase("Cancelled")) {
				EventEntryBean eventEntryBeanDetails = new EventEntryBean();
				eventEntryBeanDetails.setEvent_ID(event.getEvent_ID());
				eventEntryBeanDetails.setEventName(event.getEventname());
				eventEntryBeanDetails.setDescription_details(event.getDescription_details());
				eventEntryBeanDetails.setStart_date(event.getStart_date());
				eventEntryBeanDetails.setEnd_date(event.getEnd_date());
				// eventEntryBean.setRegion_territory(event.getRegion_territory());
				eventEntryBeanDetails.setRisk_summary(event.getRisk_summary());
				eventEntryBeanDetails.setRemarks(event.getRemarks());
				if (event.getEvent_file_name() != null) {
					List<String> fileNameList = Arrays.asList(event.getEvent_file_name().split("\\s*,\\s*"));
					eventEntryBeanDetails.setEvent_list(fileNameList);
				}

				Region region = regionService.findByRegionId(event.getRegion_id());

				if (region != null) {
					eventEntryBeanDetails.setRegion_territory(region.getRegion_territory());
				}

				Category category = categoryService.findByCategoryId(event.getEvent_category_id());

				if (category != null) {
					eventEntryBeanDetails.setEvent_category_Name(category.getEvent_category_name());
				}

				String[] eventAppSet = new String[event.getEventAppSet().size()];
				int i = 0;

				for (EventApplication eventApp : event.getEventAppSet()) {

					eventAppSet[i] = eventApp.getApplication();
					i++;
				}
				eventEntryBeanDetails.setEventAppSet(eventAppSet);

				String[] eventUserSet = new String[event.getEventUserSet().size()];
				int j = 0;
				for (EventUser eventUser : event.getEventUserSet()) {
					// for(String Username: userService.findByUsername(eventUser))
					eventUserSet[j] = eventUser.getResource();
					j++;
				}
				eventUserSet = Arrays.stream(eventUserSet).filter(s -> (s != null && s.length() > 0))
						.toArray(String[]::new);

				Set<String> userSet = new HashSet<String>(Arrays.asList(eventUserSet));
				eventUserSet = userSet.toArray(new String[userSet.size()]);
				String eventUsersString = String.join(",", eventUserSet);
				eventEntryBeanDetails.setEventUsers(eventUsersString);
				eventEntryBeanDetails.setEventUserSet(eventUserSet);
				eventEntryBeanDetails.setEmail_receipients(event.getAdditional_receipients());
				eventEntryBeanDetails.setEngagement_Name(event.getEngagement_Name());
				evnetEntryBeanList.add(eventEntryBeanDetails);
			}
		}
		model.addAttribute("evnetEntryBeanList", evnetEntryBeanList);
		model.addAttribute("filePath", dir + File.separator);
		model.addAttribute("calendarType",
				StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("viewEntry");
	}

	@RequestMapping(value = "/editEntry/{id}", method = RequestMethod.POST)
	public ModelAndView editSaveEntry(@PathVariable Long id,
			@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean, BindingResult bindingResult, Model model,
			final @RequestParam("File_upload") List<MultipartFile> File_upload) {
		eventEntryBean.setEventUserSet(eventEntryBean.getHiddenuser());
		if (eventEntryBean.getRecurrence_type().equalsIgnoreCase("weekly")
				&& eventEntryBean.getRecu_every_week().equalsIgnoreCase("")) {
			model.addAttribute("recerrorMsg", "Please provide the Recur every week");
			model.addAttribute("recType", "weekly");
			List<String> appList = applicationService.getAppNames();
			List<String> rescList = userService.getResourceNames();
			List<String> catList = categoryService.getCategoryName();
			List<String> regList = regionService.getRegionTerritory();
			List<String> caltypList = calendartypeService.getCalendarTypeName();
			model.addAttribute("eventEntryBean", eventEntryBean);
			model.addAttribute("catgoryList", catList);
			model.addAttribute("appNameList", appList);
			model.addAttribute("rescNameList", rescList);
			model.addAttribute("regionList", regList);
			model.addAttribute("caltypList", caltypList);

			EventEntry event = eventEntryService.findById(id);
			String[] eventAppSet = new String[event.getEventAppSet().size()];
			int i = 0;
			for (EventApplication eventApp : event.getEventAppSet()) {
				eventAppSet[i] = eventApp.getApplication();
				i++;
			}
			List<HashMap<String, String>> listMastp = applicationService.getPriAndSecResourceName();
			Gson gson = new Gson();
			String applicationEventJson = gson.toJson(listMastp);
			model.addAttribute("eventEntryJsonStr", applicationEventJson);
			Set<HashMap<String, String>> setMast1 = new HashSet<>();
			for (String eventApp : eventAppSet) {
				HashMap<String, String> h = new HashMap<>();
				h.put("App_name", eventApp);
				setMast1.add(h);
			}
			String applicationEventJson1 = gson.toJson(setMast1);
			model.addAttribute("selectedeventAppJsonStr", applicationEventJson1);

			return new ModelAndView("editEntry");
		}
		if (eventEntryBean.getRecurrence_type().equalsIgnoreCase("weekly")
				&& !eventEntryBean.getRecu_every_week().equalsIgnoreCase("")
				&& eventEntryBean.getRecurrence_dayName() == null) {
			model.addAttribute("recDayerrorMsg", "Please Select atleast a day");
			model.addAttribute("recType", "weekly");
			List<String> appList = applicationService.getAppNames();
			List<String> rescList = userService.getResourceNames();
			List<String> catList = categoryService.getCategoryName();
			List<String> regList = regionService.getRegionTerritory();
			List<String> caltypList = calendartypeService.getCalendarTypeName();
			model.addAttribute("eventEntryBean", eventEntryBean);
			model.addAttribute("catgoryList", catList);
			model.addAttribute("appNameList", appList);
			model.addAttribute("rescNameList", rescList);
			model.addAttribute("regionList", regList);
			model.addAttribute("caltypList", caltypList);

			EventEntry event = eventEntryService.findById(id);
			String[] eventAppSet = new String[event.getEventAppSet().size()];
			int i = 0;
			for (EventApplication eventApp : event.getEventAppSet()) {
				eventAppSet[i] = eventApp.getApplication();
				i++;
			}
			List<HashMap<String, String>> listMastp = applicationService.getPriAndSecResourceName();
			Gson gson = new Gson();
			String applicationEventJson = gson.toJson(listMastp);
			model.addAttribute("eventEntryJsonStr", applicationEventJson);
			Set<HashMap<String, String>> setMast1 = new HashSet<>();
			for (String eventApp : eventAppSet) {
				HashMap<String, String> h = new HashMap<>();
				h.put("App_name", eventApp);
				setMast1.add(h);
			}
			String applicationEventJson1 = gson.toJson(setMast1);
			model.addAttribute("selectedeventAppJsonStr", applicationEventJson1);
			return new ModelAndView("editEntry");
		}

		eventEntryValidator.validate(eventEntryBean, bindingResult);

		if (bindingResult.hasErrors()) {
			List<String> appList = applicationService.getAppNames();
			List<String> rescList = userService.getResourceNames();
			List<String> catList = categoryService.getCategoryName();
			List<String> regList = regionService.getRegionTerritory();
			List<String> caltypList = calendartypeService.getCalendarTypeName();
			model.addAttribute("catgoryList", catList);
			model.addAttribute("appNameList", appList);
			model.addAttribute("rescNameList", rescList);
			model.addAttribute("regionList", regList);
			model.addAttribute("caltypList", caltypList);

			EventEntry event = eventEntryService.findById(id);

			// added code start for Recurrence

			if (event.getRecurrence_dayName() != null) {
				List<String> recurrence_dayNameList = new ArrayList<String>(
						Arrays.asList(event.getRecurrence_dayName().split(",")));
				Gson gson = new Gson();
				String recurrence_dayNamesJson = gson.toJson(recurrence_dayNameList);
				model.addAttribute("recurrence_dayNamesJson", recurrence_dayNamesJson);
			}
			String[] eventAppSet = new String[event.getEventAppSet().size()];
			int i = 0;
			for (EventApplication eventApp : event.getEventAppSet()) {
				eventAppSet[i] = eventApp.getApplication();
				i++;
			}
			List<HashMap<String, String>> listMastp = applicationService.getPriAndSecResourceName();
			Gson gson = new Gson();
			String applicationEventJson = gson.toJson(listMastp);
			model.addAttribute("eventEntryJsonStr", applicationEventJson);
			Set<HashMap<String, String>> setMast1 = new HashSet<>();
			for (String eventApp : eventAppSet) {
				HashMap<String, String> h = new HashMap<>();
				h.put("App_name", eventApp);
				setMast1.add(h);
			}
			String applicationEventJson1 = gson.toJson(setMast1);
			model.addAttribute("selectedeventAppJsonStr", applicationEventJson1);
			model.addAttribute("eventEntryBean", eventEntryBean);

			return new ModelAndView("editEntry");
		}

		eventEntryService.deleteEventUserBeforeEditSaveUsers(id);
		eventEntryService.deleteEventAppBeforeEditSaveApps(id);

		ModelAndView model1 = new ModelAndView();
		FileUpload fileUpload = new FileUpload();
		String fileContent = null;
		String attachfileName = null;
		String getEvent_file_name = null;
		List<String> fileNames = new ArrayList<String>();
		try {
			for (MultipartFile multipartFile : File_upload) {
				fileContent = fileUpload.process(multipartFile).toString();
				attachfileName = multipartFile.getOriginalFilename();
				fileNames.add(attachfileName);
				System.out.print("attachName-------------->>" + attachfileName);

			}
			model1.addObject("message", fileContent);

		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		getEvent_file_name = fileNames.toString().replaceAll("[\\[\\]+]", "");
		EventEntry eventEntry = eventEntryService.findById(eventEntryBean.getEvent_ID());
		StringBuffer buffer = null;
		if (eventEntry.getEvent_file_name() != null && eventEntry.getEvent_file_name() != "") {
			buffer = new StringBuffer(eventEntry.getEvent_file_name());
			if (!getEvent_file_name.equals("") && buffer.length() != 0) {
				buffer.append(", " + getEvent_file_name);
			}
			eventEntryBean.setEvent_file_name(buffer.toString());
		} else {
			eventEntryBean.setEvent_file_name(getEvent_file_name);
		}
		eventEntryBean.getEngagement_Name();
		/*
		 * HttpSession httpSession = httpServletRequest.getSession(); String
		 * userAccountName = (String) httpSession.getAttribute("userAcctName");
		 * eventEntryBean.setAccount_name(userAccountName);
		 */
		eventEntryBean.setAccount_name(eventEntryBean.getEngagement_Name());

		System.out.print("inside editSave");

		eventEntryService.editSave(eventEntryBean);

		eventEntryBean.setRemarks(eventEntryBean.getRemarks());
		eventEntryBean.setFile_upload(eventEntryBean.getFile_upload());
		String file_upload = String.valueOf(eventEntryBean.getFile_upload());
		String remarks = eventEntryBean.getRemarks();
		String eventName = eventEntryBean.getEventName();
		String startSate = eventEntryBean.getStart_date() + "T" + eventEntryBean.getStart_time();
		String endDate = eventEntryBean.getEnd_date() + "T" + eventEntryBean.getEnd_time();
		String emailID = eventEntryBean.getEmail_receipients();
		String emailID1 = eventEntryBean.getEmail_receipients1();

		if (emailID != null && emailID1 != null) {
			emailid = emailID + "," + emailID1;
		} else {

			emailid = emailID;
		}

		model.addAttribute("eventName", eventName);
		model.addAttribute("remarks", remarks);
		model.addAttribute("startSate", startSate);
		model.addAttribute("endDate", endDate);
		model.addAttribute("endDate", endDate);
		model.addAttribute("file_upload", file_upload);

		CalendarService calService = new CalendarService();
		calService.createCalendar(startSate, endDate, eventName, eventEntryBean.getDescription_details(),
				eventEntryBean.getEngagement_Name(), eventEntryBean.getRisk_summary());
		SimpleDateFormat dateParser = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");

		try {
			mailService.sendInvitation("DL IN NATools_Support", new String[] { emailid }, eventEntryBean.getEventName()
			/*
			 * , dateParser.parse( "28-08-2006 18:00" ) , dateParser.parse(
			 * "28-08-2006 21:00" )
			 */
			/* , eventEntryBean.getRecurrence() */
					, dateParser.parse(eventEntryBean.getStart_date() + "T" + eventEntryBean.getStart_time()),
					dateParser.parse(eventEntryBean.getEnd_date() + "T" + eventEntryBean.getEnd_time())

					, eventEntryBean.getRecurrence_type()

					, eventEntryBean.getRecu_every_day(), eventEntryBean.getRecu_every_weekday()

					, eventEntryBean.getRecu_every_week(), eventEntryBean.getRecurrence_dayName()

					, eventEntryBean.getRecu_every_month(), eventEntryBean.getRecu_month_day(),
					eventEntryBean.getMonthdd1(), eventEntryBean.getMonthdd2(), eventEntryBean.getMonthtext1(),
					eventEntryBean.getRecu_month_day_radio(), "LIS-42", "TBD"
					/*
					 * , "<font color=\"Black\">"+eventEntryBean.getDescription_details()+"</font>"
					 */
					,
					"<body bgcolor='#E6E6FA'> <table align='center' border='2' ><tr><td>EventName :</td><td><font color=\"Blue\">"
							+ eventEntryBean.getEventName() + "</font></td></tr>"
							+ "<tr><td>Description_details :</td><td><font color=\"Blue\">"
							+ eventEntryBean.getDescription_details() + "</font></td></tr>"
							+ "<tr><td>Category Name :</td><td><font color=\"Blue\">"
							+ eventEntryBean.getEvent_category_Name() + "</font></td></tr>"
							+ "<tr><td>Engagement Name :</td><td><font color=\"Blue\">"
							+ eventEntryBean.getEngagement_Name() + "</font></td></tr>"
							+ "<tr><td>Risk Summary :</td><td><font color=\"Blue\">" + eventEntryBean.getRisk_summary()
							+ "</font></td></tr>" + "<tr><td>Region territory :</td><td><font color=\"Blue\">"
							+ eventEntryBean.getEventName() + "</font></td></tr></table></body>",
					eventEntryBean.getEvent_file_name());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		/* Email code ends here */

		/* Email code ends here */

		// return new ModelAndView("viewEntry");
		model.addAttribute("filePath", dir + File.separator);
		model.addAttribute("calendarType",
				StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView(new RedirectView("../viewEntry"));

	}

	@RequestMapping(value = "/addRecurrence", method = RequestMethod.GET)
	public String addRecurrene(Model model) {
		model.addAttribute("calendarType",
				StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return "addRecurrence";

	}

	@RequestMapping(value = "/viewEventsInExcel", method = RequestMethod.POST)
	public ModelAndView viewEventsInExcel(Model model) {

		List<EventEntryBean> evnetEntryBeanList = new ArrayList<>();
		HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		List<EventEntry> eventList = eventEntryService.findAllEventByResource(userAccountName);
		for (EventEntry event : eventList) {
			if (event.getEventstatus() != null && !event.getEventstatus().equalsIgnoreCase("Cancelled")) {
				EventEntryBean eventEntryBean = new EventEntryBean();
				eventEntryBean.setEvent_ID(event.getEvent_ID());
				eventEntryBean.setEventName(event.getEventname());
				eventEntryBean.setDescription_details(event.getDescription_details());
				eventEntryBean.setStart_date(event.getStart_date());
				eventEntryBean.setEnd_date(event.getEnd_date());
				eventEntryBean.setRisk_summary(event.getRisk_summary());
				eventEntryBean.setRemarks(event.getRemarks());
				if (event.getEvent_file_name() != null) {
					List<String> fileNameList = Arrays.asList(event.getEvent_file_name().split("\\s*,\\s*"));
					eventEntryBean.setEvent_list(fileNameList);
				}
				Region region = regionService.findByRegionId(event.getRegion_id());
				if (region != null) {
					eventEntryBean.setRegion_territory(region.getRegion_territory());
				}
				Category category = categoryService.findByCategoryId(event.getEvent_category_id());
				if (category != null) {
					eventEntryBean.setEvent_category_Name(category.getEvent_category_name());
				}
				String[] eventAppSet = new String[event.getEventAppSet().size()];
				int i = 0;
				for (EventApplication eventApp : event.getEventAppSet()) {
					eventAppSet[i] = eventApp.getApplication();
					i++;
				}
				eventEntryBean.setEventAppSet(eventAppSet);
				String[] eventUserSet = new String[event.getEventUserSet().size()];
				int j = 0;
				for (EventUser eventUser : event.getEventUserSet()) {
					eventUserSet[j] = eventUser.getResource();
					j++;
				}
				eventUserSet = Arrays.stream(eventUserSet).filter(s -> (s != null && s.length() > 0))
						.toArray(String[]::new);

				Set<String> userSet = new HashSet<String>(Arrays.asList(eventUserSet));
				eventUserSet = userSet.toArray(new String[userSet.size()]);
				String eventUsersString = String.join(",", eventUserSet);
				eventEntryBean.setEventUsers(eventUsersString);
				eventEntryBean.setEventUserSet(eventUserSet);
				eventEntryBean.setEmail_receipients(event.getAdditional_receipients());
				eventEntryBean.setEngagement_Name(event.getEngagement_Name());
				evnetEntryBeanList.add(eventEntryBean);
			}
		}
		model.addAttribute("evnetEntryBeanList", evnetEntryBeanList);
		model.addAttribute("calendarType",
				StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		model.addAttribute("loggedInUname", SecurityContextHolder.getContext().getAuthentication().getName());
		return new ModelAndView("ViewEventsExcel", "evnetEntryBeanList", evnetEntryBeanList);
	}

	/* Upload Account Master starts here */

	private boolean checkIfRowIsEmpty(Row row) {
		if (row == null) {
			return true;
		}
		if (row.getLastCellNum() <= 0) {
			return true;
		}
		for (int cellNum = row.getFirstCellNum(); cellNum < row.getLastCellNum(); cellNum++) {
			Cell cell = row.getCell(cellNum);
			if (cell != null && cell.getCellType() != Cell.CELL_TYPE_BLANK) {
				return false;
			}
		}
		return true;
	}

	@RequestMapping(value = { "/uploadEvent" }, method = RequestMethod.GET)
	public String uploadEventPlannedGET(ModelMap model,
			@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean) {
		model.addAttribute("headerName", "eventSetup");
		List<EventEntry> eventEntry = eventEntryService.findAll();

		List<String> eventEntryStr = new ArrayList<String>();

		for (EventEntry eventEntryObj : eventEntry) {
			eventEntryStr.add(eventEntryObj.getEventname());
		}

		Date dt = new Date();
		Calendar c = Calendar.getInstance(); 
		c.setTime(dt); 
		c.add(Calendar.DATE, 1);
		dt = c.getTime();
	    System.out.println(dt);
	    SimpleDateFormat sm = new SimpleDateFormat("dd-MM-yyyy");
		String strDate = sm.format(dt);
		System.out.println(strDate); 

		
	    model.addAttribute("tomorrow",dt);
		model.addAttribute("eventEntryList", eventEntryStr);
		model.addAttribute("eventEntryBeanVal", eventEntryBean);
		model.addAttribute("loggedInUname", SecurityContextHolder.getContext().getAuthentication().getName());
		model.addAttribute("message", "");
		return "uploadEvent";
	}

	@RequestMapping(value = "/uploadEvent", method = RequestMethod.POST)
	public ModelAndView uploadEventPlannedPOST(ModelMap modelMap,
			@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean, @RequestParam("file") MultipartFile file,
			Model mod, HttpServletRequest request) throws FileNotFoundException, java.text.ParseException {
		String date = request.getParameter("date");
		System.out.println("date===========>"+date);
		ModelAndView model = new ModelAndView();
		FileUpload fileUpload = new FileUpload();
		model.addObject("message", fileUpload.processEventUpload(file));
		model.setViewName("uploadEvent");
		modelMap.addAttribute("loggedInUname", SecurityContextHolder.getContext().getAuthentication().getName());
		modelMap.addAttribute("eventEntryBeanVal", eventEntryBean);

		/* test xlsx file starts here */

		String fileName = file.getOriginalFilename();
		String rootPath = System.getProperty("catalina.home");

		 File myFile = new File(rootPath +
		 "\\webapps\\CBE_V2\\resources\\files\\"+fileName);

		EventEntryBean eventEntryBeanVal = new EventEntryBean();
	//	File myFile = new File("C:\\Users\\shmukka\\Downloads\\" + fileName);
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(myFile);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}

		// Finds the workbook instance for XLSX file

		XSSFWorkbook myWorkBook = null;
		try {
			myWorkBook = new XSSFWorkbook(fis);
		} catch (IOException e) {
			e.printStackTrace();
		}

		/* FIRST SHEET DATA HANDLING STARTS HERE */
		// Return first sheet from the XLSX workbook
		// XSSFSheet mySheet = myWorkBook.getSheetAt(1);
		XSSFSheet mySheet = myWorkBook.getSheet("Event Information");

		/* Adding error document starts here */

		/* Create a copy of uploaded excel starts here */

		XSSFWorkbook wb = null;

		XSSFSheet sheet = null;

		String errors = "";

		String userId = SecurityContextHolder.getContext().getAuthentication().getName();

		try {

			FileInputStream excelFile = new FileInputStream(myFile);

			Workbook workbook = new XSSFWorkbook(excelFile);

			if (!dir.exists())

				dir.mkdirs();

			//FileOutputStream outputStream = new FileOutputStream("C:\\Users\\shmukka\\Downloads" + "\\UploadEventErrorRecords_" + userId + ".xlsm");
			FileOutputStream outputStream = new FileOutputStream("${contextPath}\\resources\\files" + "\\UploadEventErrorRecords_" + userId + ".xlsm");
			workbook.write(outputStream);

			workbook.close();

			FileInputStream clonedFile = new FileInputStream(

					new File(dir + "\\UploadEventErrorRecords_" + userId + ".xlsm"));

			wb = new XSSFWorkbook(clonedFile);

			sheet = wb.getSheetAt(0);

		} catch (Exception e) {

			// TODO: handle exception

		}

		/* Create a copy of uploaded excel ends here */

		/* Adding error document ends here */

		// Get iterator to all the rows in current sheet
		Iterator<Row> rowIterator = mySheet.iterator();
		rowIterator.next();
		// Traversing over each row of XLSX file
		String event_Name = "";
		int loopCount = 1;
		while (rowIterator.hasNext()) {
		 Row row = rowIterator.next();
			// For each row, iterate through each columns
		 if(loopCount == 1) {
			Iterator<Cell> cellIterator = row.cellIterator();
			EventPlanned eventPlanned = null;
			boolean eventPlannedFlag = false;
			Long categoryIdLong = categoryService.findByEventCategoryName(row.getCell(2).toString()).getEvent_cat_id();
			Long regionIdLong = regionService.findByRegionTerritory(row.getCell(10).toString()).getRegion_id();
			Long calTypeIdLong = calendartypeService.findByCalendarTypeName(row.getCell(12).toString())
					.getCalendar_type_id();
			String[] appNamesStrArr = null;
			if (row.getCell(6) != null) {
				appNamesStrArr = row.getCell(6).toString().split(",");
			}
			String[] resourceNamesStrArr = null;
			if (row.getCell(7) != null) {
				resourceNamesStrArr = row.getCell(7).toString().split(",");
			}

			/*
			 * List<EventPlanned> result = eventPlannedRepository.findAll().stream()
			 * .filter(c -> c.getEvent_ID().equalsIgnoreCase(q))
			 * .collect(Collectors.toList());
			 */

			while (cellIterator.hasNext()) {
				Cell cell = cellIterator.next();
				/*
				 * switch (cell.getCellType()) { case Cell.CELL_TYPE_STRING:
				 * System.out.print(cell.getStringCellValue() + "\t"); break; case
				 * Cell.CELL_TYPE_NUMERIC: System.out.print(cell.getNumericCellValue() + "\t");
				 * break; case Cell.CELL_TYPE_BOOLEAN:
				 * System.out.print(cell.getBooleanCellValue() + "\t"); break; default :
				 * 
				 * }
				 */
				if (cell.getRowIndex() > 0) {

					if (row.getCell(0) != null)
						eventEntryBeanVal.setEventName(row.getCell(0).toString());
					event_Name = eventEntryBeanVal.getEventName();
					if (row.getCell(1) != null)
						eventEntryBeanVal.setDescription_details(row.getCell(1).toString());
					if (row.getCell(2) != null)
						eventEntryBeanVal.setEvent_category_id(categoryIdLong);
					if (row.getCell(3) != null) {
						eventEntryBeanVal.setEngagement_Name(row.getCell(3).toString());
						eventEntryBeanVal.setAccount_name(row.getCell(3).toString());
					}

					if (row.getCell(4) != null) {
						if (row.getCell(4).getCellType() == 0) {
							Date date1 = row.getCell(4).getDateCellValue();
							SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
							String datetime = format1.format(date1);
							eventEntryBeanVal.setStart_date(datetime);
						} else if (row.getCell(4).getCellType() == 1) {
							eventEntryBeanVal.setStart_date(row.getCell(4).toString());
						}

					}
					if (row.getCell(5) != null) {
						if (row.getCell(5).getCellType() == 0) {
							Date date1 = row.getCell(5).getDateCellValue();
							SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
							String datetime = format1.format(date1);
							eventEntryBeanVal.setEnd_date(datetime);
						} else if (row.getCell(5).getCellType() == 1) {
							eventEntryBeanVal.setEnd_date(row.getCell(5).toString());
						}
					}
					if (row.getCell(6) != null)
						eventEntryBeanVal.setEventAppSet(appNamesStrArr);
					if (row.getCell(7) != null)
						eventEntryBeanVal.setEventUserSet(resourceNamesStrArr);
					if (row.getCell(8) != null)
						eventEntryBeanVal.setEmail_receipients(row.getCell(8).toString());
					if (row.getCell(9) != null)
						eventEntryBeanVal.setRisk_summary(row.getCell(9).toString());
					if (row.getCell(10) != null)
						eventEntryBeanVal.setRegion_id(String.valueOf(regionIdLong));
					if (row.getCell(11) != null)
						eventEntryBeanVal.setRemarks(row.getCell(11).toString());
					if (row.getCell(12) != null)
						eventEntryBeanVal.setCalendar_type_id(calTypeIdLong);
					if (row.getCell(13) != null)
						eventEntryBeanVal.setRecurrence_type(row.getCell(13).toString());
					if (row.getCell(14) != null && !row.getCell(14).toString().equalsIgnoreCase(""))
						eventEntryBeanVal.setRecu_every_day(
								String.valueOf(Math.round(Float.parseFloat(row.getCell(14).toString()))));
					if (row.getCell(15) != null && !row.getCell(15).toString().equalsIgnoreCase(""))
						eventEntryBeanVal.setRecu_every_week(
								String.valueOf(Math.round(Float.parseFloat(row.getCell(15).toString()))));
					if (row.getCell(16) != null)
						eventEntryBeanVal.setRecurrence_dayName(row.getCell(16).toString());
					/*
					 * if(row.getCell(15)!= null)
					 * eventEntryBeanVal.setRecu_every_weekday(row.getCell(15).toString());
					 */

					if (row.getCell(17) != null && !row.getCell(17).toString().equalsIgnoreCase("")) {
						eventEntryBeanVal.setRecu_month_day(
								String.valueOf(Math.round(Float.parseFloat(row.getCell(17).toString()))));
						eventEntryBeanVal.setRecu_month_day_radio("1");
					}
					if (row.getCell(18) != null && !row.getCell(18).toString().equalsIgnoreCase("")) {
						eventEntryBeanVal.setRecu_every_month(
								String.valueOf(Math.round(Float.parseFloat(row.getCell(18).toString()))));
						eventEntryBeanVal.setRecu_month_day_radio("1");
					} else {
						eventEntryBeanVal.setRecu_month_day_radio("2");
					}

					// eventEntryBeanVal.setCalendar_type_id(1L);

					/*
					 * eventEntryBeanVal.setRegion_id("4");
					 * 
					 * 
					 * eventEntryBeanVal.setEvent_category_id(1L);
					 * eventEntryBeanVal.setMonthdd1("1"); eventEntryBeanVal.setMonthdd2("2");
					 */

					if (row.getCell(19) != null) {
						if (row.getCell(19).toString().equalsIgnoreCase("First")) {
							eventEntryBeanVal.setMonthdd1("1");
						} else if (row.getCell(19).toString().equalsIgnoreCase("Second")) {
							eventEntryBeanVal.setMonthdd1("2");
						} else if (row.getCell(19).toString().equalsIgnoreCase("Third")) {
							eventEntryBeanVal.setMonthdd1("3");
						} else if (row.getCell(19).toString().equalsIgnoreCase("Fourth")) {
							eventEntryBeanVal.setMonthdd1("4");
						} else if (row.getCell(19).toString().equalsIgnoreCase("Fifth")) {
							eventEntryBeanVal.setMonthdd1("5");
						} else if (row.getCell(19).toString().equalsIgnoreCase("Last")) {
							eventEntryBeanVal.setMonthdd1("99");
						}

					}
					if (row.getCell(20) != null) {

						if (row.getCell(20).toString().equalsIgnoreCase("Weekday")) {
							eventEntryBeanVal.setMonthdd2("9");
						} else if (row.getCell(20).toString().equalsIgnoreCase("Weekendday")) {
							eventEntryBeanVal.setMonthdd2("8");
						} else if (row.getCell(20).toString().equalsIgnoreCase("Sunday")) {
							eventEntryBeanVal.setMonthdd2("1");
						} else if (row.getCell(20).toString().equalsIgnoreCase("Monday")) {
							eventEntryBeanVal.setMonthdd2("2");
						} else if (row.getCell(20).toString().equalsIgnoreCase("Tuesday")) {
							eventEntryBeanVal.setMonthdd2("3");
						} else if (row.getCell(20).toString().equalsIgnoreCase("Wednesday")) {
							eventEntryBeanVal.setMonthdd2("4");
						} else if (row.getCell(20).toString().equalsIgnoreCase("Thursday")) {
							eventEntryBeanVal.setMonthdd2("5");
						} else if (row.getCell(20).toString().equalsIgnoreCase("Friday")) {
							eventEntryBeanVal.setMonthdd2("6");
						} else if (row.getCell(20).toString().equalsIgnoreCase("Saturday")) {
							eventEntryBeanVal.setMonthdd2("7");
						}
						eventEntryBeanVal.setRecu_month_day("1");
						eventEntryBeanVal.setRecu_every_month("1");
						eventEntryBeanVal.setRecu_month_day_radio("1");

					}
					if (row.getCell(21) != null && !row.getCell(21).toString().equalsIgnoreCase("")) {
						eventEntryBeanVal.setMonthtext1(
								String.valueOf(Math.round(Float.parseFloat(row.getCell(21).toString()))));
					}
					if (row.getCell(22) != null) {
						eventEntryBeanVal.setTime_zone(row.getCell(22).toString());
						eventPlannedFlag = true;
					}

				}

			}

			errors = uploadEventEntry(eventEntryBeanVal, request, errors);

			if (eventPlannedFlag) {

				try {
					if (request.getParameter("finalUpload") != null
							&& request.getParameter("finalUpload").equalsIgnoreCase("true")) {

						mod.addAttribute("finalUploadMsg", "yes");

					} else {
						if (errors != null && errors.length() > 0) {
							/* Cell color add starts here */
							CellStyle style = wb.createCellStyle();
							Font font = wb.createFont();
							font.setColor(HSSFColor.RED.index);
							style.setFont(font);
							/* Cell color add ends here */

							XSSFRow row1 = sheet.getRow(0);

							XSSFCell cell = row1.createCell(23);

							cell.setCellValue("Errors");
							cell.setCellStyle(style);

							XSSFRow rowC = sheet.getRow(row.getRowNum());

							XSSFCell cellC = rowC.createCell(23);

							cellC.setCellValue(errors);
							cellC.setCellStyle(style);
							errors = "";
							mod.addAttribute("errorFlag", "yes");
						} else {
							mod.addAttribute("validateMsg", "yes");
						}
					}
				
				} catch (Exception hex) {
					mod.addAttribute("exception", "There is an issue in uploading. Please contact technical support.");
					List<EventEntry> eventEntry = eventEntryService.findAll();

					List<String> eventEntryStr = new ArrayList<String>();

					for (EventEntry eventEntryObj : eventEntry) {
						eventEntryStr.add(eventEntryObj.getEventname());
					}

					mod.addAttribute("eventEntryList", eventEntryStr);
					return new ModelAndView("uploadEvent");
				}

			}
		}
		 loopCount++;
		}
		/* test xlsx file ends here */
		/* FIRST SHEET DATA HANDLING ENDS HERE */

		/* SECOND SHEET DATA HANDLING STARTS HERE */

		// Return first sheet from the XLSX workbook
		// XSSFSheet mySheet1 = myWorkBook.getSheetAt(0);
		XSSFSheet mySheet1 = myWorkBook.getSheet("Event Details");
		// Get iterator to all the rows in current sheet
		Iterator<Row> rowIterator1 = mySheet1.iterator();
		rowIterator1.next();
		Row row = null;
		Iterator<Cell> cellIterator = null;
		Cell cell = null;

		boolean flag = true;
		int highestversion = 0;
		// Traversing over each row of XLSX file
		while (rowIterator1.hasNext()) {
			row = rowIterator1.next();
			// For each row, iterate through each columns
			 if(row.getCell(0) != null && !row.getCell(0).toString().trim().equalsIgnoreCase("")) {
			cellIterator = row.cellIterator();
			EventPlanned eventPlanned = null;
			boolean eventPlannedFlag = false;

			while (cellIterator.hasNext()) {
				cell = cellIterator.next();
				/*
				 * switch (cell.getCellType()) { case Cell.CELL_TYPE_STRING:
				 * System.out.print(cell.getStringCellValue() + "\t"); break; case
				 * Cell.CELL_TYPE_NUMERIC: System.out.print(cell.getNumericCellValue() + "\t");
				 * break; case Cell.CELL_TYPE_BOOLEAN:
				 * System.out.print(cell.getBooleanCellValue() + "\t"); break; default :
				 * 
				 * }
				 */
				if (cell.getRowIndex() > 0) {
					eventPlanned = new EventPlanned();

					if (row != null && row.getCell(0) != null) {
						eventPlanned.setStep_Number(row.getCell(0).toString());
					} else {
						errors = errors + "The Step Number should not be empty";
					}
					if (row != null && row.getCell(1) != null) {
						eventPlanned.setCritical_Path(row.getCell(1).toString());
					}else {
						errors = errors + "Critical_Path should not be empty";
					}
					if (row != null && row.getCell(2) != null) {
						eventPlanned.setApplication_Name(row.getCell(2).toString());
					}
					if (row != null && row.getCell(3) != null) {
						eventPlanned.setJob_Name(row.getCell(3).toString());
					} else {
						errors = errors + "Job Name should not be empty";
					}
					
					if (row != null && row.getCell(4) != null) {
						eventPlanned.setProcess_Description(row.getCell(4).toString());
					}
					
					if (row != null && row.getCell(5) != null) {
						eventPlanned.setOwner(row.getCell(5).toString());
					} else {
						errors = errors + "Owner should not be empty";
					}
					if (row != null && row.getCell(6) != null) {
						eventPlanned.setTechnology(row.getCell(6).toString());
					}

					if (row != null && row.getCell(7) != null) {

						if (row.getCell(7) == null || row.getCell(7).getCellType() == Cell.CELL_TYPE_BLANK) {
							eventPlanned.setDay("0");
						}
						eventPlanned.setDay(row.getCell(7).toString());

					}
					if (row != null && row.getCell(8) != null) {
						if (row.getCell(8).getCellType() == 0) {
							Date date1 = row.getCell(8).getDateCellValue();
							SimpleDateFormat format1 = new SimpleDateFormat("HH:mm");
							String time = format1.format(date1);
							eventPlanned.setPlanned_Start_Time(time);
						} else if (row.getCell(8).getCellType() == 1) {
							eventPlanned.setPlanned_Start_Time(row.getCell(8).toString());
						}
					} else {
						errors = errors + "The Start_Time should not be empty";
					}
					if (row != null && row.getCell(9) != null) {
						if (row.getCell(9).getCellType() == 0) {
							Date date1 = row.getCell(9).getDateCellValue();
							SimpleDateFormat format1 = new SimpleDateFormat("HH:mm");
							String time = format1.format(date1);
							eventPlanned.setPlanned_End_Time(time);
						} else if (row.getCell(9).getCellType() == 1) {
							eventPlanned.setPlanned_End_Time(row.getCell(9).toString());
						}
					} else {
						errors = errors + "The End_Time should not be empty";
					}

					if(eventPlanned.getPlanned_Start_Time().equalsIgnoreCase("NA") && (eventPlanned.getJob_Name().equalsIgnoreCase("CriticalPath") || 
							eventPlanned.getJob_Name().equalsIgnoreCase("Checkpoint"))) {
						eventPlanned.setPlanned_Run_Time("");
					}else if(eventPlanned.getPlanned_Start_Time() != null && eventPlanned.getPlanned_End_Time() != null 
							&& eventPlanned.getPlanned_Start_Time() != "NA"){
						
						SimpleDateFormat format1 = new SimpleDateFormat("HH:mm");
						Date date1 = null;
						Date date2 = null;
						try {
							date1 = format1.parse(eventPlanned.getPlanned_Start_Time());
							date2 = format1.parse(eventPlanned.getPlanned_End_Time());
						} catch (Exception e) {
							e.printStackTrace();
						}
						long difference = date2.getTime() - date1.getTime();
						long difference_In_Minutes = (difference / (1000 * 60)) % 60;
						long difference_In_Hours = (difference / (1000 * 60 * 60)) % 24;
	
						String runTime = difference_In_Hours + ":" + difference_In_Minutes;
						eventPlanned.setPlanned_Run_Time(runTime);
					}

					if (row != null && row.getCell(10) != null) {
						eventPlanned.setSupport_Team_Email_ID(row.getCell(10).toString());
					}
					if (row != null && row.getCell(11) != null) {
						eventPlanned.setEscalation_Email_Group(row.getCell(11).toString());
					}
					if (row != null && row.getCell(12) != null) {
						eventPlanned.setBusiness_Contact_Email(row.getCell(12).toString());
					}
					if (row != null && row.getCell(13) != null) {
						eventPlanned.setThresold_Alert_Time(row.getCell(13).toString());
					}
					if (row != null && row.getCell(14) != null) {
						eventPlanned.setBusiness_Impact(row.getCell(14).toString());
					}
					if (row != null && row.getCell(15) != null) {
						eventPlanned.setIsNotificationRequired(row.getCell(15).toString());
					}
					
					eventPlannedFlag = true;
				}

			}

			if (eventPlannedFlag) {
				try {
					if (request.getParameter("finalUpload") != null
							&& request.getParameter("finalUpload").equalsIgnoreCase("true")) {

						// EventEntryMaster entryMaster =
						// eventEntryMasterService.findByEventName(event_Name);
						EventEntry entryMaster = eventEntryService.findByEventName(event_Name);
						EventEntry entry = null;
						if (entryMaster != null) {

							entry = eventEntryRepository.findOne(entryMaster.getEvent_ID());

							if (flag == true) {
								highestversion = eventEntryService.getAllId(entry.getEvent_ID());
								flag = false;
							}

							eventPlanned.setEvent_ID(entry.getEvent_ID().toString());
							eventPlanned.setVersion(highestversion + 1);
							System.out.println(eventPlanned);
							eventPlanned.setEffective_Date(date);
							eventEntryService.savePlanned(eventPlanned);

							List<EventEntry> eventEntry = eventEntryService.findAll();

							List<String> eventEntryStr = new ArrayList<String>();

							for (EventEntry eventEntryObj : eventEntry) {
								eventEntryStr.add(eventEntryObj.getEventname());
							}

							mod.addAttribute("eventEntryList", eventEntryStr);
							mod.addAttribute("finalUploadMsg", "yes");
						}

					} else {
						if (errors != null && errors.length() > 0) {
							/* Cell color add starts here */
							CellStyle style = wb.createCellStyle();
							Font font = wb.createFont();
							font.setColor(HSSFColor.RED.index);
							style.setFont(font);
							/* Cell color add ends here */

							XSSFRow row1 = mySheet1.getRow(0);
							XSSFCell cell1 = row1.createCell(16);
							cell1.setCellValue("Errors");
							cell1.setCellStyle(style);

							XSSFRow rowC = sheet.getRow(row.getRowNum());
							XSSFCell cellC = rowC.createCell(16);

							cellC.setCellValue(errors);
							cellC.setCellStyle(style);
							errors = "";
							mod.addAttribute("errorFlag", "yes");
						} else {
							mod.addAttribute("validateMsg", "yes");
							mod.addAttribute("finalUploadMsg", "no");
						}
					}
				} catch (Exception hex) {
					mod.addAttribute("finalUploadMsg", "no");
					mod.addAttribute("exception", "There is an issue in uploading. Please contact technical support.");
					List<EventEntry> eventEntry = eventEntryService.findAll();

					List<String> eventEntryStr = new ArrayList<String>();

					for (EventEntry eventEntryObj : eventEntry) {
						eventEntryStr.add(eventEntryObj.getEventname());
					}

					mod.addAttribute("eventEntryList", eventEntryStr);
					return new ModelAndView("uploadEvent");
				}
			}
			}
		}
		/* SECOND SHEET DATA HANDLING ENDS HERE */

		mod.addAttribute("headerName", "eventSetup");
		return model;
	}

	@JsonIgnoreProperties
	@RequestMapping(value = "/uploadEventAJAX", method = RequestMethod.POST)
	public ResponseEntity<?> uploadEventPlannedAJAX(ModelMap modelMap,
			@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean, @RequestParam("file") MultipartFile file,
			Model mod, HttpServletRequest request) throws FileNotFoundException, java.text.ParseException {
		String date = request.getParameter("date");
		System.out.println("date==>"+date);
		ModelAndView model = new ModelAndView();
		FileUpload fileUpload = new FileUpload();
		model.addObject("message", fileUpload.processEventUpload(file));
		model.setViewName("uploadEvent");
		modelMap.addAttribute("loggedInUname", SecurityContextHolder.getContext().getAuthentication().getName());
		modelMap.addAttribute("eventEntryBeanVal", eventEntryBean);

		String event_Name = "";
		/* test xlsx file starts here */

		String fileName = file.getOriginalFilename();
		String rootPath = System.getProperty("catalina.home");
		// File myFile = new File(rootPath +
		// "/webapps/CBE-ARMS/resources/documents/"+fileName);

		EventEntryBean eventEntryBeanVal = new EventEntryBean();
		File myFile = new File(rootPath +
		"\\webapps\\CBE_V2\\resources\\files\\"+fileName);
	//	File myFile = new File("C:\\Users\\shmukka\\Downloads\\" + fileName);
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(myFile);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}

		// Finds the workbook instance for XLSX file

		XSSFWorkbook myWorkBook = null;
		try {
			myWorkBook = new XSSFWorkbook(fis);
		} catch (IOException e) {
			e.printStackTrace();
		}

		/* FIRST SHEET DATA HANDLING STARTS HERE */
		// Return first sheet from the XLSX workbook
		// XSSFSheet mySheet = myWorkBook.getSheetAt(1);
		XSSFSheet mySheet = myWorkBook.getSheet("Event Information");

		/* Adding error document starts here */

		/* Create a copy of uploaded excel starts here */

		XSSFWorkbook wb = null;

		XSSFSheet sheet = null;

		String errors = "";

		String userId = SecurityContextHolder.getContext().getAuthentication().getName();

		try {

			FileInputStream excelFile = new FileInputStream(myFile);

			Workbook workbook = new XSSFWorkbook(excelFile);

			if (!dir.exists())

				dir.mkdirs();

			FileOutputStream outputStream = new FileOutputStream(

					dir + "\\UploadEventErrorRecords_" + userId + ".xlsm");

			workbook.write(outputStream);

			workbook.close();

			FileInputStream clonedFile = new FileInputStream(

					new File(dir + "\\UploadEventErrorRecords_" + userId + ".xlsm"));

			wb = new XSSFWorkbook(clonedFile);

			sheet = wb.getSheet("EventDetail");

		} catch (Exception e) {
			// TODO: handle exception
		}

		/* Create a copy of uploaded excel ends here */

		/* Adding error document ends here */

		// Get iterator to all the rows in current sheet
		Iterator<Row> rowIterator = mySheet.iterator();
		rowIterator.next();
		int loopCount = 1;
		// Traversing over each row of XLSX file
		while (rowIterator.hasNext()) {
			Row row = rowIterator.next();
			// For each row, iterate through each columns
			if(loopCount == 1 ) {
				
			Iterator<Cell> cellIterator = row.cellIterator();
			EventPlanned eventPlanned = null;
			boolean eventPlannedFlag = false;
		
			Long categoryIdLong = categoryService.findByEventCategoryName(row.getCell(2).toString()).getEvent_cat_id();
			Long regionIdLong = regionService.findByRegionTerritory(row.getCell(10).toString()).getRegion_id();
			Long calTypeIdLong = calendartypeService.findByCalendarTypeName(row.getCell(12).toString())
					.getCalendar_type_id();
			while (cellIterator.hasNext()) {
				Cell cell = cellIterator.next();
				/*
				 * switch (cell.getCellType()) { case Cell.CELL_TYPE_STRING:
				 * System.out.print(cell.getStringCellValue() + "\t"); break; case
				 * Cell.CELL_TYPE_NUMERIC: System.out.print(cell.getNumericCellValue() + "\t");
				 * break; case Cell.CELL_TYPE_BOOLEAN:
				 * System.out.print(cell.getBooleanCellValue() + "\t"); break; default :
				 * 
				 * }
				 */

				if (cell.getRowIndex() > 0) {

					if (row.getCell(0) != null)
						eventEntryBeanVal.setEventName(row.getCell(0).toString());
					event_Name = eventEntryBeanVal.getEventName();
					if (row.getCell(1) != null)
						eventEntryBeanVal.setDescription_details(row.getCell(1).toString());
					if (row.getCell(2) != null)
						eventEntryBeanVal.setEvent_category_id(categoryIdLong);
					if (row.getCell(3) != null) {
						eventEntryBeanVal.setEngagement_Name(row.getCell(3).toString());
						eventEntryBeanVal.setAccount_name(row.getCell(3).toString());
					}
					if (row.getCell(4) != null) {
						if (row.getCell(4).getCellType() == 0) {
							Date date1 = row.getCell(4).getDateCellValue();
							SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
							String datetime = format1.format(date1);
							eventEntryBeanVal.setStart_date(datetime);
						} else if (row.getCell(4).getCellType() == 1) {
							eventEntryBeanVal.setStart_date(row.getCell(4).toString());
						}

					}
					if (row.getCell(5) != null) {
						if (row.getCell(5).getCellType() == 0) {
							Date date1 = row.getCell(5).getDateCellValue();
							SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
							String datetime = format1.format(date1);
							eventEntryBeanVal.setEnd_date(datetime);
						} else if (row.getCell(5).getCellType() == 1) {
							eventEntryBeanVal.setEnd_date(row.getCell(5).toString());
						}
					}
					if (row.getCell(8) != null)
						eventEntryBeanVal.setEmail_receipients(row.getCell(8).toString());
					if (row.getCell(9) != null)
						eventEntryBeanVal.setRisk_summary(row.getCell(9).toString());
					if (row.getCell(10) != null)
						eventEntryBeanVal.setRegion_id(String.valueOf(regionIdLong));
					if (row.getCell(11) != null)
						eventEntryBeanVal.setRemarks(row.getCell(11).toString());
					if (row.getCell(12) != null)
						eventEntryBeanVal.setCalendar_type_id(calTypeIdLong);
					if (row.getCell(13) != null)
						eventEntryBeanVal.setRecurrence_type(row.getCell(13).toString());
					if (row.getCell(14) != null && !row.getCell(14).toString().equalsIgnoreCase(""))
						eventEntryBeanVal.setRecu_every_day(
								String.valueOf(Math.round(Float.parseFloat(row.getCell(14).toString()))));
					if (row.getCell(15) != null && !row.getCell(15).toString().equalsIgnoreCase(""))
						eventEntryBeanVal.setRecu_every_week(
								String.valueOf(Math.round(Float.parseFloat(row.getCell(15).toString()))));
					if (row.getCell(16) != null)
						eventEntryBeanVal.setRecurrence_dayName(row.getCell(16).toString());
					/*
					 * if(row.getCell(15)!= null)
					 * eventEntryBeanVal.setRecu_every_weekday(row.getCell(15).toString());
					 */

					if (row.getCell(17) != null && !row.getCell(17).toString().equalsIgnoreCase("")) {
						eventEntryBeanVal.setRecu_month_day(
								String.valueOf(Math.round(Float.parseFloat(row.getCell(17).toString()))));
						eventEntryBeanVal.setRecu_month_day_radio("1");
					}
					if (row.getCell(18) != null && !row.getCell(18).toString().equalsIgnoreCase("")) {
						eventEntryBeanVal.setRecu_every_month(
								String.valueOf(Math.round(Float.parseFloat(row.getCell(18).toString()))));
						eventEntryBeanVal.setRecu_month_day_radio("1");
					} else {
						eventEntryBeanVal.setRecu_month_day_radio("2");
					}

					eventEntryBeanVal.setCalendar_type_id(1L);

					/*
					 * eventEntryBeanVal.setRegion_id("4");
					 * 
					 * 
					 * eventEntryBeanVal.setEvent_category_id(1L);
					 * eventEntryBeanVal.setMonthdd1("1"); eventEntryBeanVal.setMonthdd2("2");
					 */

					if (row.getCell(19) != null) {
						if (row.getCell(19).toString().equalsIgnoreCase("First")) {
							eventEntryBeanVal.setMonthdd1("1");
						} else if (row.getCell(19).toString().equalsIgnoreCase("Second")) {
							eventEntryBeanVal.setMonthdd1("2");
						} else if (row.getCell(19).toString().equalsIgnoreCase("Third")) {
							eventEntryBeanVal.setMonthdd1("3");
						} else if (row.getCell(19).toString().equalsIgnoreCase("Fourth")) {
							eventEntryBeanVal.setMonthdd1("4");
						} else if (row.getCell(19).toString().equalsIgnoreCase("Fifth")) {
							eventEntryBeanVal.setMonthdd1("5");
						} else if (row.getCell(19).toString().equalsIgnoreCase("Last")) {
							eventEntryBeanVal.setMonthdd1("99");
						}

					}
					if (row.getCell(20) != null) {

						if (row.getCell(20).toString().equalsIgnoreCase("Weekday")) {
							eventEntryBeanVal.setMonthdd2("9");
						} else if (row.getCell(20).toString().equalsIgnoreCase("Weekendday")) {
							eventEntryBeanVal.setMonthdd2("8");
						} else if (row.getCell(20).toString().equalsIgnoreCase("Sunday")) {
							eventEntryBeanVal.setMonthdd2("1");
						} else if (row.getCell(20).toString().equalsIgnoreCase("Monday")) {
							eventEntryBeanVal.setMonthdd2("2");
						} else if (row.getCell(20).toString().equalsIgnoreCase("Tuesday")) {
							eventEntryBeanVal.setMonthdd2("3");
						} else if (row.getCell(20).toString().equalsIgnoreCase("Wednesday")) {
							eventEntryBeanVal.setMonthdd2("4");
						} else if (row.getCell(20).toString().equalsIgnoreCase("Thursday")) {
							eventEntryBeanVal.setMonthdd2("5");
						} else if (row.getCell(20).toString().equalsIgnoreCase("Friday")) {
							eventEntryBeanVal.setMonthdd2("6");
						} else if (row.getCell(20).toString().equalsIgnoreCase("Saturday")) {
							eventEntryBeanVal.setMonthdd2("7");
						}
						eventEntryBeanVal.setRecu_month_day("1");
						eventEntryBeanVal.setRecu_every_month("1");
						eventEntryBeanVal.setRecu_month_day_radio("1");

					}
					if (row.getCell(21) != null && !row.getCell(21).toString().equalsIgnoreCase("")) {
						eventEntryBeanVal.setMonthtext1(
								String.valueOf(Math.round(Float.parseFloat(row.getCell(21).toString()))));
					}
					if (row.getCell(22) != null)
						eventEntryBeanVal.setTime_zone(row.getCell(22).toString());
					eventPlannedFlag = true;
				}
			}

			errors = uploadEventEntry(eventEntryBeanVal, request, errors);

			if (eventPlannedFlag) {
				try {
					if (request.getParameter("finalUpload") != null
							&& request.getParameter("finalUpload").equalsIgnoreCase("true")) {
						// eventEntryService.savePlanned(eventPlanned);
						mod.addAttribute("finalUploadMsg", "yes");
					} else {
						if (errors != null && errors.length() > 0) {
							/* Cell color add starts here */
							CellStyle style = wb.createCellStyle();
							Font font = wb.createFont();
							font.setColor(HSSFColor.RED.index);
							style.setFont(font);
							/* Cell color add ends here */

							XSSFRow row1 = sheet.getRow(0);

							XSSFCell cell = row1.createCell(23);

							cell.setCellValue("Errors");
							cell.setCellStyle(style);

							XSSFRow rowC = sheet.getRow(row.getRowNum());

							XSSFCell cellC = rowC.createCell(23);

							cellC.setCellValue(errors);
							cellC.setCellStyle(style);

							File outWB = new File(dir + "\\UploadEventErrorRecords_" + userId + ".xlsm");

							OutputStream out = new FileOutputStream(outWB);

							wb.write(out);

							out.flush();

							out.close();

							wb.close();

							// errors = "";
							mod.addAttribute("errorFlag", "yes");
						} else {
							mod.addAttribute("validateMsg", "yes");
						}
					
					}
				} catch (Exception hex) {
					mod.addAttribute("exception", "There is an issue in uploading. Please contact technical support.");
					// return new ModelAndView("uploadEvent");
				}

			}
		}
			loopCount++;
		}
		/* test xlsx file ends here */
		/* FIRST SHEET DATA HANDLING ENDS HERE */

		/* SECOND SHEET DATA HANDLING STARTS HERE */

		// Return first sheet from the XLSX workbook
		// XSSFSheet mySheet1 = myWorkBook.getSheetAt(0);
		XSSFSheet mySheet1 = myWorkBook.getSheet("Event Details");
		// Get iterator to all the rows in current sheet
		Iterator<Row> rowIterator1 = mySheet1.iterator();
		rowIterator1.next();
		Row row = null;

		Iterator<Cell> cellIterator = null;
		Cell cell = null;

		boolean flag = true;
		int highestversion = 0;
		Set<String> errors1 = new HashSet<String>();
		// Traversing over each row of XLSX file
		while (rowIterator1.hasNext()) {
			row = rowIterator1.next();
			// For each row, iterate through each columns
			 if(row.getCell(0) != null && !row.getCell(0).toString().trim().equalsIgnoreCase("")) {
			cellIterator = row.cellIterator();
			EventPlanned eventPlanned = null;
			boolean eventPlannedFlag = false;

			while (cellIterator.hasNext()) {
				cell = cellIterator.next();
				/*
				 * switch (cell.getCellType()) { case Cell.CELL_TYPE_STRING:
				 * System.out.print(cell.getStringCellValue() + "\t"); break; case
				 * Cell.CELL_TYPE_NUMERIC: System.out.print(cell.getNumericCellValue() + "\t");
				 * break; case Cell.CELL_TYPE_BOOLEAN:
				 * System.out.print(cell.getBooleanCellValue() + "\t"); break; default :
				 * 
				 * }
				 */
				if (cell.getRowIndex() > 0) {
					eventPlanned = new EventPlanned();

					if (row != null && row.getCell(0) != null && String.valueOf(row.getCell(0)) != "") {
						eventPlanned.setStep_Number(row.getCell(0).toString());
					} else {
						errors1.add("The Step Number should not be empty;");
					}
					if (row != null && row.getCell(1) != null) {
						eventPlanned.setCritical_Path(row.getCell(1).toString());
					}else {
						errors1.add("Critical_Path should not be empty");
					}
					if (row != null && row.getCell(2) != null) {
						eventPlanned.setApplication_Name(row.getCell(2).toString());
					}
					if (row != null && row.getCell(3) != null && String.valueOf(row.getCell(3)) != "") {
						eventPlanned.setJob_Name(row.getCell(3).toString());
					} else {
						errors1.add("Job Name should not be empty;");
					}
					
					if (row != null && row.getCell(4) != null && String.valueOf(row.getCell(4)) != "") {
						eventPlanned.setProcess_Description(row.getCell(4).toString());
					}
					
					if (row != null && row.getCell(5) != null && String.valueOf(row.getCell(5)) != "") {
						eventPlanned.setOwner(row.getCell(5).toString());
					} else {
						errors1.add("Owner should not be empty;");
					}
					if (row != null && row.getCell(6) != null) {
						eventPlanned.setTechnology(row.getCell(6).toString());
					}
					if (row != null && row.getCell(7) != null) {

						if (row.getCell(7) == null || row.getCell(7).getCellType() == Cell.CELL_TYPE_BLANK) {
							eventPlanned.setDay("0");
						}
						eventPlanned.setDay(row.getCell(7).toString());

					}

					if (row != null && row.getCell(8) != null) {
						if (row.getCell(8).getCellType() == 0) {
							Date date1 = row.getCell(8).getDateCellValue();
							SimpleDateFormat format1 = new SimpleDateFormat("HH:mm");
							String time = format1.format(date1);
							eventPlanned.setPlanned_Start_Time(time);
						} else if (row.getCell(8).getCellType() == 1) {
							eventPlanned.setPlanned_Start_Time(row.getCell(8).toString());
						}
					} else {
						errors1.add("The Start_Time should not be empty");
					}
					if (row != null && row.getCell(9) != null) {
						if (row.getCell(9).getCellType() == 0) {
							Date date1 = row.getCell(9).getDateCellValue();
							SimpleDateFormat format1 = new SimpleDateFormat("HH:mm");
							String time = format1.format(date1);
							eventPlanned.setPlanned_End_Time(time);
						} else if (row.getCell(9).getCellType() == 1) {
							eventPlanned.setPlanned_End_Time(row.getCell(9).toString());
						}
					} else {
						errors1.add("The End_Time should not be empty");
					}

					if(eventPlanned.getPlanned_Start_Time().equalsIgnoreCase("NA") && (eventPlanned.getJob_Name().equalsIgnoreCase("CriticalPath") || eventPlanned.getJob_Name().equalsIgnoreCase("Checkpoint"))) {
						eventPlanned.setPlanned_Run_Time("");
					}else if(eventPlanned.getPlanned_Start_Time() != null && eventPlanned.getPlanned_End_Time() != null 
							&& eventPlanned.getPlanned_Start_Time() != "NA"){
						
						SimpleDateFormat format1 = new SimpleDateFormat("HH:mm");
						Date date1 = null;
						Date date2 = null;
						try {
							date1 = format1.parse(eventPlanned.getPlanned_Start_Time());
							date2 = format1.parse(eventPlanned.getPlanned_End_Time());
						} catch (Exception e) {
							e.printStackTrace();
						}
						long difference = date2.getTime() - date1.getTime();
						long difference_In_Minutes = (difference / (1000 * 60)) % 60;
						long difference_In_Hours = (difference / (1000 * 60 * 60)) % 24;
	
						String runTime = difference_In_Hours + ":" + difference_In_Minutes;
						eventPlanned.setPlanned_Run_Time(runTime);
					}
					
					if (row != null && row.getCell(10) != null) {
						eventPlanned.setSupport_Team_Email_ID(row.getCell(10).toString());
					}
					if (row != null && row.getCell(11) != null) {
						eventPlanned.setEscalation_Email_Group(row.getCell(11).toString());
					}
					if (row != null && row.getCell(12) != null) {
						eventPlanned.setBusiness_Contact_Email(row.getCell(12).toString());
					}
					if (row != null && row.getCell(13) != null) {
						eventPlanned.setThresold_Alert_Time(row.getCell(13).toString());
					}
					if (row != null && row.getCell(14) != null) {
						eventPlanned.setBusiness_Impact(row.getCell(14).toString());
					}
					if (row != null && row.getCell(15) != null) {
						eventPlanned.setIsNotificationRequired(row.getCell(15).toString());
					}
					eventPlannedFlag = true;
				}
			}
			if (eventPlannedFlag) {

				try {
					if (request.getParameter("finalUpload") != null
							&& request.getParameter("finalUpload").equalsIgnoreCase("true")) {

						EventEntryMaster entryMaster = eventEntryMasterService.findByEventName(event_Name);
						EventEntry entry = null;
						if (entryMaster != null) {

							entry = eventEntryRepository.findOne(entryMaster.getEvent_ID());

							if (flag == true) {
								highestversion = eventEntryService.getAllId(entry.getEvent_ID());
								flag = false;
							}

							eventPlanned.setEvent_ID(entry.getEvent_ID().toString());
							eventPlanned.setVersion(highestversion + 1);
							System.out.println(eventPlanned);
							eventPlanned.setEffective_Date(date);
							eventEntryService.savePlanned(eventPlanned);
							mod.addAttribute("finalUploadMsg", "yes");

						}
					}

					else {
						if (errors1 != null && errors1.size() > 0) {
							// Cloning the file starts here
							FileInputStream excelFile = new FileInputStream(
									dir + "\\UploadEventErrorRecords_" + userId + ".xlsm");
							Workbook workbook = new XSSFWorkbook(excelFile);
							if (!dir.exists())
								dir.mkdirs();
							FileOutputStream outputStream = new FileOutputStream(
									dir + "\\UploadEventErrorRecords_" + userId + ".xlsm");
							workbook.write(outputStream);
							workbook.close();

							// Cloning the file ends here

							XSSFWorkbook wb1 = null;

							FileInputStream clonedFile1 = new FileInputStream(

									new File(dir + "\\UploadEventErrorRecords_" + userId + ".xlsm"));

							wb1 = new XSSFWorkbook(clonedFile1);

							XSSFSheet sheet1 = wb1.getSheet("Event Details");

							XSSFRow row1 = sheet1.getRow(0);

							XSSFCell cell1 = row1.createCell(16);

							/* Cell color add starts here */
							CellStyle style = wb1.createCellStyle();
							Font font = wb1.createFont();
							font.setColor(HSSFColor.RED.index);
							style.setFont(font);
							/* Cell color add ends here */

							cell1.setCellValue("Errors");
							cell1.setCellStyle(style);

							XSSFRow rowC = sheet1.getRow(row.getRowNum());

							XSSFCell cellC = rowC.createCell(16);

							cellC.setCellValue(errors1.toString());
							cellC.setCellStyle(style);

							File outWB = new File(dir + "\\UploadEventErrorRecords_" + userId + ".xlsm");

							OutputStream out = new FileOutputStream(outWB);

							wb1.write(out);

							out.flush();

							out.close();

							wb1.close();

							errors1 = new HashSet<String>();
							mod.addAttribute("errorFlag", "yes");
						} else {
							mod.addAttribute("validateMsg", "yes");
							mod.addAttribute("finalUploadMsg", "no");
						}
					}
				} catch (Exception hex) {
					hex.printStackTrace();
					mod.addAttribute("finalUploadMsg", "no");
					mod.addAttribute("exception", "There is an issue in uploading. Please contact technical support.");
					List<EventEntry> eventEntry = eventEntryService.findAll();

					List<String> eventEntryStr = new ArrayList<String>();

					for (EventEntry eventEntryObj : eventEntry) {
						eventEntryStr.add(eventEntryObj.getEventname());
					}

					mod.addAttribute("eventEntryList", eventEntryStr);
					// return new ModelAndView("uploadEvent");
				}
			}
			}
		}

		/* SECOND SHEET DATA HANDLING ENDS HERE */
		if (!StringUtils.isEmpty(errors) || (errors1 != null && errors1.size() > 0)) {
			return ResponseEntity.ok("Yes");
		} else {
			return ResponseEntity.ok("");
		}
	}


	
	@RequestMapping(value = "/downloadEvent/{eventName}", method = RequestMethod.GET)
	public void downloadEvent(@PathVariable String eventName,ModelMap modelMap, @ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean,
			Model mod, HttpServletRequest request, HttpServletResponse response) throws Exception {

		//eventName = request.getParameter("eventName");
		EventEntry eventEntry = eventEntryService.findByEventName(eventName);
		Long event_id = eventEntry.getEvent_ID();
		mod.addAttribute("event_id", event_id);

		String category_name = eventEntryService.getCategoryName(eventEntry.getEvent_category_id());
		String region_name = eventEntryService.getRegionName(eventEntry.getRegion_id());
		String app_name = eventEntryService.getApplicationName(event_id);
		String resource_name = eventEntryService.getResourceName(event_id);
		String calendar_type = eventEntryService.getCalendarType(eventEntry.getCalendar_type_id());

		List<EventPlanned> eventPlannedList = eventEntryService.highestVersion(eventName);
		
		FileInputStream file = new FileInputStream(dir+"\\Event_Planning Template.xlsm");
        
        XSSFWorkbook workbook = new XSSFWorkbook(file);
        XSSFSheet sheet1 = workbook.getSheetAt(0);
        XSSFSheet sheet2 = workbook.getSheetAt(1);
        file.close();
        
		if (!eventPlannedList.isEmpty()) {
			Map<Integer, Object[]> data1 = new TreeMap<Integer, Object[]>();
			
			data1.put(2, new Object[] { eventEntry.getEventname(), eventEntry.getDescription_details(), category_name,
					eventEntry.getEngagement_Name(), eventEntry.getStart_date(), eventEntry.getEnd_date(), app_name,
					resource_name, eventEntry.getAdditional_receipients(), eventEntry.getRisk_summary(), region_name,
					eventEntry.getRemarks(), calendar_type, eventEntry.getRecurrence_type(),
					eventEntry.getRecu_every_day(), eventEntry.getRecu_every_week(), eventEntry.getRecurrence_dayName(),
					eventEntry.getRecu_month_day(), eventEntry.getRecu_every_month(), eventEntry.getMonthdd1(),
					eventEntry.getMonthdd2(), eventEntry.getMonthtext1(), eventEntry.getTime_zone() });

			Set<Integer> keyset1 = data1.keySet();
			int rownum1 = 1;
			for (Integer key1 : keyset1) {
				Row row1 = sheet1.createRow(rownum1++);
				Object[] objArr1 = data1.get(key1);
				int cellnum1 = 0;
				for (Object obj1 : objArr1) {

					Cell cell1 = row1.createCell(cellnum1++);
					if (obj1 instanceof String)
						cell1.setCellValue((String) obj1);
					else if (obj1 instanceof Integer)
						cell1.setCellValue((Integer) obj1);
				}
			}
			
			Map<Integer, Object[]> data2 = new TreeMap<Integer, Object[]>();
			int i = 1;
			for (EventPlanned e : eventPlannedList) {
				i++;
				data2.put(i,
						new Object[] { e.getStep_Number(), e.getCritical_Path(), e.getApplication_Name(),
								e.getJob_Name(), e.getProcess_Description(), e.getOwner(), e.getTechnology(), e.getDay(), e.getPlanned_Start_Time(),
								e.getPlanned_End_Time(), e.getSupport_Team_Email_ID(), e.getEscalation_Email_Group(),
								e.getBusiness_Contact_Email(), e.getThresold_Alert_Time(), e.getBusiness_Impact() });
			}
			
			Set<Integer> keyset2 = data2.keySet();
			int rownum2 = 1;
			for (Integer key2 : keyset2) {
				Row row2 = sheet2.createRow(rownum2++);
				Object[] objArr2 = data2.get(key2);
				int cellnum2 = 0;
				for (Object obj2 : objArr2) {
					Cell cell2 = row2.createCell(cellnum2++);
					if (obj2 instanceof String)
						cell2.setCellValue((String) obj2);
					else if (obj2 instanceof Integer)
						cell2.setCellValue((Integer) obj2);
				}
				objArr2 = null;
				row2 = null;
			}

			try {
				ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
				workbook.write(outByteStream);
				byte [] outArray = outByteStream.toByteArray();
				response.setContentType("application/ms-excel");
				response.setContentLength(outArray.length); 
				response.setHeader("Expires:", "0"); // eliminates browser caching
				response.setHeader("Content-Disposition", "attachment; filename="+eventName+".xlsm");
				OutputStream outStream = response.getOutputStream();
				outStream.write(outArray);
				outStream.flush();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			mod.addAttribute("exception", "There is an issue in downloading. Please contact technical support.");
		}
	}
	

	@RequestMapping(value = "/getDateByEventName", method = RequestMethod.GET)
	public @ResponseBody List<String> getDateByEventName(ModelMap modelMap,
			@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean1, Model mod, HttpServletRequest request,
			HttpServletResponse response) throws FileNotFoundException, java.text.ParseException {

		String eventName = request.getParameter("eventName");
		EventEntry eventEnt = eventEntryService.findByEventName(eventName);

		HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		List<CalendarBean> evnetCalendarBeanList = new ArrayList<>();
		List<EventEntry> eveMaintList = new ArrayList<>();
		List<EventEntry> eventAccountList = eventEntryService.findAllEventByResource("DAC");
		List<EventEntry> eventCalenderListList = eventEntryService.findAll("Period End close");
		for (EventEntry eventAcct : eventAccountList) {
			for (EventEntry eventEntry : eventCalenderListList) {
				if (eventEntry.getEvent_ID().equals(eventAcct.getEvent_ID())) {
					eveMaintList.add(eventAcct);
				}
			}
		}
		List<String> eeList = new ArrayList<String>();
		List<CalendarBean> cbl = null;
		for (EventEntry event : eveMaintList) {
			CalendarBean calendarBean = new CalendarBean();
			if (event.getEventstatus() != null && !event.getEventstatus().equalsIgnoreCase("Cancelled")
					&& event.getEventname().equalsIgnoreCase(eventName)) {

				// eventEntryBean.setEvent_ID(event.getEvent_ID());
				calendarBean.setTitle(event.getEventname());
				// eventEntryBean.setDescription_details(event.getDescription_details());
				calendarBean.setDescription(event.getDescription_details());
				calendarBean.setStart(event.getStart_date());

				calendarBean.setEnd(event.getEnd_date());

				Set<String> eventAppSet = new HashSet<String>();
				int i = 0;

				for (EventApplication eventApp : event.getEventAppSet()) {
					eventAppSet.add(eventApp.getApplication());
					i++;
				}
				calendarBean.setEventAppSet(eventAppSet);

				Set<String> eventUserSet = new HashSet<String>();
				// String[] eventUserSet=new String[event.getEventUserSet().size()];
				int j = 0;
				for (EventUser eventUser : event.getEventUserSet()) {
					eventUserSet.add(eventUser.getResource());
					j++;
				}
				calendarBean.setEventUserSet(eventUserSet);

				calendarBean.setRemarks(event.getRemarks());

				EventEntryBean eventEntryBean = new EventEntryBean();

				eventEntryBean.setEngagement_Name(event.getEngagement_Name());

				String eventAppString = String.join(",", eventAppSet);
				// eventEntryBean.setApplicationNameSet(eventAppSet);
				eventEntryBean.setApplicationName(eventAppString);

				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

				Date theStartDate = null;
				try {
					theStartDate = format.parse(event.getStart_date());
				} catch (java.text.ParseException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				Calendar startCal = Calendar.getInstance();
				startCal.setTime(theStartDate);

				String pattern = "yyyy-MM-dd";
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
				String pattern2 = "HH:mm:ss";
				SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat(pattern2);

				String startDate = simpleDateFormat.format(startCal.getTime());
				eventEntryBean.setStart_date(startDate);

				String startTime = simpleDateFormat2.format(startCal.getTime());
				eventEntryBean.setStart_time(startTime);
				calendarBean.setStartTime(startTime);

				Date theEndDate = null;
				try {
					theEndDate = format.parse(event.getEnd_date());
				} catch (java.text.ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Calendar endCal = Calendar.getInstance();
				endCal.setTime(theEndDate);

				String endDate = simpleDateFormat.format(endCal.getTime());
				eventEntryBean.setEnd_date(endDate);

				String endTime = simpleDateFormat2.format(endCal.getTime());
				eventEntryBean.setEnd_time(endTime);
				calendarBean.setEndTime(endTime);

				eventEntryBean.setRecurrence_type(event.getRecurrence_type());
				eventEntryBean.setRecu_every_day(event.getRecu_every_day());
				eventEntryBean.setRecu_every_weekday(event.getRecu_every_weekday());
				eventEntryBean.setRecurrence_dayName(event.getRecurrence_dayName());
				eventEntryBean.setRecu_every_week(event.getRecu_every_week());
				eventEntryBean.setRecu_month_day(event.getRecu_month_day());
				eventEntryBean.setRecu_every_month(event.getRecu_every_month());
				UserController uc = new UserController();

				try {
					cbl = uc.getRecurrenceList(calendarBean, event);
				} catch (java.text.ParseException e) {

					e.printStackTrace();
				}
			}

		}
		for (CalendarBean cb : cbl) {
			// cb.setUrl("javascript:loadChartPage(" + event.getEvent_ID() + ");");
			eeList.add(cb.getStart());
		}
		List<String> dateList = new ArrayList<String>();

		SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String todayDate = sdformat.format(date);

		for (int i = 0; i < eeList.size(); i++) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			if (sdf.parse(eeList.get(i)).before(sdf.parse(todayDate))) {
				dateList.add(eeList.get(i));
			}
		}
		mod.addAttribute("dateList", dateList);
		return dateList;
	}

	@RequestMapping(value = "/downloadActualEvent/{eventNameAndDate}", method = RequestMethod.GET)
	public void downloadActualEvent(@PathVariable String eventNameAndDate,ModelMap modelMap, @ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean,
			Model mod, HttpServletRequest request, HttpServletResponse response)
			throws ParseException, java.text.ParseException, Exception {

		//String eventName = request.getParameter("eventName");
		//String sDate1 = request.getParameter("date");
		String value[] = eventNameAndDate.split("_");
		String eventName = value[0].toString();
		String date = value[1].toString();
		Date date1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(date);
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		String eventDateselected = sdf.format(date1);
		String eventDate = sdf.format(date1);

		List<Integer> dayList = new ArrayList<Integer>();
		List<Integer> newdayList = new ArrayList<Integer>();

		String newDate = null;
		EventEntry eventEntry = eventEntryService.findByEventName(eventName);
		List<EventPlanned> eventPlannedList = null;
		if (eventName != null)
			eventPlannedList = eventEntryService.highestVersion(eventName);

		FileInputStream file = new FileInputStream(dir+"\\Event_Planning Actuals.xlsm");
        
        XSSFWorkbook workbook = new XSSFWorkbook(file);
        XSSFSheet sheet1 = workbook.getSheetAt(0);
        file.close();

        List<Long> plannedSeqIdList = new ArrayList<>();
		for (EventPlanned e : eventPlannedList) {
			plannedSeqIdList.add(e.getPlanned_Seq_ID());
		}
		Collections.sort(plannedSeqIdList);
		Boolean flag = false;
		flag = eventEntryService.getPlannedSeqID(plannedSeqIdList.get(0),eventDate);
		 
		Map<Integer, Object[]> data1 = new TreeMap<Integer, Object[]>();

		for (EventPlanned e : eventPlannedList) {
			dayList.add(Integer.parseInt(e.getDay()));
		}
		int max = 0;
		for (Integer e : dayList) {
			if (!newdayList.contains(e))
				newdayList.add(e);
		}
		Collections.sort(newdayList);
		max = newdayList.get(newdayList.size() - 1);

		List<EventActual> eventActualList = eventEntryService.getActualData(plannedSeqIdList, eventDate, newdayList);
		
		HashMap<Integer, String> hMap = new HashMap<Integer, String>();
	
		int i1 = 1;
		for (int k = 0; k < max; k++) {
			hMap.put(i1, eventDate);
			i1++;
			Calendar c = Calendar.getInstance();
			c.setTime(sdf.parse(eventDate));
			c.add(Calendar.DATE, 1); // number of days to add
			eventDate = sdf.format(c.getTime());
		}
		int i = 1;
		int val = 0;
		if(flag == true) {
			for (EventPlanned e : eventPlannedList) {
				
				i++;
				int dayValue = Integer.parseInt(e.getDay());
				newDate = hMap.get(dayValue);
					data1.put(i,
							new Object[] { e.getPlanned_Seq_ID(), e.getEvent_ID(), e.getStep_Number(), e.getCritical_Path(),
									e.getJob_Name(), e.getProcess_Description(), e.getDay(), newDate, e.getPlanned_Start_Time(), newDate,
									e.getPlanned_End_Time(), eventActualList.get(val).getActual_Start_Date(),eventActualList.get(val).getActual_Start_Time(),
									eventActualList.get(val).getActual_End_Date(),eventActualList.get(val).getActual_End_Time(), eventActualList.get(val).getFailure_Reason(),
									eventActualList.get(val).getPreventive_Measure() });
					val++;
			}
		}else if(flag == false) {
			for (EventPlanned e : eventPlannedList) {
				i++;
				int dayValue = Integer.parseInt(e.getDay());
				newDate = hMap.get(dayValue);
				data1.put(i,
						new Object[] { e.getPlanned_Seq_ID(), e.getEvent_ID(), e.getStep_Number(), e.getCritical_Path(),
								e.getJob_Name(), e.getProcess_Description(), e.getDay(), newDate, e.getPlanned_Start_Time(), newDate,
								e.getPlanned_End_Time(), "", "", "", "", "", "" });
			}
		}

		Set<Integer> keyset1 = data1.keySet();
		int rownum1 = 1;
		for (Integer key1 : keyset1) {
			Row row1 = sheet1.createRow(rownum1++);

			XSSFDataFormat format = workbook.createDataFormat();
			XSSFCellStyle style = workbook.createCellStyle();

			Object[] objArr1 = data1.get(key1);
			int cellnum1 = 0;
			for (Object obj1 : objArr1) {

				Cell cell1 = row1.createCell(cellnum1++);
				if (obj1 instanceof String)
					cell1.setCellValue((String) obj1);
				else if (obj1 instanceof Integer)
					cell1.setCellValue((Integer) obj1);
				else if (obj1 instanceof Long)
					cell1.setCellValue((Long) obj1);
			}
		}

		try {
			ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
			workbook.write(outByteStream);
			byte [] outArray = outByteStream.toByteArray();
			response.setContentType("application/ms-excel");
			response.setContentLength(outArray.length); 
			response.setHeader("Expires:", "0"); // eliminates browser caching
			response.setHeader("Content-Disposition", "attachment; filename="+eventName+"_"+date+".xlsm");
			OutputStream outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/* Add event details through upload starts here */

	public String uploadEventEntry(EventEntryBean eventEntryBean, HttpServletRequest request, String errors) {
		// eventEntryValidator.validate(eventEntryBean, bindingResult);
		List<MultipartFile> files = eventEntryBean.getFile_upload();

		ModelAndView model1 = new ModelAndView();
		FileUpload fileUpload = new FileUpload();
		String fileContent = null;
		String attachfileName = null;
		String getEvent_file_name = null;
		List<String> fileNames = new ArrayList<String>();
		try {
			if (null != files && files.size() > 0) {
				for (MultipartFile multipartFile : files) {
					fileContent = fileUpload.process(multipartFile).toString();
					// String getEvent_upld_fix_content=fileContent;
					// getEvent_file_name = multipartFile.getOriginalFilename();
					// eventEntryBean.setEvent_file_name(getEvent_file_name);
					// eventEntryBean.setEvent_upld_fix(getEvent_upld_fix_content);
					attachfileName = multipartFile.getOriginalFilename();
					fileNames.add(attachfileName);
					System.out.print("attachName-------------->>" + attachfileName);
				}
			}
			model1.addObject("message", fileContent);

		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		getEvent_file_name = fileNames.toString().replaceAll("[\\[.\\].\\s+]", "");

		eventEntryBean.setEvent_file_name(getEvent_file_name);

		HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		eventEntryBean.setAccount_name(userAccountName);

		// will update once UI changes done.

		/*
		 * eventEntryBean.setRecurrence_type("Daily");
		 * 
		 * if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("Daily")) {
		 * eventEntryBean.setRecu_every_day("1");
		 * eventEntryBean.setRecu_every_weekday("MO,TU,WE,TH,FR"); } else
		 * if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("Weekly")) {
		 * eventEntryBean.setRecu_every_week("1");
		 * eventEntryBean.setRecurrence_dayName("MO,TU,WE,TH,FR,SU,SA"); } else
		 * if(eventEntryBean.getRecurrence_type().equalsIgnoreCase("Monthly")) {
		 * eventEntryBean.setRecu_every_month("1");
		 * eventEntryBean.setRecu_month_day("20"); }
		 */

		// will update above code once UI changes done.
		String eventName = eventEntryBean.getEventName();
		if (eventEntryBean != null) {

			try {
				if (request.getParameter("finalUpload") != null
						&& request.getParameter("finalUpload").equalsIgnoreCase("true")) {
					eventEntryService.saveOther(eventEntryBean);
				}

			} catch (Exception hex) {
				hex.printStackTrace();
			}
		}

		if (StringUtils.isEmpty(eventName)) {
			errors = errors + "The Event Name should not be empty;";
		}

		EventEntry eb = eventEntryService.findByEventName(eventName);
		if (eb.getEventname() != null) {
			errors = errors + "The Event Name provided already exists. Please provide a different Event Name;";
		}

		String remarks = eventEntryBean.getRemarks();
		String startDate = eventEntryBean.getStart_date();
		if (StringUtils.isEmpty(startDate)) {
			errors = errors + "The Start Date should not be empty;";
		}
		
		String endDate = eventEntryBean.getEnd_date();
		if (StringUtils.isEmpty(endDate)) {
			errors = errors + "The End Date should not be empty;";
		}

		String timeZone = eventEntryBean.getTime_zone();
		if (StringUtils.isEmpty(timeZone)) {
			errors = errors + "The Time Zone should not be empty;";
		}

		String emailID = eventEntryBean.getEmail_receipients();
		String emailID1 = eventEntryBean.getEmail_receipients1();

		if (emailID != null && emailID1 != null) {
			emailid = emailID + "," + emailID1;
		} else {

			emailid = emailID;
		}

		String file_upload = String.valueOf(eventEntryBean.getFile_upload());
		eventEntryBean.setFile_upload(eventEntryBean.getFile_upload());

		if (emailID.startsWith(",") || endDate.startsWith(",") || startDate.startsWith(",")
				|| remarks.startsWith(".")) {

			String startDate1 = startDate.substring(1);
			String end = endDate.substring(1);
			String remark = remarks.substring(1);
			String email1 = emailID.substring(1);

			/*
			 * String startSate=eventEntryBean.getStart_date(); String endDate =
			 * eventEntryBean.getEnd_date();
			 */

			/* String emailID=eventEntryBean.getEmail_receipients(); */
			eventEntryBean.setFile_upload(eventEntryBean.getFile_upload());

			// emailID,null,eventName, eventEntryBean.getDescription_details()

			CalendarService calService = new CalendarService();
			// calService.createUploadCalendar(startDate, endDate, eventName,
			// eventEntryBean.getDescription_details(),
			// eventEntryBean.getEngagement_Name(), eventEntryBean.getRisk_summary());
			// mailService.sendMail(email1,null,eventName,
			// eventEntryBean.getDescription_details());

		} else {

			// model.addAttribute("remarks", remarks);

			CalendarService calService = new CalendarService();
			// calService.createUploadCalendar(startDate, endDate, eventName,
			// eventEntryBean.getDescription_details(),
			// eventEntryBean.getEngagement_Name(), eventEntryBean.getRisk_summary());
			// mailService.sendMail(emailID,null,eventName,
			// eventEntryBean.getDescription_details());

		}

		/* Email code starts here */
		/*SimpleDateFormat dateParser = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

		try {
			if (!StringUtils.isEmpty(eventEntryBean.getStart_date())
					&& !StringUtils.isEmpty(eventEntryBean.getEnd_date())) {
				mailService.sendInvitation("DL IN NATools_Support", new String[] { emailid },
						eventEntryBean.getEventName()
					
						, dateParser.parse(eventEntryBean.getStart_date()),
						dateParser.parse(eventEntryBean.getEnd_date())

						, eventEntryBean.getRecurrence_type()

						, eventEntryBean.getRecu_every_day(), eventEntryBean.getRecu_every_weekday()

						, eventEntryBean.getRecu_every_week(), eventEntryBean.getRecurrence_dayName()

						, eventEntryBean.getRecu_every_month(), eventEntryBean.getRecu_month_day(),
						eventEntryBean.getMonthdd1(), eventEntryBean.getMonthdd2(), eventEntryBean.getMonthtext1(),
						eventEntryBean.getRecu_month_day_radio(), "LIS-42", "TBD"
						,
						"<body bgcolor='#E6E6FA'> <table align='center' border='2' ><tr><td>EventName :</td><td><font color=\"Blue\">"
								+ eventEntryBean.getEventName() + "</font></td></tr>"
								+ "<tr><td>Description_details :</td><td><font color=\"Blue\">"
								+ eventEntryBean.getDescription_details() + "</font></td></tr>"
								+ "<tr><td>Engagement Name :</td><td><font color=\"Blue\">"
								+ eventEntryBean.getEngagement_Name() + "</font></td></tr>"
								+ "<tr><td>Risk Summary :</td><td><font color=\"Blue\">"
								+ eventEntryBean.getRisk_summary() + "</font></td></tr>"
								+ "<tr><td>Region territory :</td><td><font color=\"Blue\">"
								+ eventEntryBean.getEventName() + "</font></td></tr></table></body>",
						getEvent_file_name);
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		
		//SimpleDateFormat dateParser = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");// BKM
		SimpleDateFormat dateParser = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");// BKM
		// SimpleDateFormat dateParser = new SimpleDateFormat( "dd-MM-yyyy" ) ;

		try {
			if (!StringUtils.isEmpty(eventEntryBean.getStart_date())
					&& !StringUtils.isEmpty(eventEntryBean.getEnd_date())) {
				
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
				
				/*
				 * final LocalDateTime start = LocalDateTime.parse(startDate, formatter); final
				 * LocalDateTime end = LocalDateTime.parse(endDate, formatter); final
				 * LocalDateTime compMin = currD.plusMinutes(15);
				 */
				
				
				//sendPlannedInvitationEmail(eventEntryBean, getEvent_file_name, dateParser, start, end);

				/* switch(eventEntryBean.getRecurrence_type()) {
				case "weekly":
					List<LocalDateTime> eventStTymLstWeek = getWeekRecur(eventEntryBean, start, end);
					//LOGGER.info("Event Id : " +eventEntryBean.getEvent_ID()+ " Total Weekly Events : "+eventStTymLstWeek.size());
					
					final LocalDateTime compOneDay = currD.plusDays(1);				
					for(LocalDateTime lcl : eventStTymLstWeek){
						//if(compOneDay.toLocalDate().compareTo(lcl.toLocalDate()) == 0) {
							if(lcl.compareTo(compOneDay.plusMinutes(15)) < 0 &&
									lcl.compareTo(compOneDay)>0
									) {
								try {
									//LOGGER.info("Event name:" +event.getEventName() + " Event Start time:" +lcl);
									sendPlannedInvitationEmail(eventEntryBean, getEvent_file_name, dateParser, start, end,eventStTymLstWeek);
								} catch (SQLException e) {
									e.printStackTrace();
								}
								
							}
						//}	
						
						//if(currD.toLocalDate().compareTo(lcl.toLocalDate()) == 0) {
							if(lcl.compareTo(compMin) < 0 &&
									lcl.compareTo(currD)>0
									) {
								try {
									//LOGGER.info("Event name:" +eventEntryBean.getEventName() + " Event Start time:" +lcl);
									sendPlannedInvitationEmail(eventEntryBean, getEvent_file_name, dateParser, start, end,eventStTymLstWeek);
								} catch (SQLException e) {
									e.printStackTrace();
								}
							}
						//}	
					}
					break;
					
				case "monthly":			

					
					List<LocalDateTime> eventStTymLstMonth = getMonthRecur(eventEntryBean, start, end);
					//LOGGER.info("Event Id : " +event.getEventID()+ " Total Monthly Events : "+eventStTymLstMonth.size());
					
					final LocalDateTime compSevenDay = currD.plusDays(7);
					for(LocalDateTime lcl : eventStTymLstMonth){
						//if(compSevenDay.toLocalDate().compareTo(lcl.toLocalDate()) == 0) {
							if(lcl.compareTo(compSevenDay.plusMinutes(15)) < 0 &&
									lcl.compareTo(compSevenDay)>0
									) {
								try {
									//LOGGER.info("Event name:" +event.getEventName() + " Event Start time:" +lcl);
									sendPlannedInvitationEmail(eventEntryBean, getEvent_file_name, dateParser, start, end,eventStTymLstMonth);
								} catch (SQLException e) {
									e.printStackTrace();
								}
								
							}
						//}	
						
						//if(currD.toLocalDate().compareTo(lcl.toLocalDate()) == 0) {
							if(lcl.compareTo(compMin) < 0 &&
									lcl.compareTo(currD)>0
									) {
								try {
									//LOGGER.info("Event name:" +event.getEventName() + " Event Start time:" +lcl);
									sendPlannedInvitationEmail(eventEntryBean, getEvent_file_name, dateParser, start, end,eventStTymLstMonth);
								} catch (SQLException e) {
									e.printStackTrace();
								}
							}
						//}	
					}
					break;
					
				default: 
					String currDate = Long.toString(System.currentTimeMillis());
					if (endDate.compareTo(currDate) > 0) {
						
						//LOGGER.info("Event Id : " +event.getEventID()+ " a daily event");
						LocalDateTime lcl = LocalDateTime.of(currD.toLocalDate(),start.toLocalTime());
						if (lcl.compareTo(compMin) < 0 &&
								lcl.compareTo(currD)>0
								) {
							try {
								//LOGGER.info("Event name:" +event.getEventName() + " Event Start time:" +start);
								sendPlannedInvitationEmail(eventEntryBean, getEvent_file_name, dateParser, start, end, eventStTymLstMonth);
							} catch (SQLException e) {
								e.printStackTrace();
							}
							
						}
					}
					break;
				} */
				
				}
		}  catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		/* Email code ends here */

		return errors;

	}
	
	private void sendPlannedInvitationEmail(EventEntryBean eventEntryBean, String getEvent_file_name,
			SimpleDateFormat dateParser, final LocalDateTime start, final LocalDateTime end)
			throws Exception, java.text.ParseException {
		boolean cntFlag = false;
		//for(LocalDateTime lcl : eventStTymLstWeek){
			if(!cntFlag){
				
			mailService.sendPlannedInvitation(start, end, "dactoolssupport.in@capgemini.com", new String[] { emailid },
					eventEntryBean.getEventName(), dateParser.parse(eventEntryBean.getStart_date()),
					dateParser.parse(eventEntryBean.getEnd_date())

					, eventEntryBean.getRecurrence_type()

					, eventEntryBean.getRecu_every_day(), eventEntryBean.getRecu_every_weekday()

					, eventEntryBean.getRecu_every_week(), eventEntryBean.getRecurrence_dayName()

					, eventEntryBean.getRecu_every_month(), eventEntryBean.getRecu_month_day(),
					eventEntryBean.getMonthdd1(), eventEntryBean.getMonthdd2(), eventEntryBean.getMonthtext1(),
					eventEntryBean.getRecu_month_day_radio(),String.valueOf(eventEntryBean.getEvent_ID()), "TBD"
					/*
					 * , "<font color=\"Black\">"+eventEntryBean.getDescription_details()+"</font>"
					 */
					,
					
					" Hello,<br><br>"
							+ " Please be informed that there is an upcoming business event planned. Details of the event are as follows: <br><br> Event Name: " 
							+ eventEntryBean.getEventName() + "<br>Event Description: " + eventEntryBean.getDescription_details() 
							+ "<br>Recurrence Type: "
							+ eventEntryBean.getRecurrence_type() + "<br> Start Date: " + eventEntryBean.getStart_date() 
							+ "<br>End Date: "+ eventEntryBean.getEnd_date() 
							+ " <br><br>Thank you<br>",
					/*"<body bgcolor='#E6E6FA'> <table align='center' border='2' ><tr><td>EventName1 :</td><td><font color=\"Blue\">"
							+ eventEntryBean.getEventName() + "</font></td></tr>"
							+ "<tr><td>Description_details :</td><td><font color=\"Blue\">"
							+ eventEntryBean.getDescription_details() + "</font></td></tr>"
							+ "<tr><td>Engagement Name :</td><td><font color=\"Blue\">"
							+ eventEntryBean.getEngagement_Name() + "</font></td></tr>"
							+ "<tr><td>Risk Summary :</td><td><font color=\"Blue\">"
							+ eventEntryBean.getRisk_summary() + "</font></td></tr>"
							+ "<tr><td>Region territory :</td><td><font color=\"Blue\">"
							+ eventEntryBean.getEventName() + "</font></td></tr></table></body>"*/
					getEvent_file_name);
			}
			cntFlag = true;
		//}
	}

	public String uploadPlannedEventEntry(EventEntryBean eventEntryBean, HttpServletRequest request, String errors) {
		// eventEntryValidator.validate(eventEntryBean, bindingResult);
		List<MultipartFile> files = eventEntryBean.getFile_upload();

		ModelAndView model1 = new ModelAndView();
		FileUpload fileUpload = new FileUpload();
		String fileContent = null;
		String attachfileName = null;
		String getEvent_file_name = null;
		List<String> fileNames = new ArrayList<String>();
		try {
			if (null != files && files.size() > 0) {
				for (MultipartFile multipartFile : files) {
					fileContent = fileUpload.process(multipartFile).toString();
					// String getEvent_upld_fix_content=fileContent;
					// getEvent_file_name = multipartFile.getOriginalFilename();
					// eventEntryBean.setEvent_file_name(getEvent_file_name);
					// eventEntryBean.setEvent_upld_fix(getEvent_upld_fix_content);
					attachfileName = multipartFile.getOriginalFilename();
					fileNames.add(attachfileName);
					System.out.print("attachName-------------->>" + attachfileName);
				}
			}
			model1.addObject("message", fileContent);

		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		getEvent_file_name = fileNames.toString().replaceAll("[\\[.\\].\\s+]", "");

		eventEntryBean.setEvent_file_name(getEvent_file_name);

		HttpSession httpSession = httpServletRequest.getSession();
		String userAccountName = (String) httpSession.getAttribute("userAcctName");
		eventEntryBean.setAccount_name(userAccountName);

		String eventName = eventEntryBean.getEventName();
		EventEntry ee = eventEntryService.findByEventName(eventName);
		eventEntryBean.setEvent_ID(ee.getEvent_ID());
		if (eventEntryBean != null) {

			try {
				if (request.getParameter("finalUpload") != null
						&& request.getParameter("finalUpload").equalsIgnoreCase("true")) {
					eventEntryService.saveUpdateOther(eventEntryBean);
				}

			} catch (Exception hex) {
				hex.printStackTrace();
			}
		}

		if (StringUtils.isEmpty(eventName)) {
			errors = errors + "The Event Name should not be empty;";
		}

		String remarks = eventEntryBean.getRemarks();
		String startDate = eventEntryBean.getStart_date();
		if (StringUtils.isEmpty(startDate)) {
			errors = errors + "The Start Date should not be empty;";
		}

		String endDate = eventEntryBean.getEnd_date();
		if (StringUtils.isEmpty(endDate)) {
			errors = errors + "The End Date should not be empty;";
		}

		String emailID = eventEntryBean.getEmail_receipients();
		String emailID1 = eventEntryBean.getEmail_receipients1();

		if (emailID != null && emailID1 != null) {
			emailid = emailID + "," + emailID1;
		} else {

			emailid = emailID;
		}

		String file_upload = String.valueOf(eventEntryBean.getFile_upload());
		eventEntryBean.setFile_upload(eventEntryBean.getFile_upload());

		if (emailID.startsWith(",") || endDate.startsWith(",") || startDate.startsWith(",")
				|| remarks.startsWith(".")) {

			String startDate1 = startDate.substring(1);
			String end = endDate.substring(1);
			String remark = remarks.substring(1);
			String email1 = emailID.substring(1);

			/*
			 * String startSate=eventEntryBean.getStart_date(); String endDate =
			 * eventEntryBean.getEnd_date();
			 */

			/* String emailID=eventEntryBean.getEmail_receipients(); */
			eventEntryBean.setFile_upload(eventEntryBean.getFile_upload());

			// emailID,null,eventName, eventEntryBean.getDescription_details()

			CalendarService calService = new CalendarService();
			calService.createUploadCalendar(startDate, endDate, eventName, eventEntryBean.getDescription_details(),
					eventEntryBean.getEngagement_Name(), eventEntryBean.getRisk_summary());
			// mailService.sendMail(email1,null,eventName,
			// eventEntryBean.getDescription_details());

		} else {

			// model.addAttribute("remarks", remarks);

			CalendarService calService = new CalendarService();
			calService.createUploadCalendar(startDate, endDate, eventName, eventEntryBean.getDescription_details(),
					eventEntryBean.getEngagement_Name(), eventEntryBean.getRisk_summary());
			// mailService.sendMail(emailID,null,eventName,
			// eventEntryBean.getDescription_details());

		}

		/* Email code starts here */
		SimpleDateFormat dateParser = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");// BKM
		// SimpleDateFormat dateParser = new SimpleDateFormat( "dd-MM-yyyy" ) ;

		try {
			if (!StringUtils.isEmpty(eventEntryBean.getStart_date())
					&& !StringUtils.isEmpty(eventEntryBean.getEnd_date())) {
				
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
				
				final LocalDateTime start = LocalDateTime.parse(startDate, formatter);
				final LocalDateTime end = LocalDateTime.parse(endDate, formatter);
				
			//	List<LocalDateTime> eventStTymLstWeek = getWeekRecur(eventEntryBean, start, end);
				
				//for(LocalDateTime lcl : eventStTymLstWeek){
				
				
				String messageContent = "Hello,<br><br>" + "There is an upcoming business event planned. Details of the event are as follows: <br> "
				+ " Event Name: " + eventEntryBean.getEventName() + " Event Description: " + eventEntryBean.getDescription_details() 
				+ "<br>Recurrence Type: " + eventEntryBean.getRecurrence_type() + "<br>Start Date: "
				+ start + "<br> End Date: " + end
				+ " <br><br><br>Regards," + "<br><br> <br>Team CBE"
				+"text/html; charset=utf-8";
				
					mailService.sendPlannedInvitation(start, end, "dactoolssupport.in@capgemini.com", new String[] { emailid },
							"CBE: " +eventEntryBean.getEventName()+ " Planned", dateParser.parse(eventEntryBean.getStart_date()),
							dateParser.parse(eventEntryBean.getEnd_date())

							, eventEntryBean.getRecurrence_type()

							, eventEntryBean.getRecu_every_day(), eventEntryBean.getRecu_every_weekday()

							, eventEntryBean.getRecu_every_week(), eventEntryBean.getRecurrence_dayName()

							, eventEntryBean.getRecu_every_month(), eventEntryBean.getRecu_month_day(),
							eventEntryBean.getMonthdd1(), eventEntryBean.getMonthdd2(), eventEntryBean.getMonthtext1(),
							eventEntryBean.getRecu_month_day_radio(),String.valueOf(eventEntryBean.getEvent_ID()), "TBD"
							/*
							 * , "<font color=\"Black\">"+eventEntryBean.getDescription_details()+"</font>"
							 */
							,
							messageContent/*"<body bgcolor='#E6E6FA'> <table align='center' border='2' >"
									+ "<tr><td>EventName1 :</td><td><font color=\"Blue\">"
									+ eventEntryBean.getEventName() + "</font></td></tr>"
									+ "<tr><td>EventName1 :</td><td><font color=\"Blue\">"
									+ eventEntryBean.getEventName() + "</font></td></tr>"
									+ "<tr><td>Description_details :</td><td><font color=\"Blue\">"
									+ eventEntryBean.getDescription_details() + "</font></td></tr>"
									+ "<tr><td>Engagement Name :</td><td><font color=\"Blue\">"
									+ eventEntryBean.getEngagement_Name() + "</font></td></tr>"
									+ "<tr><td>Risk Summary :</td><td><font color=\"Blue\">"
									+ eventEntryBean.getRisk_summary() + "</font></td></tr>"
									+ "<tr><td>Region territory :</td><td><font color=\"Blue\">"
									+ eventEntryBean.getEventName() + "</font></td></tr></table></body>"*/,
							getEvent_file_name);
				//}
				
				
			}
		}
		
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} 
			catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		/* Email code ends here */

		return errors;

	}

	/* Add event details through upload ends here */
	@RequestMapping(value = "/uploadActualEvent", method = RequestMethod.POST)
	public ModelAndView uploadActualEvent(ModelMap modelMap,
			@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean, @RequestParam("file") MultipartFile file,
			Model mod, HttpServletRequest request) throws FileNotFoundException, java.text.ParseException {

		ModelAndView model = new ModelAndView();
		FileUpload fileUpload = new FileUpload();
		model.addObject("message", fileUpload.processEventUpload(file));
		model.setViewName("uploadEvent");
		modelMap.addAttribute("loggedInUname", SecurityContextHolder.getContext().getAuthentication().getName());
		modelMap.addAttribute("eventEntryBeanVal", eventEntryBean);

		/* test xlsx file starts here */

		String fileName = file.getOriginalFilename();
		String rootPath = System.getProperty("catalina.home");
		// File myFile = new File(rootPath +
		// "/webapps/CBE-ARMS/resources/documents/"+fileName);

		EventPlanned eventPlanned = new EventPlanned();
		EventActual eventActual = new EventActual();
	//	File myFile = new File(rootPath +
	//	"\\webapps\\CBE_V2\\resources\\files\\"+fileName);
		File myFile = new File("C:\\Users\\shmukka\\Downloads\\" + fileName);
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(myFile);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}

		// Finds the workbook instance for XLSM file

		XSSFWorkbook myWorkBook = null;
		try {
			myWorkBook = new XSSFWorkbook(fis);
		} catch (IOException e) {
			e.printStackTrace();
		}

		XSSFSheet mySheet = myWorkBook.getSheet("Event Actuals");

		XSSFWorkbook wb = null;
		XSSFSheet sheet = null;
		String errors = "";
		String userId = SecurityContextHolder.getContext().getAuthentication().getName();
		try {
			FileInputStream excelFile = new FileInputStream(myFile);
			Workbook workbook = new XSSFWorkbook(excelFile);

			if (!dir.exists())
				dir.mkdirs();

			//FileOutputStream outputStream = new FileOutputStream(dir + "\\UploadEventErrorRecords_" + userId + ".xlsm");
			FileOutputStream outputStream = new FileOutputStream(dir + "\\UploadEventErrorRecords_" + userId + ".xlsm");
			workbook.write(outputStream);
			workbook.close();
			FileInputStream clonedFile = new FileInputStream(
					new File(dir + "\\UploadEventErrorRecords_" + userId + ".xlsm"));
			wb = new XSSFWorkbook(clonedFile);
			sheet = wb.getSheetAt(0);
		} catch (Exception e) {

		}

		// Get iterator to all the rows in current sheet
		Iterator<Row> rowIterator = mySheet.iterator();
		rowIterator.next();
		
		List<String> dayList = new ArrayList<>();
		List<String> newDayList = new ArrayList<>();
		List<Integer> daynew = new ArrayList<>();

		for (Row row1 : mySheet) {
			if(row1.getCell(6) != null && !row1.getCell(6).toString().equalsIgnoreCase("")) {
				String days = row1.getCell(6).toString();
				if (!days.equalsIgnoreCase("Day")) {
					dayList.add(days);
				}
			}
		}
		if(dayList != null) {
		for (int val = 0; val < dayList.size(); val++) {
			String dayValue = dayList.get(val);
			if (!newDayList.contains(dayValue)) {
				newDayList.add(dayValue);
				daynew.add(Integer.parseInt(dayValue));
			}
		}

		Collections.sort(daynew);
		int size = daynew.size();
		int maxnumDay = daynew.get(size - 1);
		}
		
		int i = 0;
		boolean flag = true;
		List<EventActual> eventActualToUpdateList = new ArrayList<>();
		int sizeofList =0;
		while (rowIterator.hasNext()) {
			// For each row, iterate through each columns
		 Row row = rowIterator.next();
		 if(row.getCell(0) != null && !row.getCell(0).toString().trim().equalsIgnoreCase("")) {
			String eventID = row.getCell(1).toString();
			
			if(flag == true) {
			String startDate = row.getCell(7).toString();
			eventActualToUpdateList = eventEntryService.getActualEvent(eventID, startDate, daynew);
			sizeofList = eventActualToUpdateList.size();
			flag = false;
			}
			
			if (eventActualToUpdateList.size() > 0 && i <= sizeofList - 1) {
				Long seq_id = eventActualToUpdateList.get(i).getActual_Seq_ID();
				eventActual.setActual_Seq_ID(seq_id);
				i++;
			} else {
				eventActual = new EventActual();
			}

			Iterator<Cell> cellIterator = row.cellIterator();
			boolean eventPlannedFlag = false;

			while (cellIterator.hasNext()) {
				Cell cell = cellIterator.next();
				if (cell.getRowIndex() > 0) {
					eventPlanned = new EventPlanned();

					Double seq_ID = row.getCell(0).getNumericCellValue();
					// System.out.println("setPlanned_Seq_ID================>"+seq_ID+"::::"+Math.round(seq_ID));
					if (row.getCell(0) != null)
						eventActual.setPlanned_Seq_ID(Math.round(seq_ID));

					String event_id = row.getCell(1).toString();
					if (row.getCell(1) != null && !StringUtils.isEmpty(event_id))
						eventActual.setEvent_ID(Integer.parseInt(event_id));
					if (row.getCell(2) != null)
						eventActual.setStep_Number(row.getCell(2).toString());
					if (row.getCell(3) != null)
						eventPlanned.setCritical_Path(row.getCell(3).toString());
					if (row.getCell(4) != null)
						eventPlanned.setJob_Name(row.getCell(4).toString());
					if (row.getCell(5) != null)
						eventPlanned.setProcess_Description(row.getCell(5).toString());
					if (row.getCell(6) != null) {
						if (row.getCell(6) == null || row.getCell(6).getCellType() == Cell.CELL_TYPE_BLANK) {
							eventPlanned.setDay("0");
						} else {
							eventPlanned.setDay(row.getCell(6).toString());
						}
					}
					// checking the type of the cell and based on that we are formatting the date
					// and time
					if (row.getCell(7) != null) {
						if (row.getCell(7).getCellType() == 0) {
							Date date1 = row.getCell(7).getDateCellValue();
							SimpleDateFormat format1 = new SimpleDateFormat("dd-MM-yyyy");
							String datetime = format1.format(date1);
							eventActual.setPlanned_Start_Date(datetime);
						} else if (row.getCell(7).getCellType() == 1) {
							eventActual.setPlanned_Start_Date(row.getCell(7).toString());
						}
					}
					if (row.getCell(8) != null) {
						if (row.getCell(8).getCellType() == 0) {
							Date date1 = row.getCell(8).getDateCellValue();
							SimpleDateFormat format1 = new SimpleDateFormat("HH:mm");
							String datetime = format1.format(date1);
							eventPlanned.setPlanned_Start_Time(datetime);
						} else if (row.getCell(8).getCellType() == 1) {
							eventPlanned.setPlanned_Start_Time(row.getCell(8).toString());
						}
					}
					if (row.getCell(9) != null) {
						if (row.getCell(9).getCellType() == 0) {
							Date date1 = row.getCell(9).getDateCellValue();
							SimpleDateFormat format1 = new SimpleDateFormat("dd-MM-yyyy");
							String datetime = format1.format(date1);
							eventActual.setPlanned_End_Date(datetime);
						} else if (row.getCell(9).getCellType() == 1) {
							eventActual.setPlanned_End_Date(row.getCell(9).toString());
						}
					}
					if (row.getCell(10) != null) {
						if (row.getCell(10).getCellType() == 0) {
							Date date1 = row.getCell(10).getDateCellValue();
							SimpleDateFormat format1 = new SimpleDateFormat("HH:mm");
							String datetime = format1.format(date1);
							eventPlanned.setPlanned_End_Time(datetime);
						} else if (row.getCell(10).getCellType() == 1) {
							eventPlanned.setPlanned_End_Time(row.getCell(10).toString());
						}
					}

					if (row.getCell(11) != null) {
						if (row.getCell(11).getCellType() == 0) {
							Date date1 = row.getCell(11).getDateCellValue();
							SimpleDateFormat format1 = new SimpleDateFormat("dd-MM-yyyy");
							String datetime = format1.format(date1);
							eventActual.setActual_Start_Date(datetime);
						} else if (row.getCell(11).getCellType() == 1) {
							eventActual.setActual_Start_Date(row.getCell(11).toString());
						}
					}

					if (row.getCell(12) != null) {
						if (row.getCell(12).getCellType() == 0) {
							Date date1 = row.getCell(12).getDateCellValue();
							SimpleDateFormat format1 = new SimpleDateFormat("HH:mm");
							String datetime = format1.format(date1);
							eventActual.setActual_Start_Time(datetime);
						} else if (row.getCell(12).getCellType() == 1) {
							eventActual.setActual_Start_Time(row.getCell(12).toString());
						}
					}

					if (row.getCell(13) != null) {
						if (row.getCell(13).getCellType() == 0) {
							Date date1 = row.getCell(13).getDateCellValue();
							SimpleDateFormat format1 = new SimpleDateFormat("dd-MM-yyyy");
							String datetime = format1.format(date1);
							eventActual.setActual_End_Date(datetime);
						} else if (row.getCell(13).getCellType() == 1) {
							eventActual.setActual_End_Date(row.getCell(13).toString());
						}
					}

					if (row.getCell(14) != null) {
						if (row.getCell(14).getCellType() == 0) {
							Date date1 = row.getCell(14).getDateCellValue();
							SimpleDateFormat format1 = new SimpleDateFormat("HH:mm");
							String datetime = format1.format(date1);
							eventActual.setActual_End_Time(datetime);
						} else if (row.getCell(14).getCellType() == 1) {
							eventActual.setActual_End_Time(row.getCell(14).toString());
						}
					}

					if (row.getCell(15) != null)
						eventActual.setFailure_Reason(row.getCell(15).toString());
					if (row.getCell(16) != null)
						eventActual.setPreventive_Measure(row.getCell(16).toString());

					if (eventActual != null && eventPlanned != null && eventActual.getActual_Start_Time() != null && eventPlanned.getJob_Name() != null &&
							!eventActual.getActual_Start_Time().trim().equalsIgnoreCase("") && 
							!eventPlanned.getJob_Name().trim().equalsIgnoreCase("") &&
							eventActual.getActual_Start_Time().equalsIgnoreCase("NA")
							&& (eventPlanned.getJob_Name().equalsIgnoreCase("CriticalPath") || eventPlanned.getJob_Name().equalsIgnoreCase("Checkpoint"))) {
						eventActual.setActual_Run_Time("");
					} else if (eventActual != null  && eventActual.getActual_Start_Time() != null
							&& eventActual.getActual_End_Time() != null
							&& eventActual.getActual_Start_Time() != "NA") {

						SimpleDateFormat format1 = new SimpleDateFormat("HH:mm");
						Date date1 = null;
						Date date2 = null;
						try {
							date1 = format1.parse(eventActual.getActual_Start_Time());
							date2 = format1.parse(eventActual.getActual_End_Time());
						} catch (Exception e) {
							e.printStackTrace();
						}
						long difference = date2.getTime() - date1.getTime();
						long difference_In_Minutes = (difference / (1000 * 60)) % 60;
						long difference_In_Hours = (difference / (1000 * 60 * 60)) % 24;

						String runTime = difference_In_Hours + ":" + difference_In_Minutes;
						eventActual.setActual_Run_Time(runTime);
					}
					// run time calculation ends here

					SimpleDateFormat format2 = new SimpleDateFormat("dd-MM-yyyy HH:mm");
					Date time1 = null;
					Date time2 = null;

					if (eventActual != null && eventPlanned != null && eventPlanned.getPlanned_End_Time() != null
							&& eventActual.getPlanned_End_Date() != null && eventActual.getActual_End_Time() != null
							&&  eventActual.getActual_End_Date() != null) {
					
					String plannedEndTime = eventPlanned.getPlanned_End_Time();
					String plannedEndDate = eventActual.getPlanned_End_Date();
					String actualEndTime = eventActual.getActual_End_Time();
					String actualEndDate = eventActual.getActual_End_Date();
					// concatenate date and time
					String planned = plannedEndDate + " " + plannedEndTime;
					String actual = actualEndDate + " " + actualEndTime;

					Date datePlanned = null;
					Date dateActual = null;
					SimpleDateFormat fmt = new SimpleDateFormat("dd-MM-yyyy");
					try {
						datePlanned = fmt.parse(plannedEndDate);
						dateActual = fmt.parse(actualEndDate);
					} catch (Exception e) {
						e.printStackTrace();
					}
					if (eventActual.getActual_End_Time() == null
							|| eventActual.getActual_End_Time().equalsIgnoreCase("")) {
						eventActual.setJob_Status("Failed");
					} else if (datePlanned.compareTo(dateActual) < 0) {
						eventActual.setJob_Status("Delayed");
					} else {
						try {
							time1 = format2.parse(planned);
							time2 = format2.parse(actual);
						} catch (Exception e) {
							e.printStackTrace();
						}
						// compareTo methods returns 0 if 2 dates are equal, if >0 date1 is after date2
						// if <0 date1 is before date2
						if (datePlanned.compareTo(dateActual) == 0 && time1.compareTo(time2) > 0 && time1 != null
								&& time2 != null) {
							eventActual.setJob_Status("On-Time");
						} else if (datePlanned.compareTo(dateActual) == 0 && time1.compareTo(time2) < 0 && time1 != null
								&& time2 != null) {
							eventActual.setJob_Status("Delayed");
						} else if (datePlanned.compareTo(dateActual) == 0 && time1.compareTo(time2) == 0
								&& time1 != null && time2 != null) {
							eventActual.setJob_Status("On-Time");
						} else if (time1 == null && time2 == null) {
							eventActual.setJob_Status("Failed");
						}
					}
					}
					// populating job status ends here
					eventActual.setEvent_Frequency_ID(1);
					eventPlannedFlag = true;
				}
			}

			if (eventPlannedFlag) {
				try {

					if (request.getParameter("finalUpload") != null
							&& request.getParameter("finalUpload").equalsIgnoreCase("true")) {
						if (eventActual != null) {
							eventActualRepository.save(eventActual);

							List<EventEntry> eventEntry = eventEntryService.findAll();

							List<String> eventEntryStr = new ArrayList<String>();

							for (EventEntry eventEntryObj : eventEntry) {
								eventEntryStr.add(eventEntryObj.getEventname());
							}

							mod.addAttribute("eventEntryList", eventEntryStr);

							mod.addAttribute("finalUploadMsg", "yes");
						}
					} else {
						if (errors != null && errors.length() > 0) {
							/* Cell color add starts here */
							CellStyle style = wb.createCellStyle();
							Font font = wb.createFont();
							font.setColor(HSSFColor.RED.index);
							style.setFont(font);
							/* Cell color add ends here */

							XSSFRow row1 = sheet.getRow(0);

							XSSFCell cell = row1.createCell(17);

							cell.setCellValue("Errors");
							cell.setCellStyle(style);

							XSSFRow rowC = sheet.getRow(row.getRowNum());

							XSSFCell cellC = rowC.createCell(17);

							cellC.setCellValue(errors);
							cellC.setCellStyle(style);
							errors = "";
							mod.addAttribute("errorFlag", "yes");
						} else {
							mod.addAttribute("validateMsg", "yes");
							mod.addAttribute("finalUploadMsg", "no");
						}
				}
				} catch (Exception hex) {
					mod.addAttribute("finalUploadMsg", "no");
					mod.addAttribute("exception", "There is an issue in uploading. Please contact technical support.");
					List<EventEntry> eventEntry = eventEntryService.findAll();

					List<String> eventEntryStr = new ArrayList<String>();

					for (EventEntry eventEntryObj : eventEntry) {
						eventEntryStr.add(eventEntryObj.getEventname());
					}

					mod.addAttribute("eventEntryList", eventEntryStr);
					return new ModelAndView("uploadEvent");
				}
			}
		}
		}

		mod.addAttribute("headerName", "eventSetup");
		return model;
	
	}

	@JsonIgnoreProperties
	@RequestMapping(value = "/uploadActualEventAJAX", method = RequestMethod.POST)
	public ResponseEntity<?> uploadActualEventAJAX(ModelMap modelMap,
			@ModelAttribute("eventEntryBean") EventEntryBean eventEntryBean, @RequestParam("file") MultipartFile file,
			Model mod, HttpServletRequest request) throws FileNotFoundException, java.text.ParseException {


		ModelAndView model = new ModelAndView();
		FileUpload fileUpload = new FileUpload();
		model.addObject("message", fileUpload.processEventUpload(file));
		model.setViewName("uploadEvent");
		modelMap.addAttribute("loggedInUname", SecurityContextHolder.getContext().getAuthentication().getName());
		modelMap.addAttribute("eventEntryBeanVal", eventEntryBean);

		Set<String> errors1 = new HashSet<String>();
		/* test xlsx file starts here */

		String fileName = file.getOriginalFilename();

		EventPlanned eventPlanned = new EventPlanned();
		EventActual eventActual = new EventActual();
	//	File myFile = new File(rootPath +
	//	"\\webapps\\CBE_V2\\resources\\files\\"+fileName);
		File myFile = new File("C:\\Users\\shmukka\\Downloads\\" + fileName);
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(myFile);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}

		// Finds the workbook instance for XLSX file

		XSSFWorkbook myWorkBook = null;
		try {
			myWorkBook = new XSSFWorkbook(fis);
		} catch (IOException e) {
			e.printStackTrace();
		}

		XSSFSheet mySheet = myWorkBook.getSheet("Event Actuals");

		XSSFWorkbook wb = null;
		XSSFSheet sheet = null;
		String errors = "";
		String userId = SecurityContextHolder.getContext().getAuthentication().getName();
		try {
			FileInputStream excelFile = new FileInputStream(myFile);
			Workbook workbook = new XSSFWorkbook(excelFile);

			if (!dir.exists())
				dir.mkdirs();

			FileOutputStream outputStream = new FileOutputStream(dir + "\\UploadEventErrorRecords_" + userId + ".xlsm");
			workbook.write(outputStream);
			workbook.close();
			FileInputStream clonedFile = new FileInputStream(
					new File(dir + "\\UploadEventErrorRecords_" + userId + ".xlsm"));
			wb = new XSSFWorkbook(clonedFile);
			sheet = wb.getSheetAt(0);
		} catch (Exception e) {

		}

		// Get iterator to all the rows in current sheet
		Iterator<Row> rowIterator = mySheet.iterator();
		rowIterator.next();
		
		
		List<String> dayList = new ArrayList<>();
		List<String> newDayList = new ArrayList<>();
		List<Integer> daynew = new ArrayList<>();

		for (Row row1 : mySheet) {
			if(row1.getCell(6) != null && !row1.getCell(6).toString().equalsIgnoreCase("")) {
			String days = row1.getCell(6).toString();
			if (!days.equalsIgnoreCase("Day")) {
				dayList.add(days);
			}
			}
		}
		if(dayList != null) {
		for (int val = 0; val < dayList.size(); val++) {
			String dayValue = dayList.get(val);
			if (!newDayList.contains(dayValue)) {
				newDayList.add(dayValue);
				daynew.add(Integer.parseInt(dayValue));
			}
		}

		Collections.sort(daynew);
		int size = daynew.size();
		int maxnumDay = daynew.get(size - 1);
		}
		int i = 0;
		
		
		
		boolean flag = true;
		List<EventActual> eventActualToUpdateList = new ArrayList<>();
		int sizeofList =0;
		while (rowIterator.hasNext()) {
			// For each row, iterate through each columns
			Row row = rowIterator.next();
			if(row.getCell(0) != null && !row.getCell(0).toString().trim().equalsIgnoreCase("")) {
			
			String eventID = row.getCell(1).toString();
			
			if(flag == true) {
			String startDate = row.getCell(7).toString();
			eventActualToUpdateList = eventEntryService.getActualEvent(eventID, startDate, daynew);
			sizeofList = eventActualToUpdateList.size();
			flag = false;
			}
			
			
			if (eventActualToUpdateList.size() > 0 && i <= sizeofList - 1) {
				Long seq_id = eventActualToUpdateList.get(i).getActual_Seq_ID();
				eventActual.setActual_Seq_ID(seq_id);
				i++;
			} else {
				eventActual = new EventActual();
			}
			// For each row, iterate through each columns

			Iterator<Cell> cellIterator = row.cellIterator();
			boolean eventPlannedFlag = false;

			while (cellIterator.hasNext()) {
				Cell cell = cellIterator.next();
				if (cell.getRowIndex() > 0) {
					eventPlanned = new EventPlanned();
					Double seq_ID = row.getCell(0).getNumericCellValue();
					if (row.getCell(0) != null) {
						eventActual.setPlanned_Seq_ID(Math.round(seq_ID));
					} else {
						errors1.add("The Sequence_ID should not be empty;");
					}
					String event_id = row.getCell(1).toString();
					if (row.getCell(1) != null && !StringUtils.isEmpty(event_id)) {
						eventActual.setEvent_ID(Integer.parseInt(event_id));
					} else {
						errors1.add("The EventID should not be empty;");
					}
					if (row.getCell(2) != null)
						eventActual.setStep_Number(row.getCell(2).toString());
					else {
						errors1.add("The Step number should not be empty;");
					}
					if (row.getCell(3) != null)
						eventPlanned.setCritical_Path(row.getCell(3).toString());
					if (row.getCell(4) != null)
						eventPlanned.setJob_Name(row.getCell(4).toString());
					
					if (row.getCell(5) != null)
						eventPlanned.setProcess_Description(row.getCell(5).toString());
					
					if (row.getCell(6) != null) {
						if (row.getCell(6) == null || row.getCell(6).getCellType() == Cell.CELL_TYPE_BLANK) {
							eventPlanned.setDay("0");
						} else {
							eventPlanned.setDay(row.getCell(6).toString());
						}
					}
					// checking the type of the cell and based on that we are formatting the date
					// and time
					if (row.getCell(7) != null) {
						if (row.getCell(7).getCellType() == 0) {
							Date date1 = row.getCell(7).getDateCellValue();
							SimpleDateFormat format1 = new SimpleDateFormat("dd-MM-yyyy");
							String datetime = format1.format(date1);
							eventActual.setPlanned_Start_Date(datetime);
						} else if (row.getCell(7).getCellType() == 1) {
							eventActual.setPlanned_Start_Date(row.getCell(7).toString());
						}
					}
					if (row.getCell(8) != null) {
						if (row.getCell(8).getCellType() == 0) {
							Date date1 = row.getCell(8).getDateCellValue();
							SimpleDateFormat format1 = new SimpleDateFormat("HH:mm");
							String datetime = format1.format(date1);
							eventPlanned.setPlanned_Start_Time(datetime);
						} else if (row.getCell(8).getCellType() == 1) {
							eventPlanned.setPlanned_Start_Time(row.getCell(8).toString());
						}
					}
					if (row.getCell(9) != null) {
						if (row.getCell(9).getCellType() == 0) {
							Date date1 = row.getCell(9).getDateCellValue();
							SimpleDateFormat format1 = new SimpleDateFormat("dd-MM-yyyy");
							String datetime = format1.format(date1);
							eventActual.setPlanned_End_Date(datetime);
						} else if (row.getCell(9).getCellType() == 1) {
							eventActual.setPlanned_End_Date(row.getCell(9).toString());
						}
					}
					if (row.getCell(10) != null) {
						if (row.getCell(10).getCellType() == 0) {
							Date date1 = row.getCell(10).getDateCellValue();
							SimpleDateFormat format1 = new SimpleDateFormat("HH:mm");
							String datetime = format1.format(date1);
							eventPlanned.setPlanned_End_Time(datetime);
						} else if (row.getCell(10).getCellType() == 1) {
							eventPlanned.setPlanned_End_Time(row.getCell(10).toString());
						}
					}

					if (row.getCell(11) != null) {
						if (row.getCell(11).getCellType() == 0) {
							Date date1 = row.getCell(11).getDateCellValue();
							SimpleDateFormat format1 = new SimpleDateFormat("dd-MM-yyyy");
							String datetime = format1.format(date1);
							eventActual.setActual_Start_Date(datetime);
						} else if (row.getCell(11).getCellType() == 1) {
							eventActual.setActual_Start_Date(row.getCell(11).toString());
						}
					} else {
						errors1.add("The Start_Date should not be empty;");
					}

					if (row.getCell(12) != null) {
						if (row.getCell(12).getCellType() == 0) {
							Date date1 = row.getCell(12).getDateCellValue();
							SimpleDateFormat format1 = new SimpleDateFormat("HH:mm");
							String datetime = format1.format(date1);
							eventActual.setActual_Start_Time(datetime);
						} else if (row.getCell(12).getCellType() == 1) {
							eventActual.setActual_Start_Time(row.getCell(12).toString());
						}
					} else {
						errors1.add("The Start_Time should not be empty;");
					}

					if (row.getCell(13) != null) {
						if (row.getCell(13).getCellType() == 0) {
							Date date1 = row.getCell(13).getDateCellValue();
							SimpleDateFormat format1 = new SimpleDateFormat("dd-MM-yyyy");
							String datetime = format1.format(date1);
							eventActual.setActual_End_Date(datetime);
						} else if (row.getCell(13).getCellType() == 1) {
							eventActual.setActual_End_Date(row.getCell(13).toString());
						}
					} else {
						errors1.add("The End_Date should not be empty;");
					}

					if (row.getCell(14) != null) {
						if (row.getCell(14).getCellType() == 0) {
							Date date1 = row.getCell(14).getDateCellValue();
							SimpleDateFormat format1 = new SimpleDateFormat("HH:mm");
							String datetime = format1.format(date1);
							eventActual.setActual_End_Time(datetime);
						} else if (row.getCell(14).getCellType() == 1) {
							eventActual.setActual_End_Time(row.getCell(14).toString());
						}
					}
//					} else {
//						errors1.add("The Actual_End_Time should not be empty;");
//					}

					if (row.getCell(15) != null)
						eventActual.setFailure_Reason(row.getCell(15).toString());
					if (row.getCell(16) != null)
						eventActual.setPreventive_Measure(row.getCell(16).toString());
					
					
					if (eventActual != null && eventPlanned != null && eventActual.getActual_Start_Time() != null && eventPlanned.getJob_Name() != null &&
							!eventActual.getActual_Start_Time().trim().equalsIgnoreCase("") && 
							!eventPlanned.getJob_Name().trim().equalsIgnoreCase("") &&
							eventActual.getActual_Start_Time().equalsIgnoreCase("NA")
							&& (eventPlanned.getJob_Name().equalsIgnoreCase("CriticalPath") || eventPlanned.getJob_Name().equalsIgnoreCase("Checkpoint"))) {
						eventActual.setActual_Run_Time("");
					} else if (eventActual != null  && eventActual.getActual_Start_Time() != null
							&& eventActual.getActual_End_Time() != null
							&& eventActual.getActual_Start_Time() != "NA") {

						SimpleDateFormat format1 = new SimpleDateFormat("HH:mm");
						Date date1 = null;
						Date date2 = null;
						try {
							date1 = format1.parse(eventActual.getActual_Start_Time());
							date2 = format1.parse(eventActual.getActual_End_Time());
						} catch (Exception e) {
							e.printStackTrace();
						}
						long difference = date2.getTime() - date1.getTime();
						long difference_In_Minutes = (difference / (1000 * 60)) % 60;
						long difference_In_Hours = (difference / (1000 * 60 * 60)) % 24;

						String runTime = difference_In_Hours + ":" + difference_In_Minutes;
						eventActual.setActual_Run_Time(runTime);
					}
					
					// run time calculation ends here

					SimpleDateFormat format2 = new SimpleDateFormat("dd-MM-yyyy HH:mm");
					Date time1 = null;
					Date time2 = null;
					if (eventActual != null && eventPlanned != null && eventPlanned.getPlanned_End_Time() != null
							&& eventActual.getPlanned_End_Date() != null && eventActual.getActual_End_Time() != null
							&&  eventActual.getActual_End_Date() != null) {
					String plannedEndTime = eventPlanned.getPlanned_End_Time();
					String plannedEndDate = eventActual.getPlanned_End_Date();
					String actualEndTime = eventActual.getActual_End_Time();
					String actualEndDate = eventActual.getActual_End_Date();
					// concatenate date and time
					String planned = plannedEndDate + " " + plannedEndTime;
					String actual = actualEndDate + " " + actualEndTime;

					Date datePlanned = null;
					Date dateActual = null;
					SimpleDateFormat fmt = new SimpleDateFormat("dd-MM-yyyy");
					try {
						datePlanned = fmt.parse(plannedEndDate);
						dateActual = fmt.parse(actualEndDate);
					} catch (Exception e) {
						e.printStackTrace();
					}

					if (eventActual.getActual_End_Time() == null
							|| eventActual.getActual_End_Time().equalsIgnoreCase("")) {
						eventActual.setJob_Status("Failed");
					} else if (datePlanned.compareTo(dateActual) < 0) {
						eventActual.setJob_Status("Delayed");
					} else {
						try {
							time1 = format2.parse(planned);
							time2 = format2.parse(actual);
						} catch (Exception e) {
							e.printStackTrace();
						}
						// compareTo methods returns 0 if 2 dates are equal, if >0 date1 is after date2
						// if <0 date1 is before date2
						if (datePlanned.compareTo(dateActual) == 0 && time1.compareTo(time2) > 0 && time1 != null
								&& time2 != null) {
							eventActual.setJob_Status("On-Time");
						} else if (datePlanned.compareTo(dateActual) == 0 && time1.compareTo(time2) < 0 && time1 != null
								&& time2 != null) {
							eventActual.setJob_Status("Delayed");
						} else if (datePlanned.compareTo(dateActual) == 0 && time1.compareTo(time2) == 0
								&& time1 != null && time2 != null) {
							eventActual.setJob_Status("On-Time");
						} else if (time1 == null && time2 == null) {
							eventActual.setJob_Status("Failed");
						}
					}
					}
					// populating job status ends here
					eventActual.setEvent_Frequency_ID(1);

					eventPlannedFlag = true;
				}
			}

			if (eventPlannedFlag) {
				try {
					if (request.getParameter("finalUpload") != null
							&& request.getParameter("finalUpload").equalsIgnoreCase("true")) {
						if (eventActual != null) {
							eventActualRepository.save(eventActual);

							List<EventEntry> eventEntry = eventEntryService.findAll();

							List<String> eventEntryStr = new ArrayList<String>();

							for (EventEntry eventEntryObj : eventEntry) {
								eventEntryStr.add(eventEntryObj.getEventname());
							}
							mod.addAttribute("eventEntryList", eventEntryStr);
							mod.addAttribute("finalUploadMsg", "yes");
						}
					} else {
						if (errors1 != null && errors1.size() > 0) {
							/* Cell color add starts here */
							CellStyle style = wb.createCellStyle();
							Font font = wb.createFont();
							font.setColor(HSSFColor.RED.index);
							style.setFont(font);
							/* Cell color add ends here */

							XSSFRow row1 = sheet.getRow(0);

							XSSFCell cell = row1.createCell(17);

							cell.setCellValue("Errors");
							cell.setCellStyle(style);

							XSSFRow rowC = sheet.getRow(row.getRowNum());

							XSSFCell cellC = rowC.createCell(17);

							cellC.setCellValue(errors);
							cellC.setCellStyle(style);
							
							File outWB = new File(dir + "\\UploadEventErrorRecords_" + userId + ".xlsm");

							OutputStream out = new FileOutputStream(outWB);

							wb.write(out);

							out.flush();

							out.close();

							wb.close();
							
							errors = "";
							mod.addAttribute("errorFlag", "yes");
						} else {
							mod.addAttribute("validateMsg", "yes");
							mod.addAttribute("finalUploadMsg", "no");
						}
					}
				} catch (Exception hex) {
					mod.addAttribute("finalUploadMsg", "no");
					mod.addAttribute("exception", "There is an issue in uploading. Please contact technical support.");
					List<EventEntry> eventEntry = eventEntryService.findAll();

					List<String> eventEntryStr = new ArrayList<String>();

					for (EventEntry eventEntryObj : eventEntry) {
						eventEntryStr.add(eventEntryObj.getEventname());
					}

					mod.addAttribute("eventEntryList", eventEntryStr);

				}

			}
			}
		}

		if (!StringUtils.isEmpty(errors) || (errors1 != null && errors1.size() > 0)) {
			return ResponseEntity.ok("Yes");
		} else {
			return ResponseEntity.ok("");
		}

	
	}
	
private static List<LocalDateTime> getWeekRecur(EventEntryBean event, LocalDateTime startlcl, LocalDateTime endlcl){
		
		String recurWeekDay = !isEmpty(event.getRecurrence_dayName()) ?event.getRecurrence_dayName().replace("MO", "2").replace("TU", "3").replace("WE", "4").replace("TH", "5").replace("FR", "6").replace("SA", "7").replace("SU", "1") : "";
		Calendar cal = Calendar.getInstance();
		Calendar calEnd = Calendar.getInstance();
		Date st = new Date(startlcl.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());
		Date end = new Date(endlcl.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());
		int recurWeek = !isEmpty(event.getRecu_every_week()) ? Integer.parseInt(event.getRecu_every_week()) : 1;
		List<LocalDateTime> lstDateTime = new ArrayList<LocalDateTime>();
		for(String s : recurWeekDay.split(",")){
			cal.setTimeInMillis(st.getTime());
			calEnd.setTimeInMillis(end.getTime());			
			int weekDay = !isEmpty(s) ? Integer.parseInt(s) : 0;
		if(cal.get(Calendar.DAY_OF_WEEK)==weekDay) {
			lstDateTime.add(LocalDateTime.ofInstant(cal.toInstant(), cal.getTimeZone().toZoneId()));			
		}
		cal.add(Calendar.WEEK_OF_YEAR, recurWeek);
		cal.set(Calendar.DAY_OF_WEEK, weekDay);			
		while(calEnd.getTimeInMillis()>cal.getTimeInMillis()){
			lstDateTime.add(LocalDateTime.ofInstant(cal.toInstant(), cal.getTimeZone().toZoneId()));
			cal.add(Calendar.WEEK_OF_YEAR, recurWeek);
			cal.set(Calendar.DAY_OF_WEEK, weekDay);			
			
		}
		}
		
		return lstDateTime;
	}

private static List<LocalDateTime> getMonthRecur(EventEntryBean event, LocalDateTime startlcl, LocalDateTime endlcl) throws ParseException {
	
	Calendar cal = Calendar.getInstance();
	Calendar calEnd = Calendar.getInstance();
	Date st = new Date(startlcl.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());
	Date end = new Date(endlcl.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());
	cal.setTimeInMillis(st.getTime());
	calEnd.setTimeInMillis(end.getTime());
	List<LocalDateTime> lstDateTime = new ArrayList<LocalDateTime>();
	
	if("2".equalsIgnoreCase(event.getRecu_month_day_radio())) {
		

		int recurWeek = !isEmpty(event.getMonthdd1()) ? Integer.parseInt(event.getMonthdd1()) : 1;
		int weekday = !isEmpty(event.getMonthdd2()) ? Integer.parseInt(event.getMonthdd2()) : 1;
		int recurMonth = !isEmpty(event.getMonthtext1()) ? Integer.parseInt(event.getMonthtext1()) : 1;
		
	if(weekday == cal.get(Calendar.DAY_OF_WEEK)) {
		recurWeek = recurWeek < 5 ? recurWeek : getLastWeekday(weekday,cal);
		cal.set(Calendar.WEEK_OF_MONTH, recurWeek);
	}else if(weekday < cal.get(Calendar.DAY_OF_WEEK)){
		recurWeek = recurWeek < 5 ? recurWeek+1 : getLastWeekday(weekday,cal);			
		cal.set(Calendar.DAY_OF_WEEK, weekday);
		cal.set(Calendar.WEEK_OF_MONTH, recurWeek);
	}else if(weekday <= Calendar.SATURDAY){
		recurWeek = recurWeek < 5 ? recurWeek : getLastWeekday(weekday,cal);			
		cal.set(Calendar.DAY_OF_WEEK, weekday);
		cal.set(Calendar.WEEK_OF_MONTH, recurWeek);			
	}else if(weekday == 9){			
			cal.set(Calendar.DAY_OF_MONTH, getNthWeekDay(recurWeek,cal));			
	}else if(weekday == 8){			
		cal.set(Calendar.DAY_OF_MONTH, getNthWeekEndDay(recurWeek,cal));			
	}
	//cal.add(Calendar.MONTH, recurMonth);
	while(calEnd.getTimeInMillis()>cal.getTimeInMillis()){
		
		lstDateTime.add(LocalDateTime.ofInstant(cal.toInstant(), cal.getTimeZone().toZoneId()));
		
		cal.add(Calendar.MONTH, recurMonth);
		if(weekday == cal.get(Calendar.DAY_OF_WEEK)) {
			recurWeek = recurWeek < 5 ? recurWeek : getLastWeekday(weekday,cal);
			cal.set(Calendar.WEEK_OF_MONTH, recurWeek);
		}else if(weekday < cal.get(Calendar.DAY_OF_WEEK)){
			recurWeek = recurWeek < 5 ? recurWeek+1 : getLastWeekday(weekday,cal);				
			cal.set(Calendar.DAY_OF_WEEK, weekday);
			cal.set(Calendar.WEEK_OF_MONTH, recurWeek);
		}else if(weekday <= Calendar.SATURDAY){
			recurWeek = recurWeek < 5 ? recurWeek : getLastWeekday(weekday,cal);			
			cal.set(Calendar.DAY_OF_WEEK, weekday);
			cal.set(Calendar.WEEK_OF_MONTH, recurWeek);			
		}else if(weekday == 9){			
				cal.set(Calendar.DAY_OF_MONTH, getNthWeekDay(recurWeek,cal));			
		}else if(weekday == 8){			
			cal.set(Calendar.DAY_OF_MONTH, getNthWeekEndDay(recurWeek,cal));			
		}
					
	}
	
		
	}else {

		int monthDay = !isEmpty(event.getRecu_month_day()) ? Integer.parseInt(event.getRecu_month_day()) : 1;
		int recurMonth = !isEmpty(event.getRecu_every_month()) ? Integer.parseInt(event.getRecu_every_month()) : 1;
	if(cal.get(Calendar.DAY_OF_MONTH)==monthDay) {
		lstDateTime.add(LocalDateTime.ofInstant(cal.toInstant(), cal.getTimeZone().toZoneId()));
			
	}
	cal.add(Calendar.MONTH, recurMonth);
	cal.set(Calendar.DAY_OF_MONTH, monthDay);
	while(calEnd.getTimeInMillis()>cal.getTimeInMillis()){
		lstDateTime.add(LocalDateTime.ofInstant(cal.toInstant(), cal.getTimeZone().toZoneId()));
		cal.add(Calendar.MONTH, recurMonth);
		cal.set(Calendar.DAY_OF_MONTH, monthDay);			
					
	}
	
	}
	return lstDateTime;
	
}

private static int getNthWeekEndDay(int recurWeek, Calendar cal3) {
	Calendar cal2 = (Calendar) cal3.clone();
	   cal2.set( Calendar.DAY_OF_MONTH, 1);
	   if(recurWeek<5) {
		   int cnt=1;
		   while ((cal2.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY
		           && cal2.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) || cnt<recurWeek){				   
		       if((cal2.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY
			           || cal2.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY)) {
		    	   cnt++;
		       }
		         cal2.add(Calendar.DATE, 1);			       
		   } 		   	       
	   }else {
		   cal2.add( Calendar.MONTH, 1);
		   do{
		       cal2.add(Calendar.DATE, -1);			       
		   } while (cal2.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY
		           && cal2.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY );
	   
		}
	   return cal2.get(Calendar.DAY_OF_MONTH);
	   }

private static int getNthWeekDay(int recurWeek, Calendar cal3) {
	Calendar cal2 = (Calendar) cal3.clone();
   cal2.set( Calendar.DAY_OF_MONTH, 1);
   if(recurWeek<21) {
	   int cnt=1;
	   
	   while ((cal2.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY
           || cal2.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) || cnt<recurWeek){
		   if((cal2.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY
		           && cal2.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY)) {
	    	   cnt++;
		   }
		   cal2.add(Calendar.DATE, 1);			       
   } 
   }else {
	   cal2.add( Calendar.MONTH, 1);
	   do{
		   cal2.add(Calendar.DATE, -1);
	       
	   } while (cal2.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY
	           || cal2.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY );
	}
   return cal2.get(Calendar.DAY_OF_MONTH);
   }

private static int getLastWeekday(int weekday, Calendar cal2) {
	   Calendar cal = (Calendar) cal2.clone();
	   cal.add( Calendar.MONTH, 1);
	   cal.set(Calendar.DAY_OF_MONTH, 1);
	   cal.add( Calendar.DAY_OF_MONTH, -(( cal.get( Calendar.DAY_OF_WEEK ) % 7 + (7-weekday) )%7) );
	   return cal.get(Calendar.WEEK_OF_MONTH);
	}

public static boolean isEmpty(Object str) {
	return (str == null || "".equals(str));
}
}
