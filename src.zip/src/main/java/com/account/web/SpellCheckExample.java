/*
Jazzy - a Java library for Spell Checking
Copyright (C) 2001 Mindaugas Idzelis
Full text of license can be found in LICENSE.txt

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/
package com.account.web;

import com.swabunga.spell.engine.SpellDictionary;
import com.swabunga.spell.engine.SpellDictionaryHashMap;
import com.swabunga.spell.event.SpellCheckEvent;
import com.swabunga.spell.event.SpellCheckListener;
import com.swabunga.spell.event.SpellChecker;
import com.swabunga.spell.event.StringWordTokenizer;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/** This class shows an example of how to use the spell checking capability.
 *
 * @author Jason Height (jheight@chariot.net.au)
 */
public class SpellCheckExample implements SpellCheckListener {

  private static String dictFile = "D:/SPELLCHECK/english.0";
  private static String phonetFile = "D:/SPELLCHECKOUT/phonet.en";

  private SpellChecker spellCheck = null;

  HashMap<String, List<String>> suggestedWords = new HashMap<String, List<String>>();
  public HashMap<String, List<String>> SpellCheckExample(String eventDetails) {
    try {
      SpellDictionary dictionary = new SpellDictionaryHashMap(new File(dictFile), new File(phonetFile));

      spellCheck = new SpellChecker(dictionary);
      spellCheck.addSpellCheckListener(this);
      spellCheck.checkSpelling(new StringWordTokenizer(eventDetails));
    } catch (Exception e) {
      e.printStackTrace();
    }
	return suggestedWords;
  }

  public void spellingError(SpellCheckEvent event) {
    List<Object> suggestions = event.getSuggestions();
    List<String> suggList = new ArrayList<>();
    if (suggestions.size() > 0) {
      System.out.println("MISSPELT WORD: " + event.getInvalidWord());
    
      for (Object str : suggestions) {
	    System.out.println("\tSuggested Word: " + str);
        suggList.add(str.toString());
      }
      suggestedWords.put(event.getInvalidWord(), suggList);
    } else {
      System.out.println("MISSPELTmm WORD: " + event.getInvalidWord());
      System.out.println("\tNo suggestions");
      suggList.add("No suggestions");
      suggestedWords.put(event.getInvalidWord(), suggList);
    }
    //Null actions
  }

  public static void main(String[] args) {
	    SpellCheckExample checkExample = new SpellCheckExample();
  		HashMap<String, List<String>> suggestions = checkExample.SpellCheckExample("HEd TOkjllk evend");
  	
  }
}