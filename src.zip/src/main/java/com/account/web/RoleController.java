package com.account.web;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.account.model.Role;
import com.account.service.CalendarTypeService;
import com.account.service.RoleService;
import com.account.validator.RoleValidator;
import com.accounts.dto.RoleBean;

@Controller
public class RoleController {

	@Autowired
	private RoleService roleService;
	
	@Autowired
	private RoleValidator roleValidator;
	
	@Autowired
    private CalendarTypeService calendarTypeService;
	
	@RequestMapping(value = "/roleDetail", method = RequestMethod.GET)
	public ModelAndView userDetails(Model model) {
		Role role=new Role();
		
		model.addAttribute("roleForm", role);
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("roleDetail");
	}
	
	@RequestMapping(value = "/roleDetail", method = RequestMethod.POST)
	public ModelAndView userDetails(@ModelAttribute("roleForm") Role roleForm, BindingResult bindingResult, Model model) {
		
		roleValidator.validate(roleForm, bindingResult);

		if (bindingResult.hasErrors()) {
			return new ModelAndView("roleDetail");
		}
		roleService.save(roleForm);

		List<RoleBean> roleBeanList=new ArrayList<>();
		List<Role> roleList = roleService.findAll();
		for(Role roleListDataBean : roleList){
		RoleBean roleBean=new RoleBean();
		
		roleBean.setRoleID(roleListDataBean.getRole_Id());
		roleBean.setRole_Name(roleListDataBean.getRole_Name());
		
		boolean b=roleListDataBean.isStatus();
		 if(b==true){
			 roleBean.setStatus1("Active");
		 }else{
			 roleBean.setStatus1("InActive");
		 }
		
		//roleBean.setStatus(userListDataBean.isStatus());
		roleBeanList.add(roleBean);
		}
		model.addAttribute("roleBeanList", roleBeanList);
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("viewRole");
		
		
	}
	
	@RequestMapping(value = "/viewRole", method = RequestMethod.GET)
	public ModelAndView viewUser(@ModelAttribute("roleForm") Role roleForm, BindingResult bindingResult, Model model) {
		
		List<RoleBean> roleBeanList=new ArrayList<>();
		List<Role> roleList = roleService.findAll();
		for(Role roleListDataBean : roleList){
		RoleBean roleBean=new RoleBean();
		
		roleBean.setRoleID(roleListDataBean.getRole_Id());
		roleBean.setRole_Name(roleListDataBean.getRole_Name());
		
		if(roleListDataBean.isStatus()==true){
			roleBean.setStatus1("Active");
		 }else{
			 roleBean.setStatus1("InActive");
		 }
		
		//roleBean.setStatus(roleListDataBean.isStatus());
		roleBeanList.add(roleBean);
		}
		Collections.sort(roleBeanList);
		model.addAttribute("roleBeanList", roleBeanList);
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("viewRole");
		
		
		//List<AccountGoals> acctGoalsList = accountGoalService.findAll();
		
		//return new ModelAndView("viewUser", "userBean", userBean);
	}
	
	
	@RequestMapping(value="/editRole/{id}" ,method = RequestMethod.GET)  
    public ModelAndView edit(@PathVariable Long id,@ModelAttribute("roleBean") RoleBean roleBean, Model model){  
        //Emp emp=dao.getEmpById(id);  
		
		Role role=roleService.findById(id);
		
		roleBean.setRoleID(role.getRole_Id());
		roleBean.setRole_Name(role.getRole_Name());
		roleBean.setStatus(role.isStatus());
		
		model.addAttribute("roleBean", roleBean);
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
        return new ModelAndView("editRole");  
    }  
	
	
	
	
	@RequestMapping(value="/editRole/{id}" ,method = RequestMethod.POST)  
    public ModelAndView editUserDataSave(@PathVariable Long id,@ModelAttribute("roleBean") RoleBean roleBean, BindingResult bindingResult, Model model){
		/*roleValidator.validate(roleBean, bindingResult);

		if (bindingResult.hasErrors()) {
			return new ModelAndView("editRole");
		}*/
		Role role=new Role();
		role.setRole_Id(roleBean.getRoleID());
		role.setRole_Name(roleBean.getRole_Name());
		role.setStatus(roleBean.isStatus());
		roleService.save(role);
		
		List<RoleBean> roleBeanList=new ArrayList<>();
		List<Role> roleList = roleService.findAll();
		for(Role roleListDataBean : roleList){
			RoleBean roleBeanData=new RoleBean();
		
		roleBean.setRoleID(roleListDataBean.getRole_Id());
			roleBeanData.setRole_Name(roleListDataBean.getRole_Name());
		
		if(roleListDataBean.isStatus()==true){
			roleBeanData.setStatus1("Active");
		 }else{
			 roleBeanData.setStatus1("InActive");
		 }
		
		//roleBean.setStatus(userListDataBean.isStatus());
		roleBeanList.add(roleBeanData);
		}
		Collections.sort(roleBeanList);
		model.addAttribute("roleBeanList", roleBeanList);
		model.addAttribute("calendarType", StringUtils.arrayToCommaDelimitedString(calendarTypeService.getCalendarTypeName().toArray()));
		return new ModelAndView("viewRole");
		
		
		
	}
	
	
}
