package com.accounts.dto;

public class CalendarTypeBean 
{

	private Long calendar_type_id;
    private String calendar_type_name;
    private boolean status;
    private String status1;
    
	public Long getCalendar_type_id() {
		return calendar_type_id;
	}
	public void setCalendar_type_id(Long calendar_type_id) {
		this.calendar_type_id = calendar_type_id;
	}
	public String getCalendar_type_name() {
		return calendar_type_name;
	}
	public void setCalendar_type_name(String calendar_type_name) {
		this.calendar_type_name = calendar_type_name;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getStatus1() {
		return status1;
	}
	public void setStatus1(String status1) {
		this.status1 = status1;
	}
	
	
}
