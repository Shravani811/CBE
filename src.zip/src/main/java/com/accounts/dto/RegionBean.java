package com.accounts.dto;

/**
 * 
 * @author kimallap
 *
 */

public class RegionBean 
{
	private Long region_id;
    private String Region_territory;
    private boolean status;
    private String status1;
    
    
	public Long getRegion_id() {
		return region_id;
	}
	public void setRegion_id(Long region_id) {
		this.region_id = region_id;
	}
	public String getRegion_territory() {
		return Region_territory;
	}
	public void setRegion_territory(String region_territory) {
		Region_territory = region_territory;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getStatus1() {
		return status1;
	}
	public void setStatus1(String status1) {
		this.status1 = status1;
	}
    
    
}
