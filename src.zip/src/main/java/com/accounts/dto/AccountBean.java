package com.accounts.dto;

public class AccountBean{
	private Long acc_ID;
	private String accName;
	public Long getAcc_ID() {
		return acc_ID;
	}
	public void setAcc_ID(Long acc_ID) {
		this.acc_ID = acc_ID;
	}
	public String getAccName() {
		return accName;
	}
	public void setAccName(String accName) {
		this.accName = accName;
	}
	
}
