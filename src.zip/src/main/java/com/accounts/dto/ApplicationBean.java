package com.accounts.dto;

/**
 * -
 * @author jaimishr
 *
 */

public class ApplicationBean implements Comparable<ApplicationBean>{
	private Long app_ID;
	private String appName;
	private String primaryResource;
	private String secondaryResource;
	private boolean status;
	private String status1;
	private String tower;
	private String ccname;
	private String cluster;
	private String lastModified_date;
	private String lastModified_by;
	/*@ManyToOne(optional = false)
	private EventEntry eventEntry;
	*/
	public Long getApp_ID() {
		return app_ID;
	}
	public void setApp_ID(Long app_ID) {
		this.app_ID = app_ID;
		
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getPrimaryResource() {
		return primaryResource;
	}
	public void setPrimaryResource(String primaryResource) {
		this.primaryResource = primaryResource;
	}
	public String getSecondaryResource() {
		return secondaryResource;
	}
	public void setSecondaryResource(String secondaryResource) {
		this.secondaryResource = secondaryResource;
	}
	/*public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}*/
	
	public String getTower() {
		return tower;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public void setTower(String tower) {
		this.tower = tower;
	}
	public String getCcname() {
		return ccname;
	}
	public void setCcname(String ccname) {
		this.ccname = ccname;
	}
	public String getCluster() {
		return cluster;
	}
	public void setCluster(String cluster) {
		this.cluster = cluster;
	}
	public String getLastModified_date() {
		return lastModified_date;
	}
	public void setLastModified_date(String lastModified_date) {
		this.lastModified_date = lastModified_date;
	}
	public String getLastModified_by() {
		return lastModified_by;
	}
	public void setLastModified_by(String lastModified_by) {
		this.lastModified_by = lastModified_by;
	}
	public String getStatus1() {
		return status1;
	}
	public void setStatus1(String status1) {
		this.status1 = status1;
	}
	@Override
	public int compareTo(ApplicationBean a) {
		
		
		//return this.getApp_Name().compareTo(a.getApp_Name());
		return this.getStatus1().compareTo(a.getStatus1());
	}
	
	
	
}
