package com.accounts.dto;

public class RoleBean implements Comparable<RoleBean>{
	private Long roleID;
    //private String roleName;
	private String Role_Name;
    private boolean status;
    private String status1;
   
	public Long getRoleID() {
		return roleID;
	}
	public void setRoleID(Long roleID) {
		this.roleID = roleID;
	}
/*	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}*/
	
	public boolean isStatus() {
		return status;
	}
	public String getRole_Name() {
		return Role_Name;
	}
	public void setRole_Name(String role_Name) {
		Role_Name = role_Name;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getStatus1() {
		return status1;
	}
	public void setStatus1(String status1) {
		this.status1 = status1;
	}
	@Override
	public int compareTo(RoleBean o) {
		
		return this.getStatus1().compareTo(o.getStatus1());
	}
	

   
}
