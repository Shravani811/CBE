package com.accounts.emailService;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

//import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFDataFormat;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.mysql.jdbc.StringUtils;


public class ReportMailService {

	//private static final Logger LOGGER = Logger.getLogger(ReportMailService.class);


	public static final LocalDateTime currD = LocalDateTime.now();
	static Connection conn, conn1, conn2, conn3, conn4, conn5, conn6;
	static CallableStatement stmt, stmt1, stmt2, stmt3, stmt4, stmt5, stmt6, stmt7;
	static ResultSet resultset, resultset1, resultset2, resultset3, resultset4, resultset5, resultset6;
	//static PreparedStatement prepared;
	public static Properties props = new Properties();

	public static void triggerActualsEmail(String[] args) throws FileNotFoundException, IOException, SQLException, ParseException {
		
		
		
		
		//new ReportMailService().sendMail("Test");
		
		//LOGGER.info("Main");
		loadProps();
		//LOGGER.info(props.values());
		conn1 = getcon();
		String query = "{CALL getEventData()}";
		stmt1 = conn1.prepareCall(query);
		//String sql = "update tbl_event_master set emailflag=? where event_id=?";
		//prepared = conn1.prepareStatement(sql);
		conn1.toString();
		resultset1 = stmt1.executeQuery();
		while (resultset1.next()) {
			EventEntry event = new EventEntry();
			try {
				
			event.setEventID(resultset1.getLong("Event_Id"));
			event.setStartDate(resultset1.getString("Start_Date"));
			event.setEndDate(resultset1.getString("End_date"));
			event.setRecurrenceType(resultset1.getString("Recurrence_type"));
			event.setEventName(resultset1.getString("eventName"));
			event.setEventDesc(resultset1.getString("Description_details"));
			event.setRecuEveryDay(resultset1.getString("recu_every_day"));
			event.setRecurrenceDayName(resultset1.getString("recurrence_dayName"));
			event.setRecuEveryWeek(resultset1.getString("recu_every_week"));
			event.setRecuMonthDay(resultset1.getString("recu_month_day"));
			event.setRecuEveryMonth(resultset1.getString("recu_every_month"));
			event.setMonthdd1(resultset1.getString("monthdd1"));
			event.setMonthdd2(resultset1.getString("monthdd2"));
			event.setMonthtext1(resultset1.getString("monthtext1"));
			event.setRecuMonthDayRadio(resultset1.getString("recu_month_day_radio"));
			event.setAttachment(resultset1.getString("file_upload"));
			
			//LOGGER.info("Event name:" +event.getEventName());
			
			String currDate = Long.toString(System.currentTimeMillis());
			
			String startDate = event.getStartDate();
			String endDate = event.getEndDate();
			
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S");
			
			final LocalDateTime start = LocalDateTime.parse(startDate, formatter);
			final LocalDateTime end = LocalDateTime.parse(endDate, formatter);
			final LocalDateTime compMin = currD.plusMinutes(15);
			//LOGGER.info("Recurrence type of this event:" +event.getRecurrenceType());
			if(null == event.getRecurrenceType()) {
				//LOGGER.info("Null Recurrence Type for event : "+ event.getEventID());
				continue;
			}
			event.setRecurrenceType("weekly");
			event.setEventID(Long.parseLong(args[0]));
		switch(event.getRecurrenceType()) {
			case "weekly":
				
				/* Day calculation starts here */
				
				conn3 = getcon();
				
				String query2 = "{CALL getEventMaxDay(?)}";
				stmt4 = conn3.prepareCall(query2);
				stmt4.setLong(1, event.getEventID());
				resultset3 = stmt4.executeQuery();

				int max_day = 0;
				String plannedEndTime = "";
				while (resultset3.next()) {
					if(resultset3.getString("max_day") != null && !resultset3.getString("max_day").equalsIgnoreCase("")){
						max_day = Integer.parseInt(resultset3.getString("max_day"));
						plannedEndTime = resultset3.getString("Planned_End_Time");
					}
					//System.out.println("Name of event:" + event.getEventName());
				}
				
				
				/* Day calculation ends here */
				
				List<LocalDateTime> eventStTymLstWeek = getWeekRecur(event, start, end, plannedEndTime, max_day);
				//LOGGER.info("Event Id : " +event.getEventID()+ " Total Weekly Events : "+eventStTymLstWeek.size());
				
				
				
				/* Final Job Status calculation starts here */
				
				conn4 = getcon();
				
				String query3 = "{CALL getEventLastJobStatus(?)}";
				stmt5 = conn4.prepareCall(query3);
				stmt5.setLong(1, event.getEventID());
				resultset4 = stmt5.executeQuery();

				String finalJobStatus = "";
				while (resultset4.next()) {
					if(resultset4.getString("Job_Status") != null && !resultset4.getString("Job_Status").equalsIgnoreCase("")){
						finalJobStatus = resultset4.getString("Job_Status");
					}
					//System.out.println("Name of event:" + event.getEventName());
				}
				
				/* Normal email sending starts here */
				
				sendMail(start, end,eventStTymLstWeek.get(0),event, finalJobStatus);
				
				/* Normal email sending ends here */
				
				
				/* Final Job Status calculation ends here */

				boolean emailSentFlag = false;
				
				final LocalDateTime compOneDay = currD.plusDays(0);				
				for(LocalDateTime lcl : eventStTymLstWeek){
					//if(compOneDay.toLocalDate().compareTo(lcl.toLocalDate()) == 0) {
						if(lcl.compareTo(compOneDay.minusMinutes(30)) < 0) {
							try {
								//LOGGER.info("Event name:" +event.getEventName() + " Event Start time:" +lcl);
								
								conn2 = getcon();
								
								
								
								String query1 = "{CALL getEventReportData(?,?,?)}";
								stmt3 = conn2.prepareCall(query1);
								stmt3.setLong(1, event.getEventID());
							    DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
								stmt3.setString(2, lcl.format(formatter1));
								if(max_day>1){
									stmt3.setString(3, lcl.plusDays(1).format(formatter1));		
								} else {
									stmt3.setString(3, "");
								}

								resultset2 = stmt3.executeQuery();

								String jobStatus = "";
								while (resultset2.next()) {
									jobStatus = resultset2.getString("Job_Status");
									if(jobStatus != null && jobStatus.equalsIgnoreCase("Failed")){
										finalJobStatus = "Failed";
									}

								}
								
								/* Download attachment starts here */
								
								String eventNameAndDate = event.getEventName()+"_"+event.getStartDate();

								//String eventName = request.getParameter("eventName");
								//String sDate1 = request.getParameter("date");
								String value[] = eventNameAndDate.split("_");
								String eventName = value[0].toString();
								String date = value[1].toString();
								Date date1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(date);
								SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
								String eventDateselected = sdf.format(date1);
								String eventDate = sdf.format(date1);

								List<Integer> dayList = new ArrayList<Integer>();
								List<Integer> newdayList = new ArrayList<Integer>();

								String newDate = null;
								//EventEntry eventEntry = eventEntryService.findByEventName(eventName);
								List<EventPlanned> eventPlannedList = null;
								if (eventName != null)
									eventPlannedList = new ReportMailService().highestVersion(eventName);

								XSSFWorkbook workbook = new XSSFWorkbook();
								// Create a sheet
								XSSFSheet sheet1 = workbook.createSheet("EventDetail");

								Map<Integer, Object[]> data1 = new TreeMap<Integer, Object[]>();
								data1.put(1,
										new Object[] { "Planned_Seq_Id", "Event_Id", "Step_Number", "Critical Path", "Job Name", "Day",
												"Planned Start Date", "Start Time", "Planned End Date", "End Time", "Actual Start Date",
												"Start Time(Actual)", "Actual End Date", "End Time (Actual)", "Job Status", "Reason for failure",
												"Preventive Measure" });

								for (EventPlanned e : eventPlannedList) {
									dayList.add(Integer.parseInt(e.getDay()));
								}
								int max = 0;
								for (Integer e : dayList) {
									if (!newdayList.contains(e))
										newdayList.add(e);
								}
								Collections.sort(newdayList);
								max = newdayList.get(newdayList.size() - 1);

								HashMap<Integer, String> hMap = new HashMap<Integer, String>();
							
								int i1 = 1;
								for (int k = 0; k < max; k++) {
									hMap.put(i1, eventDate);
									i1++;
									Calendar c = Calendar.getInstance();
									c.setTime(sdf.parse(eventDate));
									c.add(Calendar.DATE, 1);
									eventDate = sdf.format(c.getTime());
								}
								int i = 1;
								for (EventPlanned e : eventPlannedList) {
									i++;
									int dayValue = Integer.parseInt(e.getDay());
									newDate = hMap.get(dayValue);

									data1.put(i,
											new Object[] { e.getPlanned_Seq_ID(), e.getEvent_ID(), e.getStep_Number(), e.getCritical_Path(),
													e.getJob_Name(), e.getDay(), newDate, e.getPlanned_Start_Time(), newDate,
													e.getPlanned_End_Time(), e.getActualStartDate(), e.getActualStartTime(), e.getActualEndDate(), 
													e.getActualEndTime(),e.getJobStatus(), e.getFailureReason(), e.getPreventiveMeasure() });
								}

								Set<Integer> keyset1 = data1.keySet();
								int rownum1 = 0;
								for (Integer key1 : keyset1) {
									XSSFRow row1 = sheet1.createRow(rownum1++);

									XSSFDataFormat format = workbook.createDataFormat();
									XSSFCellStyle style = workbook.createCellStyle();

									Object[] objArr1 = data1.get(key1);
									int cellnum1 = 0;
									for (Object obj1 : objArr1) {

										Cell cell1 = row1.createCell(cellnum1++);
										if (obj1 instanceof String)
											cell1.setCellValue((String) obj1);
										else if (obj1 instanceof Integer)
											cell1.setCellValue((Integer) obj1);
										else if (obj1 instanceof Long)
											cell1.setCellValue((Long) obj1);
									}
								}

								try {
									/*ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
									workbook.write(outByteStream);*/
									FileOutputStream fileOut = new FileOutputStream("D:\\CBE_Report_Service\\files\\EventDetail_Actuals_"+event.getEventID()+".xlsx");  
									workbook.write(fileOut);  
									fileOut.close();
									workbook.close();
									/*ByteArrayOutputStream baos = new ByteArrayOutputStream();
									workbook = Workbook.createWorkbook(baos);
									workbook.close();
									out.write(baos.toByteArray());
									out.flush();
									out.close();*/

									
									/*response.setContentType("application/ms-excel");
									response.setContentLength(outArray.length); 
									response.setHeader("Expires:", "0"); // eliminates browser caching
									response.setHeader("Content-Disposition", "attachment; filename="+eventName+"_"+date+".xlsx");
									OutputStream outStream = response.getOutputStream();
									outStream.write(outArray);
									outStream.flush();*/

								} catch (Exception e) {
									e.printStackTrace();
								}
							
								
								/* Download attachment ends here */
								if(!emailSentFlag && !StringUtils.isNullOrEmpty(finalJobStatus)){
								sendMail(start, end,lcl,event, finalJobStatus);
									emailSentFlag = true;
								}
							} catch (SQLException e) {
								e.printStackTrace();
							}
							
						}
					//}	
					
					//if(currD.toLocalDate().compareTo(lcl.toLocalDate()) == 0) {
						if(lcl.compareTo(compMin) < 0 &&
								lcl.compareTo(currD)>0
								) {
							try {
								//LOGGER.info("Event name:" +event.getEventName() + " Event Start time:" +lcl);
								sendMail(start, end,lcl,event,"");
							} catch (SQLException e) {
								e.printStackTrace();
							}
						}
					//}	
				}
				break;
				
			case "monthly":			

				
				List<LocalDateTime> eventStTymLstMonth = getMonthRecur(event, start, end);
				//LOGGER.info("Event Id : " +event.getEventID()+ " Total Monthly Events : "+eventStTymLstMonth.size());
				
				final LocalDateTime compSevenDay = currD.plusDays(7);
				for(LocalDateTime lcl : eventStTymLstMonth){
					//if(compSevenDay.toLocalDate().compareTo(lcl.toLocalDate()) == 0) {
						if(lcl.compareTo(compSevenDay.plusMinutes(15)) < 0 &&
								lcl.compareTo(compSevenDay)>0
								) {
							try {
								//LOGGER.info("Event name:" +event.getEventName() + " Event Start time:" +lcl);
								sendMail(start, end,lcl,event,"");
							} catch (SQLException e) {
								e.printStackTrace();
							}
							
						}
					//}	
					
					//if(currD.toLocalDate().compareTo(lcl.toLocalDate()) == 0) {
						if(lcl.compareTo(compMin) < 0 &&
								lcl.compareTo(currD)>0
								) {
							try {
								//LOGGER.info("Event name:" +event.getEventName() + " Event Start time:" +lcl);
								sendMail(start, end,lcl,event,"");
							} catch (SQLException e) {
								e.printStackTrace();
							}
						}
					//}	
				}
				break;
				
			default: 
				if (endDate.compareTo(currDate) > 0) {
					
					//LOGGER.info("Event Id : " +event.getEventID()+ " a daily event");
					LocalDateTime lcl = LocalDateTime.of(currD.toLocalDate(),start.toLocalTime());
					if (lcl.compareTo(compMin) < 0 &&
							lcl.compareTo(currD)>0
							) {
						try {
							//LOGGER.info("Event name:" +event.getEventName() + " Event Start time:" +start);
							sendMail(start, end,lcl,event,"");
						} catch (SQLException e) {
							e.printStackTrace();
						}
						
					}
				}
				break;
			}

		}catch (Exception e) {
			//LOGGER.info("Exception : "+e+" Event Id :"+event.getEventID());
		}
		}
	}
	
	public List<EventPlanned> highestVersion(String event_Name) throws SQLException {
		
		int highestVersion = 0;
		Long event_id = 0L;
		
		
		conn5 = getcon();
		
		String query4 = "{CALL getEventMasterDetailByName(?)}";
		stmt6 = conn5.prepareCall(query4);
		stmt6.setString(1, event_Name);
		resultset5 = stmt6.executeQuery();
		
		while (resultset5.next()) {
			event_id = Long.parseLong(resultset5.getString("Event_ID"));
			//System.out.println("Name of event:" + event.getEventName());
		}
		
		/*List<EventEntry> eeList = eventEntryRepository.findAll();
		for(EventEntry ee: eeList){
			if(event_Name != null && (ee.getEventname().equalsIgnoreCase(event_Name))){
				event_id = ee.getEvent_ID();
			}
		}*/		
		//EventPlanned eventPlanned = new EventPlanned();
		
		
		/* Get all planned events starts here */
		
		conn6 = getcon();
		
		String query5 = "{CALL getAllPlannedEventDetails()}";
		stmt7 = conn6.prepareCall(query5);
		//stmt7.setString(1, event_Name);
		resultset6 = stmt7.executeQuery();
		
		EventPlanned eventPlanned1 = new EventPlanned();
		List<EventPlanned> finalList1 = new ArrayList<EventPlanned>();
		
		while (resultset6.next()) {
			eventPlanned1 = new EventPlanned();
				eventPlanned1.setEvent_ID(resultset6.getString("Event_ID"));
				eventPlanned1.setPlanned_Seq_ID(Long.parseLong(resultset6.getString("Planned_Seq_ID")));
				eventPlanned1.setStep_Number(resultset6.getString("Step_Number"));
				eventPlanned1.setCritical_Path(resultset6.getString("Critical_Path"));
				eventPlanned1.setApplication_Name(resultset6.getString("Application_Name"));
				eventPlanned1.setJob_Name(resultset6.getString("Job_Name"));
				eventPlanned1.setOwner(resultset6.getString("Owner"));
				eventPlanned1.setTechnology(resultset6.getString("Technology"));
				eventPlanned1.setDay(resultset6.getString("Day"));
				eventPlanned1.setPlanned_Start_Time(resultset6.getString("Planned_Start_Time"));
				eventPlanned1.setPlanned_End_Time(resultset6.getString("Planned_End_Time"));
				eventPlanned1.setPlanned_Run_Time(resultset6.getString("Planned_Run_Time"));
				eventPlanned1.setSupport_Team_Email_ID(resultset6.getString("Support_Team_Email_ID"));
				eventPlanned1.setEscalation_Email_Group(resultset6.getString("Escalation_Email_Group"));
				eventPlanned1.setBusiness_Contact_Email(resultset6.getString("Business_Contact_Email"));
				eventPlanned1.setThresold_Alert_Time(resultset6.getString("Thresold_Alert_Time"));	
				eventPlanned1.setVersion(Integer.parseInt(resultset6.getString("version")));

				eventPlanned1.setActualStartDate(resultset6.getString("Actual_Start_Date"));
				eventPlanned1.setActualStartTime(resultset6.getString("Actual_Start_Time"));
				eventPlanned1.setActualEndDate(resultset6.getString("Actual_End_Date"));
				eventPlanned1.setActualEndTime(resultset6.getString("Actual_End_Time"));
				eventPlanned1.setJobStatus(resultset6.getString("Job_Status"));
				eventPlanned1.setFailureReason(resultset6.getString("Failure_Reason"));
				eventPlanned1.setPreventiveMeasure(resultset6.getString("Preventive_Measure"));
				
				finalList1.add(eventPlanned1);
			//System.out.println("Name of event:" + event.getEventName());
		}
		
		/* Get all planned events ends here */
		
		
		
		
		List<EventPlanned> epList1 = finalList1;
		List<Integer> versionList = new ArrayList<Integer>();
		for(EventPlanned ep: epList1){
			if(Long.parseLong(ep.getEvent_ID()) == event_id){
				versionList.add(ep.getVersion());
			}
		}
		
		Collections.sort(versionList);
		int size = versionList.size();
		highestVersion = versionList.get(size-1); 
		
		//EventPlanned eventPlanned1 = new EventPlanned();
		List<EventPlanned> epList2 = finalList1;
		List<EventPlanned> finalList = new ArrayList<EventPlanned>();
		String eventid = String.valueOf(event_id);
		for(EventPlanned ep: epList2){			
			eventPlanned1 = new EventPlanned();
			if(ep.getEvent_ID().equalsIgnoreCase(eventid) && ep.getVersion() == highestVersion) {
				eventPlanned1.setEvent_ID(ep.getEvent_ID());
				eventPlanned1.setPlanned_Seq_ID(ep.getPlanned_Seq_ID());
				eventPlanned1.setStep_Number(ep.getStep_Number());
				eventPlanned1.setCritical_Path(ep.getCritical_Path());
				eventPlanned1.setApplication_Name(ep.getApplication_Name());
				eventPlanned1.setJob_Name(ep.getJob_Name());
				eventPlanned1.setOwner(ep.getOwner());
				eventPlanned1.setTechnology(ep.getTechnology());
				eventPlanned1.setDay(ep.getDay());
				eventPlanned1.setPlanned_Start_Time(ep.getPlanned_Start_Time());
				eventPlanned1.setPlanned_End_Time(ep.getPlanned_End_Time());
				eventPlanned1.setPlanned_Run_Time(ep.getPlanned_Run_Time());
				eventPlanned1.setSupport_Team_Email_ID(ep.getSupport_Team_Email_ID());
				eventPlanned1.setEscalation_Email_Group(ep.getEscalation_Email_Group());
				eventPlanned1.setBusiness_Contact_Email(ep.getBusiness_Contact_Email());
				eventPlanned1.setThresold_Alert_Time(ep.getThresold_Alert_Time());
				
				eventPlanned1.setActualStartDate(ep.getActualStartDate());
				eventPlanned1.setActualStartTime(ep.getActualStartTime());
				eventPlanned1.setActualEndDate(ep.getActualEndDate());
				eventPlanned1.setActualEndTime(ep.getActualEndTime());
				eventPlanned1.setJobStatus(ep.getJobStatus());
				eventPlanned1.setFailureReason(ep.getFailureReason());
				eventPlanned1.setPreventiveMeasure(ep.getPreventiveMeasure());
				
				finalList.add(eventPlanned1);
			}
		}	
		return finalList;
	}
	
	private static void loadProps() throws FileNotFoundException, IOException {
	
		//System.out.println(AlertMailService.class.getClassLoader().getResource("application.properties").getPath());
			props.load(ReportMailService.class.getClassLoader().getResourceAsStream("application.properties"));			
		 
		    
	}
public static Connection getcon() {
		Connection con = null;
		try {
			String driver = "com.mysql.jdbc.Driver";
			String jdbcURL = props.getProperty("url");//"jdbc:mysql://in-blr-natools:3306/cbe_bd_refactoring";
			String jdbcUsername = props.getProperty("username");//"ikon_na";
			String jdbcPassword = props.getProperty("password");//"ikonna@123";
			Class.forName(driver);
			con = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		} catch (Exception e) {
			System.out.println("exception" + e);
		}
		return con;
	}

	public static void sendMail(LocalDateTime start,
			LocalDateTime end, LocalDateTime lcl, EventEntry event, String finalJobStatus) throws SQLException, IOException {

		//LOGGER.info("In SendMail for Event Id : "+event.getEventID());
		System.out.println("In SendMail for Event Id : "+event.getEventID());
		conn = getcon();

		String query = "{CALL getRecipients(?)}";
		stmt = conn.prepareCall(query);
		stmt.setLong(1, event.getEventID());
		resultset = stmt.executeQuery();

		String recipients = "";
		while (resultset.next()) {
			recipients = resultset.getString("Additional_receipients");
			//System.out.println("Name of event:" + event.getEventName());
		}
		String to = recipients;
		// String to= "vidushi.razdan@capgemini.com";
		//LOGGER.info("Mail will go to: " + to);

		String from = "dactoolssupport.in@capgemini.com";
		
		
		
		Properties properties = System.getProperties();
	      properties.put("mail.smtp.starttls.enable", "true");
	      properties.put("mail.smtp.host", "ismtp.corp.capgemini.com");
	      properties.put("mail.smtp.user", "anima.prasad@capgemini.com");
	      properties.put("mail.smtp.port", "25");
	      properties.put("mail.smtp.auth", "false");
	      properties.put("mail.smtp.starttls.enable","false");
	      // Setup mail server
	      properties.setProperty("mail.smtp.host", "ismtp.corp.capgemini.com");
	      Session session = Session.getInstance(properties);
	      
	      DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern( "yyyyMMdd'T'HHmm'00'" ) ;
	      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

	      String eventDate = lcl.format(formatter);
	      System.out.println(eventDate);

		try {

			Message message = new MimeMessage(session);

			message.setFrom(new InternetAddress(from));

			// Set To: header field of the header.
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
			message.setRecipients(Message.RecipientType.BCC, InternetAddress.parse("manikandan.bk@capgemini.com"));
			// message.setRecipients(Message.RecipientType.CC, InternetAddress.parse(CC));
			// Set Subject: header field
			message.setSubject("CBE Event Alert: " + event.getEventName());

			// Create the message part
			BodyPart messageBodyPart = new MimeBodyPart();
			messageBodyPart.setContent("Hello,<br><br>" + "This is a "
					+ "report with the event completion status. Please find the details below:<br> "
					+ " Event Name: " + event.getEventName() + "<br>Recurrence Type: " + event.getRecurrenceType() + "<br>Start Date of Event: "
					+ eventDate + "<br> End Date: " + eventDate + "<br> End Time: "
					+ lcl.toLocalTime() + "<br> Event Status: "
					+ finalJobStatus
					
					+ " <br><br><br>Regards," + "<br><br> <br>Team CBE",
					"text/html; charset=utf-8");

			Multipart multipart = new MimeMultipart();
			
			StringBuffer messageText = new StringBuffer();
			
			//DEV
			 messageText.append("BEGIN:VCALENDAR\n" +
			 			"ATTENDEE;ROLE=REQ-PARTICIPANT;RSVP=TRUE:MAILTO:manikandan.bk@capgemini.com\n" +
		             "PRODID:-//Microsoft Corporation//Outlook 9.0 MIMEDIR//EN\n" +
		             "VERSION:2.0\n" +
		             "METHOD:REQUEST\n" +
		                 "BEGIN:VEVENT\n" +
		                 "ORGANIZER:MAILTO:dactoolssupport.in@capgemini.com" ) ;
			 messageText.append( "\n" +
			                     "DTSTART:");
			 messageText.append(lcl.format(dateFormat) ) ;
			
			 
//			 messageText.append("\n" +"RRULE:" ) ;
//			 messageText.append(rrule);
		     
			 
			 //messageText.append( start  ) ;
			 messageText.append( "\n" +"DTEND:" ) ;
			 messageText.append( ( start.toLocalTime().compareTo(end.toLocalTime()) >= 0 ? lcl.plusHours(1) : LocalDateTime.of(lcl.toLocalDate(),end.toLocalTime()) ).format(dateFormat) ) ;
			 
			 //added status
			 messageText.append("\n" +"STATUS:" ) ;
			 messageText.append("CONFIRMED");
			 messageText.append("\n" +"DESCRIPTION:" ) ;
			 messageText.append("Event Name: " + event.getEventName() + "\\r\\nEvent Description: " + event.getEventDesc()+"\\r\\nReminder From,\\r\\nDAC TOOLs.");
			 messageText.append("\n" +"SUMMARY:" ) ;
			 messageText.append(event.getEventName());
			 
			 //messageText.append( end ) ;
//			 messageText.append( "\n" +"LOCATION:" ) ;
//			 messageText.append( location ) ;
			 messageText.append( "\n" +"UID:" ) ;
			 messageText.append(event.getEventID()+lcl.toLocalDate().toEpochDay()+"cbe@dactools") ;
			 
			 messageText.append( "\n" +"DTSTAMP:" ) ;
			 messageText.append( currD.format(dateFormat) ) ;
			 
			 //messageText.append( new java.util.Date()) ;
			 messageText.append( "\n" +
			                             "BEGIN:VALARM\n" +
			                             "TRIGGER:-PT15M\n" +
			                             "ACTION:DISPLAY\n" +
			                             "DESCRIPTION:Reminder\n" +
			                             "SUMMARY:"+event.getEventName()+"\n" +
			                             "END:VALARM\n" +
			                        "END:VEVENT\n" +
			                    "END:VCALENDAR"
			                    ) ;

			
			 BodyPart messageBodyPartCal = new MimeBodyPart();
			// Fill the message
		     messageBodyPartCal.setHeader("Content-Class", "urn:content-  classes:calendarmessage");
		     messageBodyPartCal.setHeader("Content-ID", "calendar_message");
		     messageBodyPartCal.setDataHandler(new DataHandler(
		             new ByteArrayDataSource(messageText.toString(), "text/calendar")));// very important

		     multipart.addBodyPart(messageBodyPartCal);
		    multipart.addBodyPart(messageBodyPart);   
		    
		    
		  /*if (null != event.getAttachment() && !event.getAttachment().isEmpty()) 
		   {*/  
			 //File file = new File(props.getProperty("filePath")+File.separator +event.getAttachment());	
			 String attachmentFileName = "D:\\CBE_Report_Service\\files\\EventDetail_Actuals_"+event.getEventID()+".xlsx";
			 File file1 = new File(attachmentFileName);	
			 String displayFileName = event.getEventID()+".xlsx";
			// LOGGER.info("filepath : "+file.getAbsolutePath());
			 //addAttachment(multipart, props.getProperty("filePath")+File.separator +event.getAttachment());
			 addAttachment(multipart, attachmentFileName,displayFileName);
			    /*if(file.exists()) {
			    	MimeBodyPart messageBodyPart2 = new MimeBodyPart(); 
					DataSource source1 = new FileDataSource(file); 
					messageBodyPart2.setDataHandler(new DataHandler(source1)); 
					messageBodyPart2.setFileName(event.getAttachment()); 
					multipart.addBodyPart( messageBodyPart2);
			    }
			    if(file1.exists()) {
			    	LOGGER.info("************************Attachment Part : ******************"+file1.getAbsolutePath());
			    	MimeBodyPart messageBodyPart3 = new MimeBodyPart(); 
					DataSource source2 = new FileDataSource(file1); 
					messageBodyPart3.setDataHandler(new DataHandler(source2)); 
					messageBodyPart3.setFileName(attachmentFileName); 
					multipart.addBodyPart( messageBodyPart3);
			    }*/
			 
		 //  }
		   
			 
			message.setContent(multipart);

			Transport.send(message);
			//LOGGER.info("Mail has been sent with this message:" +message);
		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}

	}
	
	
	private static void addAttachment(Multipart multipart, String filename, String displayFileName) throws MessagingException
	{
		//LOGGER.info("************************Attachment Part : ******************"+filename);
	    DataSource source = new FileDataSource(filename);
	    BodyPart messageBodyPart = new MimeBodyPart();        
	    messageBodyPart.setDataHandler(new DataHandler(source));
	    messageBodyPart.setFileName(displayFileName);
	    multipart.addBodyPart(messageBodyPart);
	}
	
private static List<LocalDateTime> getWeekRecur(EventEntry event, LocalDateTime startlcl, LocalDateTime endlcl, String plannedEndTime, int max_day){
		
		String recurWeekDay = !isEmpty(event.getRecurrenceDayName()) ?event.getRecurrenceDayName().replace("MO", "2").replace("TU", "3").replace("WE", "4").replace("TH", "5").replace("FR", "6").replace("SA", "7").replace("SU", "1") : "";
		Calendar cal = Calendar.getInstance();
		Calendar calEnd = Calendar.getInstance();
		Date st = new Date(startlcl.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());
		Date end = new Date(endlcl.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());
		int recurWeek = !isEmpty(event.getRecuEveryWeek()) ? Integer.parseInt(event.getRecuEveryWeek()) : 1;
		List<LocalDateTime> lstDateTime = new ArrayList<LocalDateTime>();
		lstDateTime.add(LocalDateTime.ofInstant(cal.toInstant(), cal.getTimeZone().toZoneId()).plusDays(max_day-1));
		for(String s : recurWeekDay.split(",")){
			cal.setTimeInMillis(st.getTime());
			sendEndTime(plannedEndTime, cal);
			calEnd.setTimeInMillis(end.getTime());			
			int weekDay = !isEmpty(s) ? Integer.parseInt(s) : 0;
		if(cal.get(Calendar.DAY_OF_WEEK)==weekDay-1) {
			lstDateTime.add(LocalDateTime.ofInstant(cal.toInstant(), cal.getTimeZone().toZoneId()).plusDays(max_day-1));			
		}
		cal.add(Calendar.WEEK_OF_YEAR, recurWeek);
		cal.set(Calendar.DAY_OF_WEEK, weekDay-1);			
		while(calEnd.getTimeInMillis()>cal.getTimeInMillis()){
			lstDateTime.add(LocalDateTime.ofInstant(cal.toInstant(), cal.getTimeZone().toZoneId()).plusDays(max_day-1));
			cal.add(Calendar.WEEK_OF_YEAR, recurWeek);
			cal.set(Calendar.DAY_OF_WEEK, weekDay-1);			
			
		}
		}
		
		List<LocalDateTime> lst = new ArrayList<LocalDateTime>();
		lst.add(LocalDateTime.ofInstant(cal.toInstant(), cal.getTimeZone().toZoneId()).plusDays(0));
		
		return lst;
	}
private static void sendEndTime(String plannedEndTime, Calendar cal) {
	int hour = 0;
	int minute = 0;
	
	if(!StringUtils.isNullOrEmpty(plannedEndTime)){
		if(plannedEndTime.split(":").length > 0 && !StringUtils.isNullOrEmpty(plannedEndTime.split(":")[0]) && !StringUtils.isNullOrEmpty(plannedEndTime.split(":")[1])){
			hour = Integer.parseInt(plannedEndTime.split(":")[0]);
			minute = Integer.parseInt(plannedEndTime.split(":")[1]);
		}
	}
	
	cal.set(Calendar.HOUR_OF_DAY, hour);
	cal.set(Calendar.MINUTE, minute);
}
	private static List<LocalDateTime> getMonthRecur(EventEntry event, LocalDateTime startlcl, LocalDateTime endlcl) throws ParseException {
		
		Calendar cal = Calendar.getInstance();
		Calendar calEnd = Calendar.getInstance();
		Date st = new Date(startlcl.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());
		Date end = new Date(endlcl.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());
		cal.setTimeInMillis(st.getTime());
		calEnd.setTimeInMillis(end.getTime());
		List<LocalDateTime> lstDateTime = new ArrayList<LocalDateTime>();
		
		if("2".equalsIgnoreCase(event.getRecuMonthDayRadio())) {
			

			int recurWeek = !isEmpty(event.getMonthdd1()) ? Integer.parseInt(event.getMonthdd1()) : 1;
			int weekday = !isEmpty(event.getMonthdd2()) ? Integer.parseInt(event.getMonthdd2()) : 1;
			int recurMonth = !isEmpty(event.getMonthtext1()) ? Integer.parseInt(event.getMonthtext1()) : 1;
			
		if(weekday == cal.get(Calendar.DAY_OF_WEEK)) {
			recurWeek = recurWeek < 5 ? recurWeek : getLastWeekday(weekday,cal);
			cal.set(Calendar.WEEK_OF_MONTH, recurWeek);
		}else if(weekday < cal.get(Calendar.DAY_OF_WEEK)){
			recurWeek = recurWeek < 5 ? recurWeek+1 : getLastWeekday(weekday,cal);			
			cal.set(Calendar.DAY_OF_WEEK, weekday);
			cal.set(Calendar.WEEK_OF_MONTH, recurWeek);
		}else if(weekday <= Calendar.SATURDAY){
			recurWeek = recurWeek < 5 ? recurWeek : getLastWeekday(weekday,cal);			
			cal.set(Calendar.DAY_OF_WEEK, weekday);
			cal.set(Calendar.WEEK_OF_MONTH, recurWeek);			
		}else if(weekday == 9){			
				cal.set(Calendar.DAY_OF_MONTH, getNthWeekDay(recurWeek,cal));			
		}else if(weekday == 8){			
			cal.set(Calendar.DAY_OF_MONTH, getNthWeekEndDay(recurWeek,cal));			
		}
		//cal.add(Calendar.MONTH, recurMonth);
		while(calEnd.getTimeInMillis()>cal.getTimeInMillis()){
			
			lstDateTime.add(LocalDateTime.ofInstant(cal.toInstant(), cal.getTimeZone().toZoneId()));
			
			cal.add(Calendar.MONTH, recurMonth);
			if(weekday == cal.get(Calendar.DAY_OF_WEEK)) {
				recurWeek = recurWeek < 5 ? recurWeek : getLastWeekday(weekday,cal);
				cal.set(Calendar.WEEK_OF_MONTH, recurWeek);
			}else if(weekday < cal.get(Calendar.DAY_OF_WEEK)){
				recurWeek = recurWeek < 5 ? recurWeek+1 : getLastWeekday(weekday,cal);				
				cal.set(Calendar.DAY_OF_WEEK, weekday);
				cal.set(Calendar.WEEK_OF_MONTH, recurWeek);
			}else if(weekday <= Calendar.SATURDAY){
				recurWeek = recurWeek < 5 ? recurWeek : getLastWeekday(weekday,cal);			
				cal.set(Calendar.DAY_OF_WEEK, weekday);
				cal.set(Calendar.WEEK_OF_MONTH, recurWeek);			
			}else if(weekday == 9){			
					cal.set(Calendar.DAY_OF_MONTH, getNthWeekDay(recurWeek,cal));			
			}else if(weekday == 8){			
				cal.set(Calendar.DAY_OF_MONTH, getNthWeekEndDay(recurWeek,cal));			
			}
						
		}
		
			
		}else {

			int monthDay = !isEmpty(event.getRecuMonthDay()) ? Integer.parseInt(event.getRecuMonthDay()) : 1;
			int recurMonth = !isEmpty(event.getRecuEveryMonth()) ? Integer.parseInt(event.getRecuEveryMonth()) : 1;
		if(cal.get(Calendar.DAY_OF_MONTH)==monthDay) {
			lstDateTime.add(LocalDateTime.ofInstant(cal.toInstant(), cal.getTimeZone().toZoneId()));
				
		}
		cal.add(Calendar.MONTH, recurMonth);
		cal.set(Calendar.DAY_OF_MONTH, monthDay);
		while(calEnd.getTimeInMillis()>cal.getTimeInMillis()){
			lstDateTime.add(LocalDateTime.ofInstant(cal.toInstant(), cal.getTimeZone().toZoneId()));
			cal.add(Calendar.MONTH, recurMonth);
			cal.set(Calendar.DAY_OF_MONTH, monthDay);			
						
		}
		
		}
		return lstDateTime;
		
	}

	private static int getNthWeekEndDay(int recurWeek, Calendar cal3) {
		Calendar cal2 = (Calendar) cal3.clone();
		   cal2.set( Calendar.DAY_OF_MONTH, 1);
		   if(recurWeek<5) {
			   int cnt=1;
			   while ((cal2.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY
			           && cal2.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) || cnt<recurWeek){				   
			       if((cal2.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY
				           || cal2.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY)) {
			    	   cnt++;
			       }
			         cal2.add(Calendar.DATE, 1);			       
			   } 		   	       
		   }else {
			   cal2.add( Calendar.MONTH, 1);
			   do{
			       cal2.add(Calendar.DATE, -1);			       
			   } while (cal2.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY
			           && cal2.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY );
		   
			}
		   return cal2.get(Calendar.DAY_OF_MONTH);
		   }

	private static int getNthWeekDay(int recurWeek, Calendar cal3) {
		Calendar cal2 = (Calendar) cal3.clone();
	   cal2.set( Calendar.DAY_OF_MONTH, 1);
	   if(recurWeek<21) {
		   int cnt=1;
		   
		   while ((cal2.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY
	           || cal2.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) || cnt<recurWeek){
			   if((cal2.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY
			           && cal2.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY)) {
		    	   cnt++;
			   }
			   cal2.add(Calendar.DATE, 1);			       
	   } 
	   }else {
		   cal2.add( Calendar.MONTH, 1);
		   do{
			   cal2.add(Calendar.DATE, -1);
		       
		   } while (cal2.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY
		           || cal2.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY );
		}
	   return cal2.get(Calendar.DAY_OF_MONTH);
	   }

	private static int getLastWeekday(int weekday, Calendar cal2) {
		   Calendar cal = (Calendar) cal2.clone();
		   cal.add( Calendar.MONTH, 1);
		   cal.set(Calendar.DAY_OF_MONTH, 1);
		   cal.add( Calendar.DAY_OF_MONTH, -(( cal.get( Calendar.DAY_OF_WEEK ) % 7 + (7-weekday) )%7) );
		   return cal.get(Calendar.WEEK_OF_MONTH);
		}
	public static boolean isEmpty(Object str) {
		return (str == null || "".equals(str));
	}
	
	public String sendMail(String messagetobesent)
	   {

//		  String to="sravani.vennapusa@capgemini.com";
String to= "manikandan.bk@capgemini.com";
		 // String cc="kavitha.a.m@capgemini.com";
	      String from="natools_ikon.in@capgemini.com";
	      String messagesent=null;
	      String host="ismtp.corp.capgemini.com";
	      String subject="test mail";
	      String account="testing";
	     /* to = property.getProperty("to");
		  from = property.getProperty("from");
		  host = property.getProperty("host");
		  cc = property.getProperty("cc");
		  account=property.getProperty("account");	*/ 
			
			

 
	      Properties properties = System.getProperties();
	      
	      properties.put("mail.smtp.starttls.enable", "true");
	      properties.put("mail.smtp.host", "ismtp.corp.capgemini.com");
	      properties.put("mail.smtp.user", "anima.prasad@capgemini.com");
	      properties.put("mail.smtp.port", "25");
	      properties.put("mail.smtp.auth", "false");
	      properties.put("mail.smtp.starttls.enable","false");
	      // Setup mail server
	      properties.setProperty("mail.smtp.host", "ismtp.corp.capgemini.com");
 
 
 
/*// properties.put("mail.smtp.starttls.enable", "true");
 properties.put("mail.smtp.host", host);
 properties.put("mail.smtp.user", from);
 properties.put("mail.smtp.port", "25");
 //properties.put("mail.smtp.auth", "false");
 properties.put("mail.smtp.starttls.enable","true");
 // Setup mail server
 properties.setProperty("mail.smtp.host", host);*/
 Session session = Session.getInstance(properties);

 try{
	 subject="IKON Feed File of "+account +" is not processed"; 
   MimeMessage message = new MimeMessage(session);
   message.setFrom(new InternetAddress(from));
    // Set To: header field of the header.
    message.addRecipient(Message.RecipientType.TO,
          new InternetAddress(to));
    /*message.addRecipient(Message.RecipientType.CC,
           new InternetAddress(cc));*/
    // Set Subject: header field
    message.setSubject(subject);
   StringBuffer sb= new StringBuffer();
   sb.append("Hi Team,");
		sb.append("<br/>");
		sb.append("<br/>");
		
		sb.append("<html>");	
		sb.append("<body>");
		sb.append("Feed file is processed");
		sb.append("<br/>");
		sb.append("<br/>");
		sb.append("Thanks,<br/>IKON Team</body>");
		sb.append("</html>");
    String contentType = "text/html";
    
    MimeBodyPart messageBodyPart =    new MimeBodyPart();
    messageBodyPart.setContent(sb.toString(), "text/html"); 
    Multipart multipart = new MimeMultipart();
		 
	     multipart.addBodyPart(messageBodyPart);
    message.setContent(multipart);
    // Send message
    System.out.println("message-->");
    Transport.send(message);
 System.out.println("Sent message successfully.................");
 messagesent="Sent message successfully";
 
}
catch (MessagingException mex) 
{
	//mylogger.error("mex--->"+mex.toString());
   mex.printStackTrace();
   messagesent="Message not sent";
}

 return "";
	   }
	
	
}
