var randomScalingFactor = function() {
			return Math.round(Math.random() * 100);
		};
		
var config = {
	type: 'line',
	data: {
		labels: [' ', 'CP 1', 'CP 2', 'CP 3', 'CP 4', 'CP 5', 'CP 6', 'CP 7', 'CP 8', 'CP 9','CP 10'],
		datasets: [{
		
			label: 'Planned',
			fill: false,
			//backgroundColor: window.chartColors.blue,
			backgroundColor: '#fff',
			borderColor: '#0070ad',
							
			data: [,{
				y: new Date("2020-09-22 3:59")
			}, {
				y: new Date("2020-09-22 14:30")
			},
			{
				y: new Date("2020-09-23 22:30")
			}]
			
		}]
	},
	
	options: {
		responsive: true,
		
		title: {
			display: true,
			text: 'EVENT PROGRESS'
		},			
						
		scales: {
		
			yAxes: [
			  {
				scaleLabel: {
					fontColor:"#0070ad", 
					fontSize:12,
					fontFamily:'Ubuntu',
					display: true,
					labelString: '22 \t Sep \t 2020 \t\t\t\t\t\t\t\t\t\t\t 23\t Sep \t 2020' //'20th Sept 2020 \t\t\t\t\t\t\t\t\t\t\t  21st Sept 2020'
				},
				type: 'linear',
				position: 'left',
				ticks: {
					fontColor: "#0070ad",
				  min: moment('2020-09-22 00:00:00').valueOf(), //job start date 
				  max: moment('2020-09-23 23:59:59').valueOf(), //job end date
				  //stepSize: 3.6e+6,
				  stepSize: (3.6e+6)*4,
				  beginAtZero: false,
				  callback: value => {
					let date = moment(value);
					
				/*if(date.diff(moment('2020-09-22 23:59:59'), 'minutes') === 0) {  //current date
					  return null;
					}  */
					
					return date.format('H:mm'); //date.format('Do MMM YYYY H:mm');
				  }
				}
			  }
			],
			
			
			xAxes: [{
			ticks: {
				fontColor: "#0070ad",
				display:true,
				fontSize: 12,
				fontFamily:'Ubuntu'
				//stepSize: 1,
				//beginAtZero: true
			}
			}]
			
			
		}			
	}
};

window.onload = function() {
	var ctx = document.getElementById('canvas').getContext('2d');
	window.myLine = new Chart(ctx, config);
	
};